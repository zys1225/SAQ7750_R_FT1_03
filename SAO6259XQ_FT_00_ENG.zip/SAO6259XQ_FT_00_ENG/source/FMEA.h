/*****************************************************************************
*                                                                            *
*       Source title:   FMEA.h									           *
*                       (Universal functions for all SC test projects)       *
*         Written by:   Sky Fu                                                *
*        Description:			                                             *
*                                                                            *
*   Revision History:                                                        *
*                                                                            *
*     mm/dd/yy  r.rr  - Original coding.                                     *
*                                                                            *
*****************************************************************************/

/*
REVISION BLOCK:
-Rev. -- Date --------------------------------------------------
00   6/7/21  Initial.						Sky Fu

----------------------------------------------------------------
*/

#pragma once
#include <conio.h>
#include "stdafx.h"
#define MAX_SITES 32

class eFMEA {
public:
	eFMEA();
	~eFMEA();
	int sot();
	int eot();
	void fmea_checking(short func_index_fmea);
	void fmea_onfailsite();
	void FMEA_Site_Set(DWORD siteID);
	void force_item_fail(short func, int site);

	int fmea_sites;
	int force_failed_item;
	int reinitflag;
	int curr_site;
	int flag;
	int fmea_enable;

private:
	int valid_site[MAX_SITES];
	int fmea_items_count[MAX_SITES];
	int test_item_count;
	int eot_site_count;

	short func_index_forcefail;//��¼ǿ��fail func
	int site_forcefail;//��¼ǿ��fail site
	int flag_forcefail;//��¼ǿ��fail flag

	string int2str(DWORD n);
	int TXT_OPEN_FLAG;
	short current_func[MAX_SITES];//��¼��ǰ���е��ĸ�func


};

