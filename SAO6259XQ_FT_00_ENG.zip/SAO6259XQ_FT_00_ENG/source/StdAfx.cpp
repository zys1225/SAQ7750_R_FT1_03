// stdafx.cpp : source file that includes just the standard includes
//	DUT.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
GLOBAL int g_x_coords[SITE_NUM] = { -9999 }, g_y_coords[SITE_NUM] = { -9999 };
GLOBAL char waferid[64];
/*
 Site mapping "_" => skip die
 X -------------->
 Y	1,2,3,4
 |	5,6,7,8
 |	9,10,11,12
 |	13,14,15,16
 V

*/

GLOBAL int G_GetXYCoordinate()
{
	int rt;
	rt=StsGetSingleDieCorXY(0, g_x_coords[0], g_y_coords[0]);

	for (int site = 0; site<SITE_NUM; site++)
	{
		g_x_coords[0] = g_x_coords[0];//site1
		g_y_coords[0] = g_y_coords[0];

		g_x_coords[1] = g_x_coords[0] + 1;//site2
		g_y_coords[1] = g_y_coords[0] ;
		g_x_coords[2] = g_x_coords[0] + 2;
		g_y_coords[2] = g_y_coords[0] ;
		g_x_coords[3] = g_x_coords[0] + 3;
		g_y_coords[3] = g_y_coords[0] ;

		g_x_coords[4] = g_x_coords[0] ;
		g_y_coords[4] = g_y_coords[0] + 1;
		g_x_coords[5] = g_x_coords[0] + 1;
		g_y_coords[5] = g_y_coords[0] + 1;
		g_x_coords[6] = g_x_coords[0] + 2;
		g_y_coords[6] = g_y_coords[0] + 1;
		g_x_coords[7] = g_x_coords[0] + 3;
		g_y_coords[7] = g_y_coords[0] + 1;

		g_x_coords[8] = g_x_coords[0];
		g_y_coords[8] = g_y_coords[0] + 2;
		g_x_coords[9] = g_x_coords[0] + 1;
		g_y_coords[9] = g_y_coords[0] + 2;
		g_x_coords[10] = g_x_coords[0] + 2;
		g_y_coords[10] = g_y_coords[0] + 2;
		g_x_coords[11] = g_x_coords[0] + 3;
		g_y_coords[11] = g_y_coords[0] + 2;

		g_x_coords[12] = g_x_coords[0];
		g_y_coords[12] = g_y_coords[0] + 3;
		g_x_coords[13] = g_x_coords[0] + 1;
		g_y_coords[13] = g_y_coords[0] + 3;
		g_x_coords[14] = g_x_coords[0] + 2;
		g_y_coords[14] = g_y_coords[0] + 3;
		g_x_coords[15] = g_x_coords[0] + 3;
		g_y_coords[15] = g_y_coords[0] + 3;
		StsSetDieCorXY(site, g_x_coords[site], g_y_coords[site]);
	}
	return rt;
}
GLOBAL BYTE cbitclose(BYTE k1, BYTE k2 , BYTE k3 , BYTE k4 , BYTE k5 , BYTE k6 , BYTE k7 , BYTE k8 , BYTE k9 , BYTE k10 ,
BYTE k11 , BYTE k12 , BYTE k13 , BYTE k14 , BYTE k15 , BYTE k16 , BYTE k17 , BYTE k18 , BYTE k19 , BYTE k20 ,
BYTE k21 , BYTE k22 , BYTE k23 , BYTE k24 , BYTE k25 , BYTE k26 , BYTE k27 , BYTE k28 , BYTE k29 , BYTE k30 ,
BYTE k31 , BYTE k32 , BYTE k33 , BYTE k34 , BYTE k35 , BYTE k36 , BYTE k37 , BYTE k38 , BYTE k39 , BYTE k40 ,
BYTE k41 , BYTE k42 , BYTE k43 , BYTE k44 , BYTE k45 , BYTE k46 , BYTE k47 , BYTE k48 , BYTE k49 , BYTE k50 ,
BYTE k51 , BYTE k52 , BYTE k53 , BYTE k54 , BYTE k55 , BYTE k56 , BYTE k57 , BYTE k58 , BYTE k59 , BYTE k60 ,
BYTE k61 , BYTE k62 , BYTE k63 , BYTE k64 , BYTE k65 , BYTE k66 , BYTE k67 , BYTE k68 , BYTE k69 , BYTE k70 ,
BYTE k71 , BYTE k72 , BYTE k73 , BYTE k74 , BYTE k75 , BYTE k76 , BYTE k77 , BYTE k78 , BYTE k79 , BYTE k80 ,
BYTE k81 , BYTE k82 , BYTE k83 , BYTE k84 , BYTE k85 , BYTE k86 , BYTE k87 , BYTE k88 , BYTE k89 , BYTE k90 ,
BYTE k91 , BYTE k92 , BYTE k93 , BYTE k94 , BYTE k95 , BYTE k96 , BYTE k97 , BYTE k98 , BYTE k99 , BYTE k100 ,
BYTE k101 , BYTE k102 , BYTE k103 , BYTE k104 , BYTE k105 , BYTE k106 , BYTE k107 , BYTE k108 , BYTE k109 , BYTE k110 ,
BYTE k111 , BYTE k112 , BYTE k113 , BYTE k114 , BYTE k115 , BYTE k116 , BYTE k117 , BYTE k118 , BYTE k119 , BYTE k120 ,
BYTE k121 , BYTE k122 , BYTE k123 , BYTE k124 , BYTE k125 , BYTE k126 , BYTE k127 , BYTE k128 )
{
	BYTE relay = 0;
	va_list p;

	va_start(p, k1);//֧��128��
	relay = k1;
	if (relay == 255) return -1;
	for (int i = 0; i < 128; i++)
	{
		cbite.SetCbiteOn(relay);
		relay=va_arg(p, BYTE);
		if (relay == 255) break;
	}
			 
	va_end(p);                 
	return 0;            

}


GLOBAL BYTE cbitopen(BYTE k1, BYTE k2, BYTE k3, BYTE k4, BYTE k5, BYTE k6, BYTE k7, BYTE k8, BYTE k9, BYTE k10,
	BYTE k11, BYTE k12, BYTE k13, BYTE k14, BYTE k15, BYTE k16, BYTE k17, BYTE k18, BYTE k19, BYTE k20,
	BYTE k21, BYTE k22, BYTE k23, BYTE k24, BYTE k25, BYTE k26, BYTE k27, BYTE k28, BYTE k29, BYTE k30,
	BYTE k31, BYTE k32, BYTE k33, BYTE k34, BYTE k35, BYTE k36, BYTE k37, BYTE k38, BYTE k39, BYTE k40,
	BYTE k41, BYTE k42, BYTE k43, BYTE k44, BYTE k45, BYTE k46, BYTE k47, BYTE k48, BYTE k49, BYTE k50,
	BYTE k51, BYTE k52, BYTE k53, BYTE k54, BYTE k55, BYTE k56, BYTE k57, BYTE k58, BYTE k59, BYTE k60,
	BYTE k61, BYTE k62, BYTE k63, BYTE k64, BYTE k65, BYTE k66, BYTE k67, BYTE k68, BYTE k69, BYTE k70,
	BYTE k71, BYTE k72, BYTE k73, BYTE k74, BYTE k75, BYTE k76, BYTE k77, BYTE k78, BYTE k79, BYTE k80,
	BYTE k81, BYTE k82, BYTE k83, BYTE k84, BYTE k85, BYTE k86, BYTE k87, BYTE k88, BYTE k89, BYTE k90,
	BYTE k91, BYTE k92, BYTE k93, BYTE k94, BYTE k95, BYTE k96, BYTE k97, BYTE k98, BYTE k99, BYTE k100,
	BYTE k101, BYTE k102, BYTE k103, BYTE k104, BYTE k105, BYTE k106, BYTE k107, BYTE k108, BYTE k109, BYTE k110,
	BYTE k111, BYTE k112, BYTE k113, BYTE k114, BYTE k115, BYTE k116, BYTE k117, BYTE k118, BYTE k119, BYTE k120,
	BYTE k121, BYTE k122, BYTE k123, BYTE k124, BYTE k125, BYTE k126, BYTE k127, BYTE k128)
{
	BYTE relay = 0;
	va_list p;

	va_start(p, k1);//֧��128��
	relay = k1;
	if (relay == 255) return -1;
	for (int i = 0; i < 128; i++)
	{
		cbite.SetCbiteOff(relay);
		relay = va_arg(p, BYTE);
		if (relay == 255) break;
	}

	va_end(p);
	return 0;

}

int I2C_ADDR_DEVICE = 0x20 << 1;
int I2C_ADDR_DEVICE_FS = 0x21 << 1;