
/*****************************************************************************
*                                                                            *
*       Source title:   I2C.h                                                *
*                       (Universal functions for all SC test projects)       *
*         Written by:   Sky Fu                                               *
*        Description:			                                             *
*                                                                            *
*   Revision History:                                                        *
*                                                                            *
*     mm/dd/yy  r.rr  - Original coding.                                     *
*                                                                            *
*****************************************************************************/

/*
REVISION BLOCK:
-Rev. -- Date --------------------------------------------------
00   12/1/20  Initial.						Sky Fu

----------------------------------------------------------------
*/

void I2CWrite(DWORD bySAddress, DWORD dwRegAddress, DWORD dwDataArray[], int runVector=1);//1byte or defined?
void I2CWrite(DWORD bySAddress, DWORD dwRegAddress, int nDataLength, DWORD dwDataArray[]);// more byte, pending
void I2CConnectSetup(int connect = 1, double SDA_Vih = 3.0, double SDA_Vil = 0.0, double SDA_Voh = 1.5, double SDA_Vol = 1.0, double SCL_Vih = 3.0, double SCL_Vil = 0.0);
void I2CRead(DWORD bySAddress, DWORD dwRegAddress, DWORD readData[]);//1 byte read
void I2CRead(DWORD bySAddress, DWORD dwRegAddress, DWORD *readData, int nDataCount);//more bytes read, pending
