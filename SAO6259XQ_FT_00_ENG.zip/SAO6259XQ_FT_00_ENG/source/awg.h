/*****************************************************************************
*                                                                            *
*       Source title:   awg.h									           *
*                       (Universal functions for all SC test projects)       *
*         Written by:   Sky Fu                                                *
*        Description:			                                             *
*                                                                            *
*   Revision History:                                                        *
*                                                                            *
*     mm/dd/yy  r.rr  - Original coding.                                     *
*                                                                            *
*****************************************************************************/

/*
 REVISION BLOCK:
 -Rev. -- Date --------------------------------------------------
   00   12/1/20  Initial.						Sky Fu

----------------------------------------------------------------
*/

#pragma once
#include "stdafx.h"
#define MAX_SAMPLES 4096

struct AWG_PATTERN
{
	int id;
	double startvalue;
	double stopvalue;
	double stepvalue;
	double samplecount;
	vector<UINT> resource;
	string pattern_name;


};
struct RES_PATTERN
{
	double samplecount;
	int reload_needed;
	UINT resource;
	vector<string> pattern_name;



};
class AWG_FUNC {
public:
	AWG_FUNC();
	~AWG_FUNC();
	void awgReload();
	void StartLoad();
	void Check();
	bool res_pattern_reload_check(UINT resource, char *patname=NULL);//only valid for pattern loaded done, over 4096 return true.
	void EndLoad();
	int res_reload_check(UINT resource);
	bool pattern_unloaded(char *patname);
	DWORD delaytime;
	double twait[8];//for different grp waiting time
	vector <AWG_PATTERN> pattern_store;
	vector <RES_PATTERN> res_store;

	// Good for UVLO, threshold, power good measurement
	// fovi_cap no current loading
	BOOL rampi(FPVIe *fpvi_ramp, FPVIe_VRNG v_range, FPVIe_IRNG i_range, FOVIe fovi_cap, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue=0, double awgStopValue=0);
	BOOL rampv(FOVIe fovi_ramp, FOVIe fovi_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv(FOVIe fovi_ramp1, FOVIe fovi_ramp2, FOVIe fovi_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue=0, double awgStopValue=0);
	BOOL rampv2(FOVIe fovi_ramp1, FOVIe fovi_ramp2, FOVIe fovi_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result1, double *result2, double awgStartValue=0, double awgStopValue=0);
	BOOL rampv_cap_neg(FOVIe fovi_ramp1, FOVIe fovi_ramp2, FOVIe fovi_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue=0, double awgStopValue=0);
	BOOL rampvmi(FOVIe *fovi_ramp, ACM *acm_ramp, char* reg_str, double *scanStartValue, double *scanStopValue, int *sizeofparameter, FOVIe_VRNG *v_range = NULL, FOVIe_IRNG *i_range = NULL, ACM_IRNG *acm_i_range = NULL, int measure_enable = 0, int backToStart_enable=0, double ramptime = 8.0, double waittime = 0.0, double results[][SITE_NUM] = NULL);
	BOOL rampi(FOVIe fovi_ramp, FOVIe_VRNG vrange1, FOVIe_IRNG irange1, double scanStartValue1, double scanStopValue1, FPVIe fpvi_ramp1, FPVIe fpvi_ramp2, FPVIe fpvi_ramp3, FPVIe fpvi_ramp4, FPVIe_VRNG v_range, FPVIe_IRNG i_range, ACM acm_cap, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, int group = 0, double awgStartValue = 0, double awgStopValue = 0, int waitForChargeEnable = 1);
	BOOL rampi(FPVIe fpvi_ramp1, FPVIe fpvi_ramp2, FPVIe fpvi_ramp3, FPVIe fpvi_ramp4, FPVIe_VRNG v_range, FPVIe_IRNG i_range, ACM acm_cap, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv(FOVIe fovi_ramp, ACM acm_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv(FOVIe fovi_ramp1, FOVIe fovi_ramp2, ACM acm_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampi(ACM acm_ramp, ACM acm_cap, ACM_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv(ACM acm_ramp, ACM acm_cap, ACM_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv(ACM acm_ramp1, ACM acm_ramp2, ACM acm_cap, ACM_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);

	BOOL rampv2(FOVIe fovi_ramp1, FOVIe fovi_ramp2, ACM fovi_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result1, double *result2, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv2(FOVIe fovi_ramp1, FOVIe fovi_ramp2, ACM fovi_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue,double M1_Value,double M2_Value, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result1, double *result2, double awgStartValue = 0, double awgStopValue = 0);

	BOOL rampv(FPVIe fpvi_ramp, int grp, FPVIe_VRNG v_range, FPVIe_IRNG i_range, ACM acm_cap, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue=0, double awgStopValue=0);
	BOOL rampv2mi(FPVIe fpvi_ramp, ACM acm_cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv2mi(FPVIe fpvi_ramp, FXVIe_PLUS fxvi_cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);

	BOOL rampimi(FPVIe fpvi_ramp, FPVIe_VRNG v_range, FPVIe_IRNG i_range, ACM acm_cap, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0, int resetToZero = 0);
	BOOL rampv(FOVIe fovi_ramp, ACM acm_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double *result1, double *result2, int smooth_point_size = 5);
	BOOL rampvmi(FOVIe fovi_ramp, FOVIe_VRNG v_range, FOVIe_IRNG i_range, ACM acm_cap, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampvmi(FOVIe fovi_ramp, ACM acm_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double *result1, double *result2, int smooth_point_size = 5);
	BOOL rampvmi2(ACM acm_ramp, ACM acm_cap, ACM_IRNG i_range, char* reg_str, char* reg_str2, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double *result1, double *result2, int smooth_point_size = 5);
	
	BOOL rampv(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv(FXVIe_PLUS fxvi_ramp, ACM200 acm200_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv(ACM200 acm200_ramp, ACM200 acm200_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv(ACM200 acm200_ramp, FXVIe_PLUS fxvi_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampv(FPVIe fpvi_ramp, FXVIe_PLUS fxvi_cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampi(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampss(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, int count, int interval, double trig_level1, double trig_level2, TRIG_MODE trig_mode, double *result);
	BOOL rampi(FPVIe fpvi_ramp, FXVIe_PLUS fxvi_cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampi2(FXVIe_PLUS fpxi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double* result1, double* result2, int smooth_point_size = 5);

	BOOL rampv2(ACM200 acm200_ramp, FXVIe_PLUS fxvi_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double *result1, double *result2, int smooth_point_size = 5);
	BOOL rampv2(FXVIe_PLUS fxvi_ramp, ACM200 acm200_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double *result1, double *result2, int smooth_point_size = 5);
	BOOL rampvmi(FXVIe_PLUS fxvi_ramp, ACM200 acm200_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampvmi(ACM200 acm200_ramp, ACM200 acm200_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double* result, double awgStartValue = 0, double awgStopValue = 0);
	BOOL rampmi2(ACM200 acm200_ramp, ACM200 acm200_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double* result1, double* result2, int smooth_point_size = 5);
	BOOL rampvmi(ACM200 acm200_ramp, FXVIe_PLUS fxvi_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double* result, double awgStartValue = 0, double awgStopValue = 0);

	BOOL rampv2(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double* result1, double* result2, int smooth_point_size = 5);
	BOOL rampv2_FO(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double* result1, double* result2, int smooth_point_size = 5);

private:
	AWG_PATTERN temp_pattern;
	RES_PATTERN temp_res;
	double awgPatStart;
	double awgPatStop;

	int scanSampleSize;
	int scanSampleSize1;
	int scanSampleSize2;
	int smooth_size;
	int patSamplesize;
	int startpoint;
	int sts_first_load;//only valid for first time load at release mode
	int id;
	int pat_unload;
	int validsites[SITE_NUM];
	int pat_loadfailed;
	double pat[MAX_SAMPLES];
	double pat2[MAX_SAMPLES];
	double cap[SITE_NUM][MAX_SAMPLES];
};

