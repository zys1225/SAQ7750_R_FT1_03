// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_)
#define AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>
#include <minwindef.h>
#define DUT_API extern "C" __declspec(dllexport)
#include <string>
using namespace std;
#include "usertype.h"
#include "userres.h"
#include "SPEC.h"
#include "treg.h"
#include <fstream>
#include <sstream>
#ifdef _DEBUG
#define DEBUG_MODE 1
#else
#define DEBUG_MODE 0
#endif
#define SITE_NUM 8
#define I2C_ADDRESS 0xC0

typedef unsigned long long DataType;

//#include "BoardCheck.h"
extern DCM dcm;
extern CBITe cbite;
extern TREG dut;
extern SPEC spec;
extern FXVIe_PLUS A0_FIN_DBG_ERR_FCCU1;
extern FXVIe_PLUS A1_FOUT_RSTB_FCCU2;
extern FXVIe_PLUS A2_PGOOD;
extern FXVIe_PLUS A3_INTB;
extern FXVIe_PLUS A4_PSYNC_PREFB;
extern FXVIe_PLUS A5_AMUX;
extern ACM200 VDDIO_VBOOST_0;
extern ACM200 VBOS_1;
extern ACM200 BUCK1IN_2;
extern ACM200 BUCK2IN_3;
extern ACM200 BUCK3IN_4;
extern ACM200 BUCK1SW_5;
extern ACM200 BUCK2SW_6;
extern ACM200 BUCK3SW_BOOSTLS_7;
extern ACM200 PREFB_BUCK1FB_8;
extern ACM200 PRECSP_BUCK2FB_9;
extern ACM200 PRECMP_BUCK3FB_INTB_10;
extern ACM200 VSUP_11;
extern FXVIe_PLUS B0_PRESW_LDO1IN;
extern FXVIe_PLUS B1_PREGHS_PREGLS_LDO1OUT;
extern FXVIe_PLUS B2_PREBOOT_VBOOST;
extern FXVIe_PLUS B3_WAKE12;
extern FXVIe_PLUS B4_VSUP_LDO2OUT;
extern FXVIe_PLUS B5_VMON1234;

extern FPVIe FPVIM;
extern ACM200 BUCK123;
extern ACM200 ALL_ACM;
extern QVMe ALL_QVM;
extern QTMUe ALL_QTMU;

extern QTMUe QTMU23_0;
extern QTMUe QTMU23_1;
extern QTMUe QTMU23_3;
extern QTMUe QTMU23_2;
extern QVMe QVM1_3;
extern QVMe QVM1_2;
extern QVMe QVM1_0;
extern QVMe QVM1_1;

extern FXVIe_PLUS ALL_FXVIE;

extern ACM200 acm_grp[12];
extern FXVIe_PLUS fxvie_grp[6];

extern QVMe qvm_grp[SITE_NUM];
extern QTMUe qtmu_grp[SITE_NUM];
// SERIAL for active site
extern int test_stage;
extern int boardid;
extern int globalsite;
extern BYTE sitesta[SITE_NUM];
extern ULONG ulWriteData[SITE_NUM];
extern int nReadData[SITE_NUM];
extern double g_amux_vos[SITE_NUM];
extern double g_freq_slow[SITE_NUM];
extern double g_freq_fast[SITE_NUM];
extern double g_freq_20MHz[SITE_NUM];
extern double g_rdson_boost[SITE_NUM];
extern double g_rsns_boost[SITE_NUM];
extern double g_rsns_v_boost[SITE_NUM];
extern double g_ilmt_pk_buck1[SITE_NUM];
extern double g_ilmt_pk_buck2[SITE_NUM];
extern double g_ilmt_pk_buck3[SITE_NUM];
extern double g_ilmt_pkmini_buck1[SITE_NUM];
extern double glb_res[SITE_NUM];
extern int I2C_ADDR_DEVICE;
extern int I2C_ADDR_DEVICE_FS;
extern bool DO_CHAR;
extern int dataread[SITE_NUM];
extern int DEBUG;

extern int Clock_24MHZ_Smart_Switch;
#define SITE globalsite
#define SERIAL StsGetSiteStatus(sitesta, SITE_NUM); for(globalsite=0;globalsite<SITE_NUM;globalsite++)  if(sitesta[globalsite])
//#define SERIAL for(globalsite=0;globalsite<SITE_NUM;globalsite++) 
#define SERIAL_ALL for(globalsite=0;globalsite<SITE_NUM;globalsite++) 


#define I2C_TM_EFUSE 0x80
#define I2C_TM_CMD 0x81
#define I2C_TM_DATA1 0x82
#define I2C_TM_DATA2 0x83
#define I2C_TM_DATA3 0x84
#define I2C_TRIM_BANK 0x86
#define START_CHECK 0
#define STOP_CHECK -1
#define FMEA_CHECK_ITEM 1
#define FMEA_SKIP_ITEM 2
#define BANK_NUM 17

#define K0_WAKE2_FXVIB				0
#define K1_WAKE2_DCM				1
#define K2_5V_PU					2//
#define K3_BOOSTLS_ACM				3
#define K4_BUCK3SW_ACM				4
#define K5_DBG_DCM					5//
#define K6_DBG_FXVIA				6
#define K7_BUCK3FB_ACM				7
#define K8_SCL_SDA_DCM				8
#define K9_VMON4_FXVIB				9
#define K10_VMON3_FXVIB				10
#define K11_PRE_SLT					11
#define K12_VMON2_FXVIB				12
#define K13_VMON1_FXVIB				13//
#define K14_VCOREMON_FXVIB			14//
#define K15_PGOOD_FXVIA				15
#define K16_RSTB_FXVIA				16
#define K17_FIN_FXVIA				17
#define K18_FIN_DCM					18
#define K19_AGNDF_DCM				19
#define K20_PADS_ACM				20
#define K21_PADF_AGNDF				21
#define K22_AGNDFS_SHRT				22
#define K23_FXVI_STACK				23
#define K24_VDDIO_ACM				24
#define K25_FOUT_FXVIA				25
#define K26_FOUT_DCM				26
#define K27_220_SHRT				27
#define K28_FCCU12_FXVIA			28
#define K29_BUCK2FB_ACM				29
#define K30_INTB_ACM				30
#define K31_INTB_DCM				31
#define K32_INTB_FXVIA				32
#define K33_BUCK12SW_ACM			33
#define K34_BOOST_SLT				34
#define K35_PSYNC_FXVIA				35
#define K36_BUCK1FB_ACM				36
#define K37_ERRMON_FXVIA			37
#define K38_PRECOMP_ACM				38
#define K39_PRECSP_ACM				39
#define K40_VBOOST_ACM				40
#define K41_PREGLS_FXVIB			41
#define K42_PRESW_FXVIB				42
#define K43_PREGHS_FXVIB			43
#define K44_PREBOOT_FXVIB			44
#define K45_PREFB_FXVIA				45
#define K46_PREFB_ACM				46
#define K47_WAKE1_FXVIB				47
#define K48_WAKE1_DCM				48
#define K49_VSUP2_FXVIB				49
#define K50_VBOOST_FXVIB			50
#define K51_LDO2_FXVIB				51
#define K52_LDO1_FXVIB				52
#define K53_LDO1IN_FXVIB			53
#define K54_VDDIO_PU				54
#define K55_RSTB_PU					55
#define K56_INTB_PU					56
#define K57_FS0B_PSYNC_PU			57
#define K58_DBG_PU					58
#define K59_WAKE12_PU				59
#define K60_WAKE12_PD				60
#define K61_DBG_PD					61
#define K62_BOOST_PRESW_VCOREMON_PD	62
#define K63_CSP_FB_FPVIHL			63
#define K64_PGND_FPVIH				64
#define K65_BUCK1IN_FPVIH			65
#define K66_PGND_FPVIL				66
#define K67_SW_FPVIL				67
#define K68_BOOSTLS_FPVIL			68
#define K69_INTB_DBUFF				69
#define K70_FOUT_TMUA				70
#define K71_FIN_TMUB				71
#define K72_PGOOD_DBUFF				72
#define K73_PRESW_BOOSTLS_TMU		73
#define K74_BUCK3SW_DBUFF			74
#define K75_BUCK2SW_DBUFF			75
#define K76_BUCK1SW_DBUFF			76
#define K77_PREGHS_GLS_TMU			77
#define K78_FCCU1_PU_FCCU2_PD		78
#define K79_PGOOD_PU				79
#define K80_PRECSP_PREFB_SHRT		80
#define K81_LDO_CAPS				81
#define K82_BUCK_CAPS				82
#define K83_BUCKIN_PREFB			83
#define K84_PRECOMP_CAP				84
#define K85_BUCKSW_PD				85
#define K86_BUCK_SLT				86

//THB
#define K87_LOCK_DCM				87
#define K88_FPVI1H_A				88
#define K89_FPVI1H_B				89
#define K90_FPVI1H_C				90
#define K91_FPVI1H_D				91
#define K92_FPVI1L_A				92
#define K93_FPVI1L_B				93
#define K94_FPVI1L_C				94
#define K95_FPVI1L_D				95
#define K96_FPVI0H_A				96
#define K97_FPVI0H_B				97
#define K98_FPVI0H_C				98
#define K99_FPVI0H_D				99
#define K100_FPVI0L_A				100
#define K101_FPVI0L_B				101
#define K102_FPVI0L_C				102
#define K103_FPVI0L_D				103
#define K104_FXVI0_6_A				104
#define K105_FXVI0_6_B				105
#define K106_FXVI1_7_A				106
#define K107_FXVI1_7_B				107
#define K108_FXVI2_8_A				108
#define K109_FXVI2_8_B				109
#define K110_FXVI3_9_A				110
#define K111_FXVI3_9_B				111
#define K112_FXVI4_10_A				112
#define K113_FXVI4_10_B				113
#define K114_FXVI5_11_A				114
#define K115_FXVI5_11_B				115
#define K116_QVMH0					116
#define K117_QVMH1					117
#define K118_QVMH2					118
#define K119_QVML0					119
#define K120_QVML1					120
#define K121_QVM_S2468				121
#define K122_QVM_S1357				122
#define K123_TMU_S2468				123
#define K124_TMU_S1357				124
#define K125_DBUFF_S2468			125
#define K126_DBUFF_S1357			126
#define K127_ABUFF					127

#define K_FXVI_A					104,106,108,110,112,114
#define K_FXVI_B					105,107,109,111,113,115

#define K_FPVIH_A					88,96
#define K_FPVIH_B					89,97
#define K_FPVIH_C					90,98
#define K_FPVIH_D					91,99
#define K_FPVIL_A					92,100
#define K_FPVIL_B					93,101
#define K_FPVIL_C					94,102
#define K_FPVIL_D					95,103


struct SAMPLE_NAME_CODE
{

	string name;
	string treg_name;
	double partname;
	int useropt_burn;

};



//8200 transefer to 8300
extern DWORD original_validsite;
extern DWORD g_last_valid_fpvi;
extern DWORD g_last_valid_fpvi0;
extern DWORD g_last_valid_fpvi1;
extern DWORD g_last_valid_fpvi2;
extern DWORD g_last_valid_fpvi3;
extern bool DO_TRIM;
extern bool QC;
extern int g_x_coords[SITE_NUM], g_y_coords[SITE_NUM];
extern char waferid[64];
#define GLOBAL
GLOBAL int G_GetXYCoordinate();
GLOBAL BYTE cbitclose(BYTE k1, BYTE k2 = -1, BYTE k3 = -1, BYTE k4 = -1, BYTE k5 = -1, BYTE k6 = -1, BYTE k7 = -1, BYTE k8 = -1, BYTE k9 = -1, BYTE k10 = -1,
	BYTE k11 = -1, BYTE k12 = -1, BYTE k13 = -1, BYTE k14 = -1, BYTE k15 = -1, BYTE k16 = -1, BYTE k17 = -1, BYTE k18 = -1, BYTE k19 = -1, BYTE k20 = -1,
	BYTE k21 = -1, BYTE k22 = -1, BYTE k23 = -1, BYTE k24 = -1, BYTE k25 = -1, BYTE k26 = -1, BYTE k27 = -1, BYTE k28 = -1, BYTE k29 = -1, BYTE k30 = -1,
	BYTE k31 = -1, BYTE k32 = -1, BYTE k33 = -1, BYTE k34 = -1, BYTE k35 = -1, BYTE k36 = -1, BYTE k37 = -1, BYTE k38 = -1, BYTE k39 = -1, BYTE k40 = -1,
	BYTE k41 = -1, BYTE k42 = -1, BYTE k43 = -1, BYTE k44 = -1, BYTE k45 = -1, BYTE k46 = -1, BYTE k47 = -1, BYTE k48 = -1, BYTE k49 = -1, BYTE k50 = -1,
	BYTE k51 = -1, BYTE k52 = -1, BYTE k53 = -1, BYTE k54 = -1, BYTE k55 = -1, BYTE k56 = -1, BYTE k57 = -1, BYTE k58 = -1, BYTE k59 = -1, BYTE k60 = -1,
	BYTE k61 = -1, BYTE k62 = -1, BYTE k63 = -1, BYTE k64 = -1, BYTE k65 = -1, BYTE k66 = -1, BYTE k67 = -1, BYTE k68 = -1, BYTE k69 = -1, BYTE k70 = -1,
	BYTE k71 = -1, BYTE k72 = -1, BYTE k73 = -1, BYTE k74 = -1, BYTE k75 = -1, BYTE k76 = -1, BYTE k77 = -1, BYTE k78 = -1, BYTE k79 = -1, BYTE k80 = -1,
	BYTE k81 = -1, BYTE k82 = -1, BYTE k83 = -1, BYTE k84 = -1, BYTE k85 = -1, BYTE k86 = -1, BYTE k87 = -1, BYTE k88 = -1, BYTE k89 = -1, BYTE k90 = -1,
	BYTE k91 = -1, BYTE k92 = -1, BYTE k93 = -1, BYTE k94 = -1, BYTE k95 = -1, BYTE k96 = -1, BYTE k97 = -1, BYTE k98 = -1, BYTE k99 = -1, BYTE k100 = -1,
	BYTE k101 = -1, BYTE k102 = -1, BYTE k103 = -1, BYTE k104 = -1, BYTE k105 = -1, BYTE k106 = -1, BYTE k107 = -1, BYTE k108 = -1, BYTE k109 = -1, BYTE k110 = -1,
	BYTE k111 = -1, BYTE k112 = -1, BYTE k113 = -1, BYTE k114 = -1, BYTE k115 = -1, BYTE k116 = -1, BYTE k117 = -1, BYTE k118 = -1, BYTE k119 = -1, BYTE k120 = -1,
	BYTE k121 = -1, BYTE k122 = -1, BYTE k123 = -1, BYTE k124 = -1, BYTE k125 = -1, BYTE k126 = -1, BYTE k127 = -1, BYTE k128 = -1);
GLOBAL BYTE cbitopen(BYTE k1, BYTE k2 = -1, BYTE k3 = -1, BYTE k4 = -1, BYTE k5 = -1, BYTE k6 = -1, BYTE k7 = -1, BYTE k8 = -1, BYTE k9 = -1, BYTE k10 = -1,
	BYTE k11 = -1, BYTE k12 = -1, BYTE k13 = -1, BYTE k14 = -1, BYTE k15 = -1, BYTE k16 = -1, BYTE k17 = -1, BYTE k18 = -1, BYTE k19 = -1, BYTE k20 = -1,
	BYTE k21 = -1, BYTE k22 = -1, BYTE k23 = -1, BYTE k24 = -1, BYTE k25 = -1, BYTE k26 = -1, BYTE k27 = -1, BYTE k28 = -1, BYTE k29 = -1, BYTE k30 = -1,
	BYTE k31 = -1, BYTE k32 = -1, BYTE k33 = -1, BYTE k34 = -1, BYTE k35 = -1, BYTE k36 = -1, BYTE k37 = -1, BYTE k38 = -1, BYTE k39 = -1, BYTE k40 = -1,
	BYTE k41 = -1, BYTE k42 = -1, BYTE k43 = -1, BYTE k44 = -1, BYTE k45 = -1, BYTE k46 = -1, BYTE k47 = -1, BYTE k48 = -1, BYTE k49 = -1, BYTE k50 = -1,
	BYTE k51 = -1, BYTE k52 = -1, BYTE k53 = -1, BYTE k54 = -1, BYTE k55 = -1, BYTE k56 = -1, BYTE k57 = -1, BYTE k58 = -1, BYTE k59 = -1, BYTE k60 = -1,
	BYTE k61 = -1, BYTE k62 = -1, BYTE k63 = -1, BYTE k64 = -1, BYTE k65 = -1, BYTE k66 = -1, BYTE k67 = -1, BYTE k68 = -1, BYTE k69 = -1, BYTE k70 = -1,
	BYTE k71 = -1, BYTE k72 = -1, BYTE k73 = -1, BYTE k74 = -1, BYTE k75 = -1, BYTE k76 = -1, BYTE k77 = -1, BYTE k78 = -1, BYTE k79 = -1, BYTE k80 = -1,
	BYTE k81 = -1, BYTE k82 = -1, BYTE k83 = -1, BYTE k84 = -1, BYTE k85 = -1, BYTE k86 = -1, BYTE k87 = -1, BYTE k88 = -1, BYTE k89 = -1, BYTE k90 = -1,
	BYTE k91 = -1, BYTE k92 = -1, BYTE k93 = -1, BYTE k94 = -1, BYTE k95 = -1, BYTE k96 = -1, BYTE k97 = -1, BYTE k98 = -1, BYTE k99 = -1, BYTE k100 = -1,
	BYTE k101 = -1, BYTE k102 = -1, BYTE k103 = -1, BYTE k104 = -1, BYTE k105 = -1, BYTE k106 = -1, BYTE k107 = -1, BYTE k108 = -1, BYTE k109 = -1, BYTE k110 = -1,
	BYTE k111 = -1, BYTE k112 = -1, BYTE k113 = -1, BYTE k114 = -1, BYTE k115 = -1, BYTE k116 = -1, BYTE k117 = -1, BYTE k118 = -1, BYTE k119 = -1, BYTE k120 = -1,
	BYTE k121 = -1, BYTE k122 = -1, BYTE k123 = -1, BYTE k124 = -1, BYTE k125 = -1, BYTE k126 = -1, BYTE k127 = -1, BYTE k128 = -1);
// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_)

struct XY_COOR
{

	int xx_coor;
	int yy_coor;
	int dieid_coor;

};
