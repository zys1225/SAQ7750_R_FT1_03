#define MAX_SAMPLES 4096
#include "awg.h"
extern int Trig_Point[SITE_NUM];

extern int wafer_id;
extern AWG_FUNC awg;
extern XY_COOR maprslt[4000];

void Enter_MAIN_TM_DIG();
void Enter_FS_TM_DIG();
void Enter_MAIN_SCAN_DIG();
void Enter_FS_SCAN_DIG();
void Enter_MAIN_UOTP_PGM();
void Enter_FS_UOTP_PGM();
void I2CSetup(int debug = 1);
void I2CSetupGNG(int debug = 1);
void Enter_M_TM(ULONG M_TM1, ULONG M_TM2, ULONG M_TM3);
void Enter_FS_TM(ULONG F_TM);
void I2CWriteDataA(BYTE bySAddress, DWORD dwRegAddress, DWORD data);
void I2CWriteData(BYTE bySAddress, DWORD dwRegAddress, DWORD data);
void I2CWriteData(DWORD dwRegAddress, DWORD data,int main_fs=0);
void I2CWriteMData(DWORD dwRegAddress, DWORD data[SITE_NUM], int main_fs = 0);
void I2CWriteMData(BYTE bySAddress, DWORD dwRegAddress, DWORD data[SITE_NUM]);
void I2CReadData(int RegAddress, DWORD data[][SITE_NUM], int count);
void I2CReadData(BYTE bySAddress,int RegAddress, DWORD data[][SITE_NUM], int count);

void measure_RON(FPVIe fpvires, double *results, char* reg_str);
void vth_binary_search(const char* pin, ACM acm_cap, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us = 200, int hysmode = 1, TRIG_MODE trig_mode = TRIG_FALLING);
void vth_binary_search(ACM acm_pin, ACM acm_cap, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us = 200, int hysmode = 1, TRIG_MODE trig_mode = TRIG_FALLING);
void vth_binary_search(const char* pin, FOVIe fovicap, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us = 200, int hysmode = 1, TRIG_MODE trig_mode = TRIG_FALLING);
void vth_binary_search(const char* pin, FXVIe_PLUS fxvicap, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us = 200, int hysmode = 1, TRIG_MODE trig_mode = TRIG_FALLING);
void ith_binary_search(const char* pin, FXVIe_PLUS fxvicap, double start, double stop, double holdvalue, int stepcount, double* result, int delaytime_us = 200, int hysmode = 1, TRIG_MODE trig_mode = TRIG_FALLING);
void vth_binary_search(ACM200 acm_pin, FXVIe_PLUS fxvie_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us = 200, int hysmode = 1, TRIG_MODE trig_mode = TRIG_FALLING);
void vth_binary_search(FXVIe_PLUS fxvi_pin, FXVIe_PLUS fxvie_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us = 200, int hysmode = 1, TRIG_MODE trig_mode = TRIG_FALLING);

void  treg2pgs();
void OTP_M_Preview(int banknum = -1, int bankcount = 1);
void OTP_FS_Preview();

void power_off(int debug = 1);
void power_off2(int debug = 1);

void SCAN_TEST(ACM200 vddpin, double vdd, const char* pingrp, const char* pincap, const char* startlabel, const char* stoplabel, int samplesize, int interval, double *results_i, double *results_v, ULONG *failcount, int measuretype = 0);
void parity_check(int *res);
double sigma_cal(double *data, int datasize);
BOOL OS_Classify(short funcindex, string pin_str_array[], unsigned int OS_NUM, double os_result[][SITE_NUM]);
void load_mapping(string pathmap, XY_COOR mapdata[]);
int dieid_search_mapping(int xx, int yy);
ULONG SPI_calculateCRC(ULONG data);
ULONG IIC_calculateCRC(ULONG data);
ULONG IIC_calculateCRC2(ULONG data);
ULONG calculateSingleCRC(ULONG data, const int* bitPositions, int bitCount, int onesCount);
//unsigned char IIC_calculateCRC(DataType data);
void SPIWrite(ULONG addr, ULONG datain);
void SPIWrite(ULONG addr, ULONG datain[SITE_NUM]);
void SPIWrite_SYNC(ULONG addr, ULONG datain[SITE_NUM]);
void SPIWrite_SYNC(ULONG addr, ULONG datain);
void SPIRead(ULONG addr, ULONG dataout[SITE_NUM]);
void SPIRead(ULONG addr, ULONG dataout[][SITE_NUM], int count);
void SPIRead(ULONG addr, ULONG dataout[SITE_NUM], ULONG crcdataout[SITE_NUM]);
void SPIRead(ULONG addr, ULONG dataout[][SITE_NUM], ULONG crcdataout[][SITE_NUM], int count);
void SPIInitial(double vih, double vil, double voh, double vol, double period=1000);//ns
void measure_VPRE_SC_OPT(double start, double stop, double *results);
void measure_VPRE_SC_OPT1(double start, double stop, double* results);
void CLK_SWEEP(double *freq_slow, double *freq_fast, double range_min,double range_max,double range_step);
void spsp_freq_test(double *minfreq, double *maxfreq, double *avgfreq,double *carrFreq=NULL);
void measure_DUTY_DCM(double *results);
void measure_DUTY_QTMU(double *results,double *freq=NULL);
void measure_FREQ_DCM(double *results);
void measure_FREQ_QTMU(double *results);
void measure_VPRE_SS(double* res1,double* res2);
void measure_SS(ACM200 respin,int samplesize,double targetvalue,double* res1);
void measure_SS(FXVIe_PLUS respin,int samplesize,double targetvalue,double* res1);
void measure_ON_OFF_QTMU(double* results, double* freq=NULL,QTMUe_SLOPE slopstart=QTMUe_NEG,QTMUe_SLOPE slopstop=QTMUe_POS,double startv=2.5,double stopv=2.5);
void measure_ON_OFF_QTMU_wBUFF(double* onTime, double* freq=NULL,QTMUe_SLOPE slopstart=QTMUe_NEG,QTMUe_SLOPE slopstop=QTMUe_POS,double startv=2.5,double stopv=2.5);
void SYNC_SWEEP(double range_min, double range_max, double range_step, double *lockfreqmin, double *lockfreqmax, int flag_gng, int fin_div=0);
void measure_PLL_QTMU(double *results);

/**
* @range_min search range min,Unit Khz
* @range_max search range max,Unit Khz
* @step
*/
void measure_BGTC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BGV(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_TS(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);

void measure_ICT(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_CLK1_FSW_DCM(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_CLK1_FSW_QTMU(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_SPSP_DCM(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_SPSP_QTMU(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_CLK_CHECK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_VPRE_VREF(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_VPRE_EA_OFFSET(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_VPRE_EA_IOUT(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_VPRE_IPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_VPRE_IVY_MAX(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_VPRE_IVY_MIN(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_VPRE_INEG(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_VPRE_SC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BOOST_VREF(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BOOST_EA_OFFSET(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_RON(FPVIe fpvires, double *results, char* reg_str);
void measure_BOOST_CLAMPMAX(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BOOST_CLAMPMIN(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BOOST_ISLP(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_LDO12_DAC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_LDO1_EA(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_LDO2_EA(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_LDO1_SS(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_LDO2_SS(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_LDO1_ILMT(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_LDO2_ILMT(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK1_DAC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK2_DAC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK3_DAC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK1_IPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK2_IPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK3_IPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK1_IVY(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK2_IVY(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK3_IVY(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK1_EA(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK2_EA(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK3_EA(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK1_LOOP_GM(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK2_LOOP_GM(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK3_LOOP_GM(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK1_SLOP(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK2_SLOP(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK3_SLOP(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK2_DP_IMINPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_BUCK2_DP_IMAXPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);

void measure_FSBGTC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_FSBGV(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);
void measure_FS_CLK_QTMU(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);

void measure_QVM( double *results);
int measure_FREQ_DCM();
void DBG_TIMING(double range_min, double range_max, double range_step, double *dly_time, int flag_gng=1);