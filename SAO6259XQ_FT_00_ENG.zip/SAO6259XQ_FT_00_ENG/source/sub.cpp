#include "stdafx.h"
#include "I2C.h"
#include <iostream>
#include <fstream>  // �����ļ�����
#include "sub.h"
int i2c_connect_status = 0;

void  treg2pgs() {
	std::ofstream pgsfile;
	std::ofstream cppfile;
	map<unsigned int, map<string, unsigned int>> node_map;
	pgsfile.open("pgs.csv");//->file name setting
	cppfile.open("code.cpp");//->file name setting
	// ����ļ��Ƿ�ɹ���
	if (!pgsfile || !cppfile) {
		std::cerr << "�޷����ļ�" << std::endl;
		return;
	}

	int sel_start_work = 0;//if 1, SEL use working as limit, if 0, SEL use start code as limit

	pgsfile << "Function,Symbol,Param,Min,Max,Unit,Format\n";



	string trim_str[8] = { "_STEP", "_pre", "_pre_bit", "_post", "_post_bit", "_target", "_guessed", "_updated" };
	string ee_pre_str[2] = { "_READ", "_PRE" };
	string ee_post_str[3] = { "_COMP", "_FINAL", "_FINAL" };

	//trim to pgs
	TRIM_NODE* trim_node;
	string trim_name;
	string trim_unit;
	int trim_steps;
	double trim_target;
	for (int ntrim = 0; ntrim < dut.trim.count(); ntrim++) {
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		trim_target = trim_node->get_target(0);
		trim_unit = trim_node->get_base_unit();
		pgsfile << "T_TRIM" << ntrim + 1 << "_" << trim_name;
		trim_steps = trim_node->get_steps();
		// "Function,Symbol,Param,Min,Max,Unit,Format\n";
		//steps
		for (int nstep = 0; nstep < trim_steps; nstep++) {
			pgsfile << "," << trim_name << trim_str[0] << nstep << "," << trim_name << trim_str[0] << nstep;//symbol, param
			pgsfile << "," << trim_target * 0.1 << "," << trim_target * 2 << "," << trim_unit << ",4"; //min max unit format
			pgsfile << "\n";
		}
		//pre
		pgsfile << "," << trim_name << trim_str[1] << "," << trim_name << trim_str[1];//symbol, param
		pgsfile << "," << trim_target * 0.1 << "," << trim_target * 2 << "," << trim_unit << ",4"; //min max unit format
		pgsfile << "\n";
		//pre bit
		pgsfile << "," << trim_name << trim_str[2] << "," << trim_name << trim_str[2];//symbol, param
		pgsfile << "," << 0 << "," << trim_steps - 1 << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
		//post
		pgsfile << "," << trim_name << trim_str[3] << "," << trim_name << trim_str[3];//symbol, param
		pgsfile << "," << trim_target * 0.9 << "," << trim_target * 1.1 << "," << trim_unit << ",4"; //min max unit format
		pgsfile << "\n";
		//post bit
		pgsfile << "," << trim_name << trim_str[4] << "," << trim_name << trim_str[4];//symbol, param
		pgsfile << "," << 0 << "," << trim_steps - 1 << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
		//target
		pgsfile << "," << trim_name << trim_str[5] << "," << trim_name << trim_str[5];//symbol, param
		pgsfile << "," << "," << "," << trim_unit << ",4"; //min max unit format
		pgsfile << "\n";
		//guessed
		pgsfile << "," << trim_name << trim_str[6] << "," << trim_name << trim_str[6];//symbol, param
		pgsfile << "," << "," << "," << trim_unit << ",4"; //min max unit format
		pgsfile << "\n";
		//updated
		pgsfile << "," << trim_name << trim_str[7] << "," << trim_name << trim_str[7];//symbol, param
		pgsfile << "," << 0 << "," << 1 << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}

	//EE INIT PGS
	//BANK READ
	ASSY_NODE* assy_node;
	string assy_name;
	int assy_size;
	pgsfile << "T_EE_INIT";
	for (int nassy = 0; nassy < dut.assy.count(); nassy++) {
		assy_node = &dut.assy[nassy];
		assy_name = assy_node->get_node_name();
		assy_size = assy_node->count();
		pgsfile << "," << assy_name << ee_pre_str[0] << "," << assy_name << ee_pre_str[0];//symbol, param
		pgsfile << "," << 0 << "," << (1 << assy_size) - 1 << ",DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}
	//TRIM PRE
	for (int ntrim = 0; ntrim < dut.trim.count(); ntrim++) {
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		trim_steps = trim_node->get_steps();
		//pre
		pgsfile << "," << trim_name << ee_pre_str[1] << "," << trim_name << ee_pre_str[1];//symbol, param
		pgsfile << "," << 0 << "," << trim_steps - 1 << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}
	//SEL PRE
	SEL_NODE* sel_node;
	string sel_name;
	int sel_limit;
	for (int nsel = 0; nsel < dut.sel.count(); nsel++) {
		sel_node = &dut.sel[nsel];
		sel_name = sel_node->get_node_name();
		sel_limit = (sel_start_work ? sel_node->get_working(0) : sel_node->get_start(0));
		//pre
		pgsfile << "," << sel_name << ee_pre_str[1] << "," << sel_name << ee_pre_str[1];//symbol, param
		pgsfile << "," << 0 << "," << sel_limit << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}

	//EE FINAL PGS

	//BANK COMP
	pgsfile << "T_EE_FINAL";
	for (int nassy = 0; nassy < dut.assy.count(); nassy++) {
		assy_node = &dut.assy[nassy];
		assy_name = assy_node->get_node_name();
		assy_size = assy_node->count();
		pgsfile << "," << assy_name << ee_post_str[0] << "," << assy_name << ee_post_str[0];//symbol, param
		pgsfile << "," << 1 << "," << 1 << ",DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}
	//BANK READ
	for (int nassy = 0; nassy < dut.assy.count(); nassy++) {
		assy_node = &dut.assy[nassy];
		assy_name = assy_node->get_node_name();
		assy_size = assy_node->count();
		pgsfile << "," << assy_name << ee_post_str[1] << "," << assy_name << ee_post_str[1];//symbol, param
		pgsfile << "," << 0 << "," << (1 << assy_size) - 1 << ",DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}
	//TRIM FINAL
	for (int ntrim = 0; ntrim < dut.trim.count(); ntrim++) {
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		trim_steps = trim_node->get_steps();
		//pre
		pgsfile << "," << trim_name << ee_post_str[2] << "," << trim_name << ee_post_str[2];//symbol, param
		pgsfile << "," << 0 << "," << trim_steps - 1 << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}
	//SEL FINAL
	for (int nsel = 0; nsel < dut.sel.count(); nsel++) {
		sel_node = &dut.sel[nsel];
		sel_name = sel_node->get_node_name();
		sel_limit = (sel_start_work ? sel_node->get_working(0) : sel_node->get_start(0));
		//pre
		pgsfile << "," << sel_name << ee_post_str[2] << "," << sel_name << ee_post_str[2];//symbol, param
		pgsfile << "," << sel_limit << "," << sel_limit << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}

	pgsfile.close();//pgs file done


	cppfile << "//////This file is generated by treg2pgs tool\n//////Below code is measure function declare used in sub.h\n";
	for (int ntrim = 0; ntrim < dut.trim.count(); ntrim++) {
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		cppfile << "void measure_" << trim_name << "(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);\n";
	}

	cppfile << "\n\n//////Below code is measure function defination used in sub.cpp\n";
	for (int ntrim = 0; ntrim < dut.trim.count(); ntrim++) {
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		cppfile << "void measure_" << trim_name << "(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){\n";
		cppfile << "#ifdef _DEBUG\n";
		cppfile << "    int working = trim_node->get_working(0);\n";
		cppfile << "#endif\n";
		cppfile << "    if (treg_measure_flag == TREG_MEASURE_CHAR) {}\n";
		cppfile << "    if (treg_measure_flag == TREG_MEASURE_PRE) {}\n";
		cppfile << "    if (treg_measure_flag == TREG_MEASURE_POST) {\n";
		cppfile << "        SERIAL {\n";
		cppfile << "            //if (device_trimmed[SITE])\n";
		cppfile << "            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device\n";
		cppfile << "        }\n";
		cppfile << "    }\n";
		cppfile << "    //efuse_preview();//you should preview code here\n";
		cppfile << "    //you should measure parameter here\n";
		cppfile << "    //SERIAL results[SITE] = -99;//you should save result here\n";
		cppfile << "}\n\n";
	}

	cppfile << "\n\n//////Below code is EE INIT FINAL used in test.cpp\n";
	cppfile << "DUT_API int T_EE_INIT(short funcindex, LPCTSTR funclabel)\n";
	cppfile << "{  \n";
	cppfile << "    //{{AFX_STS_PARAM_PROTOTYPES\n";
	cppfile << "    //}}AFX_STS_PARAM_PROTOTYPES\n";
	cppfile << "\n";
	cppfile << "    // TODO: Add your function code here\n";
	cppfile << "    // add your readback code here\n";
	cppfile << "    // make sure readback value is stored in TREG read_back \n";
	cppfile << "    //Bank READ\n";
	cppfile << "    for (int reg = 0; reg < dut.assy.count(); ++reg)\n";
	cppfile << "    {\n";
	cppfile << "        string EE_str = string(dut.assy[reg].get_name()) + \"_READ\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].get_read_back(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    //TRIM PRE\n";
	cppfile << "    for (int reg = 0; reg < dut.trim.count(); ++reg){\n";
	cppfile << "        string EE_str = string(dut.trim[reg].get_name()) + \"_PRE\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.trim[reg].get_read_back(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    //SEL PRE\n";
	cppfile << "    for (int reg = 0; reg < dut.sel.count(); ++reg){\n";
	cppfile << "        string EE_str = string(dut.sel[reg].get_name()) + \"_PRE\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.sel[reg].get_read_back(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    //check device trimmed\n";
	cppfile << "    SERIAL{\n";
	cppfile << "        if (dut.assy(\"EFUSE0\").get_read_back(SITE) != 0)\n";
	cppfile << "            device_trimmed[SITE] = 1;\n";
	cppfile << "        else\n";
	cppfile << "            device_trimmed[SITE] = 0;\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    return 0;\n";
	cppfile << "}\n\n";

	cppfile << "DUT_API int T_EE_FINAL(short funcindex, LPCTSTR funclabel)\n";
	cppfile << "{\n";
	cppfile << "    //{{AFX_STS_PARAM_PROTOTYPES\n";
	cppfile << "    //}}AFX_STS_PARAM_PROTOTYPES\n";
	cppfile << "    // TODO: Add your function code here\n";
	cppfile << "    // add your readback code here\n";
	cppfile << "    // make sure readback value is stored in TREG read_back\n";
	cppfile << "\n";
	cppfile << "    //Bank FINAL\n";
	cppfile << "    for (int reg = 0; reg < dut.assy.count(); ++reg)\n";
	cppfile << "    {\n";
	cppfile << "        string EE_str = string(dut.assy[reg].get_name()) + \"_FINAL\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].get_read_back(SITE));\n";
	cppfile << "\n";
	cppfile << "        EE_str = string(dut.assy[reg].get_name()) + \"_COMP\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].comp_read_to_work(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    //TRIM FINAL\n";
	cppfile << "    for (int reg = 0; reg < dut.trim.count(); ++reg){\n";
	cppfile << "        string EE_str = string(dut.trim[reg].get_name()) + \"_FINAL\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.trim[reg].get_read_back(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    //SEL FINAL\n";
	cppfile << "    for (int reg = 0; reg < dut.sel.count(); ++reg){\n";
	cppfile << "        string EE_str = string(dut.sel[reg].get_name()) + \"_FINAL\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.sel[reg].get_read_back(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    return 0;\n";
	cppfile << "}\n\n";

	cppfile << "\n\n//////Below code is for TRIM used in test.cpp\n";
	for (int ntrim = 0; ntrim < dut.trim.count(); ntrim++) {
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();

		cppfile << "DUT_API int T_TRIM" << ntrim + 1 << "_" << trim_name << "(short funcindex, LPCTSTR funclabel)\n";
		cppfile << "{\n";
		cppfile << "    //{{AFX_STS_PARAM_PROTOTYPES\n";
		cppfile << "    //}}AFX_STS_PARAM_PROTOTYPES\n\n";
		cppfile << "    // TODO: Add your functOion code here\n\n";
		cppfile << "    // Relay Setup here\n";
		cppfile << "    // Power on here\n";
		cppfile << "    // Enter TM here\n";
		cppfile << "    // Preview Fuse here\n";
		cppfile << "    // Set TM n here\n";
		//dut.trim("BG_SYS").execute(measure_BG_SYS, spec, funcindex, funclabel, 1, 0, "BG_SYS");
		cppfile << "	dut.trim(\"" << trim_name << "\").execute(measure_" << trim_name << ", spec, funcindex, funclabel, 1, 0, \"" << trim_name << "\");\n ";
		cppfile << "    // Power off and clean up here\n";
		cppfile << "    return 0;\n";
		cppfile << "}\n\n";

	}





	cppfile.close();//cpp file done
}

double sigma_cal(double *data, int datasize)
{
	double avg_res=0;
	double var=0;
	double sigma;
	for (int i = 0; i < datasize; i++)
		avg_res += data[i];
	
	avg_res /= (datasize + 1e-30);

	for (int i = 0; i < datasize; i++)
		var += (data[i] - avg_res)*(data[i] - avg_res);
	if (datasize > 1)
		sigma = pow(var, 0.5) / datasize;
	else
		sigma = 0;
	return sigma;
}



void I2CSetup(int debug)
{
	int dynamicload = 1;
	float time_period;
	if (!DO_CHAR)
	{
		if (test_stage == 2)
			time_period = 1000;//need low freq at cold temp
		else
			time_period = 1000;//300ns
	}

	else
		time_period = 1000;//300ns
	if (debug == 1)
	{
		
		dcm.I2CSet(time_period, 8, DCM_REG8, "S24_4,S24_20,S24_44,S24_60,S24_12,S24_28,S24_36,S24_52", "S24_5,S24_21,S24_45,S24_61,S24_13,S24_29,S24_37,S24_53");

		dcm.I2CConnect();//Connect I2C relay
		dcm.I2CSetPinLevel(4.0, 0, 1.5, 1.4);
		dcm.I2CSetSCLEdge(0, time_period*0.7);
		dcm.I2CSetSDAEdge(time_period*0.1, time_period*0.995, time_period*0.1, time_period*0.95);
		if (dynamicload)
		{
			SERIAL dcm.SetDynamicLoad("SDA_WAKE1_D", SITE, DCM_OPEN_CLAMP_OPEN_LOAD, 0.015, 0.015, 3.0, 5, -2);
		}


	}
	else if (debug == 2)
	{
		dcm.I2CConnect();//Connect I2C relay
		if (dynamicload)
		{
			SERIAL dcm.SetDynamicLoad("SDA_WAKE1_D", SITE, DCM_OPEN_CLAMP_OPEN_LOAD, 0.015, 0.015, 5.0, 7, -2);
		}

	}
}
void I2CSetupGNG(int debug){
	int dynamicload = 1;
	float time_period;
	time_period = 294;//3.4Mhz
	if (debug){

		//dcm.Connect("ADDR");
		//dcm.SetPPMU("ADDR", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//ADDR1=0,ADDR2=0 =>0x64 /trim->7A
		//ADDR1=1,ADDR2=0 =>0x65//ADDR1=0,ADDR2=1 =>0x66//ADDR1=1,ADDR2=1 =>0x67
		//dcm.I2CSet(time_period, 8, DCM_REG8, "S9_5,S9_6,S9_48,S9_32,S9_7,S9_8,S9_16,S9_0", "S9_9,S9_10,S9_49,S9_33,S9_11,S9_12,S9_17,S9_1");

		dcm.I2CSet(time_period, 8, DCM_REG24, "S24_4,S24_20,S24_44,S24_60,S24_12,S24_28,S24_36,S24_52", "S24_5,S24_21,S24_45,S24_61,S24_13,S24_29,S24_37,S24_53");

		dcm.I2CConnect();//Connect I2C relay
		//if (DO_CHAR)
		//	dcm.I2CSetPinLevel(0.9, 0.37, 0.9, 0.8);
		//else
		dcm.I2CSetPinLevel(1.3, 0.4, 0.9, 0.8);

		dcm.I2CSetSCLEdge(0, time_period*0.7);
		dcm.I2CSetSDAEdge(time_period*0.1, time_period*0.995, time_period*0.1, time_period*0.95);
		if (dynamicload)
		{
			SERIAL dcm.SetDynamicLoad("SDA_WAKE1_D", SITE, DCM_OPEN_CLAMP_OPEN_LOAD, 0.015, 0.015, 1.3, 5, -2);
		}


	}
}
void Enter_MAIN_TM_DIG()
{
	ULONG data_in[SITE_NUM];

	//SERIAL_ALL data_in[SITE] = 0x5300;
	SPIWrite(0x3F, 0x5300);
	//SERIAL_ALL data_in[SITE] = 0x6300;
	SPIWrite(0x3F, 0x6300);
	//SERIAL_ALL data_in[SITE] = 0x5400;
	SPIWrite(0x3F, 0x5400);
	//SERIAL_ALL data_in[SITE] = 0x6500;
	SPIWrite(0x3F, 0x6500);
	//SERIAL_ALL data_in[SITE] = 0x7300;
	SPIWrite(0x3F, 0x7300);
	//SERIAL_ALL data_in[SITE] = 0x7400;
	SPIWrite(0x3F, 0x7400);
	//SERIAL_ALL data_in[SITE] = 0x7401;
	SPIWrite(0x3F, 0x7401);
}

void Enter_MAIN_SCAN_DIG()
{
	ULONG data_in[SITE_NUM];

	//SERIAL_ALL data_in[SITE] = 0x5300;
	SPIWrite(0x3F, 0x5300);
	//SERIAL_ALL data_in[SITE] = 0x6300;
	SPIWrite(0x3F, 0x6300);
	//SERIAL_ALL data_in[SITE] = 0x5400;
	SPIWrite(0x3F, 0x5400);
	//SERIAL_ALL data_in[SITE] = 0x6500;
	SPIWrite(0x3F, 0x6500);
	//SERIAL_ALL data_in[SITE] = 0x7300;
	SPIWrite(0x3F, 0x7300);
	//SERIAL_ALL data_in[SITE] = 0x7400;
	SPIWrite(0x3F, 0x7400);

}

void Enter_MAIN_UOTP_PGM()
{
	ULONG data_in[SITE_NUM];


	SPIWrite(0x3E, 0x5A00);
	
	SPIWrite(0x3E, 0x6800);

	SPIWrite(0x3E, 0x6100);
	
	SPIWrite(0x3E, 0x6F00);

	SPIWrite(0x3E, 0x5900);

	SPIWrite(0x3E, 0x7500);
	
	SPIWrite(0x3E, 0x6E00);

	SPIWrite(0x3E, 0x4D00);
}
void Enter_FS_UOTP_PGM()
{
	ULONG data_in[SITE_NUM];


	SPIWrite(0x7E, 0xA500);
	
	SPIWrite(0x7E, 0x9700);

	SPIWrite(0x7E, 0x9E00);
	
	SPIWrite(0x7E, 0x9000);

	SPIWrite(0x7E, 0xA600);

	SPIWrite(0x7E, 0x8A00);
	
	SPIWrite(0x7E, 0x9100);

	SPIWrite(0x7E, 0xB900);
}


void Enter_FS_TM_DIG()
{
	ULONG data_in[SITE_NUM];

	//SERIAL_ALL data_in[SITE] = 0x5300;
	SPIWrite(0x7F, 0x5300);
	//SERIAL_ALL data_in[SITE] = 0x6300;
	SPIWrite(0x7F, 0x6300);
	//SERIAL_ALL data_in[SITE] = 0x5400;
	SPIWrite(0x7F, 0x5400);
	//SERIAL_ALL data_in[SITE] = 0x6500;
	SPIWrite(0x7F, 0x6500);
	//SERIAL_ALL data_in[SITE] = 0x7300;
	SPIWrite(0x7F, 0x7300);
	//SERIAL_ALL data_in[SITE] = 0x7400;
	SPIWrite(0x7F, 0x7400);
	//SERIAL_ALL data_in[SITE] = 0x7401;
	SPIWrite(0x7F, 0x7401);
}

void Enter_FS_SCAN_DIG()
{
	ULONG data_in[SITE_NUM];

	//SERIAL_ALL data_in[SITE] = 0x5300;
	SPIWrite(0x7F, 0x5300);
	//SERIAL_ALL data_in[SITE] = 0x6300;
	SPIWrite(0x7F, 0x6300);
	//SERIAL_ALL data_in[SITE] = 0x5400;
	SPIWrite(0x7F, 0x5400);
	//SERIAL_ALL data_in[SITE] = 0x6500;
	SPIWrite(0x7F, 0x6500);
	//SERIAL_ALL data_in[SITE] = 0x7300;
	SPIWrite(0x7F, 0x7300);
	//SERIAL_ALL data_in[SITE] = 0x7400;
	SPIWrite(0x7F, 0x7400);

}

void Enter_M_TM(ULONG M_TM1, ULONG M_TM2, ULONG M_TM3)//will change to smart swith
{
	
	SPIWrite(0x30, M_TM1);
	SPIWrite(0x31, M_TM2);
	SPIWrite(0x32, M_TM3);


}
void Enter_FS_TM(ULONG F_TM)
{
	SPIWrite(0x70, F_TM);
}
void measure_RON(FPVIe fpvires, double *results, char* reg_str)
{
	double pat[1000];
	double irslt1[SITE_NUM];
	double irslt2[SITE_NUM];
	double vrslt1[SITE_NUM];
	double vrslt2[SITE_NUM];
	int patsize = 200;
	int rampsize = 20;
	UINT dly = 0;
	//will check if 1A result is stable or 2A with 10A range
	fpvires.Set(FI, 0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	for (int i = 0; i < patsize; i++)
		pat[i] = 0;
	for (int i = 0; i < rampsize; i++)
		pat[patsize + i] = i * 0.4 / (rampsize - 1);
	for (int i = 0; i < patsize; i++)
		pat[patsize + rampsize + i] = 0.4;
	for (int i = 0; i < rampsize; i++)
		pat[2 * patsize + rampsize + i] = 0.4 - i * 0.4 / (rampsize - 1);


	if (DEBUG)fpvires.AwgClear();
	SERIAL fpvires.SetAlarmMask(SITE);

	fpvires.AwgLoader(reg_str, FI, FPVIe_100MV, FPVIe_1A, pat, 2 * (patsize + rampsize));

	SERIAL fpvires.SetAlarmMask(SITE, false);
	fpvires.AwgSelect(reg_str, 0, 2 * (patsize + rampsize) - 1, 2 * (patsize + rampsize) - 1, 10);
	fpvires.MeasureVI(2 * (patsize + rampsize) - 1, 10, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);
	STSEnableAWG(&fpvires);
	STSEnableMeas(&fpvires);
	dly = (UINT)(2 * (patsize + rampsize) * 0.01) + 1;
	STSAWGRun(dly);
	SERIAL
	{
		irslt1[SITE] = 0;
		irslt2[SITE] = 0;
		for (int i = 1; i < 50; i++)
		{
			irslt1[SITE] += fpvires.GetMeasResult(SITE, MIRET, patsize - i - 10);
			irslt2[SITE] += fpvires.GetMeasResult(SITE, MIRET, 2 * patsize + rampsize - i - 10);
		}
		irslt1[SITE] = irslt1[SITE] / 49.0;
		irslt2[SITE] = irslt2[SITE] / 49.0;

		vrslt1[SITE] = 0;
		vrslt2[SITE] = 0;
		for (int i = 1; i < 50; i++)
		{
			vrslt1[SITE] += fpvires.GetMeasResult(SITE, MVRET, patsize - i - 10);
			vrslt2[SITE] += fpvires.GetMeasResult(SITE, MVRET, 2 * patsize + rampsize - i - 10);
		}
		vrslt1[SITE] = vrslt1[SITE] / 49.0;
		vrslt2[SITE] = vrslt2[SITE] / 49.0;
		results[SITE] = (vrslt2[SITE] - vrslt1[SITE]) / (irslt2[SITE] - irslt1[SITE])*1e3;//scle to mohm


	}

}

void I2CWriteDataA(BYTE bySAddress, DWORD dwRegAddress, DWORD data)
{
	//0 write, 1 read
	DWORD wrdata[SITE_NUM];
	DWORD iic40bits;
	DWORD crcdata;

	iic40bits = ((DWORD)bySAddress << 24) | (dwRegAddress << 16) | (data << 0);
	crcdata = IIC_calculateCRC2(iic40bits);
	for (int site = 0; site < SITE_NUM; site++)
	{
		wrdata[site] = (data << 8) | crcdata;
	}
	 

	dcm.I2CWriteData(bySAddress, dwRegAddress, 3, wrdata);//3��byte����

}

void I2CReadData(int RegAddress, DWORD data[][SITE_NUM], int count)//��N������
{

	DWORD data0[SITE_NUM];
	DWORD data1[SITE_NUM];
	DWORD crc[SITE_NUM];
	for (int i = 0; i<count; i++)
	{
		//SERIAL_ALL pI2CSites[SITE]->regAddress = RegAddress + i;
		dcm.I2CReadData(I2C_ADDR_DEVICE, RegAddress+i, 3);
	
		SERIAL
		{
			data0[SITE] = dcm.I2CGetReadData(SITE, 0);
			data1[SITE] = dcm.I2CGetReadData(SITE, 1);
			crc[SITE] = dcm.I2CGetReadData(SITE, 2);
			data[i][SITE] = (data0[SITE]<<8) |data1[SITE];
		}
	}

}

void I2CReadData(BYTE bySAddress, int RegAddress, DWORD data[][SITE_NUM], int count)//��N������
{

	DWORD data0[SITE_NUM];
	DWORD data1[SITE_NUM];
	DWORD crc[SITE_NUM];
	for (int i = 0; i<count; i++)
	{
		//SERIAL_ALL pI2CSites[SITE]->regAddress = RegAddress + i;
		dcm.I2CReadData(bySAddress, RegAddress+i, 3);
	
		SERIAL
		{
			data0[SITE] = dcm.I2CGetReadData(SITE, 0);
			data1[SITE] = dcm.I2CGetReadData(SITE, 1);
			crc[SITE] = dcm.I2CGetReadData(SITE, 2);
			data[i][SITE] = (data0[SITE]<<8) |data1[SITE];
		}
	}

}

void vth_binary_search(const char* pin, ACM acm_cap, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us, int hysmode, TRIG_MODE trig_mode){
	double step;
	double value[SITE_NUM];
	double res[SITE_NUM];
	step = abs(stop - start) / 4.0;
	SERIAL value[SITE] = (stop + start) / 2.0;
	for (int i = 0; i < stepcount; i++){
		if (hysmode)
		{
			dcm.SetPPMU(pin, DCM_PPMU_FVMI, start, DCM_PPMUIRANGE_2MA);
			delay_us(200);
		}
		SERIAL	dcm.SetPPMUSingleSite(pin, SITE, DCM_PPMU_FVMI, value[SITE], DCM_PPMUIRANGE_2MA);

		delay_us(delaytime_us);
		acm_cap.MeasureVI(ACM_MV, 5, 10);
		SERIAL
		{
			res[SITE] = acm_cap.GetMeasResult(SITE);
			if (trig_mode == TRIG_FALLING)
			{
				if (res[SITE] < 2.5)
					value[SITE] -= step;
				else
					value[SITE] += step;
			}
			else
			{
				if (res[SITE] < 2.5)
					value[SITE] += step;
				else
					value[SITE] -= step;
			}
		}
		step = step / 2.0;
	}
	SERIAL result[SITE] = value[SITE];
	dcm.SetPPMU(pin, DCM_PPMU_FVMI, holdvalue, DCM_PPMUIRANGE_2MA);
}

void vth_binary_search(const char* pin, FOVIe fovicap, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us, int hysmode, TRIG_MODE trig_mode){
	double step;
	double value[SITE_NUM];
	double res[SITE_NUM];
	step = abs(stop - start) / 4.0;
	SERIAL value[SITE] = (stop + start) / 2.0;
	for (int i = 0; i < stepcount; i++){
		if (hysmode)
		{
			dcm.SetPPMU(pin, DCM_PPMU_FVMI, start, DCM_PPMUIRANGE_2MA);
			delay_us(delaytime_us);
		}
		SERIAL	dcm.SetPPMUSingleSite(pin, SITE, DCM_PPMU_FVMI, value[SITE], DCM_PPMUIRANGE_2MA);

		delay_us(delaytime_us);
		fovicap.MeasureVI(5, 10);
		SERIAL
		{
			res[SITE] = fovicap.GetMeasResult(SITE, MIRET);
			if (trig_mode == TRIG_FALLING)
			{
				if (res[SITE] < 100e-6)
					value[SITE] -= step;
				else
					value[SITE] += step;
			}
			else
			{
				if (res[SITE] < 100e-6)
					value[SITE] += step;
				else
					value[SITE] -= step;
			}
		}
		step = step / 2.0;
	}
	SERIAL result[SITE] = value[SITE];
	dcm.SetPPMU(pin, DCM_PPMU_FVMI, holdvalue, DCM_PPMUIRANGE_2MA);
}

void vth_binary_search(ACM acm_pin, ACM acm_cap, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us, int hysmode, TRIG_MODE trig_mode){
	double step;
	double value[SITE_NUM];
	double res[SITE_NUM];
	step = abs(stop - start) / 4.0;
	SERIAL value[SITE] = (stop + start) / 2.0;
	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_5UA, ACM_RELAY_ON);
	for (int i = 0; i < stepcount; i++){
		if (hysmode)
		{
			acm_pin.Set(FV, start, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON);

			delay_us(10);
		}

		acm_pin.SetSyn(FV, value, SITE_NUM, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON);

		delay_us(delaytime_us);
		acm_cap.MeasureVI(ACM_MV, 5, 10);
		SERIAL
		{
			res[SITE] = acm_cap.GetMeasResult(SITE);
			if (trig_mode == TRIG_FALLING)
			{
				if (res[SITE] < 2.5)
					value[SITE] -= step;
				else
					value[SITE] += step;
			}
			else
			{
				if (res[SITE] < 2.5)
					value[SITE] += step;
				else
					value[SITE] -= step;
			}
		}
		step = step / 2.0;
	}
	SERIAL result[SITE] = value[SITE];
	acm_pin.Set(FV, holdvalue, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON);
}

void vth_binary_search(ACM200 acm_pin, FXVIe_PLUS fxvie_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us, int hysmode, TRIG_MODE trig_mode){
	double step;
	double value[SITE_NUM];
	double res[SITE_NUM];
	step = abs(stop - start) / 4.0;
	SERIAL value[SITE] = (stop + start) / 2.0;
//	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_5UA, ACM_RELAY_ON);
	for (int i = 0; i < stepcount; i++){
		if (hysmode)
		{
			acm_pin.Set(FV, start, v_range, i_range, ACM200_RELAY_ON);

			delay_us(delaytime_us);
		}

		acm_pin.SetSyn(FV, value, SITE_NUM, v_range, i_range, ACM200_RELAY_ON,1.0);

		delay_us(delaytime_us);
		fxvie_cap.MeasureVI(5, 10);
		SERIAL
		{
			res[SITE] = fxvie_cap.GetMeasResult(SITE, MVRET);
			if (trig_mode == TRIG_FALLING)
			{
				if (res[SITE] < 2.5)
					value[SITE] -= step;
				else
					value[SITE] += step;
			}
			else
			{
				if (res[SITE] < 2.5)
					value[SITE] += step;
				else
					value[SITE] -= step;
			}
		}
		step = step / 2.0;
	}
	SERIAL result[SITE] = value[SITE];
	acm_pin.Set(FV, holdvalue, v_range, i_range, ACM200_RELAY_ON);
}

void vth_binary_search(FXVIe_PLUS fxvi_pin, FXVIe_PLUS fxvie_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us, int hysmode, TRIG_MODE trig_mode){
	double step;
	double value[SITE_NUM];
	double res[SITE_NUM];
	step = abs(stop - start) / 4.0;
	SERIAL value[SITE] = (stop + start) / 2.0;
//	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_5UA, ACM_RELAY_ON);
	for (int i = 0; i < stepcount; i++){
		if (hysmode)
		{
			fxvi_pin.Set(FV, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);

			delay_us(delaytime_us);
		}

		fxvi_pin.SetSyn(FV, value, SITE_NUM, v_range, i_range, FXVIe_PLUS_RELAY_ON,1.0);

		delay_us(delaytime_us);
		fxvie_cap.MeasureVI(5, 10);
		SERIAL
		{
			res[SITE] = fxvie_cap.GetMeasResult(SITE, MVRET);
			if (trig_mode == TRIG_FALLING)
			{
				if (res[SITE] < 2.5)
					value[SITE] -= step;
				else
					value[SITE] += step;
			}
			else
			{
				if (res[SITE] < 2.5)
					value[SITE] += step;
				else
					value[SITE] -= step;
			}
		}
		step = step / 2.0;
	}
	SERIAL result[SITE] = value[SITE];
	fxvi_pin.Set(FV, holdvalue, v_range, i_range, FXVIe_PLUS_RELAY_ON);
}
void SCAN_TEST(FOVIe vddpin, double vdd, const char* pingrp, const char* pincap, const char* startlabel, const char* stoplabel, int samplesize, int interval, double *results_i, double *results_v, ULONG *failcount, int measuretype)
{
	double vih;
	double vil;
	double voh;
	double vol;
	if (vdd<4.0)
		vih = vdd / 2.0 + 1.0;
	else
		vih = vdd / 2.0 ;
	voh = vdd / 2.0;
	vol = voh - 0.5;
	vil = 0;
	if (measuretype == 0)
	{
		vddpin.Set(FV, vdd, FOVIe_10V, FOVIe_100MA, FOVIe_RELAY_ON, 1.0);//will check current of Vout
		delay_ms(5);
	}
	dcm.SetPinLevel(pingrp, vih, vil, voh, vol);
	int nRetVal = dcm.RunVectorEn(pingrp, startlabel, stoplabel);//4MHz with 1M pattern about 250ms
	if ((measuretype == 0 )|| (measuretype == 2))
	{
		vddpin.MeasureVI(samplesize, interval, FOVIe_MI_X1, MEAS_AWG);// test  250ms Iq
		STSEnableMeas(&vddpin);
	}
	STSAWGRun();
	if (measuretype==1)
	{
		delay_ms(8);
		if (strcmp(startlabel, "IDDQ_START") == 0)
			delay_ms(10);
		//some device need long delay to avoid Idqq delta fail due to some functions working

		vddpin.MeasureVI(samplesize, interval, FOVIe_MI_X10, MEAS_NORMAL);

		SERIAL
		{
			results_i[SITE] = vddpin.GetMeasResult(SITE, MIRET);
			results_v[SITE] = vddpin.GetMeasResult(SITE, MVRET);
			dcm.GetFailCount(pincap, SITE, failcount[SITE]);
		}
			//if (strcmp(startlabel, "IDDQ0") == 0)
	}
	else
	{
		SERIAL
		{
			results_i[SITE] = vddpin.GetMeasResult(SITE, MIRET, MAX_RESULT);
			results_v[SITE] = vddpin.GetMeasResult(SITE, MVRET, MIN_RESULT);
			dcm.GetFailCount(pincap, SITE, failcount[SITE]);
		}
	}

}
void SCAN_TEST(ACM vddpin, double vdd, const char* pingrp, const char* pincap, const char* startlabel, const char* stoplabel, int samplesize, int interval, double *results_i, ULONG *failcount, int measuretype)
{
	double vih;
	double vil;
	double voh;
	double vol;
	if (vdd<4.0)
		vih = vdd / 2.0 + 1.0;
	else
		vih = vdd / 2.0;
	voh = vdd / 2.0;
	vol = voh - 0.5;
	vil = 0;
	if (measuretype == 0)
	{
		vddpin.Set(FV, vdd, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON, 1.0);//will check current of Vout
		delay_ms(1);
	}
	dcm.SetPinLevel(pingrp, vih, vil, voh, vol);
	int nRetVal = dcm.RunVectorEn(pingrp, startlabel, stoplabel);//4MHz with 1M pattern about 250ms
	if ((measuretype == 0) || (measuretype == 2))
	{
		vddpin.MeasureVI(ACM_MI,samplesize, interval, MEAS_AWG);// test  250ms Iq
		STSEnableMeas(&vddpin);
	}
	STSAWGRun();
	if (measuretype == 1)
	{
		vddpin.Set(FV, vdd, ACM_N2P18V, ACM_200UA, ACM_RELAY_ON);//will check current of Vout

		delay_ms(4);
		if (strcmp(startlabel, "IDDQ_START") == 0)
			delay_ms(1);
		//some device need long delay to avoid Idqq delta fail due to some functions working

		vddpin.MeasureVI(ACM_MI,samplesize, interval, MEAS_NORMAL);
		vddpin.Set(FV, vdd, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON);//will check current of Vout

		SERIAL
		{
			results_i[SITE] = vddpin.GetMeasResult(SITE);
			dcm.GetFailCount(pincap, SITE, failcount[SITE]);
		}
			//if (strcmp(startlabel, "IDDQ0") == 0)
	}
	else
	{
		SERIAL
		{
			results_i[SITE] = vddpin.GetMeasResult(SITE, MAX_RESULT);
			//results_v[SITE] = vddpin.GetMeasResult(SITE, MVRET, MIN_RESULT);
			dcm.GetFailCount(pincap, SITE, failcount[SITE]);
		}
	}

}
void SCAN_TEST(FOVIe vddpin, double vdd, const char* pingrp, const char* pincap, const char* startlabel, const char* stoplabel, int samplesize, int interval, double *results_i, ULONG *failcount, int measuretype)
{
	double vih;
	double vil;
	double voh;
	double vol;
	if (vdd<4.0)
		vih = vdd / 2.0 + 1.0;
	else
		vih = vdd / 2.0;
	voh = vdd / 2.0;
	vol = voh - 0.5;
	vil = 0;
	if (measuretype == 0)
	{
		vddpin.Set(FV, vdd, FOVIe_10V, FOVIe_100MA, FOVIe_RELAY_ON, 1.0);//will check current of Vout
		delay_ms(5);
	}
	dcm.SetPinLevel(pingrp, vih, vil, voh, vol);
	int nRetVal = dcm.RunVectorEn(pingrp, startlabel, stoplabel);//4MHz with 1M pattern about 250ms
	if ((measuretype == 0) || (measuretype == 2))
	{
		vddpin.MeasureVI( samplesize, interval,FOVIe_MI_X1, MEAS_AWG);// test  250ms Iq
		STSEnableMeas(&vddpin);
	}
	STSAWGRun();
	if (measuretype == 1)
	{
		vddpin.Set(FV, vdd, FOVIe_10V, FOVIe_1MA, FOVIe_RELAY_ON);//will check current of Vout

		delay_ms(8);
		if (strcmp(startlabel, "IDDQ_START") == 0)
			delay_ms(10);
		//some device need long delay to avoid Idqq delta fail due to some functions working

		vddpin.MeasureVI(samplesize, interval, FOVIe_MI_X1, MEAS_NORMAL);
		vddpin.Set(FV, vdd, FOVIe_10V, FOVIe_100MA, FOVIe_RELAY_ON);//will check current of Vout

		SERIAL
		{
			results_i[SITE] = vddpin.GetMeasResult(SITE,MIRET);
			dcm.GetFailCount(pincap, SITE, failcount[SITE]);
		}
			//if (strcmp(startlabel, "IDDQ0") == 0)
	}
	else
	{
		SERIAL
		{
			results_i[SITE] = vddpin.GetMeasResult(SITE, MIRET,MAX_RESULT);
			//results_v[SITE] = vddpin.GetMeasResult(SITE, MVRET, MIN_RESULT);
			dcm.GetFailCount(pincap, SITE, failcount[SITE]);
		}
	}

}
void I2CWriteData(BYTE bySAddress, DWORD dwRegAddress, DWORD data)
{
	//0 write, 1 read
	DWORD wrdata[SITE_NUM];
	DWORD iic40bits;
	DWORD crcdata;

	iic40bits = ((DWORD)bySAddress << 24) | (dwRegAddress << 16) | (data << 0);
	crcdata = IIC_calculateCRC2(iic40bits);
	for (int site = 0; site < SITE_NUM; site++)
	{
		wrdata[site] = (data << 8) | crcdata;
	}
	 

	dcm.I2CWriteData(bySAddress, dwRegAddress, 3, wrdata);//3��byte����

}
void I2CWriteMData(BYTE bySAddress, DWORD dwRegAddress, DWORD data[SITE_NUM])
{
	DWORD wrdata[SITE_NUM];
	DWORD iic40bits;
	DWORD crcdata;
	for (int site = 0; site < SITE_NUM; site++)
	{
		iic40bits = ((DWORD)bySAddress << 24) | (dwRegAddress << 16) | (data[site] << 0);
		crcdata = IIC_calculateCRC2(iic40bits);
		wrdata[site] = (data[site] << 8) | crcdata;
	}
	
	dcm.I2CWriteData(bySAddress, dwRegAddress, 3, wrdata);

}
void I2CWriteData(DWORD dwRegAddress, DWORD data, int main_fs)
{
	DWORD wrdata[SITE_NUM];
	DWORD iic40bits;
	DWORD crcdata;
	DWORD bySAddress1;
	if (main_fs == 0)
		bySAddress1 = I2C_ADDR_DEVICE;
	else
		bySAddress1 = I2C_ADDR_DEVICE_FS;
	iic40bits = (bySAddress1 << 24) | (dwRegAddress << 16) | (data << 0);
	crcdata=IIC_calculateCRC2(iic40bits);
	//iic40bits = (bySAddress1 << 32) | (dwRegAddress << 24) | (data << 8);
	//crcdata = IIC_calculateCRC(iic40bits);
	for (int site = 0; site < SITE_NUM; site++)
	{
		wrdata[site] = (data << 8) | crcdata;
	}

	if (main_fs==0)
		dcm.I2CWriteData(I2C_ADDR_DEVICE, dwRegAddress, 3, wrdata);
	else
		dcm.I2CWriteData(I2C_ADDR_DEVICE_FS, dwRegAddress, 3, wrdata);
}
void I2CWriteMData(DWORD dwRegAddress, DWORD data[SITE_NUM], int main_fs)
{
	DWORD wrdata[SITE_NUM];
	DWORD iic40bits;
	DWORD crcdata;
	DWORD bySAddress1;
	if (main_fs == 0)
		bySAddress1 = I2C_ADDR_DEVICE;
	else
		bySAddress1 = I2C_ADDR_DEVICE_FS;

	for (int site = 0; site < SITE_NUM; site++)
	{
		iic40bits = (bySAddress1 << 24) | (dwRegAddress << 16) | (data[site] << 0);
		crcdata = IIC_calculateCRC2(iic40bits);
		wrdata[site] = (data[site] << 8) | crcdata;
	}

	if (main_fs == 0)
		dcm.I2CWriteData(I2C_ADDR_DEVICE, dwRegAddress, 3, wrdata);
	else
		dcm.I2CWriteData(I2C_ADDR_DEVICE_FS, dwRegAddress, 3, wrdata);

}

BOOL OS_Classify(short funcindex, string pin_str_array[], unsigned int OS_NUM, double os_result[][SITE_NUM])
{
	if (OS_NUM == 0) return FALSE;
	unsigned int open_count[SITE_NUM] = { 0 };
	int SHORT_FLAG[SITE_NUM] = { 0 };
	int SOME_OPEN_FLAG[SITE_NUM] = { 0 };
	int ALL_OPEN_FLAG[SITE_NUM] = { 0 };
	CParam *OS_Param;

	for (unsigned int os_count = 0; os_count < OS_NUM; ++os_count){
		OS_Param = StsGetParam(funcindex, pin_str_array[os_count].c_str());
		double spec_l = OS_Param->GetMinLimit();
		double spec_h = OS_Param->GetMaxLimit();
		SERIAL{
			if (spec_l > 0){
				if (os_result[os_count][SITE] < spec_l)
					SHORT_FLAG[SITE] = 1;
				if (SHORT_FLAG[SITE] != 1 && (os_result[os_count][SITE] > spec_h))
					open_count[SITE]++;
			}
			if (spec_h < 0){
				if (os_result[os_count][SITE] >spec_h)
					SHORT_FLAG[SITE] = 1;
				if (SHORT_FLAG[SITE] != 1 && (os_result[os_count][SITE] < spec_l))
					open_count[SITE]++;
			}
		}
	}



	SERIAL    //judge some open or all open 
	{
		if (SHORT_FLAG[SITE] != 1 && open_count[SITE] == OS_NUM)
		ALL_OPEN_FLAG[SITE] = 1;
		else if ((SHORT_FLAG[SITE] != 1) && (open_count[SITE] < OS_NUM) && (open_count[SITE] > 0))
			SOME_OPEN_FLAG[SITE] = 1;
	}

	SERIAL	StsGetParam(funcindex, "OS_SHORT")->SetTestResult(SITE, 0, SHORT_FLAG[SITE]);
	SERIAL	StsGetParam(funcindex, "OS_SOME_OPEN")->SetTestResult(SITE, 0, SOME_OPEN_FLAG[SITE]);
	SERIAL	StsGetParam(funcindex, "OS_ALL_OPEN")->SetTestResult(SITE, 0, ALL_OPEN_FLAG[SITE]);

	return TRUE;
}
void power_off(int debug)
{

	if (debug)
	{
		VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
		VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
		VBOS_1.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		delay_ms(5);//for discharge


	
		for (int i = 0; i < 12; i++)
			acm_grp[i].TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
		for (int i = 0; i < 6; i++)
			fxvie_grp[i].TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
		STSTArming();
		dcm.InitPPMU("DCM_ALLPINS");
		dcm.InitMCU("DCM_ALLPINS");
		dcm.Disconnect("DCM_ALLPINS");
		ALL_QVM.Disconnect();
		FPVIM.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);

		cbite.SetOn(-1);
		delay_ms(2);

	}
}
void power_off2(int debug)
{
	if (debug)
	{

		
	


	}
}

void OTP_M_Preview(int banknum, int bankcount)
{
	ULONG data0[SITE_NUM] = { 0 };
	string EE_str;

	
	if (banknum == -1)
	{
		for (int reg = 0; reg<BANK_NUM-1; ++reg){
			for (int site = 0; site<SITE_NUM; site++) data0[site] = 0;

			EE_str = "MBANK" + to_string(reg);
			SERIAL data0[SITE] = dut.assy(EE_str.c_str()).get_working(SITE);
			SPIWrite(0x0020+reg, data0);
		
		}
		
	}
	else
	{
		for (int reg = 0; reg<bankcount; ++reg){
			if (banknum >= BANK_NUM)	banknum = BANK_NUM - 1;
			if (bankcount >= BANK_NUM)	bankcount = BANK_NUM - 1;
			for (int site = 0; site<SITE_NUM; site++) data0[site] = 0;

			EE_str = "MBANK" + to_string(reg + banknum);
			SERIAL data0[SITE] = dut.assy(EE_str.c_str()).get_working(SITE);
			SPIWrite(0x0020 + banknum+reg, data0);
		}
		
	}


}
void OTP_FS_Preview()
{
	ULONG data0[SITE_NUM] = { 0 };
	string EE_str;

	SERIAL data0[SITE] = dut.assy("FSBANK0").get_working(SITE);
	SPIWrite(0x0050, data0);
		


}

void load_mapping(string pathmap, XY_COOR mappingdata[])
{
	ifstream mapdata;
	string linedata;
	istringstream linestr;
	string data0;


	int x1;
	int y1;
	int dieid1;
	int xx = 0;
	int count = 0;
	mapdata.open(pathmap.c_str(), ios::in);

	if (!mapdata)	exit(0);
	getline(mapdata, linedata);
	while (getline(mapdata, linedata))
	{
		linestr.clear();
		linestr.str(linedata);
		xx = 0;
		while (getline(linestr, data0, ','))
		{
			if (xx == 0) x1 = atoi(data0.c_str());
			if (xx == 1) y1 = atoi(data0.c_str());
			if (xx == 2) dieid1 = atoi(data0.c_str());
			xx++;
		}
		mappingdata[count].xx_coor = x1;
		mappingdata[count].yy_coor = y1;
		mappingdata[count].dieid_coor = dieid1;
		count++;
	}
	mapdata.close();
}
int dieid_search_mapping(int xx, int yy)
{
	for (int i = 0; i < 4000; i++)
		if ((maprslt[i].xx_coor == xx) && (maprslt[i].yy_coor == yy))
			return maprslt[i].dieid_coor;

	
	return 0;
}



// ���� CRC �ĺ���
ULONG SPI_calculateCRC(ULONG data) {
	ULONG crc = 0;

	// ���� CRC_7
	crc |= ((((data >> 31) & 1) ^ ((data >> 24) & 1) ^ ((data >> 23) & 1) ^ ((data >> 22) & 1) ^
		((data >> 20) & 1) ^ ((data >> 17) & 1) ^ ((data >> 13) & 1) ^ ((data >> 12) & 1) ^
		((data >> 11) & 1) ^ 1 ^ 1) << 7);

	// ���� CRC_6
	crc |= ((((data >> 31) & 1) ^ ((data >> 30) & 1) ^ ((data >> 23) & 1) ^ ((data >> 22) & 1) ^
		((data >> 21) & 1) ^ ((data >> 19) & 1) ^ ((data >> 16) & 1) ^ ((data >> 12) & 1) ^
		((data >> 11) & 1) ^ ((data >> 10) & 1) ^ 1 ^ 1) << 6);

	// ���� CRC_5
	crc |= ((((data >> 30) & 1) ^ ((data >> 29) & 1) ^ ((data >> 22) & 1) ^ ((data >> 21) & 1) ^
		((data >> 20) & 1) ^ ((data >> 18) & 1) ^ ((data >> 15) & 1) ^ ((data >> 11) & 1) ^
		((data >> 10) & 1) ^ ((data >> 9) & 1) ^ 1 ^ 1) << 5);

	// ���� CRC_4
	crc |= ((((data >> 29) & 1) ^ ((data >> 28) & 1) ^ ((data >> 21) & 1) ^ ((data >> 20) & 1) ^
		((data >> 19) & 1) ^ ((data >> 17) & 1) ^ ((data >> 14) & 1) ^ ((data >> 10) & 1) ^
		((data >> 9) & 1) ^ ((data >> 8) & 1) ^ 1 ^ 1) << 4);

	// ���� CRC_3
	crc |= ((((data >> 28) & 1) ^ ((data >> 27) & 1) ^ ((data >> 24) & 1) ^ ((data >> 23) & 1) ^
		((data >> 22) & 1) ^ ((data >> 19) & 1) ^ ((data >> 18) & 1) ^ ((data >> 17) & 1) ^
		((data >> 16) & 1) ^ ((data >> 12) & 1) ^ ((data >> 11) & 1) ^ ((data >> 9) & 1) ^
		((data >> 8) & 1) ^ 1 ^ 1 ^ 1) << 3);

	// ���� CRC_2
	crc |= ((((data >> 27) & 1) ^ ((data >> 26) & 1) ^ ((data >> 24) & 1) ^ ((data >> 21) & 1) ^
		((data >> 20) & 1) ^ ((data >> 18) & 1) ^ ((data >> 16) & 1) ^ ((data >> 15) & 1) ^
		((data >> 13) & 1) ^ ((data >> 12) & 1) ^ ((data >> 10) & 1) ^ ((data >> 8) & 1) ^
		1 ^ 1 ^ 1) << 2);

	// ���� CRC_1
	crc |= ((((data >> 26) & 1) ^ ((data >> 25) & 1) ^ ((data >> 24) & 1) ^ ((data >> 22) & 1) ^
		((data >> 19) & 1) ^ ((data >> 15) & 1) ^ ((data >> 14) & 1) ^ ((data >> 13) & 1) ^
		((data >> 9) & 1) ^ 1 ^ 1 ^ 1) << 1);

	// ���� CRC_0
	crc |= ((((data >> 25) & 1) ^ ((data >> 24) & 1) ^ ((data >> 23) & 1) ^ ((data >> 21) & 1) ^
		((data >> 18) & 1) ^ ((data >> 14) & 1) ^ ((data >> 13) & 1) ^ ((data >> 12) & 1) ^
		((data >> 8) & 1) ^ 1 ^ 1));

	return crc;
}



// ����һ���㹻����������洢���ݣ�����ʹ�� unsigned long long(64λ�� ��֧����� B39 λ


// ���㵥�� CRC λ�ĺ���
ULONG calculateSingleCRC(ULONG data, const int* bitPositions, int bitCount, int onesCount) {
	ULONG result = 0;
	for (int i = 0; i < bitCount; ++i) {
		result ^= (data >> bitPositions[i]) & 1;
	}
	for (int i = 0; i < onesCount; ++i) {
		result ^= 1;
	}
	return result;
}

// �������� CRC �ĺ���
ULONG IIC_calculateCRC(ULONG data) {
	ULONG crc = 0;

	// CRC_7
	const int crc7Positions[] = { 38, 35, 32, 31, 24, 23, 22, 20, 17, 13, 12, 11 };
	crc |= calculateSingleCRC(data, crc7Positions, 12, 3) << 7;

	// CRC_6
	const int crc6Positions[] = { 37, 34, 23, 22, 21, 19, 16, 12, 11, 10 };
	crc |= calculateSingleCRC(data, crc6Positions, 10, 2) << 6;

	// CRC_5
	const int crc5Positions[] = { 39, 36, 33, 30, 29, 22, 21, 20, 18, 15, 11, 10, 9 };
	crc |= calculateSingleCRC(data, crc5Positions, 13, 3) << 5;

	// CRC_4
	const int crc4Positions[] = { 39, 38, 35, 32, 29, 28, 21, 20, 19, 17, 14, 10, 9, 8 };
	crc |= calculateSingleCRC(data, crc4Positions, 14, 4) << 4;

	// CRC_3
	const int crc3Positions[] = { 37, 35, 34, 32, 28, 27, 24, 23, 22, 19, 18, 17, 16, 12, 11, 9, 8 };
	crc |= calculateSingleCRC(data, crc3Positions, 17, 4) << 3;

	// CRC_2
	const int crc2Positions[] = { 39, 38, 36, 35, 34, 33, 32, 27, 26, 24, 21, 20, 18, 16, 15, 13, 12, 10, 8 };
	crc |= calculateSingleCRC(data, crc2Positions, 19, 7) << 2;

	// CRC_1
	const int crc1Positions[] = { 37, 34, 33, 26, 25, 24, 22, 19, 15, 14, 13, 9 };
	crc |= calculateSingleCRC(data, crc1Positions, 12, 3) << 1;

	// CRC_0
	const int crc0Positions[] = { 39, 36, 33, 32, 25, 24, 23, 21, 18, 14, 13, 12, 8 };
	crc |= calculateSingleCRC(data, crc0Positions, 13, 4);

	return crc;
}
// �������� CRC �ĺ���
ULONG IIC_calculateCRC2(ULONG data) {
	ULONG crc = 0;

	// CRC_7
	const int crc7Positions[] = { 30, 27, 24, 23, 16, 15, 14, 12, 9, 5, 4, 3 };
	crc |= calculateSingleCRC(data, crc7Positions, 12, 3) << 7;

	// CRC_6
	const int crc6Positions[] = { 37-8, 34-8, 23-8, 22-8, 21-8, 19-8, 16-8, 12-8, 11-8, 10-8 };
	crc |= calculateSingleCRC(data, crc6Positions, 10, 2) << 6;

	// CRC_5
	const int crc5Positions[] = { 39-8, 36-8, 33-8, 30-8, 29-8, 22-8, 21-8, 20-8, 18-8, 15-8, 11-8, 10-8, 9-8 };
	crc |= calculateSingleCRC(data, crc5Positions, 13, 3) << 5;

	// CRC_4
	const int crc4Positions[] = { 39-8, 38-8, 35-8, 32-8, 29-8, 28-8, 21-8, 20-8, 19-8, 17-8, 14-8, 10-8, 9-8, 8-8 };
	crc |= calculateSingleCRC(data, crc4Positions, 14, 4) << 4;

	// CRC_3
	const int crc3Positions[] = { 37-8, 35-8, 34-8, 32-8, 28-8, 27-8, 24-8, 23-8, 22-8, 19-8, 18-8, 17-8, 16-8, 12-8, 11-8, 9-8, 8-8 };
	crc |= calculateSingleCRC(data, crc3Positions, 17, 4) << 3;

	// CRC_2
	const int crc2Positions[] = { 39-8, 38-8, 36-8, 35-8, 34-8, 33-8, 32-8, 27-8, 26-8, 24-8, 21-8, 20-8, 18-8, 16-8, 15-8, 13-8, 12-8, 10-8, 8-8 };
	crc |= calculateSingleCRC(data, crc2Positions, 19, 7) << 2;

	// CRC_1
	const int crc1Positions[] = { 37-8, 34-8, 33-8, 26-8, 25-8, 24-8, 22-8, 19-8, 15-8, 14-8, 13-8, 9-8 };
	crc |= calculateSingleCRC(data, crc1Positions, 12, 3) << 1;

	// CRC_0
	const int crc0Positions[] = { 39-8, 36-8, 33-8, 32-8, 25-8, 24-8, 23-8, 21-8, 18-8, 14-8, 13-8, 12-8, 8-8 };
	crc |= calculateSingleCRC(data, crc0Positions, 13, 4);

	return crc;
}
//main=0;fs=1
void SPIInitial(double vih, double vil, double voh, double vol, double period)
{

	dcm.InitMCU("SPI_G");
	dcm.SetPinLevel("SPI_G", vih, vil, voh, vol);
	dcm.Connect("SPI_G");
	if (period > 20)//default use pattern setting
	{


		dcm.SetPeriod("SPI", period);
		dcm.SetEdge("SPI_G1", "SPI", DCM_DTFT_NRZ, period*0.05, period*0.9, period*0.1, period*0.7);
		dcm.SetEdge("SCLK", "SPI", DCM_DTFT_RZ, period*0.25, period*0.75, period*0.25, period*0.5);
	}
	

}
void SPIWrite(ULONG addr, ULONG datain[SITE_NUM])
{
	ULONG wdata_wocrc;
	ULONG wdata;
	ULONG wcrcdata[SITE_NUM] = { 0 };
	ULONG dataout[SITE_NUM] = { 0 };
	//dcm.WriteWaveData("MOSI", "W_REG_ADDR", DCM_ALLSITE, 0, 7, addr);

	SERIAL
	{
		wdata_wocrc = (addr << 25) | 0x01000000 | (datain[SITE] << 8);
		wdata = wdata_wocrc | SPI_calculateCRC(wdata_wocrc);
	
		dcm.WriteWaveData("MOSI", "W_REG_ADDR", SITE, 0, 32, wdata);

	}


	int i = dcm.RunVectorWithGroup("SPI_G","SPIWrite", "SPIWrite_End");
	//for debug to check status
	if (DEBUG)
	{
		SERIAL
		{

			dcm.GetCaptureData("MISO_D", "W_REG_ADDR", SITE, 0, 32, wcrcdata[SITE]);
			dataout[SITE] = (wcrcdata[SITE] >> 8) & 0x00FFFF;//data
			//crcdataout[SITE] = wcrcdata[SITE] & 0x0000FF;
		}
	}

}
void SPIWrite_SYNC(ULONG addr, ULONG datain[SITE_NUM])
{
	ULONG wdata_wocrc;
	ULONG wdata;
	ULONG wcrcdata[SITE_NUM] = { 0 };
	ULONG dataout[SITE_NUM] = { 0 };
	//dcm.WriteWaveData("MOSI", "W_REG_ADDR", DCM_ALLSITE, 0, 7, addr);

	SERIAL
	{
		wdata_wocrc = (addr << 25) | 0x01000000 | (datain[SITE] << 8);
		wdata = wdata_wocrc | SPI_calculateCRC(wdata_wocrc);
		
		dcm.WriteWaveData("MOSI", "W_REG_ADDR", SITE, 0, 32, wdata);

	}
		//standby , not running yet , for sync with awg
	int i=dcm.RunVectorEn("SPI_G", "SPIWrite", "SPIWrite_End");



}
void SPIWrite_SYNC(ULONG addr, ULONG datain)
{
	ULONG wdata_wocrc;
	ULONG wdata;
	ULONG wcrcdata[SITE_NUM] = { 0 };
	ULONG dataout[SITE_NUM] = { 0 };
	//dcm.WriteWaveData("MOSI", "W_REG_ADDR", DCM_ALLSITE, 0, 7, addr);
	wdata_wocrc = (addr << 25) | 0x01000000 | (datain << 8);
	wdata = wdata_wocrc | SPI_calculateCRC(wdata_wocrc);

	dcm.WriteWaveData("MOSI", "W_REG_ADDR", DCM_ALLSITE, 0, 32, wdata);

	//standby , not running yet , for sync with awg
	int i = dcm.RunVectorEn("SPI_G", "SPIWrite", "SPIWrite_End");



}
void SPIWrite(ULONG addr, ULONG datain)
{
	ULONG wdata_wocrc;
	ULONG wdata;
	ULONG wcrcdata[SITE_NUM] = { 0 };
	ULONG dataout[SITE_NUM] = { 0 };
	//dcm.WriteWaveData("MOSI", "W_REG_ADDR", DCM_ALLSITE, 0, 7, addr);
	wdata_wocrc = (addr << 25) | 0x01000000 | (datain << 8);
	wdata = wdata_wocrc | SPI_calculateCRC(wdata_wocrc);
	
	dcm.WriteWaveData("MOSI", "W_REG_ADDR", DCM_ALLSITE, 0, 32, wdata);

	int i = dcm.RunVectorWithGroup("SPI_G", "SPIWrite", "SPIWrite_End");
	if (DEBUG)
	{ 
		SERIAL
		{

			dcm.GetCaptureData("MISO_D", "W_REG_ADDR", SITE, 0, 32, wcrcdata[SITE]);
			dataout[SITE] = (wcrcdata[SITE] >> 8) & 0x00FFFF;//data
			//crcdataout[SITE] = wcrcdata[SITE] & 0x0000FF;
		}
	}

}

void SPIRead(ULONG addr, ULONG dataout[SITE_NUM], ULONG crcdataout[SITE_NUM])
{
	ULONG rdata_wocrc;
	ULONG rdata;
	ULONG wcrcdata[SITE_NUM] = { 0 };
	//dcm.WriteWaveData("MOSI", "R_REG_ADDR", DCM_ALLSITE, 0, 7, addr);
	rdata_wocrc = addr << 25;
	rdata = rdata_wocrc | SPI_calculateCRC(rdata_wocrc);
	dcm.WriteWaveData("MOSI", "R_REG_ADDR", DCM_ALLSITE, 0, 32, rdata);
	int i = dcm.RunVectorWithGroup("SPI_G", "SPIRead", "SPIRead_End");

	SERIAL
	{

		dcm.GetCaptureData("MISO_D", "R_REG_ADDR", SITE, 0, 32, wcrcdata[SITE]);
		dataout[SITE] = (wcrcdata[SITE] >> 8) & 0x00FFFF;//data
		crcdataout[SITE] = wcrcdata[SITE] & 0x0000FF;
	}
	

}
void SPIRead(ULONG addr, ULONG dataout[SITE_NUM])
{
	ULONG rdata_wocrc;
	ULONG rdata;
	ULONG wcrcdata[SITE_NUM] = { 0 };
//	dcm.WriteWaveData("MOSI", "R_REG_ADDR", DCM_ALLSITE, 0, 7, addr);
	rdata_wocrc = addr << 25;
	rdata = rdata_wocrc | SPI_calculateCRC(rdata_wocrc);

	dcm.WriteWaveData("MOSI", "R_REG_ADDR", DCM_ALLSITE, 0, 32, rdata);

	int i = dcm.RunVectorWithGroup("SPI_G", "SPIRead", "SPIRead_End");

	SERIAL
	{

		dcm.GetCaptureData("MISO_D", "R_REG_ADDR", SITE, 0, 32, wcrcdata[SITE]);
		dataout[SITE] = (wcrcdata[SITE] >> 8) & 0x00FFFF;//data
		//crcdataout[SITE] = wcrcdata[SITE] & 0x0000FF;
	}


}
void SPIRead(ULONG addr, ULONG dataout[][SITE_NUM], ULONG crcdataout[][SITE_NUM],int count)
{
	ULONG rdata_wocrc;
	ULONG rdata;
	ULONG wcrcdata[SITE_NUM] = { 0 };
	for (int i = 0; i < count; i++)
	{

		rdata_wocrc = (addr + i) << 25;
		rdata = rdata_wocrc | SPI_calculateCRC(rdata_wocrc);

		dcm.WriteWaveData("MOSI", "R_REG_ADDR", DCM_ALLSITE, 0, 32, rdata);
		//dcm.WriteWaveData("MOSI", "R_REG_ADDR", DCM_ALLSITE, 0, 7, addr+i);

		dcm.RunVectorWithGroup("SPI_G", "SPIRead", "SPIRead_End");

		SERIAL
		{

			dcm.GetCaptureData("MISO_D", "R_REG_ADDR", SITE, 0, 32, wcrcdata[SITE]);
			dataout[i][SITE] = (wcrcdata[SITE] >> 8) & 0x00FFFF;//data
			crcdataout[i][SITE] = wcrcdata[SITE] & 0x000000FF;
		}
	}

}

void SPIRead(ULONG addr, ULONG dataout[][SITE_NUM],  int count)
{

	ULONG rdata;
	ULONG rdata_wocrc;
	ULONG wcrcdata[SITE_NUM] = { 0 };
	int retv;
	for (int i = 0; i < count; i++)
	{

		rdata_wocrc = (addr + i) << 25;
		rdata = rdata_wocrc | SPI_calculateCRC(rdata_wocrc);

		dcm.WriteWaveData("MOSI", "R_REG_ADDR", DCM_ALLSITE, 0, 32, rdata);
		//dcm.WriteWaveData("MOSI", "R_REG_ADDR", DCM_ALLSITE, 0, 7, addr + i);

		retv=dcm.RunVectorWithGroup("SPI_G", "SPIRead", "SPIRead_End");

		SERIAL
		{

			dcm.GetCaptureData("MISO_D", "R_REG_ADDR", SITE, 0, 32, wcrcdata[SITE]);
			dataout[i][SITE] = (wcrcdata[SITE] >> 8) & 0x00FFFF;//data
		//	crcdataout[i][SITE] = wcrcdata[SITE] & 0x0000FF;
		}
	}

}

void measure_BGTC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(0);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(10);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];


}

void measure_BGV(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(0);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];

}

void measure_ICT(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(0);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);
	A0_FIN_DBG_ERR_FCCU1.MeasureVI(30, 10);
	SERIAL res[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
	SERIAL results[SITE] = -res[SITE];
}
void measure_CLK1_FSW_DCM(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(0,2);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(2);
	dcm.TMUMeasure("FOUT_INTB",DCM_MEAS_FREQ_DUTY,36,5);

	SERIAL
	{
		results[SITE] = dcm.GetTMUMeasureResult("FOUT_INTB", SITE, DCM_FREQ)*1e3;
		if (treg_measure_flag == TREG_MEASURE_PRE || TREG_MEASURE_PRE == TREG_MEASURE_POST)
		g_freq_20MHz[SITE] = results[SITE] * 48 ;//hz
	}

}
void measure_DUTY_DCM( double *results){


	dcm.TMUMeasure("FOUT_INTB", DCM_MEAS_FREQ_DUTY, 36, 5);

	SERIAL
	{
		results[SITE] = dcm.GetTMUMeasureResult("FOUT_INTB", SITE, DCM_HIGH_DUTY);
	
	}

}
void measure_CLK1_FSW_QTMU(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(0,2);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);

	BYTE S_QTMU_GP[2] = { K124_TMU_S1357, K123_TMU_S2468 };
	DWORD validsite;
	int siteconnect;
	original_validsite = 0;
	SERIAL original_validsite += DWORD(pow(2, SITE));
	for (int grp = 0; grp < 2; grp++)
	{
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(2);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_FREQ, 36, 5, QTMUe_TRANGE_MS);
		SERIAL 
		{
			results[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE)*1e3;
			if (treg_measure_flag == TREG_MEASURE_PRE || TREG_MEASURE_PRE == TREG_MEASURE_POST)
			g_freq_20MHz[SITE] = results[SITE] * 48 ;//hz
		}
		cbitopen(S_QTMU_GP[grp]);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}
	

}
void measure_DUTY_QTMU( double *results, double *freq){

	BYTE S_QTMU_GP[2] = { K124_TMU_S1357, K123_TMU_S2468 };
	DWORD validsite;
	int siteconnect;
	original_validsite = 0;
	SERIAL original_validsite += DWORD(pow(2, SITE));
	for (int grp = 0; grp < 2; grp++)
	{
		ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
		ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 20);
		ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(2);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_HIGH_DUTY, 36, 5, QTMUe_TRANGE_MS);
		SERIAL
		{
			results[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE);
		
		}
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_FREQ, 36, 5, QTMUe_TRANGE_MS);
		SERIAL
		{
			freq[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE);

		}
		cbitopen(S_QTMU_GP[grp]);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}


}
void measure_SPSP_DCM(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(0, 2);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(2);
	dcm.TMUMeasure("FOUT_INTB", DCM_MEAS_FREQ_DUTY, 36, 5);

	SERIAL results[SITE] = dcm.GetTMUMeasureResult("FOUT_INTB", SITE, DCM_FREQ);

}
void spsp_freq_test(double *minfreq, double *maxfreq,double *avgfreq,double *carrFreq){
	BYTE S_QTMU_GP[2] = { K124_TMU_S1357, K123_TMU_S2468 };
	DWORD validsite;
	int siteconnect;
	//double minfreq[SITE_NUM] = { 999999 };
	//double maxfreq[SITE_NUM] = { 0 };
	//double avgfreq[SITE_NUM] = { 0 };
	const int datasize=1024;
	double freq[datasize*2+10][SITE_NUM];
	double period1[datasize][SITE_NUM];
	double period2[datasize][SITE_NUM];
	double minperiod[SITE_NUM];
	double maxperiod[SITE_NUM];
	double data1[datasize];
	double data2[datasize];
	double ncount=0;
	double temp;
	original_validsite = 0;
	SERIAL original_validsite += DWORD(pow(2, SITE));
	for (int grp = 0; grp < 2; grp++)
	{
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(2);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_EVENT, datasize*2+10, 10, QTMUe_TRANGE_MS);

		SERIAL
		{
			minperiod[SITE] = 999999;
			maxperiod[SITE] = 0;
			avgfreq[SITE] = 0;
			for (int i = 0; i < datasize*2+10; i++)
			{
				freq[i][SITE] = qtmu_grp[SITE].GetMeasureResult(SITE, i);

			}
			for (int i = 0; i < datasize; i++)//SPSP 
			{
				if (freq[2 * i + 2][SITE]>0)
				{
					period1[i][SITE] = freq[2 * i + 2][SITE] - freq[2 * i][SITE];
					data1[i]=period1[i][SITE] ;
					if (period1[i][SITE]<minperiod[SITE])
						minperiod[SITE] = period1[i][SITE];

					if (period1[i][SITE]>maxperiod[SITE])
						maxperiod[SITE] = period1[i][SITE];

					avgfreq[SITE] += period1[i][SITE];

				}
				else
				{
					minfreq[SITE] = -999999;
					maxfreq[SITE] = -999999;
					break;
				}
			}
			avgfreq[SITE] = 1.0 / (avgfreq[SITE] / datasize + 1e-30)*1e3; //average period, freq=1/average
			minfreq[SITE] = 1.0 / (maxperiod[SITE]+1e-30) * 1e3;//khz
			maxfreq[SITE] = 1.0/(minperiod[SITE]+1e-30)*1e3;//khz
			STSGetFFTData(data1,data2,1024);
			temp=0;
			for(int i=1;i<512;i++)
			{

				if(data2[i]>temp)
				{
					temp=data2[i];
					ncount=i;
				}
			}
			carrFreq[SITE]=avgfreq[SITE]*ncount/1024.0;
		}


		cbitopen(S_QTMU_GP[grp]);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}
}
void measure_SPSP_QTMU(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(0, 2);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);

	BYTE S_QTMU_GP[2] = { K124_TMU_S1357, K123_TMU_S2468 };
	DWORD validsite;
	int siteconnect;
	original_validsite = 0;
	SERIAL original_validsite += DWORD(pow(2, SITE));
	for (int grp = 0; grp < 2; grp++)
	{
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(2);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_FREQ, 36, 5, QTMUe_TRANGE_MS);
		SERIAL results[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE);//scale to HZ

		cbitopen(S_QTMU_GP[grp]);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}


}
void measure_CLK_CHECK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double freqslow[SITE_NUM];
	double freqfast[SITE_NUM];

	OTP_M_Preview(0, 2);
	delay_ms(1);

	//will search different range with different code
	if(treg_measure_flag== TREG_MEASURE_CHAR)
		CLK_SWEEP(freqslow, freqfast,  80, 700, 5);
	else
		CLK_SWEEP(freqslow, freqfast, 100, 400, 5);
	SERIAL{
		g_freq_slow[SITE] = freqslow[SITE];
		g_freq_fast[SITE] = freqfast[SITE];
		results[SITE] = (freqslow[SITE] + freqfast[SITE]) / 2.0*1e3;
	}


}
void CLK_SWEEP(double *freq_slow, double *freq_fast,  double range_min, double range_max, double range_step)
{
	double out_flip[200][SITE_NUM];
	ULONG failcount[SITE_NUM];
	double period;
	int count=0;
	count = (int)((range_max - range_min) / (range_step+1e-30)+1);
	SERIAL_ALL
	{
		freq_slow[SITE] = 0;
		freq_fast[SITE] = 0;

	}
	dcm.SetPinLevel("CLK_CHK_G", 5.0, 0, 2.5, 2.4);
	//dcm.SetPinLevel("FOUT_INTB", 5.0, 0, 2.5, 2.4);
	if (count <= 0)
	{
		return;
	}
	else
	{
		if (count > 200)count = 200;
		for (int i = 0; i < count; i++)
		{
			period = 1.0 / (range_min + range_step*i + 1e-30)*1e6;//scale to ns
			dcm.SetPeriod("CLK_SWEEP", period);
			dcm.SetEdge("FIN_WAKE2", "CLK_SWEEP", DCM_DTFT_RZ,DCM_IO_NRZ, period*0.25, period*0.75, period*0.25, period*0.75, period*0.5);
			dcm.SetEdge("FOUT_INTB", "CLK_SWEEP", DCM_DTFT_RZ, DCM_IO_NRZ, period*0.25, period*0.75, period*0.25, period*0.75, period*0.5);

			int nRetVal = dcm.RunVectorWithGroup("CLK_CHK_G", "CLK_SWEEP_START", "CLK_SWEEP_STOP", true);

			SERIAL
			{
				dcm.GetFailCount("FOUT_INTB_D", SITE, failcount[SITE]);
				out_flip[i][SITE] = failcount[SITE];
			}
		}
		SERIAL
		{
			for (int i = 0; i < count; i++)
			{
		
				if (out_flip[i][SITE] == 0)
				{
					freq_slow[SITE] = range_min + range_step * i;
					break;
				}

			}
			
		}
			SERIAL
		{
			for (int i = count-1; i > -1; i--)
			{
			
				if (out_flip[i][SITE] == 0)
				{
					freq_fast[SITE] = range_min + range_step * i;
					break;
				}

			}

		}
		
	}

}

void measure_FREQ_DCM( double *results){


	dcm.TMUMeasure("FOUT_INTB", DCM_MEAS_FREQ_DUTY, 36, 5);

	SERIAL
	{
		results[SITE] = dcm.GetTMUMeasureResult("FOUT_INTB", SITE, DCM_FREQ);
		
	}

}

int measure_FREQ_DCM(){


	dcm.TMUMeasure("FOUT_INTB", DCM_MEAS_FREQ_DUTY, 36, 5);

	SERIAL
	{
		glb_res[SITE] = dcm.GetTMUMeasureResult("FOUT_INTB", SITE, DCM_FREQ);

	}
	return 0;
}
void measure_FREQ_QTMU( double *results){

	BYTE S_QTMU_GP[2] = { K124_TMU_S1357, K123_TMU_S2468 };
	DWORD validsite;
	int siteconnect;
	original_validsite = 0;
	SERIAL original_validsite += DWORD(pow(2, SITE));
	for (int grp = 0; grp < 2; grp++)
	{
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(3);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_FREQ, 36, 5, QTMUe_TRANGE_MS);
		SERIAL
		{
			results[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE);
		}
		cbitopen(S_QTMU_GP[grp]);
		delay_ms(2);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}


}

void measure_ON_OFF_QTMU(double* results,double* freq,QTMUe_SLOPE slopstart,QTMUe_SLOPE slopstop,double startv,double stopv) {

	BYTE S_QTMU_GP[2] = { K124_TMU_S1357, K123_TMU_S2468 };
	DWORD validsite;
	int siteconnect;
	original_validsite = 0;
	SERIAL original_validsite += DWORD(pow(2, SITE));
	for (int grp = 0; grp < 2; grp++)
	{
		if (freq != NULL)
		{
			ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, slopstart, startv, QTMUe_FILTER_PASS, 8);
			ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, slopstop, stopv, QTMUe_FILTER_PASS, 5);
		}
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(3);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_TIME, 36, 5, QTMUe_TRANGE_MS);
		SERIAL
		{
			results[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE);
		}
		if (freq != NULL)
		{
			ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_FREQ, 36, 5, QTMUe_TRANGE_MS);
			SERIAL
			{
				freq[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE);
			}
		
		}
		cbitopen(S_QTMU_GP[grp]);
		delay_ms(2);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}


}
void measure_ON_OFF_QTMU_wBUFF(double* onTime, double* freq ,QTMUe_SLOPE slopstart,QTMUe_SLOPE slopstop,double startv,double stopv) {

	BYTE S_QTMU_GP[2] = { K126_DBUFF_S1357, K125_DBUFF_S2468 };
	DWORD validsite;
	int siteconnect;
	double all_points[100][SITE_NUM];
	double temp;
	original_validsite = 0;
	SERIAL original_validsite += DWORD(pow(2, SITE));
	for (int grp = 0; grp < 2; grp++)
	{
		if (freq != NULL)
		{
			ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, slopstart, startv, QTMUe_FILTER_PASS, 5);
			ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, slopstop, stopv, QTMUe_FILTER_PASS, 5);
		}
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(3);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_TIME, 30, 5, QTMUe_TRANGE_MS);
		SERIAL
		{
			onTime[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE);



		}
		if (freq != NULL)
		{
			ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_FREQ, 30, 5, QTMUe_TRANGE_MS);
			SERIAL
			{
				freq[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE);

			}
		}
		cbitopen(S_QTMU_GP[grp]);
		delay_ms(2);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}


}

void measure_PLL_QTMU(double *results){

	BYTE S_QTMU_GP[2] = { K124_TMU_S1357, K123_TMU_S2468 };
	double cap[SITE_NUM][4000];
	double cap1[SITE_NUM][2100];
	int start1[SITE_NUM] = { 0 };
	int stop1[SITE_NUM] = { 0 };
	double time1[SITE_NUM] = { 0 };
	DWORD validsite;
	int siteconnect;
	original_validsite = 0;
	SERIAL original_validsite += DWORD(pow(2, SITE));
	for (int grp = 0; grp < 2; grp++)
	{
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(1);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_EVENT, 4100, 20, QTMUe_TRANGE_MS);
		int nRetVal = dcm.RunVectorWithGroup("FIN_WAKE2", "SYNC4_START", "SYNC4_STOP", 0);
		//SPIWrite(0x05, 0x1840);
		delay_ms(20);
		//Will check if change to event
		
		SERIAL
		{
			for (int i = 0; i < 4000;i++)
			{
				cap1[SITE][i] = qtmu_grp[SITE].GetMeasureResult(SITE, i);
			

			}
			for (int i = 0; i < 2000; i++)
			{
				cap[SITE][i] = cap1[SITE][i*2+2] - cap1[SITE][i*2];


			}
			//����5������500K�ڣ�450K�� ��ʼ��ʱ��+/-15k����
			for (int i = 0; i < 595; i++)
			{
				if ((cap[SITE][i] < 385) && (cap[SITE][i]>415) && (cap[SITE][i + 1] < 385) && (cap[SITE][i + 1]>415) && (cap[SITE][i + 2] < 385) && (cap[SITE][i + 2]>415) && (cap[SITE][i + 3] < 385) && (cap[SITE][i + 3]>415) && (cap[SITE][i + 4] < 385) && (cap[SITE][i + 4]>415))//bigger than 400khz
					start1[SITE] = i+4;
		
			}
			for (int i = 0; i < 595; i++)
			{
				if ((cap[SITE][i] < 435) && (cap[SITE][i]>465) && (cap[SITE][i + 1] < 435) && (cap[SITE][i + 1]>465) && (cap[SITE][i + 2] < 435) && (cap[SITE][i + 2]>465) && (cap[SITE][i + 3] < 435) && (cap[SITE][i + 3]>465) && (cap[SITE][i + 4] < 435) && (cap[SITE][i + 4]>465))//bigger than 400khz
				{
					stop1[SITE] = i;
					break;
				}

			}
			for (int i = 0; i < 595; i++)
			{
				if ((i > start1[SITE]) && (i < stop1[SITE]))
					time1[SITE] += 1.0 / (cap[SITE][i]+1e-30)*1e3;//us
			}
			dcm.StopVector("FIN_WAKE2");
			results[SITE] = time1[SITE];
		}
		cbitopen(S_QTMU_GP[grp]);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}


}
void SYNC_SWEEP(double range_min, double range_max, double range_step, double *lockfreqmin, double *lockfreqmax,  int flag_gng,int fin_div)
{

	int valid_site = 0;
	int valid_dly = 0;
	double period;
	double res[SITE_NUM];
	double pass_min = 0.95;
	double pass_max = 1.05;
	int site_measured[SITE_NUM] = {0};
	int site_measured2[SITE_NUM] = { 0 };
	int count = 0;
	count = (int)((range_max - range_min) / (range_step + 1e-30)*0.5 + 1);
	SERIAL_ALL
	{
		lockfreqmin[SITE] = 0;
		lockfreqmax[SITE] = 0;
		site_measured[SITE] = 0;
		site_measured2[SITE] = 0;
	}
		if (count <= 0)
		{
			return;
		}
		else
		{
			if (flag_gng)
			{
				period = 1.0/range_min*1e6;//scale to ns
				//dcm.SetPeriod("CLK_SWEEP", period);
			//	dcm.SetEdge("FIN_WAKE2", "CLK_SWEEP", DCM_DTFT_RZ, DCM_IO_NRZ, period*0.25, period*0.75, period*0.25, period*0.75, period*0.5);
				dcm.SetSynFunction(0, measure_FREQ_DCM);
				dcm.RunVectorWithGroup("PPL_G", "SYNC_START", "SYNC_STOP",0);
				delay_us(100);
				res[SITE] = glb_res[SITE];
				if (fin_div == 1)res[SITE] = res[SITE] * 6.0;
				SERIAL
				{
					lockfreqmin[SITE] = res[SITE];


				}
				dcm.StopVector("PPL_G");
				
				period = 1.0 / range_max*1e6;//scale to ns
				dcm.SetPeriod("CLK_SWEEP", period);
				dcm.SetEdge("FIN_WAKE2", "CLK_SWEEP", DCM_DTFT_RZ, DCM_IO_NRZ, period*0.25, period*0.75, period*0.25, period*0.75, period*0.5);
				dcm.RunVectorWithGroup("FIN_WAKE2", "SYNC_START", "SYNC_STOP", 0);
				delay_us(100);
				measure_FREQ_DCM(res);
				if (fin_div == 1)res[SITE] = res[SITE] * 6.0;
				SERIAL
				{
					lockfreqmax[SITE] = res[SITE];


				}
				dcm.StopVector("FIN_WAKE2");

			}
			else
			{
				//only for temp char ,can adjust to binary search
				if (count > 20)count = 20;
				for (int i = 0; i < count; i++)
				{
					period = 1.0/(range_min + i*range_step)*1e6;
					//dcm.SetPeriod("CLK_SWEEP", period);
					//dcm.SetEdge("FIN_WAKE2", "CLK_SWEEP", DCM_DTFT_RZ, DCM_IO_NRZ, period*0.25, period*0.75, period*0.25, period*0.75, period*0.5);
					int nRetVal = dcm.RunVectorWithGroup("PPL_G", "SYNC_START1", "SYNC_STOP1", 0);
					delay_us(100);
				
					measure_FREQ_DCM(res);
					
					valid_site = 0;
					valid_dly = 0;

					SERIAL
					{
							res[SITE] = glb_res[SITE];
						if (fin_div == 1)res[SITE] = res[SITE] * 6.0;
						if (site_measured[SITE] == 0)
						{
							valid_site++;
					

							if ((res[SITE] < ((range_min + i*range_step)*pass_max)) && (res[SITE] > ((range_min + i*range_step)*pass_min)))
							{
								lockfreqmin[SITE] = res[SITE];
								site_measured[SITE] = 1;
								valid_dly++;
							}
						} 


					}
					if (valid_site == valid_dly) break;
				}

				for (int i = 0; i < count; i++)
				{
					period = 1.0 / (range_max - i*range_step)*1e6;
				//	dcm.SetPeriod("CLK_SWEEP", period);
				//	dcm.SetEdge("FIN_WAKE2", "CLK_SWEEP", DCM_DTFT_RZ, DCM_IO_NRZ, period*0.25, period*0.75, period*0.25, period*0.75, period*0.5);
					int nRetVal = dcm.RunVectorWithGroup("PPL_G", "SYNC_START1", "SYNC_STOP1", 0);
					delay_us(100);
					measure_FREQ_DCM(res);

					valid_site = 0;
					valid_dly = 0;
					SERIAL
					{
						if (fin_div == 1)res[SITE] = res[SITE] * 6.0;
						if (site_measured2[SITE] == 0)
						{
							valid_site++;

							if ((res[SITE] < ((range_min + i*range_step)*pass_max)) && (res[SITE] > ((range_min + i*range_step)*pass_min)))
							{
								lockfreqmin[SITE] = res[SITE];
								site_measured2[SITE] = 1;
								valid_dly++;
							}
						}


					}
					if (valid_site == valid_dly) break;
				}
			}




		}

}
void DBG_TIMING(double range_min, double range_max, double range_step, double *dly_time,int flag_gng)
{

	int valid_site = 0;
	int valid_dly = 0;
	double period;
	double res[SITE_NUM];
	int count = 0;
	
	dcm.SetPinLevel("DBG_WAKE12_G", 5.0, 0, 2.5, 2.4);
	count = (int)((range_max - range_min) / (range_step + 1e-30) + 1);
	SERIAL_ALL
	{
		dly_time[SITE] = 0;


	}
		if (count <= 0)
		{
			return;
		}
		else
		{
			if (flag_gng)
			{
				period = range_max*1e3;//scale to ns
				dcm.SetPeriod("TIMING_SWEEP", period);
				dcm.SetEdge("DBG_WAKE12_G", "TIMING_SWEEP", DCM_DTFT_NRZ, DCM_IO_NRZ, period*0.25, period*0.75, period*0.25, period*0.75, period*0.5);
				int nRetVal = dcm.RunVectorWithGroup("DBG_WAKE12_G", "DBG_START", "DBG_STOP");
			//	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_32MA);
				delay_ms(3);//will check the delay time, if ready into test mode
				Enter_MAIN_TM_DIG();
				Enter_FS_TM_DIG();
				Enter_M_TM(0x0071, 0x0000, 0x0000);
				delay_ms(1);
				A3_INTB.MeasureVI(10, 10);
				SERIAL
				{
					res[SITE] = A3_INTB.GetMeasResult(SITE, MVRET);
					if (res[SITE] < 1.0)
						dly_time[SITE] = range_max;

				}
				
			}
			else
			{
				//only for temp char ,can adjust to binary search
				if (count > 100)count = 100;
				for (int i = 0; i < count; i++)
				{
					period = (range_min + i*range_step)*1e3;
					dcm.SetPeriod("TIMING_SWEEP", period);
					dcm.SetEdge("DBG_WAKE12_G", "TIMING_SWEEP", DCM_DTFT_NRZ, DCM_IO_NRZ, period*0.25, period*0.75, period*0.25, period*0.75, period*0.5);
					//dcm.Connect("DBG_WAKE12_G");
					dcm.RunVectorWithGroup("DBG_WAKE12_G", "DBG_START", "DBG_STOP");
					//dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_32MA);
					//dcm.SetChannelStatus("DBG_WAKE12_G", DCM_HIGH);
					delay_ms(3);//will check the delay time, if ready into test mode
					Enter_MAIN_TM_DIG();
					Enter_FS_TM_DIG();
					Enter_M_TM(0x0071, 0x0000, 0x0000);
					delay_us(200);
					A3_INTB.MeasureVI(10, 10);
					valid_site = 0;
					valid_dly = 0;
					SERIAL
					{
						valid_site++;
						res[SITE] = A3_INTB.GetMeasResult(SITE, MVRET);
						if (res[SITE] < 1.0)
						{
							dly_time[SITE] = period*1e-3;
							valid_dly++;
						}
							

					}
					if (valid_site == valid_dly) break;
				}
			}
		
			
			

		}

}


void vth_binary_search(const char* pin, FXVIe_PLUS fxvicap, double start, double stop, double holdvalue, int stepcount, double *result, int delaytime_us, int hysmode, TRIG_MODE trig_mode){
	double step;
	double value[SITE_NUM];
	double res[SITE_NUM];
	step = abs(stop - start) / 4.0;
	SERIAL value[SITE] = (stop + start) / 2.0;
	for (int i = 0; i < stepcount; i++){
		if (hysmode)
		{
			dcm.SetPPMU(pin, DCM_PPMU_FVMI, start, DCM_PPMUIRANGE_2MA);
			delay_us(delaytime_us);
		}
		SERIAL	dcm.SetPPMUSingleSite(pin, SITE, DCM_PPMU_FVMI, value[SITE], DCM_PPMUIRANGE_2MA);

		delay_us(delaytime_us);
		fxvicap.MeasureVI(5, 10);
		SERIAL
		{
			res[SITE] = fxvicap.GetMeasResult(SITE, MVRET);
			if (trig_mode == TRIG_FALLING)
			{
				if (res[SITE] < 1.5)
					value[SITE] -= step;
				else
					value[SITE] += step;
			}
			else
			{
				if (res[SITE] < 1.5)
					value[SITE] += step;
				else
					value[SITE] -= step;
			}
		}
		step = step / 2.0;
	}
	SERIAL result[SITE] = value[SITE];
	dcm.SetPPMU(pin, DCM_PPMU_FVMI, holdvalue, DCM_PPMUIRANGE_2MA);
}


void ith_binary_search(const char* pin, FXVIe_PLUS fxvicap, double start, double stop, double holdvalue, int stepcount, double* result, int delaytime_us, int hysmode, TRIG_MODE trig_mode) {
	double step;
	double value[SITE_NUM];
	double res[SITE_NUM];
	step = abs(stop - start) / 4.0;
	PPMUIRange pmurange;
	if ((abs(stop) < 2e-6) && (abs(start) < 2e-6))
		pmurange = DCM_PPMUIRANGE_2UA;
	else if ((abs(stop) < 20e-6) && (abs(start) < 20e-6))
		pmurange = DCM_PPMUIRANGE_20UA;
	else if ((abs(stop) < 200e-6) && (abs(start) < 200e-6))
		pmurange = DCM_PPMUIRANGE_200UA;
	else if ((abs(stop) < 2e-3) && (abs(start) < 2e-3))
		pmurange = DCM_PPMUIRANGE_2MA;
	else 
		pmurange = DCM_PPMUIRANGE_32MA;

	SERIAL value[SITE] = (stop + start) / 2.0;
	for (int i = 0; i < stepcount; i++) {
		if (hysmode)
		{
			dcm.SetPPMU(pin, DCM_PPMU_FIMV, start, pmurange);
			delay_us(delaytime_us);
		}
		SERIAL	dcm.SetPPMUSingleSite(pin, SITE, DCM_PPMU_FIMV, value[SITE], pmurange);

		delay_us(delaytime_us);
		fxvicap.MeasureVI(5, 10);
		SERIAL
		{
			res[SITE] = fxvicap.GetMeasResult(SITE, MVRET);
			if (trig_mode == TRIG_FALLING)
			{
				if (res[SITE] < 1.5)
					value[SITE] -= step;
				else
					value[SITE] += step;
			}
			else
			{
				if (res[SITE] < 1.5)
					value[SITE] += step;
				else
					value[SITE] -= step;
			}
		}
		step = step / 2.0;
	}
	SERIAL result[SITE] = value[SITE];
	dcm.SetPPMU(pin, DCM_PPMU_FIMV, holdvalue, pmurange);
}
void measure_VPRE_VREF(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(2);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];

}
void measure_VPRE_SS(double* res1, double* res2)
{
	double cap[SITE_NUM][500];
	double cap1[SITE_NUM][500];
	Enter_M_TM(0x0003, 0x0000, 0x0000);

	//0x31  0000 0000 00xx xx00
	A3_INTB.MeasureVI(300, 10, FXVIe_PLUS_MI_X1, MEAS_AWG);
	PRECMP_BUCK3FB_INTB_10.MeasureVI(300, 10, MEAS_AWG);
	STSEnableMeas(&PRECMP_BUCK3FB_INTB_10, &A3_INTB);

	SPIWrite_SYNC(0x31, 0x0028);

	STSAWGRun();

	SERIAL{
		A3_INTB.BlockRead(SITE, 0, 300, cap[SITE], MVRET);
		PRECMP_BUCK3FB_INTB_10.BlockRead(SITE, 0, 300, cap1[SITE], MVRET);
		res1[SITE] = 0;

		for (int i = 5; i < 100; i++)
		{
			if (cap[SITE][i] < 2.0)
			{
				res1[SITE] = i;//
				break;
			}

		}


	}
		SERIAL{

		res2[SITE] = 0;

		for (int i = 299; i > 5; i--)
		{
			if (cap1[SITE][i] < 0.495)
			{
				res2[SITE] = i;//
				break;
			}

		}


	}
}
void measure_VPRE_EA_OFFSET(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res_r[SITE_NUM];
	OTP_M_Preview(4);
	delay_ms(1);
	//will change to binary search
	vth_binary_search(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA,3.15, 3.5, 3.15, 8, res_r, 1500, 0, TRIG_FALLING);
	//awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, "VPRE_EA_OS00", 3.15, 3.5, 0.001, 1000, 2.0, TRIG_FALLING, res_r);
	PREFB_BUCK1FB_8.Set(FV, 3.15, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	SERIAL results[SITE] = res_r[SITE];

}
void measure_VPRE_IPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res_r[SITE_NUM];
	OTP_M_Preview(2);
	delay_ms(1);
	SPIWrite(0x00, 0x0300);
	FPVIM.Set(FV, 0.04, FPVIe_1V, FPVIe_100UA, FPVIe_RELAY_ON);
	if (treg_measure_flag == TREG_MEASURE_CHAR)
		awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_100UA, "VPRE_IPK001", 0.04, 0.7, 0.0003, 50, 2.0, TRIG_FALLING, res_r);
	else
		awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_100UA, "VPRE_IPK00", 0.04, 0.3, 0.0003, 50, 2.0, TRIG_FALLING, res_r);

	SERIAL results[SITE] = res_r[SITE];

}

void measure_VPRE_IVY_MAX(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res_r[SITE_NUM];
	OTP_M_Preview(3);
	delay_ms(1);
	if (treg_measure_flag == TREG_MEASURE_CHAR)
		awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_1MA, "VPRE_IVY_MAX001", 0.15, -0.02, 0.00025, 80, 2.0, TRIG_FALLING, res_r);

	else
		awg.rampv(FPVIM, A3_INTB, FPVIe_100MV, FPVIe_1MA, "VPRE_IVY_MAX00", 0.08, 0.02, 0.00025, 80, 2.0, TRIG_FALLING, res_r);

	SERIAL results[SITE] = res_r[SITE];

}
void measure_VPRE_IVY_MIN(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
    double res_r[SITE_NUM];
	OTP_M_Preview(3);
	FPVIM.Set(FV, 0.01, FPVIe_100MV, FPVIe_1MA, FPVIe_RELAY_ON);
	delay_ms(1);
	awg.rampv(FPVIM, A3_INTB, FPVIe_100MV, FPVIe_1MA, "VPRE_IVY_MIN", 0.01, -0.03, 0.00015, 100, 2.0, TRIG_FALLING, res_r);

	SERIAL results[SITE] = res_r[SITE];

}
void measure_VPRE_INEG(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	int a=0;
	double res_r[SITE_NUM];
	OTP_M_Preview(4);
	a=trim_node->get_working(5);
	delay_ms(1);
	if (treg_measure_flag == TREG_MEASURE_CHAR)
	awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10MA, "VPRE_INEG", -0.015, -0.15, 0.00025, 50, 2.0, TRIG_FALLING, res_r);

	else
	awg.rampv(FPVIM, A3_INTB, FPVIe_100MV, FPVIe_10MA, "VPRE_INEG", -0.015, -0.1, 0.00025, 50, 2.0, TRIG_FALLING, res_r);

	SERIAL results[SITE] = res_r[SITE];

}
void measure_VPRE_EA_IOUT(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	OTP_M_Preview(3);
	PREFB_BUCK1FB_8.Set(FV, 3.25, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	PRECMP_BUCK3FB_INTB_10.MeasureVI(30,10);
	SERIAL{
		res1[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);

	}
	PREFB_BUCK1FB_8.Set(FV, 3.2, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	PRECMP_BUCK3FB_INTB_10.MeasureVI(30, 10);
	SERIAL{
		res2[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);

	}
	SERIAL results[SITE] = (res1[SITE] - res2[SITE])/0.05*6.0;

}

void measure_VPRE_SC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	if (treg_measure_flag != TREG_MEASURE_NONE)  OTP_M_Preview(3);
	Enter_M_TM(0x0003, 0x0024, 0x0000);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.2, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "VPRE_SC1", 1.2, 0.6, 0.002, 500, 4.5, TRIG_FALLING, res1);
	//awg.rampvmi(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "VPRE_SC1", 0.6, 1.0, 0.002, 50, -10.0e-6, TRIG_RISING, res1);

	Enter_M_TM(0x0003, 0x0010, 0x0000);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.1, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "VPRE_SC2", 1.2, 0.6, 0.002, 500, 2.0, TRIG_FALLING, res2);

	//awg.rampvmi(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "VPRE_SC2", 1.1, 0.6, 0.002, 50, 2.0, TRIG_FALLING, res2);

	SERIAL results[SITE] = (res1[SITE] - res2[SITE])*g_freq_20MHz[SITE] / 44.0*1e-6;//0.455;//455K, V/us

}

void measure_VPRE_SC_OPT(double start,double stop, double *results){
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double step = (stop - start) / 150.0;
	Enter_M_TM(0x0003, 0x0024, 0x0000);
	PRECMP_BUCK3FB_INTB_10.Set(FV, stop, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "VPRE_SC1", stop, start, step, 500, 4.5, TRIG_FALLING, res1);

	Enter_M_TM(0x0003, 0x0010, 0x0000);
	PRECMP_BUCK3FB_INTB_10.Set(FV, stop, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "VPRE_SC2", stop, start, step, 500, 2.0, TRIG_FALLING, res2);


	SERIAL results[SITE] = (res1[SITE] - res2[SITE])*g_freq_20MHz[SITE] / 44.0*1e-3;//0.455;//455K, V/us

}
void measure_VPRE_SC_OPT1(double start, double stop, double* results) {
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double step = (stop - start) / 150.0;
	Enter_M_TM(0x0003, 0x0024, 0x0000);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	FPVIM.Set(FV, 0.0, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(1);
	awg.rampv(FPVIM, A3_INTB, FPVIe_100MV, FPVIe_10MA, "VPRE_SC11", stop, start, step, 500, 4.0, TRIG_FALLING, res1);

	Enter_M_TM(0x0003, 0x0010, 0x0000);
	FPVIM.Set(FV, 0.0, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(1);
	awg.rampv(FPVIM, A3_INTB, FPVIe_100MV, FPVIe_10MA, "VPRE_SC21", stop, start, step, 500, 2.0, TRIG_FALLING, res2);

	FPVIM.Set(FV, 0.02, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL results[SITE] = (res2[SITE] - res1[SITE]) * g_freq_20MHz[SITE] / 44.0 * 1e-3*6.2;//0.455;//455K, V/us

}

void measure_BOOST_VREF(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(6);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];

}
void measure_BOOST_EA_OFFSET(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(6);
	//if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	//if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);
	//A5_AMUX.MeasureVI(30, 10);
	//SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
	vth_binary_search(B2_PREBOOT_VBOOST,A3_INTB,FXVIe_PLUS_10V,FXVIe_PLUS_100MA,4.6,5.4,4.6,10,res,200,0,TRIG_RISING);
	SERIAL results[SITE] = res[SITE];
}

void measure_QVM(double *results)
{

	BYTE QVM_GP1[2] = { K122_QVM_S1357, K121_QVM_S2468 };
	
	ALL_QVM.Connect();
	for (int grp = 0; grp < 2; grp++)
	{

		cbitclose(QVM_GP1[grp]);

		delay_ms(2);

		ALL_QVM.MeasureLADC(30, 10, QVMe_LADC_5V, QVMe_LADC_400KHz, MEAS_NORMAL);
		for (int siten = 0; siten < 4; siten++)
			results[siten * 2 + grp] = qvm_grp[siten * 2 + grp].GetMeasResult(siten * 2 + grp);


		cbitopen(QVM_GP1[grp]);
	}
}

void measure_BOOST_CLAMPMAX(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res_r[SITE_NUM];
	OTP_M_Preview(6);
	delay_ms(1);
	if(1)
	{ 
	//check if need FPVI_MV_X2/5 to get high accuracy
		FPVIM.Set(FV, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
		awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_100MA, "BOOST_CLAMPMAX", 0, -0.4, 0.001, 50, 2.0, TRIG_FALLING, res_r);

		SERIAL 
		{
			g_rsns_v_boost[SITE] = res_r[SITE];
			results[SITE] = -res_r[SITE] / g_rdson_boost[SITE]*1e3;//A
		}
	}
	else
	{

		FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
		delay_ms(10);
		awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BOOST_CLAMPMAX", 0, -4.0, 0.01, 50, 2.0, TRIG_FALLING, res_r);
		FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
		SERIAL
		{
			g_rsns_v_boost[SITE] = res_r[SITE];
			results[SITE] = -res_r[SITE] ;//A
		}
	}
}

void measure_BOOST_CLAMPMIN(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res_r[SITE_NUM];
	OTP_M_Preview(6);
	delay_ms(1);
	if(1)
	{
	//check if need FPVI_MV_X2/5 to get high accuracy
	FPVIM.Set(FV, -0.04, FPVIe_100MV, FPVIe_100MA, FPVIe_RELAY_ON);
	delay_us(100);
	awg.rampv(FPVIM, A3_INTB, FPVIe_100MV, FPVIe_100MA, "BOOST_CLAMPMIN",-0.04 ,0.005 , 0.0001, 100, 0.8, TRIG_RISING, res_r);

	SERIAL
	{
		
		results[SITE] = -res_r[SITE] / g_rdson_boost[SITE] * 1e3;//A
	}
	}
	else
	{
			//check if need FPVI_MV_X2/5 to get high accuracy
		FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
		delay_us(100);
		awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_1A, "BOOST_CLAMPMIN",0 ,-0.3 , 0.005, 100, 2.0, TRIG_FALLING, res_r);
		FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
		SERIAL
		{
		
			results[SITE] = -res_r[SITE] ;//A
		}
	}

}

void measure_BOOST_ISLP(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res_r[SITE_NUM];
	double t1[SITE_NUM];
	double t2[SITE_NUM];
	double se[SITE_NUM];
	double sf[SITE_NUM];
	OTP_M_Preview(5,2);
	delay_ms(1);
	//will check if voltage clamped
	A0_FIN_DBG_ERR_FCCU1.Set(FI,-17e-6, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	BYTE S_QTMU_GP[2] = { K126_DBUFF_S1357, K125_DBUFF_S2468 };
	DWORD validsite;
	int siteconnect;
	original_validsite = 0;
	SERIAL original_validsite += DWORD(pow(2, SITE));
	for (int grp = 0; grp < 2; grp++)
	{
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(3);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_TIME, 36, 5, QTMUe_TRANGE_MS);
		SERIAL
		{
			results[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE);
			t1[SITE] = results[SITE]*1000+8.0;//ns
		}
		cbitopen(S_QTMU_GP[grp]);
		delay_ms(1);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}
	A0_FIN_DBG_ERR_FCCU1.Set(FI, -12e-6, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	for (int grp = 0; grp < 2; grp++)
	{
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(3);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_TIME, 36, 5, QTMUe_TRANGE_MS);
		SERIAL
		{
			results[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE);
			t2[SITE] = results[SITE]*1000+8.0;//ns
		}
		cbitopen(S_QTMU_GP[grp]);
		delay_ms(1);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}
	//0.8 for rising time factor
	SERIAL 
	{
		se[SITE] = (17.0/4.0*t1[SITE]-12.0/4.0 *t2[SITE] )/ (t2[SITE]*t2[SITE] - t1[SITE]*t1[SITE] + 1e-30)*1000*2;
		//sf[SITE] = g_rdson_boost[SITE] * 5.0 / 4.7;
		results[SITE] =se[SITE] *25000/((5.0+0.5-3.3)/4.7)/1.0e6 ;//A
	}

}

void measure_LDO12_DAC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(8);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];


}
void measure_LDO1_EA(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(7);

	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET) ;


}
void measure_LDO2_EA(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_M_Preview(7);

	delay_ms(2);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);


}

void measure_LDO1_ILMT(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(8);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.8*0.8, FXVIe_PLUS_3p6V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,0.5);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL res[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
	SERIAL results[SITE] = -res[SITE];
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.8*1.02, FXVIe_PLUS_3p6V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(4);
}

void measure_LDO2_ILMT(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(8);
	B4_VSUP_LDO2OUT.Set(FV, 1.8*0.8, FXVIe_PLUS_3p6V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);
	delay_ms(1);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL res[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
	SERIAL results[SITE] = -res[SITE];
	B4_VSUP_LDO2OUT.Set(FV, 1.8*1.02, FXVIe_PLUS_3p6V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(4);
}
void measure_LDO1_SS(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	double cap[SITE_NUM][1000];
	double t1[SITE_NUM] = { 0 };
	double t2[SITE_NUM] = { 0 };
	int samplecount = 600;
	OTP_M_Preview(7);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(samplecount, 10, FXVIe_PLUS_MI_X1, MEAS_AWG);
	STSEnableMeas(&B1_PREGHS_PREGLS_LDO1OUT);
	
	STSAWGRun(1);
	Enter_M_TM(0x0005, 0x2000, 0x0000);
	delay_us(samplecount*10);
	SERIAL
	{
		B1_PREGHS_PREGLS_LDO1OUT.BlockRead(SITE, 0, samplecount, cap[SITE], MVRET);
		for (int i = 0; i<samplecount; i++)
		{
			if (cap[SITE][i]>1.8*0.1)
			{
				t1[SITE] = i;
				break;
			}

		}
		for (int i = 0; i<samplecount; i++)
		{
			if (cap[SITE][i]>1.8*0.9)
			{
				t2[SITE] = i;
				break;
			}

		}
		results[SITE] = (t2[SITE] - t1[SITE]) * 0.01*1e-3;//s
	}
	Enter_M_TM(0x0005, 0x0000, 0x0000);//discharge,for next test.
	delay_ms(1);
	//awg.rampss(B0_PRESW_LDO1IN, B1_PREGHS_PREGLS_LDO1OUT, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "LDO1_SS1", 0, 3.3, 200, 15, 3.3*0.1, 3.3*0.9, TRIG_RISING, res);
	//SERIAL results[SITE] = res[SITE];

}
void measure_LDO2_SS(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	double cap[SITE_NUM][1000];
	double t1[SITE_NUM] = { 0 };
	double t2[SITE_NUM] = { 0 };
	int samplecount = 600;
	OTP_M_Preview(7);
	B4_VSUP_LDO2OUT.MeasureVI(samplecount, 10, FXVIe_PLUS_MI_X1, MEAS_AWG);
	STSEnableMeas(&B4_VSUP_LDO2OUT);

	STSAWGRun(1);
	Enter_M_TM(0x0005, 0x4000, 0x0000);
	delay_us(samplecount * 10);
	SERIAL
	{
		B4_VSUP_LDO2OUT.BlockRead(SITE, 0, samplecount, cap[SITE], MVRET);
		for (int i = 0; i<samplecount; i++)
		{
			if (cap[SITE][i]>1.8*0.1)
			{
				t1[SITE] = i;
				break;
			}

		}
		for (int i = 0; i<samplecount; i++)
		{
			if (cap[SITE][i]>1.8*0.9)
			{
				t2[SITE] = i;
				break;
			}

		}
		results[SITE] = (t2[SITE] - t1[SITE]) * 0.01*1e-3;//s
	}
	Enter_M_TM(0x0005, 0x0000, 0x0000);//discharge,for next test.
	delay_ms(1);
//	awg.rampss(B2_PREBOOT_VBOOST, B4_VSUP_LDO2OUT, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "LDO1_SS1", 0, 3.3, 200, 15, 3.3*0.1, 3.3*0.9, TRIG_RISING, res);
//	SERIAL results[SITE] = res[SITE];

}

void measure_BUCK1_DAC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	if (treg_measure_flag != TREG_MEASURE_NONE) OTP_M_Preview(9);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];


}
void measure_BUCK2_DAC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	if (treg_measure_flag != TREG_MEASURE_NONE) OTP_M_Preview(11);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];


}

void measure_BUCK3_DAC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	if (treg_measure_flag != TREG_MEASURE_NONE) OTP_M_Preview(13);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];


}
void measure_BUCK2_DP_IMINPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(12);

	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_2A, "BUCK2_DP_IMINPK", 0.2, -1.4, 0.005, 10, 2.0, TRIG_RISING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	SERIAL{
		
		results[SITE] = res[SITE] - g_ilmt_pkmini_buck1[SITE];
	if ((res[SITE] > 10 ) && (trim_node->get_working(SITE)) < 8)
		results[SITE] = -0.999;
	else if ((res[SITE] > 10) )
		results[SITE] = 0.999;
	
	}


}

void measure_BUCK2_DP_IMAXPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(12);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(15);
	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK2_DP_IMAXPK", 0, 4.5, 0.01, 10, 2.0, TRIG_FALLING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL{
	
		results[SITE] = res[SITE]*2 - g_ilmt_pk_buck1[SITE];
	if ((res[SITE] > 10) && (trim_node->get_working(SITE)) < 16) 
		res[SITE] = 5.0;//avoid high current
	else if ((res[SITE] > 10))
		res[SITE] = -5.0;

	}


}
void measure_BUCK1_IPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
 OTP_M_Preview(9);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(15);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK1_IPK", 0.5, 4.5, 0.01, 10, 2.0, TRIG_FALLING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL{
		if ((res[SITE] > 10) && (trim_node->get_working(SITE)) < 8) 
			res[SITE] = 5.0;//avoid high current
		else if ((res[SITE] > 10))
			res[SITE] = -5.0;
		results[SITE] = res[SITE];
		g_ilmt_pk_buck1[SITE] = res[SITE];
	}


}
void measure_BUCK2_IPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(11);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(15);//for charge
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK2_IPK", 0.5, 4.5, 0.01, 10, 2.0, TRIG_FALLING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL
	{
		if ((res[SITE] > 10) && (trim_node->get_working(SITE)) < 8)
			res[SITE] = 5.0;//avoid high current
		else if ((res[SITE] > 10))
			res[SITE] = -5.0;
		results[SITE] = res[SITE];
		g_ilmt_pk_buck2[SITE] = res[SITE];
	}


}
void measure_BUCK3_IPK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(13);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(15);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK3_IPK", 0.5, 4.5, 0.01, 10, 2.0, TRIG_FALLING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL
	{
		if ((res[SITE] > 10) && (trim_node->get_working(SITE)) < 8)
			res[SITE] = 5.0;//avoid high current
		else if ((res[SITE] > 10))
			res[SITE] = -5.0;
		results[SITE] = res[SITE];
		g_ilmt_pk_buck3[SITE] = res[SITE];
	}

}

void measure_BUCK1_EA(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(9);

	delay_ms(1);

	//awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_EA", 1.56, 1.64, 0.0004, 1000, 2.0, TRIG_FALLING, res);
	vth_binary_search(PREFB_BUCK1FB_8,A3_INTB,ACM200_3p6V,ACM200_100MA,1.55,1.65,1.56,8,res,1000,0,TRIG_FALLING);
	SERIAL results[SITE] = res[SITE];


}

void measure_BUCK2_EA(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(11);

	delay_ms(1);

	//awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK2_EA", 1.56, 1.64, 0.0004, 30, 2.0, TRIG_FALLING, res);
	vth_binary_search(PRECSP_BUCK2FB_9,A3_INTB,ACM200_3p6V,ACM200_100MA,1.55,1.65,1.56,8,res,1000,0,TRIG_FALLING);
	SERIAL results[SITE] = res[SITE];


}

void measure_BUCK3_EA(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(13);

	delay_ms(1);
	vth_binary_search(PRECMP_BUCK3FB_INTB_10,A3_INTB,ACM200_3p6V,ACM200_100MA,1.55,1.65,1.56,8,res,1000,0,TRIG_FALLING);
	//awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK3_EA", 1.56, 1.64, 0.0004, 100, 2.0, TRIG_FALLING, res);

	SERIAL results[SITE] = res[SITE];


}
void measure_BUCK1_IVY(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(9);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(10);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK1_IVY", 0.5, 4.5, 0.01, 10, 2.0, TRIG_RISING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL
	{
		if ((res[SITE] > 10) && (trim_node->get_working(SITE)) < 8)
			res[SITE] = 5.0;//avoid high current
		else if ((res[SITE] > 10))
			res[SITE] = -5.0;
		results[SITE] = res[SITE];
	}


}

void measure_BUCK2_IVY(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(11);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(10);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK2_IVY", 0.5, 4.5, 0.01, 10, 2.0, TRIG_RISING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL
	{
		if ((res[SITE] > 10) && (trim_node->get_working(SITE)) < 8)
			res[SITE] = 5.0;//avoid high current
		else if ((res[SITE] > 10))
			res[SITE] = -5.0;
		results[SITE] = res[SITE];
	}


}

void measure_BUCK3_IVY(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(13);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(10);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK3_IVY", 0.5, 4.5, 0.01, 10, 2.0, TRIG_RISING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL
	{
		if ((res[SITE] > 10) && (trim_node->get_working(SITE)) < 8)
			res[SITE] = 5.0;//avoid high current
		else if ((res[SITE] > 10))
			res[SITE] = -5.0;
		results[SITE] = res[SITE];
	}


}
void measure_BUCK1_LOOP_GM(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	if (treg_measure_flag != TREG_MEASURE_NONE)
	{
		OTP_M_Preview(10);

		delay_ms(1);
	}
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(10);
	delay_ms(3);//for resource charge
	//target 1.6
	PREFB_BUCK1FB_8.TSet(FV, 1.65, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_us(200);
	awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_LOOP_GM1", 1.65, 1.35, 0.0003, 20, 0.5, TRIG_RISING, res1);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 2.0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON,0.2);
	//delay_ms(1);
	PREFB_BUCK1FB_8.TSet(FV, 1.65, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_us(200);
	awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_LOOP_GM2", 1.65, 1.35, 0.0003, 20, 0.5, TRIG_RISING, res2);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL results[SITE] = 2.0/(res1[SITE] - res2[SITE]+1e-30);


}

void measure_BUCK2_LOOP_GM(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	if (treg_measure_flag != TREG_MEASURE_NONE)
	{
		OTP_M_Preview(12);

		delay_ms(1);
	}
	//target 1.28V
	PRECSP_BUCK2FB_9.TSet(FV, 1.65, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_us(200);
	awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_LOOP_GM1", 1.65, 1.35, 0.0003, 20, 0.5, TRIG_RISING, res1);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 2.0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON,0.2);
	//delay_ms(1);
	PRECSP_BUCK2FB_9.TSet(FV, 1.65, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_us(200);
	awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_LOOP_GM2", 1.65, 1.35, 0.0003, 20, 0.5, TRIG_RISING, res2);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	
	SERIAL results[SITE] = 2.0 / (res1[SITE] - res2[SITE] + 1e-30);


}
void measure_BUCK3_LOOP_GM(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	if (treg_measure_flag != TREG_MEASURE_NONE)
	{
		OTP_M_Preview(14);

		delay_ms(1);
	}
	//target 1.28V
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 1.65, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_us(200);
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_LOOP_GM1", 1.65, 1.35, 0.0003, 20, 0.5, TRIG_RISING, res1);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 2.0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON,0.2);
	//delay_ms(1);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 1.65, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_us(200);
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_LOOP_GM2", 1.65, 1.35, 0.0003, 20, 0.5, TRIG_RISING, res2);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL results[SITE] = 2.0 / (res1[SITE] - res2[SITE] + 1e-30);


}

void measure_BUCK1_SLOP(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(10);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(10);
	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK1_SLOP", -0.5, 3.0, 0.01, 10, 2.0, TRIG_FALLING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL results[SITE] = g_ilmt_pk_buck1[SITE]- res[SITE];


}

void measure_BUCK2_SLOP(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(12);

	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK2_SLOP", -0.5, 3.0, 0.01, 10, 2.0, TRIG_FALLING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL results[SITE] = g_ilmt_pk_buck2[SITE] - res[SITE];


}


void measure_BUCK3_SLOP(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(14);

	delay_ms(1);

	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK3_SLOP", -0.5, 3.0, 0.01, 10, 2.0, TRIG_FALLING, res);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL results[SITE] = g_ilmt_pk_buck3[SITE] - res[SITE];


}


void measure_FSBGTC(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_FS_Preview();
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];

}
void measure_FSBGV(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){

	OTP_FS_Preview();
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	delay_ms(1);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];

}
void measure_TS(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	double res[SITE_NUM];
	OTP_M_Preview(14);
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(2);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(2);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		results[SITE] =( 1.26-res[SITE])/3.93*1000+25.0;
	}

}
void measure_FS_CLK_QTMU(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
	//dut.trim("FS_CLK").set_working(4);
	ULONG fs_trim_data[SITE_NUM];
	OTP_FS_Preview();
	if (treg_measure_flag == TREG_MEASURE_CHAR) delay_ms(3);
	if (treg_measure_flag == TREG_MEASURE_PRE) delay_ms(3);
	SPIRead(0x0050, fs_trim_data);
	BYTE S_QTMU_GP[2] = { K124_TMU_S1357, K123_TMU_S2468 /*K126_DBUFF_S1357, K125_DBUFF_S2468*/ };
	DWORD validsite;
	int siteconnect;
	original_validsite = 0;
	SERIAL original_validsite += DWORD(pow(2, SITE));
	for (int grp = 0; grp < 2; grp++)
	{
		siteconnect = 0;
		validsite = 0;
		SERIAL
		{
			if ((SITE % 2) == grp)
			{
				validsite += DWORD(pow(2, SITE));
			}

		}
		if (validsite == 0) continue;
		STSSetSiteStatus(validsite);

		cbitclose(S_QTMU_GP[grp]);
		delay_ms(2);
		ALL_QTMU.Measure(QTMUe_MU1, QTMUe_MEAS_FREQ, 36, 5, QTMUe_TRANGE_MS);
		SERIAL results[SITE] = qtmu_grp[SITE].GetMeasureResult(SITE) *1e3;//scale to HZ

		cbitopen(S_QTMU_GP[grp]);
		STSSetSiteStatus(original_validsite);//recover to original sites.
	}


}

void SCAN_TEST(ACM200 vddpin, double vdd, const char* pingrp, const char* pincap, const char* startlabel, const char* stoplabel, int samplesize, int interval, double *results_i, double *results_v, ULONG *failcount, int measuretype)
{
	double vih;
	double vil;
	double voh;
	double vol;
	if (vdd>5.0)
		vih = 5.0;
	else
		vih = vdd;
	voh = 2.0;
	vol = 1.9;
	vil = 0;
	if (measuretype == 0)
	{
		vddpin.Set(FV, vdd, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 1.0);//will check current of Vout
		delay_ms(5);
	}
	dcm.SetPinLevel(pingrp, vih, vil, voh, vol);
	int nRetVal = dcm.RunVectorEn(pingrp, startlabel, stoplabel);//4MHz with 1M pattern about 250ms
	if ((measuretype == 0) || (measuretype == 2))
	{
		vddpin.MeasureVI(samplesize, interval, MEAS_AWG);// test  250ms Iq
		STSEnableMeas(&vddpin);
	}
	STSAWGRun();
	if (measuretype == 1)
	{
		vddpin.Set(FV, vdd, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check current of Vout

		delay_ms(8);
		if (strcmp(startlabel, "IDDQ_START") == 0)
			delay_ms(10);
		//some device need long delay to avoid Idqq delta fail due to some functions working

		vddpin.MeasureVI(samplesize, interval, MEAS_NORMAL);
		vddpin.Set(FV, vdd, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check current of Vout

		SERIAL
		{
			results_i[SITE] = vddpin.GetMeasResult(SITE, MIRET);
			results_v[SITE] = vddpin.GetMeasResult(SITE, MVRET);
			dcm.GetFailCount(pincap, SITE, failcount[SITE]);
		}
			//if (strcmp(startlabel, "IDDQ0") == 0)
	}
	else
	{
		SERIAL
		{
			results_i[SITE] = vddpin.GetMeasResult(SITE, MIRET, MAX_RESULT);
			results_v[SITE] = vddpin.GetMeasResult(SITE, MVRET, MIN_RESULT);
			dcm.GetFailCount(pincap, SITE, failcount[SITE]);
		}
	}

}

void measure_SS(ACM200 respin,int samplesize,double targetvalue,double* res1)
{
	double pt1[SITE_NUM];
	double pt2[SITE_NUM];
	double cap[SITE_NUM][4000];
	SERIAL
	{
		pt1[SITE] = 0;
		pt2[SITE] = 0;
		respin.BlockRead(SITE, 0, samplesize, cap[SITE], MVRET);
		for (int i = 0; i<samplesize; i++)
		{
			if (cap[SITE][i]>(targetvalue*0.1))//typical 1.8
			{
				pt1[SITE] = i;
				break;
			}

		}
		for (int i = 0; i<samplesize; i++)
		{
			if (cap[SITE][i]>(targetvalue*0.9))//typical 1.8
			{
				pt2[SITE] = i;
				break;
			}

		}

		res1[SITE]=(pt2[SITE] -pt1[SITE] )*10;//us
		}

}
void measure_SS(FXVIe_PLUS respin,int samplesize,double targetvalue,double* res1)
{
	double pt1[SITE_NUM];
	double pt2[SITE_NUM];
	double cap[SITE_NUM][4000];
	SERIAL
	{
		pt1[SITE] = 0;
		pt2[SITE] = 0;
		respin.BlockRead(SITE, 0, samplesize, cap[SITE], MVRET);
		for (int i = 0; i<samplesize; i++)
		{
			if (cap[SITE][i]>(targetvalue*0.1))//typical 1.8
			{
				pt1[SITE] = i;
				break;
			}

		}
		for (int i = 0; i<samplesize; i++)
		{
			if (cap[SITE][i]>(targetvalue*0.9))//typical 1.8
			{
				pt2[SITE] = i;
				break;
			}

		}

		res1[SITE]=(pt2[SITE] -pt1[SITE] )*10;//us
		}
}