/*****************************************************************************
*                                                                            *
*       Source title:   exGPIB.h									           *
*                       (Universal functions for all SC test projects)       *
*         Written by:   Sky Fu                                                *
*        Description:			                                             *
*                                                                            *
*   Revision History:                                                        *
*                                                                            *
*     mm/dd/yy  r.rr  - Original coding.                                     *
*                                                                            *
*****************************************************************************/

/*
REVISION BLOCK:
-Rev. -- Date --------------------------------------------------
00   2/18/21  Initial.						Sky Fu

----------------------------------------------------------------
*/

#pragma once
#include <conio.h>
#include "stdafx.h"
#include "visa.h"

typedef double(*device_temp_read_func)(int site, int state);
class eGPIB {
public:
	eGPIB();
	~eGPIB();
	int sot();
	int eot();
	int reinit();
	void userload(int enable_gpib);
	void userexit();
	void set_loopcount(int lcount);
	void set_accuracy(double accuracy);
	void set_soaktime(double stime);
	void cap_temp_site(int site);
	double get_current_temp(int state);
	double get_set_temp();
	double max_temp;
	double min_temp;
	void tempcycle_setting(double *tempgrp,int size);
	void abort();
	void add_temp_func(device_temp_read_func a_meas_func);
	device_temp_read_func meas_func;
	int loopcount;
	int loopindex;
	double tmp_grp[100];
	double soaktime;
	unsigned long cooldowntime;
	unsigned long defrosttime;
	double cool_down_target_temp;
	double defrost_target_temp;
	double cool_down_temp;
	double defrost_temp;
	int dieid;
	int retest_count_limit;
	int retest_type;//0 =always ask if failed, 1= continue test,don't care the fail,2=always execute retest, if the retest count > retest count limit then continue next.
	double tmp_accuracy;
	double current_temp;
	double temp_target;
//	static unsigned char buffer[100];
//	static unsigned long retCount;
	double TS; 
	double KR; 
	double TN; 
	double TV;
private:
	int init();
	int retest_count;
	void char_setup();
	int dut_sample();
	void WriteCommandAndRead(ViBuf cmd, BOOL isQuery);
	void SendCommand(ViBuf cmd);
	void SendCommandAndRead(ViBuf cmd);
	double air_temp_in_valid_ranage;
	double read_temp;
	unsigned int tmpindex;
	unsigned int tmpcount;
	bool gpib_enable;
	bool gpib_pause;
	bool debug_window_enable;
	int validsite;
	int tempsite;
	int initstatus;
	int maxloopcount_captemp;
	char readtemp[100];
	int cID;
	double cTEMP;
	double y0, y1;           // forced temperature
	double e0, e1, e2;        // temperature error

};

