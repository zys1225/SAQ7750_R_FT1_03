/*****************************************************************************
*
*
*         Written by:   Sky Fu
*   Last Modified by:   Sky Fu
*               Date:   3/25/2025
*        Current Rev:   00
*
*        Description:    Zhaoyun SC6259XQ

		 .----------.
		/            \
      _(.-. _...._ .-.)_
	 (_)`-' __()__ `-'(_)
	(....__|ZhaoYun|__....)
	 | |    ~~~~~~    | |
	 `-'              `-'


*****************************************************************************/

/***************************************************************/
/***                  Copyright (C) 2020-2021                ***/
/***                    South Chip		                   ***/
/***                   All rights reserved                   ***/
/***                                                         ***/
/***   The information  and/or drawings set sforth  in this   ***/
/***   document  and  all  rights  in  and  to  inventions   ***/
/***   disclosed herein and patents which might be granted   ***/
/***   thereon  disclosing  or  employing  the  materials,   ***/
/***   methods, techniques, or apparatus  described herein   ***/
/***   are the exclusive property of South Chip.			  ***/
/***                                                         ***/
/***   No disclosure of  information or drawings shall  be   ***/
/***   made to  any other person  or organization  without   ***/
/***   the prior consent of South Chip.				        ***/
/***                                                         ***/
/***************************************************************/

/*****************************************************************************
Part Name:	
Alias:	Zhaoyun
Description:
The SC8741Q is a buck-boost converter with two low-side integrated power switches capable of
regulating the output voltage at, above, or below the input voltage. The SC8741Q operates over
3.7V to 36V wide input voltage and can output 1V to 22V voltage to support a variety of applications.
Fab site:	SMIC
Process:	BCDA
Die name:	SCK2G9A0
A/T site :	
Package :	QFN3X5-20
ATE :	CP: ACCO8300
Test Type:	Final test
Handler(room&hot):	Handler(Room): 
Test Board Number:	HIB: ; PIB:		 PC:
PBD Number(Probe):
Contactor:
Mount and Bond:	NA
Leadframe(Links)
Test Temperature:	FT:; Probe:25C/125C/-40C 
QC Temperature:	25C
Program Number:	FT: ;  Probe:
Diagnostic Prg Number:	Included in FT/Probe program

SC8741Q(SC8742/SC8321) Pin Configuration

			VIN	  BT1	HD1    EN     VGATE(IMON/Mode)
		_____________________________________
		|__|20|   |19|	|18|  |17|    |16|__|
		|_____|	  |__|	|__|  |__|	  |_____|
		|								    |
		|____								|
SCL		|__1_|			  __________________|
		|____			 |____________15____|PGND
SDA		|__2_|		S    					|
		|____		C	  __________________|
ALT		|__3_|		8	 |____________14____|SW1
		|____		7	  __________________|
FB		|__4_|      4    |____________13____|SW2
		|____		1						|
ISEN-	|__5_|		Q	  __________________|
		|____			 |____________12____|PGND
ISEN+	|__6_|								|
		|									|
		|_____	   __     __    __	  ______|
		|__	7 |	  |	8|	 | 9|  |10|	 |11 ___|
		|__|__|___|__|___|__|__|__|__|__|___|
		VOUT   BT2   HD2    VCC  AGND



DEVICE PIN DEFINITION
==================
1	SCL	I	Clock of I2C interface
2	SDA	I	Data of I2C interface
3	ALT	O	I2C alert pin. Open drain output, active low
4	FB	I	Output voltage feedback input to the internal control loop. Connect to feedback divider tap point for adjustable output voltage.
5	ISEN-	I	Negative node of current sense signal input. An optional current sense resistor could be placed between PGND to output capacitor��s GND.
6	ISEN+	I	Positive node of current sense signal input. An optional current sense resistor could be placed between PGND to output capacitor��s GND.
7	VOUT	O	Output of the buck-boost converter. It��s also used to provide VCC supply at certain VOUT condition.
8	BT2	O	Power supply for high-side MOSFET gate driver in boost side. A ceramic capacitor of 0.1 ��F must be connected between this pin and the SW2 pin.
9	HD2	O	Gate driver output for high-side MOSFET in boost side
10	VCC	O	Internal LDO regulator output. Decouple with a 4.7��F capacitor between this pin and the AGND pin.
11	AGND	PWR	Signal ground of the IC.
12	PGND	PWR	Power ground of the IC.
13	SW2	I	Switching node pin of the boost side. It is connected to the drain of the internal low-side power MOSFET and the source of external high-side power MOSFET.
14	SW1	I	Switching node pin of the buck side. It is connected to the drain of the internal low-side power MOSFET and the source of external high-side power MOSFET.
15	PGND	I	Power Ground. PGND requires extra care during PCB layout. Connect to GND with copper traces and vias.
16	VGATE	O	Gate drive pin to drive external MOSFET to do ground short to battery protection.
IMON	O	Current monitor output. Represent signal between ISEN+ and ISEN-
MODE	I	Mode configure pin. Pull high to configure SC
17	EN	I	EN input. Apply logic high to enable the chip.
18	HD1	O	Gate driver output for high-side MOSFET in buck side
19	BT1	I	Power supply for high-side MOSFET gate driver in buck side. A ceramic capacitor of 0.1 ��F must be connected between this pin and the SW1 pin.
20	VIN	PWR	Input power supply for the IC.
Note:


**********************************************************************************************************************/

/**********************************************************************************************************************
Revision History:
Rev.	    Date				Name		TestTime				Description
00			04/01/2025			Sky Fu								Initial .

**********************************************************************************************************************/
//*************************************************************************//
#include "stdafx.h"
#include "BoardCheck.h"
#include "math.h"
#include "time.h"
#include "sub.h"
#include "I2C.h"
#include "awg.h"
//#include "BoardCheck.h"
//#include "MC_Interface.h"
//#include "h"
//#include "sub.h"
//#include "GenerateTextFile.h"
//#include "mylib.h"
//#include "EEPROM_Interface.h"
#include "Pin_Channel_define.h"
#include "exGPIB.h"
#include "FMEA.h"
#include "DECL-32.H"

/*The following code was created for STS PinPlanner,don't modify*/
/****STS_PINPLANNER_CODE_BEGIN****/
#define STS_SITE_NUM 8
#define APA_CHECKCODE_DISABLE_WARNING 
/****PIN GROUP DEFINITION****/
FXVIe_PLUS A0_FIN_DBG_ERR_FCCU1(_PIN_CHANNEL_DEFINE_A0_FIN_DBG_ERR_FCCU1_, "A0_FIN_DBG_ERR_FCCU1");
FXVIe_PLUS A1_FOUT_RSTB_FCCU2(_PIN_CHANNEL_DEFINE_A1_FOUT_RSTB_FCCU2_, "A1_FOUT_RSTB_FCCU2");
FXVIe_PLUS A2_PGOOD(_PIN_CHANNEL_DEFINE_A2_PGOOD_, "A2_PGOOD");
FXVIe_PLUS A3_INTB(_PIN_CHANNEL_DEFINE_A3_INTB_, "A3_INTB");
FXVIe_PLUS A4_PSYNC_PREFB(_PIN_CHANNEL_DEFINE_A4_PSYNC_PREFB_, "A4_PSYNC_PREFB");
FXVIe_PLUS A5_AMUX(_PIN_CHANNEL_DEFINE_A5_AMUX_, "A5_AMUX");
ACM200 VDDIO_VBOOST_0(_PIN_CHANNEL_DEFINE_VDDIO_VBOOST_0_, "VDDIO_VBOOST_0");
ACM200 VBOS_1(_PIN_CHANNEL_DEFINE_VBOS_1_, "VBOS_1");
ACM200 BUCK1IN_2(_PIN_CHANNEL_DEFINE_BUCK1IN_2_, "BUCK1IN_2");
ACM200 BUCK2IN_3(_PIN_CHANNEL_DEFINE_BUCK2IN_3_, "BUCK2IN_3");
ACM200 BUCK3IN_4(_PIN_CHANNEL_DEFINE_BUCK3IN_4_, "BUCK3IN_4");
ACM200 BUCK1SW_5(_PIN_CHANNEL_DEFINE_BUCK1SW_5_, "BUCK1SW_5");
ACM200 BUCK2SW_6(_PIN_CHANNEL_DEFINE_BUCK2SW_6_, "BUCK2SW_6");
ACM200 BUCK3SW_BOOSTLS_7(_PIN_CHANNEL_DEFINE_BUCK3SW_BOOSTLS_7_, "BUCK3SW_BOOSTLS_7");
ACM200 PREFB_BUCK1FB_8(_PIN_CHANNEL_DEFINE_PREFB_BUCK1FB_8_, "PREFB_BUCK1FB_8");
ACM200 PRECSP_BUCK2FB_9(_PIN_CHANNEL_DEFINE_PRECSP_BUCK2FB_9_, "PRECSP_BUCK2FB_9");
ACM200 PRECMP_BUCK3FB_INTB_10(_PIN_CHANNEL_DEFINE_PRECMP_BUCK3FB_INTB_10_, "PRECMP_BUCK3FB_INTB_10");
ACM200 VSUP_11(_PIN_CHANNEL_DEFINE_VSUP_11_, "VSUP_11");
FXVIe_PLUS B0_PRESW_LDO1IN(_PIN_CHANNEL_DEFINE_B0_PRESW_LDO1IN_, "B0_PRESW_LDO1IN");
FXVIe_PLUS B1_PREGHS_PREGLS_LDO1OUT(_PIN_CHANNEL_DEFINE_B1_PREGHS_PREGLS_LDO1OUT_, "B1_PREGHS_PREGLS_LDO1OUT");
FXVIe_PLUS B2_PREBOOT_VBOOST(_PIN_CHANNEL_DEFINE_B2_PREBOOT_VBOOST_, "B2_PREBOOT_VBOOST");
FXVIe_PLUS B3_WAKE12(_PIN_CHANNEL_DEFINE_B3_WAKE12_, "B3_WAKE12");
FXVIe_PLUS B4_VSUP_LDO2OUT(_PIN_CHANNEL_DEFINE_B4_VSUP_LDO2OUT_, "B4_VSUP_LDO2OUT");
FXVIe_PLUS B5_VMON1234(_PIN_CHANNEL_DEFINE_B5_VMON1234_, "B5_VMON1234");

ACM200 BUCK123(_GROUP_CHANNEL_DEFINE_BUCK123_, "BUCK123");

FPVIe FPVIM(_PIN_CHANNEL_DEFINE_FPVIM_, "FPVIM");

QTMUe QTMU23_0(_PIN_CHANNEL_DEFINE_QTMU23_0_, "QTMU23_0");
QTMUe QTMU23_1(_PIN_CHANNEL_DEFINE_QTMU23_1_, "QTMU23_1");
QTMUe QTMU23_3(_PIN_CHANNEL_DEFINE_QTMU23_3_, "QTMU23_3");
QTMUe QTMU23_2(_PIN_CHANNEL_DEFINE_QTMU23_2_, "QTMU23_2");
QVMe QVM1_3(_PIN_CHANNEL_DEFINE_QVM1_3_, "QVM1_3");
QVMe QVM1_2(_PIN_CHANNEL_DEFINE_QVM1_2_, "QVM1_2");
QVMe QVM1_0(_PIN_CHANNEL_DEFINE_QVM1_0_, "QVM1_0");
QVMe QVM1_1(_PIN_CHANNEL_DEFINE_QVM1_1_, "QVM1_1");

FXVIe_PLUS ALL_FXVIE(_GROUP_CHANNEL_DEFINE_ALL_FXVIE_, "ALL_FXVIE");
ACM200 ALL_ACM(_GROUP_CHANNEL_DEFINE_ALL_ACM_, "ALL_ACM");
ACM200 ALL_BUCKIN(_GROUP_CHANNEL_DEFINE_BUCK123_, "ALL_BUCKIN");
ACM200 BUCK123SW(_GROUP_CHANNEL_DEFINE_BUCK123SW_, "BUCK123SW");
QVMe ALL_QVM(_GROUP_CHANNEL_DEFINE_ALL_QVM_, "ALL_QVM");
QTMUe ALL_QTMU(_GROUP_CHANNEL_DEFINE_ALL_QTMU_, "ALL_QTMU");
ACM200 EVEN1_ACM(_GROUP_CHANNEL_DEFINE_EVEN1_ACM_, "EVEN1_ACM");
ACM200 ODD1_ACM(_GROUP_CHANNEL_DEFINE_ODD1_ACM_, "ODD1_ACM");
ACM200 EVEN2_ACM(_GROUP_CHANNEL_DEFINE_EVEN2_ACM_, "EVEN2_ACM");
ACM200 ODD2_ACM(_GROUP_CHANNEL_DEFINE_ODD2_ACM_, "ODD2_ACM");
FXVIe_PLUS EVEN1_FXVIE(_GROUP_CHANNEL_DEFINE_EVEN1_FXVIE_, "EVEN1_FXVIE");
FXVIe_PLUS ODD1_FXVIE(_GROUP_CHANNEL_DEFINE_ODD1_FXVIE_, "ODD1_FXVIE");
FXVIe_PLUS EVEN2_FXVIE(_GROUP_CHANNEL_DEFINE_EVEN2_FXVIE_, "EVEN2_FXVIE");
FXVIe_PLUS ODD2_FXVIE(_GROUP_CHANNEL_DEFINE_ODD2_FXVIE_, "ODD2_FXVIE");
FXVIe_PLUS PREBOOT_SW(_GROUP_CHANNEL_DEFINE_PREBOOT_SW_, "PREBOOT_SW");
/****multisite settings should be included here****/
DUT_API void HardWareCfg()
{

	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_1, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE1_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_2, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE2_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_3, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE3_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_4, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE4_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_5, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE5_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_6, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE6_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_7, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE7_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_8, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE8_);

	STSSetMultiSiteBind(MD_ACM200, SITE_1, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE1_);
	STSSetMultiSiteBind(MD_ACM200, SITE_2, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE2_);
	STSSetMultiSiteBind(MD_ACM200, SITE_3, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE3_);
	STSSetMultiSiteBind(MD_ACM200, SITE_4, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE4_);
	STSSetMultiSiteBind(MD_ACM200, SITE_5, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE5_);
	STSSetMultiSiteBind(MD_ACM200, SITE_6, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE6_);
	STSSetMultiSiteBind(MD_ACM200, SITE_7, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE7_);
	STSSetMultiSiteBind(MD_ACM200, SITE_8, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE8_);

	STSSetMultiSiteBind(MD_FPVIe, SITE_1, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE1_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_2, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE2_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_3, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE3_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_4, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE4_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_5, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE5_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_6, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE6_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_7, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE7_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_8, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE8_);

	STSSetMultiSiteBind(MD_QVMe, NO_SITE, _PIN_SITE_BIND_DEFINE_MD_QVME_NOSITE);
	STSSetMultiSiteBind(MD_QTMUe, NO_SITE, _PIN_SITE_BIND_DEFINE_MD_QTMUE_NOSITE);

}
/****STS_PINPLANNER_CODE_END****/

extern "C" int GetPgsFullPath(LPTSTR pgsPath, int chNum);
string pgs_path;
bool DO_TRIM = true;
bool QC = false;
int DEBUG = 1;
int firmwareEnable = 1;
int globalsite;
int boardid;
//int PAT_UNLOADED = 1;
int PART_NO = 62595;
int treg_log_mode = 0;//2 for debug ,0 for standard
DWORD original_validsite;
//board check coding
bool DO_BoardCheck = false;
bool DO_FMEA = false;
extern BOOL run_diags();     // global funtion for HW checker
bool DO_CHAR = false;
int GPIB_CHAR_ENABLE = 0;
int g_dieid_x = 0;
int g_dieid_y = 0;
int wafer_id;
int dataread[SITE_NUM] = { 0 };
int scan_flag = 1;
int test_stage = 0;
int SSD_EN = 0;
int bk12mult=0;
ULONG rdata[SITE_NUM];
double glb_res[SITE_NUM];
XY_COOR maprslt[4000];
eGPIB egpib;
BYTE sitesta[SITE_NUM];
DCM dcm;
CBITe cbite;
TREG dut;
SPEC spec;
AWG_FUNC awg;
eFMEA efmea;

ACM200 acm_grp[12] = { VDDIO_VBOOST_0, VBOS_1, BUCK1IN_2, BUCK2IN_3, BUCK3IN_4, BUCK1SW_5, BUCK2SW_6, BUCK3SW_BOOSTLS_7, PREFB_BUCK1FB_8, PRECSP_BUCK2FB_9, PRECMP_BUCK3FB_INTB_10, VSUP_11 };
FXVIe_PLUS fxvie_grp[6] = { A0_FIN_DBG_ERR_FCCU1, A1_FOUT_RSTB_FCCU2, A2_PGOOD, A3_INTB, A4_PSYNC_PREFB, A5_AMUX };
FXVIe_PLUS fxvie_grpb[6] = { B0_PRESW_LDO1IN, B1_PREGHS_PREGLS_LDO1OUT, B2_PREBOOT_VBOOST, B3_WAKE12, B4_VSUP_LDO2OUT, B5_VMON1234 };

QVMe qvm_grp[SITE_NUM] = { QVM1_3, QVM1_3, QVM1_1, QVM1_1, QVM1_2, QVM1_2, QVM1_0, QVM1_0 };//if 8 sites,repeat the name.
QTMUe qtmu_grp[SITE_NUM] = { QTMU23_3, QTMU23_3, QTMU23_1, QTMU23_1, QTMU23_2, QTMU23_2, QTMU23_0, QTMU23_0};


int i = 0;
bool m_burn_flag[SITE_NUM];
bool fs_burn_flag[SITE_NUM];
bool user_otp_burn_flag[SITE_NUM];
double g_amux_vos[SITE_NUM] = { 0 };
double g_freq_slow[SITE_NUM] = { 0 };
double g_freq_fast[SITE_NUM] = { 0 };
double g_freq_20MHz[SITE_NUM] = { 20000.0 };

double g_rdson_boost[SITE_NUM] = { 0.075 };//ohm
double g_rsns_boost[SITE_NUM] = { 1250 };//ohm
double g_rsns_v_boost[SITE_NUM] = { 0.15 };//V

double g_ilmt_pk_buck1[SITE_NUM] = {2.0};
double g_ilmt_pk_buck2[SITE_NUM] = { 2.0 };
double g_ilmt_pk_buck3[SITE_NUM] = { 2.0 };

double g_ilmt_pkmini_buck1[SITE_NUM] = { -0.5 };

double g_temp[SITE_NUM] = { 25 };

SAMPLE_NAME_CODE	SC6295X[20];
int find_ID = -1;
int last_find_ID = -1;
 double temp_meas(int site, int state)
 {
	 double res, temperature;
	 temperature = 25;
	 if (state == 0) {

		 //setup up for pin os test

		 
		 cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, -1);
		 SPIInitial(4.0, 0, 2.0, 1.9, 200);
		delay_ms(1);
	
		VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
		VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
		A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
		delay_ms(5);
		Enter_MAIN_TM_DIG();
		Enter_FS_TM_DIG();
		SPIWrite(0x3F, 0x7401);
		SPIWrite(0x04, 0x0002);
		SPIWrite(0x3F, 0x7481);
	 }

	 //get test result,and cal the temp
	 delay_ms(3);
	 A5_AMUX.MeasureVI(30, 10);
	 res = A5_AMUX.GetMeasResult(site, MVRET);
	temperature = (1.26 - res) / 3.93 * 1000 + 25.0;
	 if (state == 2) {
		 //off resource ,and ready to run
		 VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
		 VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
		 A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
		 delay_ms(5);//for cap discharge

		 power_off(1);
	 }
	 return temperature;
 }
/************************************************************************/
/*                                                                      */
/************************************************************************/
//initialize function will be called before all the test functions.
DUT_API void UserLoad()
{
	char pgsname[100];
	int t;
	t=dcm.LoadVectorFile("SAO6259XQ.acvec", FALSE);

	dcm.SetPinGroup("MISO", "MISO_D");
	dcm.SetPinGroup("MOSI", "MOSI_D");	
	dcm.SetPinGroup("SCLK", "SCLK_D");
	dcm.SetPinGroup("CSB", "CSB_D");
	dcm.SetPinGroup("SCL_DBG", "SCL_DBG_D");
	dcm.SetPinGroup("SDA_WAKE1", "SDA_WAKE1_D");
	dcm.SetPinGroup("FIN_WAKE2", "FIN_WAKE2_D");
	dcm.SetPinGroup("FOUT_INTB", "FOUT_INTB_D");

	dcm.SetPinGroup("I2C_G", "SCL_DBG_D,SDA_WAKE1_D");
	dcm.SetPinGroup("SPI_G", "MISO_D,MOSI_D,SCLK_D,CSB_D");
	dcm.SetPinGroup("SPI_G1", "MISO_D,MOSI_D,CSB_D");
	dcm.SetPinGroup("EVEN_G", "MISO_D,SCLK_D,SCL_DBG_D,FOUT_INTB_D");
	dcm.SetPinGroup("ODD_G", "MOSI_D,CSB_D,SDA_WAKE1_D,FIN_WAKE2_D");
	dcm.SetPinGroup("DCM_ALLPINS", "MISO_D,MOSI_D,SCLK_D,CSB_D,SCL_DBG_D,SDA_WAKE1_D,FIN_WAKE2_D,FOUT_INTB_D");
	//dcm.SetPinGroup("DCM_OSPINS", "SCL_D,SDA_D,ALT_D,ISENN_D,ISENP_D,EN_D");
	dcm.SetPinGroup("SCAN_PINS", "FIN_WAKE2_D,SCL_DBG_D,SCLK_D,SDA_WAKE1_D,MISO_D");

	dcm.SetPinGroup("CLK_CHK_G", "FIN_WAKE2_D,FOUT_INTB_D");
	dcm.SetPinGroup("DBG_WAKE1_G", "SCL_DBG_D,SDA_WAKE1_D");
	dcm.SetPinGroup("WAKE12_G", "SDA_WAKE1_D,FIN_WAKE2_D");
	dcm.SetPinGroup("DBG_WAKE12_G", "SCL_DBG_D,SDA_WAKE1_D,FIN_WAKE2_D");
	dcm.SetPinGroup("PPL_G", "MISO_D,MOSI_D,SCLK_D,CSB_D,FIN_WAKE2_D");
	//FIN_WAKE2_D =>shift_en
	//SCL_DBG_D =>scan_clock
	//SCLK_D =>scan_reset
	//SDA_WAKE1_D =>scan_data_in
	//MISO_D =>scan_data_out

	//dcm.SetPinGroup("DCM_BC_ALLPINS", "SCL_D,SDA_D,ISENN_D");
	//dcm.SetPinGroup("EVEN_G", "SCL_D,ALT_D,ISENN_D,EN_D");
	//dcm.SetPinGroup("ODD_G", "SDA_D,ISENP_D");
	//

	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_1, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE1_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_2, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE2_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_3, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE3_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_4, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE4_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_5, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE5_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_6, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE6_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_7, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE7_);
	STSSetMultiSiteBind(MD_FXVIe_PLUS, SITE_8, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE8_);

	STSSetMultiSiteBind(MD_ACM200, SITE_1, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE1_);
	STSSetMultiSiteBind(MD_ACM200, SITE_2, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE2_);
	STSSetMultiSiteBind(MD_ACM200, SITE_3, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE3_);
	STSSetMultiSiteBind(MD_ACM200, SITE_4, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE4_);
	STSSetMultiSiteBind(MD_ACM200, SITE_5, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE5_);
	STSSetMultiSiteBind(MD_ACM200, SITE_6, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE6_);
	STSSetMultiSiteBind(MD_ACM200, SITE_7, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE7_);
	STSSetMultiSiteBind(MD_ACM200, SITE_8, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE8_);

	STSSetMultiSiteBind(MD_FPVIe, SITE_1, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE1_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_2, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE2_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_3, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE3_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_4, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE4_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_5, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE5_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_6, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE6_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_7, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE7_);
	STSSetMultiSiteBind(MD_FPVIe, SITE_8, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE8_);

	STSSetMultiSiteBind(MD_QVMe, NO_SITE, _PIN_SITE_BIND_DEFINE_MD_QVME_NOSITE);
	STSSetMultiSiteBind(MD_QTMUe, NO_SITE, _PIN_SITE_BIND_DEFINE_MD_QTMUE_NOSITE);

	AstBindingAllModule();

	
	//load_mapping(pathofmapping, maprslt);
	
	STSSetSiteStatus(0xFFFF);
	for (int i = 0; i < 12; i++)
	{
		acm_grp[i].Set(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_OFF);
		acm_grp[i].AwgClear();
	}

	for (int i = 0; i < 4; i++)
	{
		fxvie_grp[i].Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);
		fxvie_grp[i].AwgClear();
	}

	dcm.InitPPMU("DCM_ALLPINS");
	dcm.Disconnect("DCM_ALLPINS");
	
	FPVIM.Set(FI, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
	FPVIM.AwgClear();

	boardid = 99;
	if (DO_BoardCheck)
		run_diags();
	//check pgs name if include "char", do char test if yes
	STSGetPgsName(pgsname, sizeof(pgsname) / sizeof(pgsname[0]));
	int k = -1;
	while (pgsname[k++])
		pgsname[k] = tolower(pgsname[k]);

	if (strstr(pgsname, "char") != NULL)
		DO_CHAR = true;
	else
		DO_CHAR = false;
	test_stage = 0;
	SC6295X[0].name = "SC6259XQ";		SC6295X[0].treg_name = "SC6259XQ"; SC6295X[0].partname = 62595.1;	 SC6295X[0].useropt_burn = 0;
	SC6295X[1].name = "SC62594Q_NUB";		SC6295X[1].treg_name = "SC62594Q"; SC6295X[1].partname = 62594.1;	 SC6295X[1].useropt_burn = 0;
	SC6295X[2].name = "SC62595Q_NUB";		SC6295X[2].treg_name = "SC6259XQ"; SC6295X[2].partname = 62595.2;	 SC6295X[2].useropt_burn = 0;
	SC6295X[3].name = "SC62595Q_HW";		SC6295X[3].treg_name = "HW_SC62595Q"; SC6295X[3].partname = 62595.3;SC6295X[3].useropt_burn = 1;
	SC6295X[4].name = "SC62595Q_HTOL";		SC6295X[4].treg_name = "SC62595Q_HTOL"; SC6295X[4].partname = 62595.4;SC6295X[4].useropt_burn = 1;
	SC6295X[5].name = "SC62595Q_2HW";		SC6295X[5].treg_name = "HW2_SC62595Q"; SC6295X[5].partname = 62595.5;SC6295X[5].useropt_burn = 1;
	SC6295X[6].name = "SC62594Q_WJ";		SC6295X[6].treg_name = "SC62594Q_wUOTP"; SC6295X[6].partname = 62594.2;SC6295X[6].useropt_burn = 1;

	SC6295X[7].name = "END";			SC6295X[7].treg_name = "END"; SC6295X[7].partname = 0;SC6295X[7].useropt_burn = 0;
	char pDes1[] = "Device ID";
	char pData1[256] = { 0 };
	char* ppDes[] = { pDes1 };
	char* ppData[] = { pData1 };
	int OK = -1;
	int Double_OK = -1;
	int times = 3;
	string msgstr;
	string In_ID;
	if (0) find_ID = 4;//force
	else
	while (OK != 1 && times > 0)
	{
		OK = STSPopupStringDialog("�����Ϻ�����", ppDes, ppData, 1, "��ʹ��ɨ��ǹ�����Ϻţ�", DO_BoardCheck);
		if (OK == 2)
		{
			if (times == 3) MessageBoxA(NULL, "û�е��OK,ȷ�����뷽ʽ�Ƿ���ȷ,ʣ��2�λ��ᣡ", "������ʾ�Ի���", MB_OK);
			if (times == 2) MessageBoxA(NULL, "û�е��OK,ȷ�����뷽ʽ�Ƿ���ȷ,ʣ��1�λ��ᣡ", "������ʾ�Ի���", MB_OK);
			if (times == 1) MessageBoxA(NULL, "û�е��OK,ȷ�����뷽ʽ�Ƿ���ȷ,ʣ��0�λ��ᣡ", "������ʾ�Ի���", MB_OK);
		}
		if (OK == 1)
		{
			In_ID = pData1;
			for (int i = 0; i < 20; i++)
			{
				if (SC6295X[i].name == "END" || i == 19)
				{
					OK = -1;
					if (times == 3) MessageBoxA(NULL, "û��ƥ�䵽��ȷDevice ID,ʣ��2�λ��ᣬ���������룡", "������ʾ�Ի���", MB_OK);
					if (times == 2) MessageBoxA(NULL, "û��ƥ�䵽��ȷDevice ID,ʣ��1�λ��ᣬ���������룡", "������ʾ�Ի���", MB_OK);
					if (times == 1) MessageBoxA(NULL, "û��ƥ�䵽��ȷDevice ID,ʣ��0�λ��ᣬ���������룡", "������ʾ�Ի���", MB_OK);

					break;
				}

				else if (In_ID.compare(0, SC6295X[i].name.length(), SC6295X[i].name, 0, SC6295X[i].name.length()) == 0)
				{

					find_ID = i;
					msgstr = "�����Ѿ��ҵ����Ϻ�������:" + In_ID;
					Double_OK = MessageBoxA(NULL, msgstr.c_str(), "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);

					break;
				}

			}

		}
		times--;
	}



	if (find_ID == -1 || Double_OK == 7)
		PostQuitMessage(0);


	int teststageres;
	string pgsstr;
	//STSGetPgsName(pgsname, 50);
	pgsstr = pgsname;

//	teststageres = pgsstr.find("_ENG_CHAR");
//	if (teststageres != -1)
//		DO_CHAR = TRUE;
	teststageres = pgsstr.find("_h_");
	if (teststageres != -1) //== 0x12)
		test_stage = 1;
	else
	{
		teststageres = pgsstr.find("_l_");
		if (teststageres != -1)// == 0x12)
			test_stage = 2;
		else
			test_stage = 0;
	}
	teststageres = pgsstr.find("_qc");
	if (teststageres != -1) //== 0x14)
		QC = 1;
	else
		QC = 0;


	//GPIB enable and setting
	//=========GPIB======================//
	if (DO_CHAR)
		GPIB_CHAR_ENABLE = 1;//change the code if needed
	else
		GPIB_CHAR_ENABLE = 0;

	if (DO_FMEA)
		efmea.fmea_enable = 1;
	//GPIB_CHAR_ENABLE = 2;
	double tempgrp[] = { 25, -10, -40, 85, 125 ,150};
	egpib.add_temp_func(temp_meas);
	egpib.set_loopcount(1);
	egpib.set_soaktime(30000);//ms
	egpib.tempcycle_setting(tempgrp, sizeof(tempgrp) / sizeof(tempgrp[0]));
	//GPIB_CHAR_ENABLE=1 enable char,GPIB_CHAR_ENABLE=0 disable char and debug window, GPIB_CHAR_ENABLE>1, disable char ,enable debug window for printf output
	egpib.userload(GPIB_CHAR_ENABLE);//enable GPIB or disable it
	//char pgsname[100];
	SSD_EN = 0;
/* for cp only
	int	handler_fd = ibdev(0, 5, 0, T10s, 1, 0);//��GPIB�ϵ�ַΪ5������
	ibwrt(handler_fd, "f1\r\n", strlen("f1\r\n"));
	delay_ms(10);
	char results_string[110] = "";
	ibrd(handler_fd, results_string, 100);
	int temp = 0;
	if (results_string[0] == 45)
		temp = - (results_string[1] - 48) * 10 - (results_string[2] - 48);
	else
		temp = (results_string[0] - 48) * 100+ (results_string[1] - 48) * 10 + (results_string[2] - 48);

	if ((test_stage == 0) && (temp<22 || temp>28))
	{
		MessageBox(NULL, "Warning���ò�ƷCP1��Ҫ��25�Ȳ��ԣ�����ȷ��CHUCK̨�¶Ⱥ��ٵ�����", "�Ի����������ʾ����", MB_TOPMOST | MB_ICONSTOP);
		exit(0);
	}
	else if ((test_stage == 1) && (temp < 122 || temp>128))
	{
		MessageBox(NULL, "Warning���ò�ƷCP2��Ҫ��125�Ȳ��ԣ�����ȷ��CHUCK̨�¶Ⱥ��ٵ�����", "�Ի����������ʾ����", MB_TOPMOST | MB_ICONSTOP);
		exit(0);
	}
	else if ((test_stage == 2) && (temp < -42 || temp>-38))//need check string 0 for native temp
	{
		MessageBox(NULL, "Warning���ò�ƷCP3��Ҫ��-40�Ȳ��ԣ�����ȷ��CHUCK̨�¶Ⱥ��ٵ�����", "�Ի����������ʾ����", MB_TOPMOST | MB_ICONSTOP);
		exit(0);
	}
	*/
	//=====================================//
}
/*                                                                      */
/************************************************************************/
DUT_API void UserInit()
{

	char pgsfullpath[300];
	GetPgsFullPath(pgsfullpath, 300);
	string fullpathpgs(pgsfullpath);
	string pathofpgs = "";

	int pos = fullpathpgs.find_last_of('\\');
	if (pos > -1)
	{
		pathofpgs = fullpathpgs.substr(0, pos + 1);
	}
	string pathoftreg = pathofpgs + SC6295X[find_ID].treg_name+ ".treg";
	//string pathofmapping = pathofpgs + "SC8741_mapping.csv";
	pgs_path = pathofpgs;
	if (test_stage > 0) DO_TRIM = 0;
	dut.init(pathoftreg.c_str(), SITE_NUM, QC, DO_TRIM);
	spec.init(pgsfullpath);
	for (int i = 0; i < 12; i++)
	{
		acm_grp[i].Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
		acm_grp[i].AwgClear();
	}
	
	for (int i = 0; i < 6; i++)
	{
		fxvie_grp[i].Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
		fxvie_grp[i].AwgClear();
	}

	dcm.InitPPMU("DCM_ALLPINS");
	dcm.InitMCU("DCM_ALLPINS");
	dcm.Disconnect("DCM_ALLPINS");
	ALL_QVM.Disconnect();
	FPVIM.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
	FPVIM.AwgClear();

	cbite.SetOn(-1);
	
	if ((test_stage == 2) || (test_stage==1)|| (QC==1))
		dut.force_skip_post_measurement(true);

	awg.awgReload();
}
/************************************************************************/
DUT_API void UserExit()
{
	egpib.userexit();
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
DUT_API void InitBeforeTestFlow()
{
	
	//check if need reload awg due to site change.
	int sitecount=0;
	//awg.awgReload();
	awg.StartLoad();

	FPVIM.Set(FI, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
	for (int i = 0; i < 12; i++)
	{
		acm_grp[i].TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	}
	

	for (int i = 0; i < 6; i++)
	{
		fxvie_grp[i].TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	}
	STSTArming();
	dcm.InitPPMU("DCM_ALLPINS");
	dcm.InitMCU("DCM_ALLPINS");
	dcm.Disconnect("DCM_ALLPINS");
	
	cbite.SetOn(-1);

	//DEBUG = false;
	dut.sot();
//	treg2pgs();
	egpib.retest_type = 1;
	egpib.sot();
	efmea.sot();

	if (DO_CHAR) dut.force_table_char_active(1);
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//initializefunction will be called after all the test functions.
DUT_API void InitAfterTestFlow()
{
	
	awg.EndLoad();
	
	FPVIM.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
	for (int i = 0; i < 12; i++)
	{
		acm_grp[i].TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	}


	for (int i = 0; i < 6; i++)
	{
		fxvie_grp[i].TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	}
	STSTArming();
	dcm.InitPPMU("DCM_ALLPINS");
	dcm.InitMCU("DCM_ALLPINS");
	dcm.Disconnect("DCM_ALLPINS");
	ALL_QVM.Disconnect();
	cbite.SetOn(-1);


}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//Fail site hardware set function will be called after failed params, it can be called for serveral times.
DUT_API void SetupFailSite(const unsigned char*byFailSite)
{
	//int failsite;

	awg.Check();

	efmea.fmea_onfailsite();

}
/************************************************************************/
/*                                                                      */
/************************************************************************/

DUT_API void BinOutDut()
{

	dut.eot();
	egpib.eot();
	efmea.eot();
}
/************************************************************************/
/*                                                                      */

DUT_API int T01_TEST_INFO(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Part_No = StsGetParam(funcindex,"Part_No");
    CParam *QC_flag = StsGetParam(funcindex,"QC_flag");
    CParam *TRIM = StsGetParam(funcindex,"TRIM");
	CParam *TEMP_COND = StsGetParam(funcindex, "TEMP_COND");
	CParam *DIE_ID = StsGetParam(funcindex, "DIE_ID");
	CParam *BoardID = StsGetParam(funcindex, "BoardID");
    //}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	

	SERIAL 
	{
		Part_No->SetTestResult(SITE, 0, SC6295X[find_ID].partname);
		 QC_flag->SetTestResult(SITE, 0, QC);
		 TRIM->SetTestResult(SITE, 0, DO_TRIM);
		 BoardID->SetTestResult(SITE, 0, boardid);

	}
	if (DO_CHAR)
	{
		if (GPIB_CHAR_ENABLE)
		{
			SERIAL
			{
				TEMP_COND->SetTestResult(SITE, 0, egpib.get_set_temp());
				DIE_ID->SetTestResult(SITE, 0, egpib.dieid);
			}
		}

	}

    return 0;
}


DUT_API int T02_TEST_OS(short funcindex, LPCTSTR funclabel)
{

	CParam *OS_SHORT = StsGetParam(funcindex, "OS_SHORT");
	CParam *OS_SOME_OPEN = StsGetParam(funcindex, "OS_SOME_OPEN");
	CParam *OS_ALL_OPEN = StsGetParam(funcindex, "OS_ALL_OPEN");
	CParam *AGND_Kelvin_CRES = StsGetParam(funcindex, "AGND_Kelvin_CRES");
	CParam *PGND_Kelvin_CRES = StsGetParam(funcindex, "PGND_Kelvin_CRES");
	CParam *PVIN_Bonding_CHECK = StsGetParam(funcindex, "PVIN_Bonding_CHECK");
	CParam *FPVIA_CHK_CSP_FB = StsGetParam(funcindex, "FPVIA_CHK_CSP_FB");
	CParam *FPVIA_CHK_PGND_BUCK1_SW = StsGetParam(funcindex, "FPVIA_CHK_PGND_BUCK1_SW");
	CParam *FPVIA_CHK_BUCK1IN_BOOSTLS = StsGetParam(funcindex, "FPVIA_CHK_BUCK1IN_BOOSTLS");
	CParam *FPVIB_CHK_BUCK3IN_SW = StsGetParam(funcindex, "FPVIB_CHK_BUCK3IN_SW");
	CParam *FPVIC_CHK_BUCK2IN_SW = StsGetParam(funcindex, "FPVIC_CHK_BUCK2IN_SW");
	CParam *FPVID_CHK_PRE_BOOT_SW = StsGetParam(funcindex, "FPVID_CHK_PRE_BOOT_SW");

	CParam *OS_MISO = StsGetParam(funcindex, "OS_MISO");
	CParam *OS_MOSI = StsGetParam(funcindex, "OS_MOSI");
	CParam *OS_SCLK = StsGetParam(funcindex, "OS_SCLK");
	CParam *OS_CSB = StsGetParam(funcindex, "OS_CSB");
	CParam *OS_SCL = StsGetParam(funcindex, "OS_SCL");
	CParam *OS_SDA = StsGetParam(funcindex, "OS_SDA");
	CParam *OS_FIN = StsGetParam(funcindex, "OS_FIN");
	CParam *OS_FOUT = StsGetParam(funcindex, "OS_FOUT");
	CParam *OS_VDDIO = StsGetParam(funcindex, "OS_VDDIO");
	CParam *OS_VBOS = StsGetParam(funcindex, "OS_VBOS");
	CParam *OS_BUCK1IN = StsGetParam(funcindex, "OS_BUCK1IN");
	CParam *OS_BUCK2IN = StsGetParam(funcindex, "OS_BUCK2IN");
	CParam *OS_BUCK3IN = StsGetParam(funcindex, "OS_BUCK3IN");
	CParam *OS_BUCK1SW = StsGetParam(funcindex, "OS_BUCK1SW");
	CParam *OS_BUCK2SW = StsGetParam(funcindex, "OS_BUCK2SW");
	CParam *OS_BUCK3SW = StsGetParam(funcindex, "OS_BUCK3SW");
	CParam *OS_BUCK1FB = StsGetParam(funcindex, "OS_BUCK1FB");
	CParam *OS_BUCK2FB = StsGetParam(funcindex, "OS_BUCK2FB");
	CParam *OS_BUCK3FB = StsGetParam(funcindex, "OS_BUCK3FB");
	CParam *OS_VSUP = StsGetParam(funcindex, "OS_VSUP");
	CParam *OS_FCCU1 = StsGetParam(funcindex, "OS_FCCU1");
	CParam *OS_FCCU2 = StsGetParam(funcindex, "OS_FCCU2");
	CParam *OS_PGOOD = StsGetParam(funcindex, "OS_PGOOD");
	CParam *OS_INTB = StsGetParam(funcindex, "OS_INTB");
	CParam *OS_PSYNC = StsGetParam(funcindex, "OS_PSYNC");
	CParam *OS_AMUX = StsGetParam(funcindex, "OS_AMUX");

	CParam *OS_MISO_VDDIO = StsGetParam(funcindex, "OS_MISO_VDDIO");
	CParam *OS_FOUT_VDDIO = StsGetParam(funcindex, "OS_FOUT_VDDIO");
	CParam *OS_AMUX_VDDIO = StsGetParam(funcindex, "OS_AMUX_VDDIO");
	CParam *OS_BUCK1SW_IN = StsGetParam(funcindex, "OS_BUCK1SW_IN");
	CParam *OS_BUCK2SW_IN = StsGetParam(funcindex, "OS_BUCK2SW_IN");
	CParam *OS_BUCK3SW_IN = StsGetParam(funcindex, "OS_BUCK3SW_IN");

	CParam *OS_PRESW_PREBOOT = StsGetParam(funcindex, "OS_PRESW_PREBOOT");
	CParam *OS_PREGHS_PREBOOT = StsGetParam(funcindex, "OS_PREGHS_PREBOOT");
	CParam *OS_WAKE1 = StsGetParam(funcindex, "OS_WAKE1");
	CParam *OS_LDO2OUT = StsGetParam(funcindex, "OS_LDO2OUT");
	CParam *OS_VMON1 = StsGetParam(funcindex, "OS_VMON1");
	CParam *OS_VBOOST = StsGetParam(funcindex, "OS_VBOOST");
	CParam *OS_BOOSTLS = StsGetParam(funcindex, "OS_BOOSTLS");
	CParam *OS_PREFB = StsGetParam(funcindex, "OS_PREFB");
	CParam *OS_PRECSP = StsGetParam(funcindex, "OS_PRECSP");
	CParam *OS_PRECMP = StsGetParam(funcindex, "OS_PRECMP");


	CParam *OS_PREBOOT = StsGetParam(funcindex, "OS_PREBOOT");
	CParam *OS_PRESW_PREGHS = StsGetParam(funcindex, "OS_PRESW_PREGHS");


	CParam *OS_WAKE2 = StsGetParam(funcindex, "OS_WAKE2");
	CParam *OS_VMON2 = StsGetParam(funcindex, "OS_VMON2");
	CParam *OS_PREGLS = StsGetParam(funcindex, "OS_PREGLS");
	CParam *OS_PRECMP_VBOS = StsGetParam(funcindex, "OS_PRECMP_VBOS");
	CParam *OS_LDO2OUT_VBOOST = StsGetParam(funcindex, "OS_LDO2OUT_VBOOST");
	CParam *OS_PREGLS_VBOS = StsGetParam(funcindex, "OS_PREGLS_VBOS");
	CParam *OS_VMON3 = StsGetParam(funcindex, "OS_VMON3");
	CParam *OS_VMON4 = StsGetParam(funcindex, "OS_VMON4");
	CParam *OS_LDO1OUT_IN = StsGetParam(funcindex, "OS_LDO1OUT_IN");
	CParam *OS_ERRMON = StsGetParam(funcindex, "OS_ERRMON");
	CParam *OS_RSTB = StsGetParam(funcindex, "OS_RSTB");
	CParam *OS_FS0B = StsGetParam(funcindex, "OS_FS0B");
	CParam *OS_SSD = StsGetParam(funcindex, "OS_SSD");
	CParam *OS_DBG = StsGetParam(funcindex, "OS_DBG");


	CParam *TEMP = StsGetParam(funcindex, "TEMP");

	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	
	// TODO: Add your function code here
	//************************************ Add OS classify ***********************************************
	const int PIN_NUM = 58;
	const int LEAK_NUM = 0;
	const int exclude_NUM = 0;
	string pin_str_array[PIN_NUM] = {
		"OS_MISO",
		"OS_MOSI",
		"OS_SCLK",
		"OS_CSB",
		"OS_SCL",
		"OS_SDA",
		"OS_FIN",
		"OS_FOUT",
		"OS_VDDIO",
		"OS_VBOS",
		"OS_BUCK1IN",
		"OS_BUCK2IN",
		"OS_BUCK3IN",
		"OS_BUCK1SW",
		"OS_BUCK2SW",
		"OS_BUCK3SW",
		"OS_BUCK1FB",
		"OS_BUCK2FB",
		"OS_BUCK3FB",
		"OS_VSUP",
		"OS_FCCU1",
		"OS_FCCU2",
		"OS_PGOOD",
		"OS_INTB",
		"OS_PSYNC",
		"OS_AMUX",
		"OS_MISO_VDDIO",
		"OS_FOUT_VDDIO",
		"OS_AMUX_VDDIO",
		"OS_BUCK1SW_IN",
		"OS_BUCK2SW_IN",
		"OS_BUCK3SW_IN",
		"OS_PRESW_PREBOOT",
		"OS_PREGHS_PREBOOT",
		"OS_WAKE1",
		"OS_LDO2OUT",
		"OS_VMON1",
		"OS_VBOOST",
		"OS_BOOSTLS",
		"OS_PREFB",
		"OS_PRECSP",
		"OS_PRECMP",
		"OS_PREBOOT",
		"OS_PRESW_PREGHS",
		"OS_WAKE2",
		"OS_VMON2",
		"OS_PREGLS",
		"OS_PRECMP_VBOS",
		"OS_LDO2OUT_VBOOST",
		"OS_PREGLS_VBOS",
		"OS_VMON3",
		"OS_VMON4",
		"OS_LDO1OUT_IN",
		"OS_ERRMON",
		"OS_RSTB",
		"OS_FS0B",
		"OS_DBG",
		"OS_SSD",
	};
	

	double os_result[PIN_NUM][SITE_NUM] = { 0 };
	double res[SITE_NUM] = { 0 };

	vector<string> vec_exclude;

	//Kelvin check

	cbite.SetOn(K19_AGNDF_DCM, -1);
	delay_ms(1);
	dcm.Connect("FIN_WAKE2");
	dcm.SetPPMU("FIN_WAKE2_D", DCM_PPMU_FIMV, 10e-3, DCM_PPMUIRANGE_32MA);
	delay_ms(2);
	dcm.PPMUMeasure("FIN_WAKE2", 30, 10);
	SERIAL
	{

		res[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		AGND_Kelvin_CRES->SetTestResult(SITE, 0, res[SITE]/0.01);
	}
	dcm.SetPPMU("FIN_WAKE2_D", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);

	cbite.SetOn(K21_PADF_AGNDF, K20_PADS_ACM, - 1);
	delay_ms(1);

	VDDIO_VBOOST_0.Set(FI, 10e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	
	delay_ms(2);
	VDDIO_VBOOST_0.MeasureVI(30, 10);
	SERIAL
	{
		res[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MVRET);
		PGND_Kelvin_CRES->SetTestResult(SITE, 0, res[SITE] / 0.01);
	}

	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);

	cbite.SetOn(K49_VSUP2_FXVIB, K113_FXVI4_10_B ,- 1);
	delay_ms(1);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	VSUP_11.Set(FI, 20e-3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(2);
	VSUP_11.MeasureVI(30, 10);
	SERIAL
	{
		res[SITE] = VSUP_11.GetMeasResult(SITE, MVRET);
		PVIN_Bonding_CHECK->SetTestResult(SITE, 0, res[SITE] / 0.02);
	}
	VSUP_11.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	VSUP_11.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);


	//Kelvin check



	//FPVI Matrix contact check
	cbite.SetOn(K88_FPVI1H_A, K96_FPVI0H_A, K92_FPVI1L_A, K100_FPVI0L_A, K63_CSP_FB_FPVIHL, -1);
	delay_ms(1);
	//all open
	FPVIM.ContactCheck(FPVIe_ALL_SIDE);

	SERIAL
	{
		res[SITE] = FPVIM.GetContactCheckResult(SITE);
		FPVIA_CHK_CSP_FB->SetTestResult(SITE, 0, res[SITE] );
	}

	cbite.SetOn(K88_FPVI1H_A, K96_FPVI0H_A, K92_FPVI1L_A, K100_FPVI0L_A, K64_PGND_FPVIH, K67_SW_FPVIL ,- 1);
	delay_ms(1);
	
	FPVIM.ContactCheck(FPVIe_ALL_SIDE);

	SERIAL
	{
		res[SITE] = FPVIM.GetContactCheckResult(SITE);
		FPVIA_CHK_PGND_BUCK1_SW->SetTestResult(SITE, 0, res[SITE] );
	}


	cbite.SetOn(K88_FPVI1H_A, K96_FPVI0H_A, K92_FPVI1L_A, K100_FPVI0L_A, K65_BUCK1IN_FPVIH, K68_BOOSTLS_FPVIL, -1);
	delay_ms(1);
	
	FPVIM.ContactCheck(FPVIe_ALL_SIDE);

	SERIAL
	{
		res[SITE] = FPVIM.GetContactCheckResult(SITE);
		FPVIA_CHK_BUCK1IN_BOOSTLS->SetTestResult(SITE, 0, res[SITE]);
	}



	cbite.SetOn(K89_FPVI1H_B, K93_FPVI1L_B, K97_FPVI0H_B, K101_FPVI0L_B, -1);
	delay_ms(1);
	FPVIM.ContactCheck(FPVIe_ALL_SIDE);

	SERIAL
	{
		res[SITE] = FPVIM.GetContactCheckResult(SITE);
		FPVIB_CHK_BUCK3IN_SW->SetTestResult(SITE, 0, res[SITE]);
	}

	cbite.SetOn(K90_FPVI1H_C, K94_FPVI1L_C, K98_FPVI0H_C, K102_FPVI0L_C, -1);
	delay_ms(1);
	FPVIM.ContactCheck(FPVIe_ALL_SIDE);

	SERIAL
	{
		res[SITE] = FPVIM.GetContactCheckResult(SITE);
		FPVIC_CHK_BUCK2IN_SW->SetTestResult(SITE, 0, res[SITE]);
	}
	cbite.SetOn(K91_FPVI1H_D, K95_FPVI1L_D, K99_FPVI0H_D, K103_FPVI0L_D, -1);
	delay_ms(1);
	FPVIM.ContactCheck(FPVIe_ALL_SIDE);

	SERIAL
	{
		res[SITE] = FPVIM.GetContactCheckResult(SITE);
		FPVID_CHK_PRE_BOOT_SW->SetTestResult(SITE, 0, res[SITE]);
	}
	
	//--------FPVI Matrix END-------------//

	cbite.SetOn(K8_SCL_SDA_DCM, K18_FIN_DCM, K26_FOUT_DCM, K24_VDDIO_ACM, K4_BUCK3SW_ACM, K33_BUCK12SW_ACM, K7_BUCK3FB_ACM, K29_BUCK2FB_ACM, 
		K36_BUCK1FB_ACM, K28_FCCU12_FXVIA, K15_PGOOD_FXVIA, K32_INTB_FXVIA, K35_PSYNC_FXVIA, K27_220_SHRT ,
		K104_FXVI0_6_A, K106_FXVI1_7_A, K108_FXVI2_8_A, K110_FXVI3_9_A, K112_FXVI4_10_A, K114_FXVI5_11_A ,- 1);//vbos,buck1,2,3 in
	delay_ms(1);
	dcm.Connect("DCM_ALLPINS");

	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FIMV, -1e-3, DCM_PPMUIRANGE_2MA);
	ALL_FXVIE.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	ALL_ACM.Set(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	dcm.PPMUMeasure("DCM_ALLPINS", 10, 10);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	SERIAL
	{

		os_result[0][SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		OS_MISO->SetTestResult(SITE, 0, os_result[0][SITE]);

		os_result[1][SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		OS_MOSI->SetTestResult(SITE, 0, os_result[1][SITE]);

		os_result[2][SITE] = dcm.GetPPMUMeasResult("SCLK_D", SITE);
		OS_SCLK->SetTestResult(SITE, 0, os_result[2][SITE]);

		os_result[3][SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		OS_CSB->SetTestResult(SITE, 0, os_result[3][SITE]);

		os_result[4][SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		OS_SCL->SetTestResult(SITE, 0, os_result[4][SITE]);

		os_result[5][SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		OS_SDA->SetTestResult(SITE, 0, os_result[5][SITE]);

		os_result[6][SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		OS_FIN->SetTestResult(SITE, 0, os_result[6][SITE]);

		os_result[7][SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		OS_FOUT->SetTestResult(SITE, 0, os_result[7][SITE]);
		
		os_result[8][SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MVRET);
		OS_VDDIO->SetTestResult(SITE, 0, os_result[8][SITE]);

		os_result[9][SITE] = VBOS_1.GetMeasResult(SITE, MVRET);
		OS_VBOS->SetTestResult(SITE, 0, os_result[9][SITE]);

		os_result[10][SITE] = BUCK1IN_2.GetMeasResult(SITE, MVRET);
		OS_BUCK1IN->SetTestResult(SITE, 0, os_result[10][SITE]);

		os_result[11][SITE] = BUCK2IN_3.GetMeasResult(SITE, MVRET);
		OS_BUCK2IN->SetTestResult(SITE, 0, os_result[11][SITE]);

		os_result[12][SITE] = BUCK3IN_4.GetMeasResult(SITE, MVRET);
		OS_BUCK3IN->SetTestResult(SITE, 0, os_result[12][SITE]);

		os_result[13][SITE] = BUCK1SW_5.GetMeasResult(SITE, MVRET);
		OS_BUCK1SW->SetTestResult(SITE, 0, os_result[13][SITE]);

		os_result[14][SITE] = BUCK2SW_6.GetMeasResult(SITE, MVRET);
		OS_BUCK2SW->SetTestResult(SITE, 0, os_result[14][SITE]);

		os_result[15][SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MVRET);
		OS_BUCK3SW->SetTestResult(SITE, 0, os_result[15][SITE]);

		os_result[16][SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MVRET);
		OS_BUCK1FB->SetTestResult(SITE, 0, os_result[16][SITE]);

		os_result[17][SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MVRET);
		OS_BUCK2FB->SetTestResult(SITE, 0, os_result[17][SITE]);

		os_result[18][SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MVRET);
		OS_BUCK3FB->SetTestResult(SITE, 0, os_result[18][SITE]);

		os_result[19][SITE] = VSUP_11.GetMeasResult(SITE, MVRET);
		OS_VSUP->SetTestResult(SITE, 0, os_result[19][SITE]);

		os_result[20][SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MVRET);
		OS_FCCU1->SetTestResult(SITE, 0, os_result[20][SITE]);

		os_result[21][SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MVRET);
		OS_FCCU2->SetTestResult(SITE, 0, os_result[21][SITE]);

		os_result[22][SITE] = A2_PGOOD.GetMeasResult(SITE, MVRET);
		OS_PGOOD->SetTestResult(SITE, 0, os_result[22][SITE]);

		os_result[23][SITE] = A3_INTB.GetMeasResult(SITE, MVRET);
		OS_INTB->SetTestResult(SITE, 0, os_result[23][SITE]);

		os_result[24][SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MVRET);
		OS_PSYNC->SetTestResult(SITE, 0, os_result[24][SITE]);

		os_result[25][SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		OS_AMUX->SetTestResult(SITE, 0, os_result[25][SITE]);



	}

	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
	ALL_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	ALL_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);

	dcm.SetPPMU("MISO", DCM_PPMU_FIMV, 1e-3, DCM_PPMUIRANGE_2MA);
	dcm.SetPPMU("FOUT_INTB", DCM_PPMU_FIMV, 1e-3, DCM_PPMUIRANGE_2MA);
	A5_AMUX.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	BUCK123SW.Set(FI, 1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);

	dcm.PPMUMeasure("MISO", 30, 10);
	dcm.PPMUMeasure("FOUT_INTB", 30, 10);
	A5_AMUX.MeasureVI(30, 10);
	BUCK123SW.MeasureVI(30, 10);
	SERIAL
	{

		os_result[26][SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		OS_MISO_VDDIO->SetTestResult(SITE, 0, os_result[26][SITE]);

		os_result[27][SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		OS_FOUT_VDDIO->SetTestResult(SITE, 0, os_result[27][SITE]);

		os_result[28][SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		OS_AMUX_VDDIO->SetTestResult(SITE, 0, os_result[28][SITE]);

		os_result[29][SITE] = BUCK1SW_5.GetMeasResult(SITE, MVRET);
		OS_BUCK1SW_IN->SetTestResult(SITE, 0, os_result[29][SITE]);

		os_result[30][SITE] = BUCK2SW_6.GetMeasResult(SITE, MVRET);
		OS_BUCK2SW_IN->SetTestResult(SITE, 0, os_result[30][SITE]);

		os_result[31][SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MVRET);
		OS_BUCK3SW_IN->SetTestResult(SITE, 0, os_result[31][SITE]);

	}

	dcm.SetPPMU("MISO", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
	dcm.SetPPMU("FOUT_INTB", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
	A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	BUCK123SW.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);

	cbite.SetOn(K8_SCL_SDA_DCM, K18_FIN_DCM, K26_FOUT_DCM, K40_VBOOST_ACM, K3_BOOSTLS_ACM, K46_PREFB_ACM, K39_PRECSP_ACM, K38_PRECOMP_ACM,
		K42_PRESW_FXVIB, K43_PREGHS_FXVIB, K44_PREBOOT_FXVIB, K47_WAKE1_FXVIB, K13_VMON1_FXVIB, K51_LDO2_FXVIB,
		K105_FXVI0_6_B, K107_FXVI1_7_B, K109_FXVI2_8_B, K111_FXVI3_9_B, K113_FXVI4_10_B, K115_FXVI5_11_B, K21_PADF_AGNDF,- 1);//
	delay_ms(1);

	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B3_WAKE12.TSet(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.TSet(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	VDDIO_VBOOST_0.TSet(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	STSTArming();
	delay_ms(4);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);

	SERIAL
	{

	//	os_result[32][SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MVRET);
	//	OS_PRESW->SetTestResult(SITE, 0, os_result[32][SITE]);

		os_result[43][SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		OS_PRESW_PREGHS->SetTestResult(SITE, 0, os_result[43][SITE]);

		os_result[34][SITE] = B3_WAKE12.GetMeasResult(SITE, MVRET);
		OS_WAKE1->SetTestResult(SITE, 0, os_result[34][SITE]);

		os_result[35][SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		OS_LDO2OUT->SetTestResult(SITE, 0, os_result[35][SITE]);

		os_result[36][SITE] = B5_VMON1234.GetMeasResult(SITE, MVRET);
		OS_VMON1->SetTestResult(SITE, 0, os_result[36][SITE]);

		os_result[37][SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MVRET);
		OS_VBOOST->SetTestResult(SITE, 0, os_result[37][SITE]);

		os_result[38][SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MVRET);
		OS_BOOSTLS->SetTestResult(SITE, 0, os_result[38][SITE]);

		os_result[39][SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MVRET);
		OS_PREFB->SetTestResult(SITE, 0, os_result[39][SITE]);

		os_result[40][SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MVRET);
		OS_PRECSP->SetTestResult(SITE, 0, os_result[40][SITE]);

		os_result[41][SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MVRET);
		OS_PRECMP->SetTestResult(SITE, 0, os_result[41][SITE]);

	
	}

	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B0_PRESW_LDO1IN.MeasureVI(30, 10);
	SERIAL
	{

		os_result[32][SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MVRET);
		OS_PRESW_PREBOOT->SetTestResult(SITE, 0, os_result[32][SITE]);

		os_result[33][SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		OS_PREGHS_PREBOOT->SetTestResult(SITE, 0, os_result[33][SITE]);

	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B3_WAKE12.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//B2_PREBOOT_VBOOST.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	ALL_FXVIE.Set(FV,0 , FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	

	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	cbite.SetCbiteOff(K43_PREGHS_FXVIB);
	cbite.SetCbiteOff(K42_PRESW_FXVIB);
	delay_ms(1);
	B2_PREBOOT_VBOOST.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B2_PREBOOT_VBOOST.MeasureVI(30, 10);
	SERIAL
	{

		os_result[42][SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MVRET);
		OS_PREBOOT->SetTestResult(SITE, 0, os_result[42][SITE]);
	}
	//cbite.SetCbiteOn(K43_PREGHS_FXVIB);
	cbite.SetCbiteOn(K42_PRESW_FXVIB);
	//delay_ms(1);
	//B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	//B0_PRESW_LDO1IN.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(2);
	//B0_PRESW_LDO1IN.MeasureVI(30, 10);
	//SERIAL
	//{

	//	os_result[43][SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MVRET);
	//	OS_PRESW_PREGHS->SetTestResult(SITE, 0, os_result[43][SITE]);
	//}
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	cbite.SetCbiteOn(K41_PREGLS_FXVIB);
	cbite.SetCbiteOn(K0_WAKE2_FXVIB);
	cbite.SetCbiteOn(K12_VMON2_FXVIB);
	cbite.SetCbiteOff(K43_PREGHS_FXVIB);
	cbite.SetCbiteOff(K47_WAKE1_FXVIB);
	cbite.SetCbiteOff(K13_VMON1_FXVIB);
	delay_ms(1);
	B3_WAKE12.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FI, 1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	//B3_WAKE12.MeasureVI(30, 10);
	//B5_VMON1234.MeasureVI(30, 10);
	//B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		os_result[44][SITE] = B3_WAKE12.GetMeasResult(SITE, MVRET);
		OS_WAKE2->SetTestResult(SITE, 0, os_result[44][SITE]);
		os_result[45][SITE] = B5_VMON1234.GetMeasResult(SITE, MVRET);
		OS_VMON2->SetTestResult(SITE, 0, os_result[45][SITE]);
		os_result[46][SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		OS_PREGLS->SetTestResult(SITE, 0, os_result[46][SITE]);
		os_result[47][SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MVRET);
		OS_PRECMP_VBOS->SetTestResult(SITE, 0, os_result[47][SITE]);
		os_result[48][SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		OS_LDO2OUT_VBOOST->SetTestResult(SITE, 0, os_result[48][SITE]);

	}
	B3_WAKE12.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	

	cbite.SetCbiteOn(K10_VMON3_FXVIB);
	cbite.SetCbiteOff(K12_VMON2_FXVIB);
	delay_ms(1);
	B5_VMON1234.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B5_VMON1234.MeasureVI(30, 10);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		os_result[49][SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		OS_PREGLS_VBOS->SetTestResult(SITE, 0, os_result[49][SITE]);
		os_result[50][SITE] = B5_VMON1234.GetMeasResult(SITE, MVRET);
		OS_VMON3->SetTestResult(SITE, 0, os_result[50][SITE]);
	
	}
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	cbite.SetCbiteOn(K9_VMON4_FXVIB);
	cbite.SetCbiteOff(K10_VMON3_FXVIB);
	delay_ms(1);

	B5_VMON1234.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B5_VMON1234.MeasureVI(30, 10);

	SERIAL
	{

		os_result[51][SITE] = B5_VMON1234.GetMeasResult(SITE, MVRET);
		OS_VMON4->SetTestResult(SITE, 0, os_result[51][SITE]);

	}
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	//ldo1 in /out
	cbite.SetCbiteOn(K52_LDO1_FXVIB);
	cbite.SetCbiteOn(K53_LDO1IN_FXVIB);
	cbite.SetCbiteOff(K41_PREGLS_FXVIB);
	cbite.SetCbiteOff(K10_VMON3_FXVIB);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);

	SERIAL
	{

		os_result[52][SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		OS_LDO1OUT_IN->SetTestResult(SITE, 0, os_result[52][SITE]);

	}
	//errmon /rstb
	cbite.SetCbiteOn(K37_ERRMON_FXVIA);
	cbite.SetCbiteOn(K16_RSTB_FXVIA);
	cbite.SetCbiteOn(K104_FXVI0_6_A);
	cbite.SetCbiteOn(K106_FXVI1_7_A);
	cbite.SetCbiteOn(K5_DBG_DCM);
	cbite.SetCbiteOff(K52_LDO1_FXVIB);
	cbite.SetCbiteOff(K53_LDO1IN_FXVIB);
	cbite.SetCbiteOff(K105_FXVI0_6_B);
	cbite.SetCbiteOff(K107_FXVI1_7_B);

	cbite.SetCbiteOff(K8_SCL_SDA_DCM);
	delay_ms(1);
	A0_FIN_DBG_ERR_FCCU1.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	B5_VMON1234.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FIMV, -1e-3, DCM_PPMUIRANGE_2MA);

	delay_ms(2);
	ALL_FXVIE.MeasureVI(30, 10);
	dcm.PPMUMeasure("SCL_DBG", 30, 10);
	//A1_FOUT_RSTB_FCCU2.MeasureVI(30, 10);

	SERIAL
	{
		os_result[53][SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MVRET);
		OS_ERRMON->SetTestResult(SITE, 0, os_result[53][SITE]);
		os_result[54][SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MVRET);
		OS_RSTB->SetTestResult(SITE, 0, os_result[54][SITE]);
		os_result[55][SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		OS_FS0B->SetTestResult(SITE, 0, os_result[55][SITE]);
	
		os_result[56][SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		OS_DBG->SetTestResult(SITE, 0, os_result[56][SITE]);
		//only valid for ssd version
		if (SSD_EN)
		{ 
			os_result[57][SITE] = B5_VMON1234.GetMeasResult(SITE, MVRET);
			OS_SSD->SetTestResult(SITE, 0, os_result[57][SITE]);
		}

	}
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	if (SSD_EN)
	{
		OS_Classify(funcindex, pin_str_array, PIN_NUM, os_result);
	}
	else
	{
		OS_Classify(funcindex, pin_str_array, PIN_NUM - 1, os_result);
	}

	
	if (DEBUG)
	{

	
		dcm.InitPPMU("DCM_ALLPINS");
		dcm.Disconnect("DCM_ALLPINS");
		FPVIM.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
		for (int i = 0; i < 12; i++)
		{
			acm_grp[i].Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
		}


		for (int i = 0; i < 6; i++)
		{
			fxvie_grp[i].Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
		}
	}
    return 0;
}

DUT_API int T03_TEST_P2P_LEAK(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam *POS_LEAK_MISO = StsGetParam(funcindex, "POS_LEAK_MISO");
	CParam *POS_LEAK_SCLK = StsGetParam(funcindex, "POS_LEAK_SCLK");
	CParam *POS_LEAK_SCL_DBG = StsGetParam(funcindex, "POS_LEAK_SCL_DBG");
	CParam *POS_LEAK_FOUT = StsGetParam(funcindex, "POS_LEAK_FOUT");
	CParam *POS_LEAK_VBOS = StsGetParam(funcindex, "POS_LEAK_VBOS");
	CParam *POS_LEAK_BUCK1SW = StsGetParam(funcindex, "POS_LEAK_BUCK1SW");
	CParam *POS_LEAK_BUCK2SW = StsGetParam(funcindex, "POS_LEAK_BUCK2SW");
	CParam *POS_LEAK_BUCK3SW = StsGetParam(funcindex, "POS_LEAK_BUCK3SW");
	CParam *POS_LEAK_VSUP = StsGetParam(funcindex, "POS_LEAK_VSUP");
	CParam *POS_LEAK_FCCU1_ERR = StsGetParam(funcindex, "POS_LEAK_FCCU1_ERR");
	CParam *POS_LEAK_PGOOD = StsGetParam(funcindex, "POS_LEAK_PGOOD");
	CParam *POS_LEAK_PSYNC = StsGetParam(funcindex, "POS_LEAK_PSYNC");
	CParam *POS_LEAK_AMUX = StsGetParam(funcindex, "POS_LEAK_AMUX");

	CParam *NEG_LEAK_MISO = StsGetParam(funcindex, "NEG_LEAK_MISO");
	CParam *NEG_LEAK_SCLK = StsGetParam(funcindex, "NEG_LEAK_SCLK");
	CParam *NEG_LEAK_SCL_DBG = StsGetParam(funcindex, "NEG_LEAK_SCL_DBG");
	CParam *NEG_LEAK_FOUT = StsGetParam(funcindex, "NEG_LEAK_FOUT");
	CParam *NEG_LEAK_VBOS = StsGetParam(funcindex, "NEG_LEAK_VBOS");
	CParam *NEG_LEAK_BUCK1SW = StsGetParam(funcindex, "NEG_LEAK_BUCK1SW");
	CParam *NEG_LEAK_BUCK2SW = StsGetParam(funcindex, "NEG_LEAK_BUCK2SW");
	CParam *NEG_LEAK_BUCK3SW = StsGetParam(funcindex, "NEG_LEAK_BUCK3SW");
	CParam *NEG_LEAK_VSUP = StsGetParam(funcindex, "NEG_LEAK_VSUP");
	CParam *NEG_LEAK_FCCU1_ERR = StsGetParam(funcindex, "NEG_LEAK_FCCU1_ERR");
	CParam *NEG_LEAK_PGOOD = StsGetParam(funcindex, "NEG_LEAK_PGOOD");
	CParam *NEG_LEAK_PSYNC = StsGetParam(funcindex, "NEG_LEAK_PSYNC");
	CParam *NEG_LEAK_AMUX = StsGetParam(funcindex, "NEG_LEAK_AMUX");

	CParam *POS_LEAK_MOSI = StsGetParam(funcindex, "POS_LEAK_MOSI");
	CParam *POS_LEAK_CSB = StsGetParam(funcindex, "POS_LEAK_CSB");
	CParam *POS_LEAK_SDA = StsGetParam(funcindex, "POS_LEAK_SDA");
	CParam *POS_LEAK_FIN = StsGetParam(funcindex, "POS_LEAK_FIN");
	CParam *POS_LEAK_VDDIO = StsGetParam(funcindex, "POS_LEAK_VDDIO");
	CParam *POS_LEAK_BUCK1IN = StsGetParam(funcindex, "POS_LEAK_BUCK1IN");
	CParam *POS_LEAK_BUCK2IN = StsGetParam(funcindex, "POS_LEAK_BUCK2IN");
	CParam *POS_LEAK_BUCK3IN = StsGetParam(funcindex, "POS_LEAK_BUCK3IN");
	CParam *POS_LEAK_BUCK1FB = StsGetParam(funcindex, "POS_LEAK_BUCK1FB");
	CParam *POS_LEAK_BUCK2FB = StsGetParam(funcindex, "POS_LEAK_BUCK2FB");
	CParam *POS_LEAK_BUCK3FB = StsGetParam(funcindex, "POS_LEAK_BUCK3FB");
	CParam *POS_LEAK_FCCU2_RSTB = StsGetParam(funcindex, "POS_LEAK_FCCU2_RSTB");
	CParam *POS_LEAK_INTB = StsGetParam(funcindex, "POS_LEAK_INTB");

	CParam *NEG_LEAK_MOSI = StsGetParam(funcindex, "NEG_LEAK_MOSI");
	CParam *NEG_LEAK_CSB = StsGetParam(funcindex, "NEG_LEAK_CSB");
	CParam *NEG_LEAK_SDA = StsGetParam(funcindex, "NEG_LEAK_SDA");
	CParam *NEG_LEAK_FIN = StsGetParam(funcindex, "NEG_LEAK_FIN");
	CParam *NEG_LEAK_VDDIO = StsGetParam(funcindex, "NEG_LEAK_VDDIO");
	CParam *NEG_LEAK_BUCK1IN = StsGetParam(funcindex, "NEG_LEAK_BUCK1IN");
	CParam *NEG_LEAK_BUCK2IN = StsGetParam(funcindex, "NEG_LEAK_BUCK2IN");
	CParam *NEG_LEAK_BUCK3IN = StsGetParam(funcindex, "NEG_LEAK_BUCK3IN");
	CParam *NEG_LEAK_BUCK1FB = StsGetParam(funcindex, "NEG_LEAK_BUCK1FB");
	CParam *NEG_LEAK_BUCK2FB = StsGetParam(funcindex, "NEG_LEAK_BUCK2FB");
	CParam *NEG_LEAK_BUCK3FB = StsGetParam(funcindex, "NEG_LEAK_BUCK3FB");
	CParam *NEG_LEAK_FCCU2_RSTB = StsGetParam(funcindex, "NEG_LEAK_FCCU2_RSTB");
	CParam *NEG_LEAK_INTB = StsGetParam(funcindex, "NEG_LEAK_INTB");

	CParam *POS_LEAK_VBOOST = StsGetParam(funcindex, "POS_LEAK_VBOOST");
	CParam *POS_LEAK_PREFB = StsGetParam(funcindex, "POS_LEAK_PREFB");
	CParam *POS_LEAK_PRECMP = StsGetParam(funcindex, "POS_LEAK_PRECMP");
	CParam *POS_LEAK_PREGHS_GHL = StsGetParam(funcindex, "POS_LEAK_PREGHS_GHL");
	CParam *POS_LEAK_WAKE12 = StsGetParam(funcindex, "POS_LEAK_WAKE12");
	CParam *POS_LEAK_VMON1234 = StsGetParam(funcindex, "POS_LEAK_VMON1234");

	CParam *NEG_LEAK_VBOOST = StsGetParam(funcindex, "NEG_LEAK_VBOOST");
	CParam *NEG_LEAK_PREFB = StsGetParam(funcindex, "NEG_LEAK_PREFB");
	CParam *NEG_LEAK_PRECMP = StsGetParam(funcindex, "NEG_LEAK_PRECMP");
	CParam *NEG_LEAK_PREGHS_GHL = StsGetParam(funcindex, "NEG_LEAK_PREGHS_GHL");
	CParam *NEG_LEAK_WAKE12 = StsGetParam(funcindex, "NEG_LEAK_WAKE12");
	CParam *NEG_LEAK_VMON1234 = StsGetParam(funcindex, "NEG_LEAK_VMON1234");

	CParam *POS_LEAK_VBOS2 = StsGetParam(funcindex, "POS_LEAK_VBOS2");
	CParam *POS_LEAK_BOOSTLS = StsGetParam(funcindex, "POS_LEAK_BOOSTLS");
	CParam *POS_LEAK_PRECSP = StsGetParam(funcindex, "POS_LEAK_PRECSP");
	CParam *POS_LEAK_PRESW = StsGetParam(funcindex, "POS_LEAK_PRESW");
	CParam *POS_LEAK_PREBOOT = StsGetParam(funcindex, "POS_LEAK_PREBOOT");
	CParam *POS_LEAK_LDO2OUT = StsGetParam(funcindex, "POS_LEAK_LDO2OUT");

	CParam *NEG_LEAK_VBOS2 = StsGetParam(funcindex, "NEG_LEAK_VBOS2");
	CParam *NEG_LEAK_BOOSTLS = StsGetParam(funcindex, "NEG_LEAK_BOOSTLS");
	CParam *NEG_LEAK_PRECSP = StsGetParam(funcindex, "NEG_LEAK_PRECSP");
	CParam *NEG_LEAK_PRESW = StsGetParam(funcindex, "NEG_LEAK_PRESW");
	CParam *NEG_LEAK_PREBOOT = StsGetParam(funcindex, "NEG_LEAK_PREBOOT");
	CParam *NEG_LEAK_LDO2OUT = StsGetParam(funcindex, "NEG_LEAK_LDO2OUT");


	CParam *POS_LEAK_LDO1IN = StsGetParam(funcindex, "POS_LEAK_LDO1IN");
	CParam *POS_LEAK_SSD = StsGetParam(funcindex, "POS_LEAK_SSD");
	CParam *NEG_LEAK_LDO1IN = StsGetParam(funcindex, "NEG_LEAK_LDO1IN");
	CParam *NEG_LEAK_SSD = StsGetParam(funcindex, "NEG_LEAK_SSD");

	CParam *POS_LEAK_LDO1OUT = StsGetParam(funcindex, "POS_LEAK_LDO1OUT");
	CParam *POS_LEAK_FS0B = StsGetParam(funcindex, "POS_LEAK_FS0B");
	CParam *NEG_LEAK_LDO1OUT = StsGetParam(funcindex, "NEG_LEAK_LDO1OUT");
	CParam *NEG_LEAK_FS0B = StsGetParam(funcindex, "NEG_LEAK_FS0B");


	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double pinleakage[SITE_NUM];

	double pos_v = 0.1;
	double neg_v = -0.1;
	
	if ((test_stage==1))
	{
		pos_v = 0.05;
		neg_v = -0.05;
	}
	else
	{
		pos_v = 0.15;
		neg_v = -0.15;

	}
	if (DO_CHAR)
	{

		pos_v = 0.05;
		neg_v = -0.05;
	}
	cbite.SetOn(K8_SCL_SDA_DCM, K5_DBG_DCM,K18_FIN_DCM, K26_FOUT_DCM, K24_VDDIO_ACM, K4_BUCK3SW_ACM, K33_BUCK12SW_ACM, K7_BUCK3FB_ACM, K29_BUCK2FB_ACM,
		K36_BUCK1FB_ACM, K28_FCCU12_FXVIA, K37_ERRMON_FXVIA, K16_RSTB_FXVIA,K15_PGOOD_FXVIA, K32_INTB_FXVIA, K35_PSYNC_FXVIA, K27_220_SHRT,
		K104_FXVI0_6_A, K106_FXVI1_7_A, K108_FXVI2_8_A, K110_FXVI3_9_A, K112_FXVI4_10_A, K114_FXVI5_11_A, -1);//vbos,buck1,2,3 in
	delay_ms(1);
	dcm.Connect("DCM_ALLPINS");

	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	ALL_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	ALL_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	dcm.SetPPMU("EVEN_G", DCM_PPMU_FVMI, pos_v, DCM_PPMUIRANGE_2UA);
	if (DO_CHAR || (test_stage==1 ))
		EVEN1_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	else
		EVEN1_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	EVEN1_FXVIE.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A5_AMUX.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(8);
	if (DO_CHAR|| (test_stage==1 ))delay_ms(20);
	
	dcm.PPMUMeasure("EVEN_G", 30, 10);
	EVEN1_FXVIE.MeasureVI(30, 10);
	EVEN1_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		POS_LEAK_MISO->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCLK_D", SITE);
		POS_LEAK_SCLK->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);
	
		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		POS_LEAK_SCL_DBG->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		POS_LEAK_FOUT->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		POS_LEAK_VBOS->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		POS_LEAK_BUCK1SW->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		POS_LEAK_BUCK2SW->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		POS_LEAK_BUCK3SW->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		POS_LEAK_VSUP->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		POS_LEAK_FCCU1_ERR->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = A2_PGOOD.GetMeasResult(SITE, MIRET);
		POS_LEAK_PGOOD->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MIRET);
		POS_LEAK_PSYNC->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);

		pinleakage[SITE] = A5_AMUX.GetMeasResult(SITE, MIRET);
		POS_LEAK_AMUX->SetTestResult(SITE, 0, pinleakage[SITE]* 1e9);


	}
	dcm.SetPPMU("EVEN_G", DCM_PPMU_FVMI, neg_v, DCM_PPMUIRANGE_2UA);
	if (DO_CHAR|| (test_stage==1 ))
		EVEN1_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	else
		EVEN1_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	A5_AMUX.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	EVEN1_FXVIE.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A5_AMUX.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(8);
	if (DO_CHAR|| (test_stage==1 )) delay_ms(20);

	dcm.PPMUMeasure("EVEN_G", 30, 10);
	EVEN1_FXVIE.MeasureVI(30, 10);
	EVEN1_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		NEG_LEAK_MISO->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCLK_D", SITE);
		NEG_LEAK_SCLK->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		NEG_LEAK_SCL_DBG->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		NEG_LEAK_FOUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		NEG_LEAK_VBOS->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		NEG_LEAK_BUCK1SW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		NEG_LEAK_BUCK2SW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		NEG_LEAK_BUCK3SW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		NEG_LEAK_VSUP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		NEG_LEAK_FCCU1_ERR->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A2_PGOOD.GetMeasResult(SITE, MIRET);
		NEG_LEAK_PGOOD->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


		pinleakage[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MIRET);
		NEG_LEAK_PSYNC->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A5_AMUX.GetMeasResult(SITE, MIRET);
		NEG_LEAK_AMUX->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


	}
	dcm.SetPPMU("EVEN_G", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);

	EVEN1_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	A5_AMUX.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	EVEN1_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	dcm.SetPPMU("ODD_G", DCM_PPMU_FVMI, pos_v, DCM_PPMUIRANGE_2UA);
	ODD1_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	ODD1_FXVIE.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);

	dcm.PPMUMeasure("ODD_G", 30, 10);
	ODD1_FXVIE.MeasureVI(30, 10);
	ODD1_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		POS_LEAK_MOSI->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		POS_LEAK_CSB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		POS_LEAK_SDA->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		POS_LEAK_FIN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		POS_LEAK_VDDIO->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK1IN_2.GetMeasResult(SITE, MIRET);
		POS_LEAK_BUCK1IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2IN_3.GetMeasResult(SITE, MIRET);
		POS_LEAK_BUCK2IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3IN_4.GetMeasResult(SITE, MIRET);
		POS_LEAK_BUCK3IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		POS_LEAK_BUCK1FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		POS_LEAK_BUCK2FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		POS_LEAK_BUCK3FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		POS_LEAK_FCCU2_RSTB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A3_INTB.GetMeasResult(SITE, MIRET);
		POS_LEAK_INTB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}


	dcm.SetPPMU("ODD_G", DCM_PPMU_FVMI, neg_v, DCM_PPMUIRANGE_2UA);
	ODD1_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	ODD1_FXVIE.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);

	dcm.PPMUMeasure("ODD_G", 30, 10);
	ODD1_FXVIE.MeasureVI(30, 10);
	ODD1_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		NEG_LEAK_MOSI->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		NEG_LEAK_CSB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		NEG_LEAK_SDA->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		NEG_LEAK_FIN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		NEG_LEAK_VDDIO->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK1IN_2.GetMeasResult(SITE, MIRET);
		NEG_LEAK_BUCK1IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2IN_3.GetMeasResult(SITE, MIRET);
		NEG_LEAK_BUCK2IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3IN_4.GetMeasResult(SITE, MIRET);
		NEG_LEAK_BUCK3IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		NEG_LEAK_BUCK1FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		NEG_LEAK_BUCK2FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		NEG_LEAK_BUCK3FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		NEG_LEAK_FCCU2_RSTB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A3_INTB.GetMeasResult(SITE, MIRET);
		NEG_LEAK_INTB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}
	dcm.SetPPMU("ODD_G", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	ODD1_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	ODD1_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	cbite.SetOn(K8_SCL_SDA_DCM, K5_DBG_DCM, K18_FIN_DCM, K26_FOUT_DCM, K40_VBOOST_ACM, K3_BOOSTLS_ACM, K33_BUCK12SW_ACM, K38_PRECOMP_ACM, K39_PRECSP_ACM,
		K46_PREFB_ACM, K42_PRESW_FXVIB, K43_PREGHS_FXVIB, K41_PREGLS_FXVIB, K44_PREBOOT_FXVIB, K47_WAKE1_FXVIB, K0_WAKE2_FXVIB, K51_LDO2_FXVIB, K13_VMON1_FXVIB,
		K12_VMON2_FXVIB, K10_VMON3_FXVIB, K9_VMON4_FXVIB, K105_FXVI0_6_B, K107_FXVI1_7_B, K109_FXVI2_8_B, K111_FXVI3_9_B, K113_FXVI4_10_B, K115_FXVI5_11_B, -1);//vbos,buck1,2,3 in
	delay_ms(1);
	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	EVEN2_FXVIE.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	EVEN2_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	EVEN2_FXVIE.MeasureVI(30, 10);
	EVEN2_ACM.MeasureVI(30, 10);
	SERIAL
	{

	
		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		POS_LEAK_VBOOST->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		POS_LEAK_PREFB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		POS_LEAK_PRECMP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		POS_LEAK_PREGHS_GHL->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);
		POS_LEAK_WAKE12->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		POS_LEAK_VMON1234->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


	}


	EVEN2_FXVIE.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	EVEN2_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	EVEN2_FXVIE.MeasureVI(30, 10);
	EVEN2_ACM.MeasureVI(30, 10);
	SERIAL
	{
		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		NEG_LEAK_VBOOST->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		NEG_LEAK_PREFB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		NEG_LEAK_PRECMP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		NEG_LEAK_PREGHS_GHL->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);
		NEG_LEAK_WAKE12->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		NEG_LEAK_VMON1234->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


	}
	EVEN2_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	EVEN2_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);

	ODD2_FXVIE.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	if (DO_CHAR || (test_stage==1 ))
		ODD2_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	else
		ODD2_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ODD2_FXVIE.MeasureVI(30, 10);
	ODD2_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		POS_LEAK_VBOS2->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		POS_LEAK_BOOSTLS->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		POS_LEAK_PRECSP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		POS_LEAK_PRESW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);
		POS_LEAK_PREBOOT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		POS_LEAK_LDO2OUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}


	ODD2_FXVIE.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	if (DO_CHAR || (test_stage==1 ))
		ODD2_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	else
		ODD2_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);

	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ODD2_FXVIE.MeasureVI(30, 10);
	ODD2_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		NEG_LEAK_VBOS2->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		NEG_LEAK_BOOSTLS->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		NEG_LEAK_PRECSP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		NEG_LEAK_PRESW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);
		NEG_LEAK_PREBOOT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		NEG_LEAK_LDO2OUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}
	ODD2_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	ODD2_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	cbite.SetOn(K8_SCL_SDA_DCM, K5_DBG_DCM, K18_FIN_DCM, K26_FOUT_DCM, K40_VBOOST_ACM, K3_BOOSTLS_ACM, K33_BUCK12SW_ACM, K38_PRECOMP_ACM, K39_PRECSP_ACM,
	K46_PREFB_ACM, K53_LDO1IN_FXVIB, K52_LDO1_FXVIB, K44_PREBOOT_FXVIB, K47_WAKE1_FXVIB, K0_WAKE2_FXVIB, 
	K105_FXVI0_6_B, K107_FXVI1_7_B, K109_FXVI2_8_B, K111_FXVI3_9_B, K113_FXVI4_10_B, K115_FXVI5_11_B, -1);//vbos,buck1,2,3 in
	delay_ms(1);

	B0_PRESW_LDO1IN.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	B0_PRESW_LDO1IN.MeasureVI(30, 10);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		POS_LEAK_LDO1IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		POS_LEAK_SSD->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}
	B0_PRESW_LDO1IN.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	B0_PRESW_LDO1IN.MeasureVI(30, 10);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		NEG_LEAK_LDO1IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		NEG_LEAK_SSD->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		POS_LEAK_LDO1OUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		POS_LEAK_FS0B->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		NEG_LEAK_LDO1OUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		NEG_LEAK_FS0B->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	ALL_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	ALL_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_OFF);
	dcm.Disconnect("DCM_ALLPINS");
	if (DEBUG)
	{


		dcm.InitPPMU("DCM_ALLPINS");
		dcm.Disconnect("DCM_ALLPINS");
		FPVIM.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
		for (int i = 0; i < 12; i++)
		{
			acm_grp[i].Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
		}


		for (int i = 0; i < 6; i++)
		{
			fxvie_grp[i].Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
		}
	}


	return 0;
}
//will add per pin leakage test

DUT_API int T04_TEST_LEAKAGE(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam *LEAK_MISO_5V = StsGetParam(funcindex, "LEAK_MISO_5V");
	CParam *LEAK_SCLK_5V = StsGetParam(funcindex, "LEAK_SCLK_5V");
	CParam *LEAK_SCL_5V = StsGetParam(funcindex, "LEAK_SCL_5V");
	CParam *LEAK_FOUT_5V = StsGetParam(funcindex, "LEAK_FOUT_5V");
	CParam *LEAK_MOSI_5V = StsGetParam(funcindex, "LEAK_MOSI_5V");
	CParam *LEAK_CSB_5V = StsGetParam(funcindex, "LEAK_CSB_5V");
	CParam *LEAK_SDA_5V = StsGetParam(funcindex, "LEAK_SDA_5V");
	CParam *LEAK_FIN_5V = StsGetParam(funcindex, "LEAK_FIN_5V");
	CParam *LEAK_VBOS_0V = StsGetParam(funcindex, "LEAK_VBOS_0V");
	CParam *LEAK_BUCK1SW_0V = StsGetParam(funcindex, "LEAK_BUCK1SW_0V");
	CParam *LEAK_BUCK2SW_0V = StsGetParam(funcindex, "LEAK_BUCK2SW_0V");
	CParam *LEAK_BUCK3SW_0V = StsGetParam(funcindex, "LEAK_BUCK3SW_0V");
	CParam *LEAK_VSUP_12V = StsGetParam(funcindex, "LEAK_VSUP_12V");
	CParam *LEAK_VDDIO_5V = StsGetParam(funcindex, "LEAK_VDDIO_5V");
	CParam *LEAK_BUCK1IN_5V = StsGetParam(funcindex, "LEAK_BUCK1IN_5V");
	CParam *LEAK_BUCK2IN_5V = StsGetParam(funcindex, "LEAK_BUCK2IN_5V");
	CParam *LEAK_BUCK3IN_5V = StsGetParam(funcindex, "LEAK_BUCK3IN_5V");
	CParam *LEAK_BUCK1FB_4V = StsGetParam(funcindex, "LEAK_BUCK1FB_4V");
	CParam *LEAK_BUCK2FB_4V = StsGetParam(funcindex, "LEAK_BUCK2FB_4V");
	CParam *LEAK_BUCK3FB_4V = StsGetParam(funcindex, "LEAK_BUCK3FB_4V");
	CParam *LEAK_FCCU2_0p5V = StsGetParam(funcindex, "LEAK_FCCU2_0p5V");
	CParam *LEAK_INTB_0p5V = StsGetParam(funcindex, "LEAK_INTB_0p5V");
	CParam *LEAK_FCCU1_5V = StsGetParam(funcindex, "LEAK_FCCU1_5V");
	CParam *LEAK_PGOOD_0p5V = StsGetParam(funcindex, "LEAK_PGOOD_0p5V");
	CParam *LEAK_PSYNC_5V = StsGetParam(funcindex, "LEAK_PSYNC_5V");
	CParam *LEAK_AMUX_0p5V = StsGetParam(funcindex, "LEAK_AMUX_0p5V");
	CParam *LEAK_BUCK1SW_5V = StsGetParam(funcindex, "LEAK_BUCK1SW_5V");
	CParam *LEAK_BUCK2SW_5V = StsGetParam(funcindex, "LEAK_BUCK2SW_5V");
	CParam *LEAK_BUCK3SW_5V = StsGetParam(funcindex, "LEAK_BUCK3SW_5V");
	CParam *LEAK_VBOS2_0V = StsGetParam(funcindex, "LEAK_VBOS2_0V");
	CParam *LEAK_RSTB_5V = StsGetParam(funcindex, "LEAK_RSTB_5V");
	CParam *LEAK_ERR_5V = StsGetParam(funcindex, "LEAK_ERR_5V");
	CParam *ABSLEAK_MISO_5p5V = StsGetParam(funcindex, "ABSLEAK_MISO_5p5V");
	CParam *ABSLEAK_SCLK_5p5V = StsGetParam(funcindex, "ABSLEAK_SCLK_5p5V");
	CParam *ABSLEAK_SCL_5p5V = StsGetParam(funcindex, "ABSLEAK_SCL_5p5V");
	CParam *ABSLEAK_FOUT_5p5V = StsGetParam(funcindex, "ABSLEAK_FOUT_5p5V");
	CParam *ABSLEAK_MOSI_5p5V = StsGetParam(funcindex, "ABSLEAK_MOSI_5p5V");
	CParam *ABSLEAK_CSB_5p5V = StsGetParam(funcindex, "ABSLEAK_CSB_5p5V");
	CParam *ABSLEAK_SDA_5p5V = StsGetParam(funcindex, "ABSLEAK_SDA_5p5V");
	CParam *ABSLEAK_FIN_5p5V = StsGetParam(funcindex, "ABSLEAK_FIN_5p5V");
	CParam *ABSLEAK_VBOS3_0V = StsGetParam(funcindex, "ABSLEAK_VBOS3_0V");
	CParam *ABSLEAK_BUCK1SW_0V = StsGetParam(funcindex, "ABSLEAK_BUCK1SW_0V");
	CParam *ABSLEAK_BUCK2SW_0V = StsGetParam(funcindex, "ABSLEAK_BUCK2SW_0V");
	CParam *ABSLEAK_BUCK3SW_0V = StsGetParam(funcindex, "ABSLEAK_BUCK3SW_0V");
	CParam *ABSLEAK_VSUP_12V = StsGetParam(funcindex, "ABSLEAK_VSUP_12V");
	CParam *ABSLEAK_VDDIO_5p5V = StsGetParam(funcindex, "ABSLEAK_VDDIO_5p5V");
	CParam *ABSLEAK_BUCK1IN_5p5V = StsGetParam(funcindex, "ABSLEAK_BUCK1IN_5p5V");
	CParam *ABSLEAK_BUCK2IN_5p5V = StsGetParam(funcindex, "ABSLEAK_BUCK2IN_5p5V");
	CParam *ABSLEAK_BUCK3IN_5p5V = StsGetParam(funcindex, "ABSLEAK_BUCK3IN_5p5V");
	CParam *ABSLEAK_BUCK1FB_4V = StsGetParam(funcindex, "ABSLEAK_BUCK1FB_4V");
	CParam *ABSLEAK_BUCK2FB_4V = StsGetParam(funcindex, "ABSLEAK_BUCK2FB_4V");
	CParam *ABSLEAK_BUCK3FB_4V = StsGetParam(funcindex, "ABSLEAK_BUCK3FB_4V");
	CParam *ABSLEAK_FCCU2_0p5V = StsGetParam(funcindex, "ABSLEAK_FCCU2_0p5V");
	CParam *ABSLEAK_INTB_0p5V = StsGetParam(funcindex, "ABSLEAK_INTB_0p5V");
	CParam *ABSLEAK_FCCU1_5p5V = StsGetParam(funcindex, "ABSLEAK_FCCU1_5p5V");
	CParam *ABSLEAK_PGOOD_0p5V = StsGetParam(funcindex, "ABSLEAK_PGOOD_0p5V");
	CParam *ABSLEAK_PSYNC_5p5V = StsGetParam(funcindex, "ABSLEAK_PSYNC_5p5V");
	CParam *ABSLEAK_AMUX_0p5V = StsGetParam(funcindex, "ABSLEAK_AMUX_0p5V");
	CParam *ABSLEAK_BUCK1SW_5p5V = StsGetParam(funcindex, "ABSLEAK_BUCK1SW_5p5V");
	CParam *ABSLEAK_BUCK2SW_5p5V = StsGetParam(funcindex, "ABSLEAK_BUCK2SW_5p5V");
	CParam *ABSLEAK_BUCK3SW_5p5V = StsGetParam(funcindex, "ABSLEAK_BUCK3SW_5p5V");
	CParam *ABSLEAK_VBOS_5p5V = StsGetParam(funcindex, "ABSLEAK_VBOS_5p5V");
	CParam *ABSLEAK_RSTB_5p5V = StsGetParam(funcindex, "ABSLEAK_RSTB_5p5V");
	CParam *ABSLEAK_ERR_5p5V = StsGetParam(funcindex, "ABSLEAK_ERR_5p5V");
	CParam* LEAK_DBG_5V = StsGetParam(funcindex, "LEAK_DBG_5V");
	CParam *LEAK_WAKE1_0p5V = StsGetParam(funcindex, "LEAK_WAKE1_0p5V");
	CParam *LEAK_WAKE2_0p5V = StsGetParam(funcindex, "LEAK_WAKE2_0p5V");
	CParam *LEAK_VSUP2_12V = StsGetParam(funcindex, "LEAK_VSUP2_12V");
	CParam *LEAK_VBOS4_0V = StsGetParam(funcindex, "LEAK_VBOS4_0V");
	CParam *LEAK_BOOSTLS_6V = StsGetParam(funcindex, "LEAK_BOOSTLS_6V");
	CParam *LEAK_VBOOST_5V = StsGetParam(funcindex, "LEAK_VBOOST_5V");
	CParam *LEAK_PREFB_4V = StsGetParam(funcindex, "LEAK_PREFB_4V");
	CParam *LEAK_PRECSP_4V = StsGetParam(funcindex, "LEAK_PRECSP_4V");
	CParam *LEAK_PRECMP_0p3V = StsGetParam(funcindex, "LEAK_PRECMP_0p3V");
	CParam *LEAK_PRESW_5V = StsGetParam(funcindex, "LEAK_PRESW_5V");
	
	CParam *LEAK_PREBOOT_10V = StsGetParam(funcindex, "LEAK_PREBOOT_10V");
	CParam *LEAK_LDO2OUT_0V = StsGetParam(funcindex, "LEAK_LDO2OUT_0V");
	CParam *LEAK_VMON1_5V = StsGetParam(funcindex, "LEAK_VMON1_5V");
	CParam *LEAK_PREBOOT2_10V = StsGetParam(funcindex, "LEAK_PREBOOT2_10V");

	CParam *LEAK_VMON2_5V = StsGetParam(funcindex, "LEAK_VMON2_5V");
	CParam *LEAK_LDO2OUT_5V = StsGetParam(funcindex, "LEAK_LDO2OUT_5V");

	CParam *LEAK_VMON3_5V = StsGetParam(funcindex, "LEAK_VMON3_5V");

	CParam *LEAK_VMON4_5V = StsGetParam(funcindex, "LEAK_VMON4_5V");
	CParam* ABSLEAK_DBG_6V = StsGetParam(funcindex, "ABSLEAK_DBG_6V");
	CParam *ABSLEAK_WAKE1_1V = StsGetParam(funcindex, "ABSLEAK_WAKE1_1V");
	CParam *ABSLEAK_WAKE2_1V = StsGetParam(funcindex, "ABSLEAK_WAKE2_1V");
	CParam *ABSLEAK_VSUP2_12V = StsGetParam(funcindex, "ABSLEAK_VSUP2_12V");
	CParam *ABSLEAK_VBOS2_0V = StsGetParam(funcindex, "ABSLEAK_VBOS2_0V");
	CParam *ABSLEAK_BOOSTLS_9V = StsGetParam(funcindex, "ABSLEAK_BOOSTLS_9V");
	CParam *ABSLEAK_VBOOST_7V = StsGetParam(funcindex, "ABSLEAK_VBOOST_7V");
	CParam *ABSLEAK_PREFB_5p5V = StsGetParam(funcindex, "ABSLEAK_PREFB_5p5V");
	CParam *ABSLEAK_PRECSP_5p5V = StsGetParam(funcindex, "ABSLEAK_PRECSP_5p5V");
	CParam *ABSLEAK_PRECMP_0p3V = StsGetParam(funcindex, "ABSLEAK_PRECMP_0p3V");
	CParam *ABSLEAK_PRESW_0V = StsGetParam(funcindex, "ABSLEAK_PRESW_0V");

	CParam *ABSLEAK_PREBOOT_5p5V = StsGetParam(funcindex, "ABSLEAK_PREBOOT_5p5V");
	CParam *ABSLEAK_LDO2OUT_0V = StsGetParam(funcindex, "ABSLEAK_LDO2OUT_0V");
	CParam *ABSLEAK_LDO2OUT_5p5V = StsGetParam(funcindex, "ABSLEAK_LDO2OUT_5p5V");
	CParam *LEAK_FS0B_5V = StsGetParam(funcindex, "LEAK_FS0B_5V");
	CParam *LEAK_LDO1OUT_0V = StsGetParam(funcindex, "LEAK_LDO1OUT_0V");
	CParam *LEAK_LDO1IN_5V = StsGetParam(funcindex, "LEAK_LDO1IN_5V");
	CParam *LEAK_LDO1OUT_5V = StsGetParam(funcindex, "LEAK_LDO1OUT_5V");
	CParam *ABSLEAK_LDO1IN_5p5V = StsGetParam(funcindex, "ABSLEAK_LDO1IN_5p5V");
	CParam *ABSLEAK_LDO1OUT_5p5V = StsGetParam(funcindex, "ABSLEAK_LDO1OUT_5p5V");


	CParam *IQLEAK_WAKE1_5V = StsGetParam(funcindex, "IQLEAK_WAKE1_5V");
	CParam *IQLEAK_WAKE2_5V = StsGetParam(funcindex, "IQLEAK_WAKE2_5V");
	CParam *IQLEAK_VBOS_0V = StsGetParam(funcindex, "IQLEAK_VBOS_0V");
	CParam *IQLEAK_BUCK1SW_0V = StsGetParam(funcindex, "IQLEAK_BUCK1SW_0V");
	CParam *IQLEAK_BUCK2SW_0V = StsGetParam(funcindex, "IQLEAK_BUCK2SW_0V");
	CParam *IQLEAK_BUCK3SW_0V = StsGetParam(funcindex, "IQLEAK_BUCK3SW_0V");
	CParam *IQLEAK_VSUP_12V = StsGetParam(funcindex, "IQLEAK_VSUP_12V");
	CParam *IQLEAK_VDDIO_5V = StsGetParam(funcindex, "IQLEAK_VDDIO_5V");
	CParam *IQLEAK_BUCK1IN_3p3V = StsGetParam(funcindex, "IQLEAK_BUCK1IN_3p3V");
	CParam *IQLEAK_BUCK2IN_3p3V = StsGetParam(funcindex, "IQLEAK_BUCK2IN_3p3V");
	CParam *IQLEAK_BUCK3IN_3p3V = StsGetParam(funcindex, "IQLEAK_BUCK3IN_3p3V");
	CParam *IQLEAK_BUCK1FB_1p8V = StsGetParam(funcindex, "IQLEAK_BUCK1FB_1p8V");
	CParam *IQLEAK_BUCK2FB_1p8V = StsGetParam(funcindex, "IQLEAK_BUCK2FB_1p8V");
	CParam *IQLEAK_BUCK3FB_1p8V = StsGetParam(funcindex, "IQLEAK_BUCK3FB_1p8V");
	CParam *IQLEAK_BUCK3FB_3p6V = StsGetParam(funcindex, "IQLEAK_BUCK3FB_3p6V");
	
	CParam *IQLEAK_LDO1IN_3p3V = StsGetParam(funcindex, "IQLEAK_LDO1IN_3p3V");
	CParam *IQLEAK_LDO1OUT_0p2V = StsGetParam(funcindex, "IQLEAK_LDO1OUT_0p2V");
	CParam *IQLEAK_VBOOST_3p3V = StsGetParam(funcindex, "IQLEAK_VBOOST_3p3V");
	CParam *IQLEAK_LDO2OUT_0p2V = StsGetParam(funcindex, "IQLEAK_LDO2OUT_0p2V");
	//}}AFX_STS_PARAM_PROTOTYPES

	double pinleakage[SITE_NUM];

	cbite.SetOn(K60_WAKE12_PD,K8_SCL_SDA_DCM, K18_FIN_DCM, K26_FOUT_DCM, K24_VDDIO_ACM, K4_BUCK3SW_ACM, K33_BUCK12SW_ACM, K7_BUCK3FB_ACM, K29_BUCK2FB_ACM,
		K36_BUCK1FB_ACM, K28_FCCU12_FXVIA, K15_PGOOD_FXVIA, K32_INTB_FXVIA, K35_PSYNC_FXVIA, K27_220_SHRT,
		K104_FXVI0_6_A, K106_FXVI1_7_A, K108_FXVI2_8_A, K110_FXVI3_9_A, K112_FXVI4_10_A, K114_FXVI5_11_A, -1);//vbos,buck1,2,3 in
	delay_ms(1);
	//wake12=0
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(5);
	//high temp need high current range
	VBOS_1.Set(FV,5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);//make floating node in stable status,will check the status if stable at full temp
	VDDIO_VBOOST_0.TSet(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	BUCK1IN_2.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2IN_3.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3IN_4.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 4.15, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 4.15, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 4.15, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK1SW_5.TSet(FV, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	BUCK2SW_6.TSet(FV, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);

	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	A2_PGOOD.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	A4_PSYNC_PREFB.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A5_AMUX.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();

	dcm.Connect("DCM_ALLPINS");
	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_2UA);
	dcm.SetPPMU("SCLK", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_200UA);
	VBOS_1.Set(FV,0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	VBOS_1.Set(FV,0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		LEAK_MISO_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCLK_D", SITE);
		LEAK_SCLK_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);//uA

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		LEAK_SCL_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		LEAK_FOUT_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		LEAK_MOSI_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		LEAK_CSB_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		LEAK_SDA_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		LEAK_FIN_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		LEAK_VBOS_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		LEAK_BUCK1SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		LEAK_BUCK2SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		LEAK_BUCK3SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		LEAK_VSUP_12V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		LEAK_BUCK1FB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		LEAK_BUCK2FB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		LEAK_BUCK3FB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		LEAK_FCCU2_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);



		pinleakage[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		LEAK_FCCU1_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = A2_PGOOD.GetMeasResult(SITE, MIRET);
		LEAK_PGOOD_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);

		pinleakage[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MIRET);
		LEAK_PSYNC_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = A5_AMUX.GetMeasResult(SITE, MIRET);
		LEAK_AMUX_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


	}
	VBOS_1.Set(FV,5.0 , ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{
		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		LEAK_VDDIO_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK1IN_2.GetMeasResult(SITE, MIRET);
		LEAK_BUCK1IN_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2IN_3.GetMeasResult(SITE, MIRET);
		LEAK_BUCK2IN_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3IN_4.GetMeasResult(SITE, MIRET);
		LEAK_BUCK3IN_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A3_INTB.GetMeasResult(SITE, MIRET);
		LEAK_INTB_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);
	}
	VBOS_1.Set(FV,0 , ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);

	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	delay_ms(1);
	cbite.SetCbiteOff(K28_FCCU12_FXVIA);

	delay_ms(1);
	cbite.SetCbiteOn(K37_ERRMON_FXVIA);
	cbite.SetCbiteOn(K16_RSTB_FXVIA);
	delay_ms(1);
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	BUCK1SW_5.TSet(FV, 5.0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	BUCK2SW_6.TSet(FV, 5.0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 5.0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	STSTArming();
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	SERIAL
	{
		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		LEAK_BUCK1SW_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		LEAK_BUCK2SW_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		LEAK_BUCK3SW_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		LEAK_VBOS2_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		LEAK_RSTB_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);

		pinleakage[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		LEAK_ERR_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

	}
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	cbite.SetCbiteOff(K16_RSTB_FXVIA);
	cbite.SetCbiteOff(K37_ERRMON_FXVIA);
	delay_ms(1);
	
	cbite.SetCbiteOn(K28_FCCU12_FXVIA);
	delay_ms(1);

	BUCK1SW_5.TSet(FV, 0.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2SW_6.TSet(FV, 0.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	VBOS_1.TSet(FV, 0.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	STSTArming();
	//absxmax
	VBOS_1.TSet(FV,5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);//make floating node in stable status,will check the status if stable at full temp
	VDDIO_VBOOST_0.TSet(FV, 5.5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON,0.5);
	BUCK1IN_2.TSet(FV, 5.5, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	BUCK2IN_3.TSet(FV, 5.5, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	BUCK3IN_4.TSet(FV, 5.5, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	PREFB_BUCK1FB_8.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	PRECSP_BUCK2FB_9.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	BUCK1SW_5.TSet(FV, 5.5, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	BUCK2SW_6.TSet(FV, 5.5, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	BUCK3SW_BOOSTLS_7.TSet(FV, 5.5, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	//VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 5.5, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON, 0.5);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	A2_PGOOD.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	A4_PSYNC_PREFB.TSet(FV, 5.5, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON, 0.5);
	A5_AMUX.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();

	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 5.5, DCM_PPMUIRANGE_2UA);
	dcm.SetPPMU("SCLK", DCM_PPMU_FVMI, 5.5, DCM_PPMUIRANGE_200UA);
	VBOS_1.Set(FV,0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	VBOS_1.Set(FV,0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		ABSLEAK_MISO_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCLK_D", SITE);
		ABSLEAK_SCLK_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);//uA

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		ABSLEAK_SCL_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		ABSLEAK_FOUT_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		ABSLEAK_MOSI_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		ABSLEAK_CSB_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		ABSLEAK_SDA_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		ABSLEAK_FIN_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		ABSLEAK_VBOS3_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK1SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK2SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK3SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		ABSLEAK_VSUP_12V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK1FB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK2FB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK3FB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		ABSLEAK_FCCU2_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);
		//ABSLEAK_FCCU2_0p5V
		pinleakage[SITE] = A3_INTB.GetMeasResult(SITE, MIRET);
		ABSLEAK_INTB_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		ABSLEAK_FCCU1_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = A2_PGOOD.GetMeasResult(SITE, MIRET);
		ABSLEAK_PGOOD_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);

		pinleakage[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MIRET);
		ABSLEAK_PSYNC_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = A5_AMUX.GetMeasResult(SITE, MIRET);
		ABSLEAK_AMUX_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


	}
	VBOS_1.Set(FV,5.0 , ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		ABSLEAK_VDDIO_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK1IN_2.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK1IN_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2IN_3.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK2IN_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3IN_4.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK3IN_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);
	
		pinleakage[SITE] = A3_INTB.GetMeasResult(SITE, MIRET);
		ABSLEAK_INTB_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

	}
	VBOS_1.Set(FV,0 , ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	delay_ms(1);
	cbite.SetCbiteOff(K28_FCCU12_FXVIA);

	delay_ms(1);
	cbite.SetCbiteOn(K37_ERRMON_FXVIA);
	cbite.SetCbiteOn(K16_RSTB_FXVIA);
	delay_ms(1);
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 5.5, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON, 0.5);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 2.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON, 0.5);
	BUCK1SW_5.TSet(FV, 5.5, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON,0.5);
	BUCK2SW_6.TSet(FV, 5.5, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON,0.5);
	BUCK3SW_BOOSTLS_7.TSet(FV, 5.5, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON,0.5);
	VBOS_1.TSet(FV, 5.5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON,0.5);
	STSTArming();
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	SERIAL
	{
		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK1SW_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK2SW_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		ABSLEAK_BUCK3SW_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		ABSLEAK_VBOS_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


		pinleakage[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		ABSLEAK_RSTB_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);

		pinleakage[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		ABSLEAK_ERR_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

	}
	BUCK1SW_5.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	BUCK2SW_6.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON, 0.5);
	VDDIO_VBOOST_0.TSet(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	STSTArming();
	delay_ms(1);
	BUCK1IN_2.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2IN_3.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3IN_4.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	
	A2_PGOOD.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A4_PSYNC_PREFB.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A5_AMUX.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	dcm.SetPPMU("SCLK", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_200UA);
	delay_ms(1);
	cbite.SetOn(K1_WAKE2_DCM, K48_WAKE1_DCM,K5_DBG_DCM, K40_VBOOST_ACM, K3_BOOSTLS_ACM, K38_PRECOMP_ACM, K39_PRECSP_ACM,
		K46_PREFB_ACM, K42_PRESW_FXVIB, K43_PREGHS_FXVIB, K44_PREBOOT_FXVIB, K51_LDO2_FXVIB, K13_VMON1_FXVIB,
		 K105_FXVI0_6_B, K107_FXVI1_7_B, K109_FXVI2_8_B, K111_FXVI3_9_B, K113_FXVI4_10_B, K115_FXVI5_11_B, -1);//vbos,buck1,2,3 in
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(1);
	VBOS_1.TSet(FV,5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);//make floating node in stable status,will check the status if stable at full temp

	VDDIO_VBOOST_0.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 4.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 4.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0.3, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 6.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	//VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	B2_PREBOOT_VBOOST.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	//will add dbg

	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 0.5, DCM_PPMUIRANGE_2UA);
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_20UA);
	B2_PREBOOT_VBOOST.Set(FV, 10, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON, 0.5);
	delay_ms(2);
	VBOS_1.Set(FV,0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(2);
	//VBOS_1.Set(FV,0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);

	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{




		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		LEAK_VSUP2_12V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		LEAK_VBOS4_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		LEAK_BOOSTLS_6V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);



		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		LEAK_PREFB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		LEAK_PRECSP_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		LEAK_PRECMP_0p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		LEAK_PRESW_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


		pinleakage[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);
		LEAK_PREBOOT_10V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		LEAK_LDO2OUT_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		LEAK_VMON1_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


	}
	VBOS_1.TSet(FV,5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(5);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);

	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{
		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		LEAK_DBG_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		LEAK_WAKE1_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		LEAK_WAKE2_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		LEAK_VBOOST_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);
	}
	VBOS_1.TSet(FV,0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	cbite.SetCbiteOn(K12_VMON2_FXVIB);
	cbite.SetCbiteOff(K13_VMON1_FXVIB);
	delay_ms(5);
	
	ALL_FXVIE.MeasureVI(30, 10);

	SERIAL
	{

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		LEAK_VMON2_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		LEAK_LDO2OUT_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

	}

	B2_PREBOOT_VBOOST.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON,0.5);
	B0_PRESW_LDO1IN.TSet(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);

	cbite.SetCbiteOff(K12_VMON2_FXVIB);

	cbite.SetCbiteOn(K10_VMON3_FXVIB);

	delay_ms(3);


	B5_VMON1234.MeasureVI(30, 10);

	SERIAL
	{


		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		LEAK_VMON3_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


	}
	
	cbite.SetCbiteOn(K9_VMON4_FXVIB);
	cbite.SetCbiteOff(K10_VMON3_FXVIB);
	delay_ms(3);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		LEAK_VMON4_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


	}
		//absmax
	VBOS_1.TSet(FV,5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);//make floating node in stable status,will check the status if stable at full temp

	VDDIO_VBOOST_0.TSet(FV, 7.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 5.5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 5.5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0.3, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 9.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
//	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	B2_PREBOOT_VBOOST.TSet(FV, 5.5, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();

	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 0.5, DCM_PPMUIRANGE_2UA);
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FVMI, 6.0, DCM_PPMUIRANGE_20UA);
	delay_ms(3);
	VBOS_1.Set(FV,0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
//	delay_ms(3);
//	VBOS_1.Set(FV,0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);

	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{





		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		ABSLEAK_VSUP2_12V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		ABSLEAK_VBOS2_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		ABSLEAK_BOOSTLS_9V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);



		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		ABSLEAK_PREFB_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		ABSLEAK_PRECSP_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		ABSLEAK_PRECMP_0p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		ABSLEAK_PRESW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);
		ABSLEAK_PREBOOT_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		ABSLEAK_LDO2OUT_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	


	}
	VBOS_1.TSet(FV,5.5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(5);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);

	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);

	SERIAL
	{
		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		ABSLEAK_DBG_6V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		ABSLEAK_WAKE1_1V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		ABSLEAK_WAKE2_1V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		ABSLEAK_VBOOST_7V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);
	}
	VBOS_1.TSet(FV,0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 5.5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON, 0.5);
	delay_ms(5);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		ABSLEAK_LDO2OUT_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


	}
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON, 0.5);
	B4_VSUP_LDO2OUT.Set(FV,2, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON, 0.5);
	delay_ms(5);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		LEAK_FS0B_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);


	}
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON, 0.5);

		//ldo1 in
	VBOS_1.TSet(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	
	B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B0_PRESW_LDO1IN.TSet(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	STSTArming();
	delay_ms(1);
	cbite.SetCbiteOff(K42_PRESW_FXVIB);
	cbite.SetCbiteOff(K41_PREGLS_FXVIB);
	delay_ms(1);
	cbite.SetCbiteOn(K52_LDO1_FXVIB);
	cbite.SetCbiteOn(K53_LDO1IN_FXVIB);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(5);
	ALL_FXVIE.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		LEAK_LDO1OUT_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);
		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		LEAK_LDO1IN_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON, 0.5);
	delay_ms(5);
	ALL_FXVIE.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		LEAK_LDO1OUT_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);
	
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON, 0.5);
	B0_PRESW_LDO1IN.Set(FV, 5.5, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	ALL_FXVIE.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		ABSLEAK_LDO1IN_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.5, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON, 0.5);
	delay_ms(3);
	ALL_FXVIE.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		ABSLEAK_LDO1OUT_5p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

	}

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON, 0.5);
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 0.0, DCM_PPMUIRANGE_200UA);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	
	B4_VSUP_LDO2OUT.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.TSet(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	VDDIO_VBOOST_0.TSet(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);

	STSTArming();

	for (int i = 0; i < 12; i++)
		acm_grp[i].TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	for (int i = 0; i < 6; i++)
		fxvie_grp[i].TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	STSTArming();

	dcm.Disconnect("DCM_ALLPINS");
	ULONG m_reg_data1[4][SITE_NUM];
	ULONG data0=0x0000;
	//Iq power on
	cbite.SetOn(K48_WAKE1_DCM, K1_WAKE2_DCM, /*K82_BUCK_CAPS, */K24_VDDIO_ACM, K4_BUCK3SW_ACM, K33_BUCK12SW_ACM, K7_BUCK3FB_ACM, K29_BUCK2FB_ACM,
		K36_BUCK1FB_ACM, K52_LDO1_FXVIB, K53_LDO1IN_FXVIB, K51_LDO2_FXVIB, K50_VBOOST_FXVIB,
		K105_FXVI0_6_B, K107_FXVI1_7_B, K109_FXVI2_8_B, K113_FXVI4_10_B, - 1);//vbos,buck1,2,3 in
	delay_ms(1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	//wake12=0
	dcm.Connect("WAKE12_G");
	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_200UA);
	VBOS_1.TSet(FV, 5.5, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	VDDIO_VBOOST_0.TSet(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	STSTArming();
	delay_ms(15);//will check delay time
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	SPIWrite(0x3F, 0x7481);//switch to main otp table
	delay_us(10);
	//string EE_str;
	dut.trim("BUCK2_DP_IMINPK").set_working(0);//for buck2 test stable iq

	//dut.trim("BUCK1_EA").copy_start_to_work();
	//dut.trim("BUCK1_DAC").copy_start_to_work();
	//dut.trim("BUCK1_IVY").copy_start_to_work();
	//dut.trim("BUCK1_IPK").copy_start_to_work();

	OTP_M_Preview(12,1);
	if(SC6295X[find_ID].useropt_burn==1)
	{
		for (int addr = 0; addr < 10; ++addr)
		{

			SPIWrite(0x00+addr, data0);

		}
	}
	//SPIWrite(0x23, 0x5555);//read main register
	//SPIWrite(0x24, 0xAAAA);
	//SPIRead(0x23, m_reg_data1, 4);//read main register
	BUCK1IN_2.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2IN_3.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3IN_4.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 1.8, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 1.8, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	//if(SC6295X[find_ID].name == "HW_SC62595Q")
	//	PRECMP_BUCK3FB_INTB_10.TSet(FV, 3.6, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	//else
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 1.8, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK1SW_5.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2SW_6.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);

	B0_PRESW_LDO1IN.TSet(FV, 3.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FV, 0.2, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	B2_PREBOOT_VBOOST.TSet(FV, 3.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FV, 0.2, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	STSTArming();


	delay_ms(5);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_ACM.MeasureVI(3810, 100);
	ALL_FXVIE.MeasureVI(30, 10);
	dcm.PPMUMeasure("WAKE12_G", 30, 10);
	SERIAL
	{


		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		IQLEAK_WAKE1_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		IQLEAK_WAKE2_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		IQLEAK_VBOS_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);

		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		IQLEAK_BUCK1SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		IQLEAK_BUCK2SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		IQLEAK_BUCK3SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		IQLEAK_VSUP_12V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		IQLEAK_VDDIO_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK1IN_2.GetMeasResult(SITE, MIRET);
		IQLEAK_BUCK1IN_3p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK2IN_3.GetMeasResult(SITE, MIRET);
		IQLEAK_BUCK2IN_3p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK3IN_4.GetMeasResult(SITE, MIRET);
		IQLEAK_BUCK3IN_3p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		IQLEAK_BUCK1FB_1p8V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		IQLEAK_BUCK2FB_1p8V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		//if(SC6295X[find_ID].name == "HW_SC62595Q")
		//	IQLEAK_BUCK3FB_3p6V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);
		//else
		IQLEAK_BUCK3FB_1p8V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		IQLEAK_LDO1IN_3p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		IQLEAK_LDO1OUT_0p2V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);

		pinleakage[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);
		IQLEAK_VBOOST_3p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		IQLEAK_LDO2OUT_0p2V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);
	
	

	}

	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 0.0, DCM_PPMUIRANGE_200UA);
	delay_ms(1);
	VSUP_11.Set(FV, 0.0, ACM200_20V, ACM200_10MA, ACM200_RELAY_ON);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(3);

	BUCK1IN_2.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2IN_3.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3IN_4.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK1SW_5.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2SW_6.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	for (int i = 0; i < 12; i++)
		acm_grp[i].TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	for (int i = 0; i < 6; i++)
		fxvie_grp[i].TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	STSTArming();
	dcm.Disconnect("DCM_ALLPINS");

	return 0;
}

DUT_API int T05_TEST_OTP_CHECK(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES


	CParam *eFUSE_MBANK0_READ = StsGetParam(funcindex, "eFUSE_MBANK0_READ");
	CParam *eFUSE_MBANK1_READ = StsGetParam(funcindex, "eFUSE_MBANK1_READ");
	CParam *eFUSE_MBANK2_READ = StsGetParam(funcindex, "eFUSE_MBANK2_READ");
	CParam *eFUSE_MBANK3_READ = StsGetParam(funcindex, "eFUSE_MBANK3_READ");
	CParam *eFUSE_MBANK4_READ = StsGetParam(funcindex, "eFUSE_MBANK4_READ");
	CParam *eFUSE_MBANK5_READ = StsGetParam(funcindex, "eFUSE_MBANK5_READ");
	CParam *eFUSE_MBANK6_READ = StsGetParam(funcindex, "eFUSE_MBANK6_READ");
	CParam *eFUSE_MBANK7_READ = StsGetParam(funcindex, "eFUSE_MBANK7_READ");
	CParam *eFUSE_MBANK8_READ = StsGetParam(funcindex, "eFUSE_MBANK8_READ");
	CParam *eFUSE_MBANK9_READ = StsGetParam(funcindex, "eFUSE_MBANK9_READ");
	CParam *eFUSE_MBANK10_READ = StsGetParam(funcindex, "eFUSE_MBANK10_READ");
	CParam *eFUSE_MBANK11_READ = StsGetParam(funcindex, "eFUSE_MBANK11_READ");
	CParam *eFUSE_MBANK12_READ = StsGetParam(funcindex, "eFUSE_MBANK12_READ");
	CParam *eFUSE_MBANK13_READ = StsGetParam(funcindex, "eFUSE_MBANK13_READ");
	CParam *eFUSE_MBANK14_READ = StsGetParam(funcindex, "eFUSE_MBANK14_READ");
	CParam *eFUSE_MBANK15_READ = StsGetParam(funcindex, "eFUSE_MBANK15_READ");
	CParam *eFUSE_FSBANK0_READ = StsGetParam(funcindex, "eFUSE_FSBANK0_READ");
	CParam *M_UOTP_BURN = StsGetParam(funcindex, "M_UOTP_BURN");
	CParam *FS_UOTP_BURN = StsGetParam(funcindex, "FS_UOTP_BURN");
	//}}AFX_STS_PARAM_PROTOTYPES

	ULONG m_reg_data[12][SITE_NUM];
	ULONG m_reg_data1[4][SITE_NUM];
	ULONG m_reg_data2[4][SITE_NUM];
	ULONG m_reg_data1_i2c[4][SITE_NUM];
	ULONG tempdata[4][SITE_NUM];
	ULONG fs_reg_data[29][SITE_NUM];
	ULONG m_otp_data[10][SITE_NUM];
	ULONG fs_otp_data[5][SITE_NUM];

	ULONG m_trim_data[16][SITE_NUM];
	ULONG fs_trim_data[SITE_NUM];
	ULONG motp_burn_data[SITE_NUM];
	ULONG fsotp_burn_data[SITE_NUM];
	int trim_data[10][SITE_NUM];
	int reg1_data[4][SITE_NUM];
	int unburn_part[SITE_NUM];
	static int dieid_debug = 0;
	static int dieid_debug2 = 1;
	// TODO: Add your function code here
	string EE_str;
	CParam *EE_Params[BANK_NUM] = { eFUSE_MBANK0_READ, eFUSE_MBANK1_READ, eFUSE_MBANK2_READ, eFUSE_MBANK3_READ, eFUSE_MBANK4_READ, eFUSE_MBANK5_READ, eFUSE_MBANK6_READ, eFUSE_MBANK7_READ, eFUSE_MBANK8_READ, eFUSE_MBANK9_READ,
		eFUSE_MBANK10_READ, eFUSE_MBANK11_READ, eFUSE_MBANK12_READ, eFUSE_MBANK13_READ, eFUSE_MBANK14_READ, eFUSE_MBANK15_READ, eFUSE_FSBANK0_READ };
	string m_param_str_array[] = { "M_REG_00", "M_REG_01", "M_REG_02", "M_REG_03", "M_REG_04", "M_REG_05", "M_REG_06", "M_REG_07", "M_REG_08", "M_REG_09", "M_REG_0A", "M_REG_0B", "M_REG_23", "M_REG_24", "M_REG_25", "M_REG_26" };
	string fs_param_str_array[] = { "FS_REG_00", "FS_REG_01", "FS_REG_02", "FS_REG_03", "FS_REG_04", "FS_REG_05", "FS_REG_06", "FS_REG_07", "FS_REG_08", "FS_REG_09", "FS_REG_0A", "FS_REG_0B", "FS_REG_0C", "FS_REG_0D", "FS_REG_0E", "FS_REG_0F",
		"FS_REG_10", "FS_REG_11", "FS_REG_12", "FS_REG_13", "FS_REG_14", "FS_REG_15", "FS_REG_16", "FS_REG_17", "FS_REG_18", "FS_REG_19", "FS_REG_1A", "FS_REG_1B", "FS_REG_1C" };
	string m_param_str_array1[] = { "M_OTP_00", "M_OTP_01", "M_OTP_02", "M_OTP_03", "M_OTP_04", "M_OTP_05", "M_OTP_06", "M_OTP_07", "M_OTP_08", "M_OTP_09" };
	string fs_param_str_array1[] = { "FS_OTP_00", "FS_OTP_01", "FS_OTP_02", "FS_OTP_03", "FS_OTP_04" };

	string m_param_str_array_i2c[] = { "M_REG_23_I2C", "M_REG_24_I2C", "M_REG_25_I2C", "M_REG_26_I2C" };

	string m_param_str_array_1[] = { "M_REG_00", "M_REG_01", "M_REG_02", "M_REG_03_1", "M_REG_04", "M_REG_05", "M_REG_06", "M_REG_07", "M_REG_08", "M_REG_09", "M_REG_0A", "M_REG_0B", "M_REG_23", "M_REG_24", "M_REG_25_1", "M_REG_26" };
	string fs_param_str_array_1[] = { "FS_REG_00", "FS_REG_01", "FS_REG_02", "FS_REG_03", "FS_REG_04", "FS_REG_05", "FS_REG_06", "FS_REG_07", "FS_REG_08", "FS_REG_09", "FS_REG_0A", "FS_REG_0B", "FS_REG_0C", "FS_REG_0D", "FS_REG_0E", "FS_REG_0F",
		"FS_REG_10", "FS_REG_11", "FS_REG_12", "FS_REG_13", "FS_REG_14", "FS_REG_15", "FS_REG_16", "FS_REG_17_1", "FS_REG_18_1", "FS_REG_19_1", "FS_REG_1A_1", "FS_REG_1B_1", "FS_REG_1C_1" };
	string m_param_str_array1_1[] = { "M_OTP_00_1", "M_OTP_01_1", "M_OTP_02_1", "M_OTP_03_1", "M_OTP_04_1", "M_OTP_05_1", "M_OTP_06_1", "M_OTP_07_1", "M_OTP_08_1", "M_OTP_09_1" };
	string fs_param_str_array1_1[] = { "FS_OTP_00_1", "FS_OTP_01_1", "FS_OTP_02_1", "FS_OTP_03_1", "FS_OTP_04_1" };
	string m_param_str_array_2[] = { "M_REG_00", "M_REG_01_WJ", "M_REG_02", "M_REG_03_1", "M_REG_04", "M_REG_05", "M_REG_06", "M_REG_07", "M_REG_08", "M_REG_09", "M_REG_0A", "M_REG_0B", "M_REG_23", "M_REG_24", "M_REG_25_1", "M_REG_26" };
	string fs_param_str_array_2[] = { "FS_REG_00", "FS_REG_01", "FS_REG_02", "FS_REG_03", "FS_REG_04", "FS_REG_05", "FS_REG_06", "FS_REG_07", "FS_REG_08", "FS_REG_09", "FS_REG_0A", "FS_REG_0B", "FS_REG_0C", "FS_REG_0D", "FS_REG_0E", "FS_REG_0F",
		"FS_REG_10", "FS_REG_11_WJ", "FS_REG_12", "FS_REG_13", "FS_REG_14", "FS_REG_15", "FS_REG_16", "FS_REG_17_1", "FS_REG_18_1", "FS_REG_19_1", "FS_REG_1A_1", "FS_REG_1B_1", "FS_REG_1C_1" };
	string fs_param_str_array_2hw[] = { "FS_REG_00", "FS_REG_01", "FS_REG_02", "FS_REG_03", "FS_REG_04", "FS_REG_05", "FS_REG_06", "FS_REG_07", "FS_REG_08", "FS_REG_09", "FS_REG_0A", "FS_REG_0B", "FS_REG_0C", "FS_REG_0D", "FS_REG_0E", "FS_REG_0F",
		"FS_REG_10", "FS_REG_11_2HW", "FS_REG_12", "FS_REG_13", "FS_REG_14", "FS_REG_15", "FS_REG_16", "FS_REG_17_1", "FS_REG_18_1", "FS_REG_19_1", "FS_REG_1A_1", "FS_REG_1B_1", "FS_REG_1C_1" };


	string m_param_str_array_i2c_1[] = { "M_REG_23_I2C", "M_REG_24_I2C", "M_REG_25_I2C_1", "M_REG_26_I2C" };
	map<unsigned int, map<string, unsigned int>> node_map;	// map<site, map<node_name, value>>

	//for debug
	//I2C_ADDR_DEVICE = 0x67 << 1;
	//	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K58_DBG_PU, K57_FS0B_PSYNC_PU, K46_PREFB_ACM,
	//		K32_INTB_FXVIA, K110_FXVI3_9_A, K38_PRECOMP_ACM, K80_PRECSP_PREFB_SHRT, K43_PREGHS_FXVIB, K107_FXVI1_7_B,
	//	 K56_INTB_PU, K84_PRECOMP_CAP, K42_PRESW_FXVIB, K105_FXVI0_6_B, K44_PREBOOT_FXVIB, K109_FXVI2_8_B, K21_PADF_AGNDF ,-1);
	//delay_ms(1);

	////cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K54_VDDIO_PU, K59_WAKE12_PU, K8_SCL_SDA_DCM, K78_FCCU1_PU_FCCU2_PD , K80_PRECSP_PREFB_SHRT ,- 1);//will check if need the caps.
	////delay_ms(1);
	//SPIInitial(4.0, 0, 2.0, 1.9, 200);
	////need check IIC setup and read
	//I2CSetup(1);
	//VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	//VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	////VBOS_1.Set(FI, 0, ACM200_20V, ACM200_10UA, ACM200_RELAY_ON);//will check VBOS startup time
	//	//VBOS_1.MeasureVI(1000, 10);
	//delay_ms(5);//will check delay time
	//	cbite.SetCbiteOn(K59_WAKE12_PU);
	//		delay_ms(15);//
	//	SPIWrite(0x02, 0x7F);
	////Enter_MAIN_TM_DIG();
	////Enter_FS_TM_DIG();
	//double res[SITE_NUM];
	//cbite.SetCbiteOff(K58_DBG_PU);
	//cbite.SetCbiteOn(K61_DBG_PD);
	//delay_ms(5);
	//B2_PREBOOT_VBOOST.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//awg.rampvmi(B1_PREGHS_PREGLS_LDO1OUT,B2_PREBOOT_VBOOST,FXVIe_PLUS_10V,FXVIe_PLUS_1A,"test1",0,5.0,0.010,200,-0.1,TRIG_FALLING,res);
	//B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	//B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);

	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K54_VDDIO_PU, K59_WAKE12_PU, K8_SCL_SDA_DCM, K78_FCCU1_PU_FCCU2_PD , K80_PRECSP_PREFB_SHRT ,- 1);//will check if need the caps.
	delay_ms(1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	//need check IIC setup and read
	I2CSetup(1);
	SPIWrite(0x23, 0x5555);//for pattern inital to avoid spi clk err.
	delay_ms(1);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	//VBOS_1.Set(FI, 0, ACM200_20V, ACM200_10UA, ACM200_RELAY_ON);//will check VBOS startup time
		//VBOS_1.MeasureVI(1000, 10);
	delay_ms(15);//will check delay time
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	// Read Main register
	SPIWrite(0x23, 0x5555);//read main register
	SPIWrite(0x24, 0xAAAA);
	SPIRead(0x00, m_reg_data, 12);//read main register
	SPIRead(0x23, m_reg_data1, 4);//read main register

	SPIWrite(0x3F, 0x7481);//switch to main otp table
	delay_us(10);
	SPIRead(0x00, m_otp_data, 10);// read user otp1
	SPIRead(0x20, m_trim_data, 16);//read trim data
	SPIRead(0x1F, motp_burn_data);
	
	SPIRead(0x40, fs_reg_data, 29);//read fs register
	SPIWrite(0x7F, 0x7481);//switch to fs otp table
	delay_us(30);
	SPIRead(0x40, fs_otp_data, 5);//read fs user otp
	SPIRead(0x50, fs_trim_data);//read trim data
	SPIRead(0x4F, fsotp_burn_data);

	SERIAL{
		if((motp_burn_data[SITE]==0) && (fsotp_burn_data[SITE]==0))
			unburn_part[SITE]=1;
		else
			unburn_part[SITE]=0;



	}

	SPIWrite(0x3F, 0x7401);

	if(SC6295X[find_ID].name=="SC62595Q_2HW")
	{
		StsGetSiteStatus(sitesta, SITE_NUM);
		for(int site=0;site<SITE_NUM;site++) 
		{
			if(sitesta[site]==1)
			{
				if(unburn_part[site]==1)
				{
					I2CWriteData(0x23, 0xAAAA);
					I2CWriteData(0x24, 0x5555);
					I2CReadData(0x23, tempdata, 4);
					m_reg_data1_i2c[0][site]=(tempdata[0][site]);
					m_reg_data1_i2c[1][site]=tempdata[1][site];
					m_reg_data1_i2c[2][site]=tempdata[2][site];
					m_reg_data1_i2c[3][site]=tempdata[3][site];
				}
				else
				{

					I2CWriteDataA(0x22<<1,0x23, 0xAAAA);
					I2CWriteDataA(0x22<<1,0x24, 0x5555);
					I2CReadData(0x22<<1,0x23, tempdata, 4);
					m_reg_data1_i2c[0][site]=tempdata[0][site];
					m_reg_data1_i2c[1][site]=tempdata[1][site];
					m_reg_data1_i2c[2][site]=tempdata[2][site];
					m_reg_data1_i2c[3][site]=tempdata[3][site];
				}
			}


		}
	}
	else
	{
		I2CWriteData(0x23, 0xAAAA);
		I2CWriteData(0x24, 0x5555);
		I2CReadData(0x23, m_reg_data1_i2c, 4);
	}

	//Power off
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);

	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.


	power_off(1);

	SERIAL{
		if(SC6295X[find_ID].useropt_burn == 0)
		{
			for (int addr = 0; addr < 12; ++addr)
			StsGetParam(funcindex, m_param_str_array[addr].c_str())->SetTestResult(SITE, 0, m_reg_data[addr][SITE]);
			for (int addr = 0; addr < 4; ++addr)
			{
				StsGetParam(funcindex, m_param_str_array[addr + 12].c_str())->SetTestResult(SITE, 0, m_reg_data1[addr][SITE]);
				StsGetParam(funcindex, m_param_str_array_i2c[addr].c_str())->SetTestResult(SITE, 0, m_reg_data1_i2c[addr][SITE]);
			}
			for (int addr = 0; addr < 29; ++addr)
				StsGetParam(funcindex, fs_param_str_array[addr].c_str())->SetTestResult(SITE, 0, fs_reg_data[addr][SITE]);


			for (int addr = 0; addr < 10; ++addr)
				StsGetParam(funcindex, m_param_str_array1[addr].c_str())->SetTestResult(SITE, 0, m_otp_data[addr][SITE]);
			for (int addr = 0; addr < 5; ++addr)
				StsGetParam(funcindex, fs_param_str_array1[addr].c_str())->SetTestResult(SITE, 0, fs_otp_data[addr][SITE]);
		}
		else
		{
			if(unburn_part[SITE]==1)
			{

				for (int addr = 0; addr < 12; ++addr)
				StsGetParam(funcindex, m_param_str_array[addr].c_str())->SetTestResult(SITE, 0, m_reg_data[addr][SITE]);
				for (int addr = 0; addr < 4; ++addr)
				{
					StsGetParam(funcindex, m_param_str_array[addr + 12].c_str())->SetTestResult(SITE, 0, m_reg_data1[addr][SITE]);
					StsGetParam(funcindex, m_param_str_array_i2c[addr].c_str())->SetTestResult(SITE, 0, m_reg_data1_i2c[addr][SITE]);
				}
				for (int addr = 0; addr < 29; ++addr)
					StsGetParam(funcindex, fs_param_str_array[addr].c_str())->SetTestResult(SITE, 0, fs_reg_data[addr][SITE]);


				for (int addr = 0; addr < 10; ++addr)
					StsGetParam(funcindex, m_param_str_array1[addr].c_str())->SetTestResult(SITE, 0, m_otp_data[addr][SITE]);
				for (int addr = 0; addr < 5; ++addr)
					StsGetParam(funcindex, fs_param_str_array1[addr].c_str())->SetTestResult(SITE, 0, fs_otp_data[addr][SITE]);

			}
			else
			{
				if ((SC6295X[find_ID].name == "SC62595Q_HTOL") ||(SC6295X[find_ID].name == "SC62595Q_HW")   )
				{
					for (int addr = 0; addr < 12; ++addr)
					StsGetParam(funcindex, m_param_str_array_1[addr].c_str())->SetTestResult(SITE, 0, m_reg_data[addr][SITE]);
					for (int addr = 0; addr < 4; ++addr)
					{
						StsGetParam(funcindex, m_param_str_array_1[addr + 12].c_str())->SetTestResult(SITE, 0, m_reg_data1[addr][SITE]);
						StsGetParam(funcindex, m_param_str_array_i2c_1[addr].c_str())->SetTestResult(SITE, 0, m_reg_data1_i2c[addr][SITE]);
					}
					for (int addr = 0; addr < 29; ++addr)
						StsGetParam(funcindex, fs_param_str_array_1[addr].c_str())->SetTestResult(SITE, 0, fs_reg_data[addr][SITE]);


					for (int addr = 0; addr < 10; ++addr)
						StsGetParam(funcindex, m_param_str_array1_1[addr].c_str())->SetTestResult(SITE, 0, m_otp_data[addr][SITE]);
					for (int addr = 0; addr < 5; ++addr)
						StsGetParam(funcindex, fs_param_str_array1_1[addr].c_str())->SetTestResult(SITE, 0, fs_otp_data[addr][SITE]);
				}
				if (SC6295X[find_ID].name == "SC62595Q_2HW")
				{
					for (int addr = 0; addr < 12; ++addr)
					StsGetParam(funcindex, m_param_str_array_1[addr].c_str())->SetTestResult(SITE, 0, m_reg_data[addr][SITE]);
					for (int addr = 0; addr < 4; ++addr)
					{
						StsGetParam(funcindex, m_param_str_array_1[addr + 12].c_str())->SetTestResult(SITE, 0, m_reg_data1[addr][SITE]);
						StsGetParam(funcindex, m_param_str_array_i2c_1[addr].c_str())->SetTestResult(SITE, 0, m_reg_data1_i2c[addr][SITE]);
					}
					for (int addr = 0; addr < 29; ++addr)
						StsGetParam(funcindex, fs_param_str_array_2hw[addr].c_str())->SetTestResult(SITE, 0, fs_reg_data[addr][SITE]);

					for (int addr = 0; addr < 10; ++addr)
						StsGetParam(funcindex, m_param_str_array1_1[addr].c_str())->SetTestResult(SITE, 0, m_otp_data[addr][SITE]);
					for (int addr = 0; addr < 5; ++addr)
						StsGetParam(funcindex, fs_param_str_array1_1[addr].c_str())->SetTestResult(SITE, 0, fs_otp_data[addr][SITE]);
				}

				if ((SC6295X[find_ID].name == "SC62594Q_WJ")  )
				{
						for (int addr = 0; addr < 12; ++addr)
						StsGetParam(funcindex, m_param_str_array_2[addr].c_str())->SetTestResult(SITE, 0, m_reg_data[addr][SITE]);
						for (int addr = 0; addr < 4; ++addr)
						{
							StsGetParam(funcindex, m_param_str_array_2[addr + 12].c_str())->SetTestResult(SITE, 0, m_reg_data1[addr][SITE]);
							StsGetParam(funcindex, m_param_str_array_i2c_1[addr].c_str())->SetTestResult(SITE, 0, m_reg_data1_i2c[addr][SITE]);
						}
						for (int addr = 0; addr < 29; ++addr)
							StsGetParam(funcindex, fs_param_str_array_2[addr].c_str())->SetTestResult(SITE, 0, fs_reg_data[addr][SITE]);


						for (int addr = 0; addr < 10; ++addr)
							StsGetParam(funcindex, m_param_str_array1_1[addr].c_str())->SetTestResult(SITE, 0, m_otp_data[addr][SITE]);
						for (int addr = 0; addr < 5; ++addr)
							StsGetParam(funcindex, fs_param_str_array1_1[addr].c_str())->SetTestResult(SITE, 0, fs_otp_data[addr][SITE]);
				}
				//if (SC6295X[find_ID].name == "SC62595Q_HTOL")
				//{
				//	for (int addr = 0; addr < 12; ++addr)
				//		StsGetParam(funcindex, m_param_str_array_1[addr].c_str())->SetTestResult(SITE, 0, m_reg_data[addr][SITE]);
				//	for (int addr = 0; addr < 4; ++addr)
				//	{
				//		StsGetParam(funcindex, m_param_str_array_1[addr + 12].c_str())->SetTestResult(SITE, 0, m_reg_data1[addr][SITE]);
				//		StsGetParam(funcindex, m_param_str_array_i2c_1[addr].c_str())->SetTestResult(SITE, 0, m_reg_data1_i2c[addr][SITE]);
				//	}
				//	for (int addr = 0; addr < 29; ++addr)
				//		StsGetParam(funcindex, fs_param_str_array_1[addr].c_str())->SetTestResult(SITE, 0, fs_reg_data[addr][SITE]);


				//	for (int addr = 0; addr < 10; ++addr)
				//		StsGetParam(funcindex, m_param_str_array1_1[addr].c_str())->SetTestResult(SITE, 0, m_otp_data[addr][SITE]);
				//	for (int addr = 0; addr < 5; ++addr)
				//		StsGetParam(funcindex, fs_param_str_array1_1[addr].c_str())->SetTestResult(SITE, 0, fs_otp_data[addr][SITE]);
				//}
			}
		
		}

		M_UOTP_BURN->SetTestResult(SITE, 0, motp_burn_data[SITE] );
		FS_UOTP_BURN->SetTestResult(SITE, 0, fsotp_burn_data[SITE] );
	}


	SERIAL
	{
		m_burn_flag[SITE] = true;
		fs_burn_flag[SITE] = true;
		user_otp_burn_flag[SITE] = true;
		for (int addr = 0; addr < 10; ++addr)
		{
			if( m_otp_data[addr][SITE]!=0)
					user_otp_burn_flag[SITE] = false;
		}
		for (int addr = 0; addr < 5; ++addr)
		{
				if( fs_otp_data[addr][SITE]!=0)
					user_otp_burn_flag[SITE] = false;
		}
		// main
		for (int addr = 0; addr < BANK_NUM - 1; ++addr)
		{

			EE_str = "MBANK" + to_string(addr);
			dut.assy(EE_str.c_str()).set_read_back((m_trim_data[addr][SITE]), SITE);
			dut.assy(EE_str.c_str()).copy_read_to_prog();
			if (((m_trim_data[addr][SITE] && addr<15) || QC || (test_stage>1)))//only compare pre 15 banks at FT
			{
				m_burn_flag[SITE] = false;
			}
			EE_Params[addr]->SetTestResult(SITE, 0, m_trim_data[addr][SITE]);
			for (unsigned int node_no = 0; node_no<dut.assy(EE_str.c_str()).count(); ++node_no){
				string node_name(dut.assy(EE_str.c_str())[node_no].get_node_name());

				if (dut.find(node_name.c_str()) == FOUND_TRIM)									// judge if it is trim node, not sel node
					node_map[SITE][node_name] = dut.trim(node_name.c_str()).get_read_back(SITE);
				else if (dut.find(node_name.c_str()) == FOUND_SEL)
					node_map[SITE][node_name] = dut.sel(node_name.c_str()).get_read_back(SITE);
			}
		}

		//fs
		EE_str = "FSBANK0";
		dut.assy(EE_str.c_str()).set_read_back((fs_trim_data[SITE]), SITE);
		dut.assy(EE_str.c_str()).copy_read_to_prog();
		if ((fs_trim_data[SITE] || QC || (test_stage>1)))//only compare pre 15 banks at FT
		{
			fs_burn_flag[SITE] = false;
		}
		EE_Params[BANK_NUM - 1]->SetTestResult(SITE, 0, fs_trim_data[SITE]);
		for (unsigned int node_no = 0; node_no<dut.assy(EE_str.c_str()).count(); ++node_no){
			string node_name(dut.assy(EE_str.c_str())[node_no].get_node_name());

			if (dut.find(node_name.c_str()) == FOUND_TRIM)									// judge if it is trim node, not sel node
				node_map[SITE][node_name] = dut.trim(node_name.c_str()).get_read_back(SITE);
			else if (dut.find(node_name.c_str()) == FOUND_SEL)
				node_map[SITE][node_name] = dut.sel(node_name.c_str()).get_read_back(SITE);
		}

		if (m_burn_flag[SITE] == false){	// trimmed
			for (int addr = 0; addr < BANK_NUM - 1; ++addr)
			{
				EE_str = "MBANK" + to_string(addr);
				dut.assy(EE_str.c_str()).copy_read_to_work(SITE);

			}

		}
		else
		{
			if (DEBUG)
			{

				dieid_debug++;
				if (dieid_debug > 63)
				{
					dieid_debug2++;
					dieid_debug = 1;
					
				}
				dut.sel("DIEID_X").set_start(dieid_debug2, SITE);
				dut.sel("DIEID_Y").set_start(dieid_debug, SITE);
			}
			for (int addr = 0; addr < BANK_NUM - 2; ++addr)
			{
				EE_str = "MBANK" + to_string(addr);
				dut.assy(EE_str.c_str()).copy_start_to_work(SITE);

			}
	
		}
		if (fs_burn_flag[SITE] == false){	// trimmed


			dut.assy("FSBANK0").copy_read_to_work(SITE);

		}
		else
		{

			dut.assy("FSBANK0").copy_start_to_work(SITE);

		}
		for (int addr = 0; addr < BANK_NUM - 1; ++addr)
		{
			EE_str = "MBANK" + to_string(addr);
			for (unsigned int node_no = 0; node_no<dut.assy(EE_str.c_str()).count(); ++node_no){
				string node_name(dut.assy(EE_str.c_str())[node_no].get_node_name());

				if (dut.find(node_name.c_str()) == FOUND_TRIM)									// judge if it is trim node, not sel node
					dut.trim(node_name.c_str()).set_trim_allowed(m_burn_flag[SITE], SITE);	// if burn_flag is false, disable trim allow, else enable
			}
		}
		for (unsigned int node_no = 0; node_no<dut.assy("FSBANK0").count(); ++node_no){
			string node_name(dut.assy("FSBANK0")[node_no].get_node_name());

			if (dut.find(node_name.c_str()) == FOUND_TRIM)									// judge if it is trim node, not sel node
				dut.trim(node_name.c_str()).set_trim_allowed(fs_burn_flag[SITE], SITE);	// if burn_flag is false, disable trim allow, else enable
		}

	}
	for (map<unsigned int, map<string, unsigned int>>::iterator it_site = node_map.begin(); it_site != node_map.end(); ++it_site){
		for (map<string, unsigned int>::iterator it_node = it_site->second.begin(); it_node != it_site->second.end(); ++it_node){
			if (it_node->first.find("dummy") != string::npos)	continue;

			string param_str = it_node->first + "_PRE";
			StsGetParam(funcindex, param_str.c_str())->SetTestResult(it_site->first, 0, it_node->second);
		}
	}

	return 0;
}

DUT_API int T07_BG_trim(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam *AMUX_VOS = StsGetParam(funcindex, "AMUX_VOS");
	CParam *IAMUX_NEG = StsGetParam(funcindex, "IAMUX_NEG");
	CParam *IAMUX_POS = StsGetParam(funcindex, "IAMUX_POS");
	CParam* BGTC_VSUP12V = StsGetParam(funcindex, "BGTC_VSUP12V");
	CParam *BGV_VSUP36V = StsGetParam(funcindex, "BGV_VSUP36V");
	CParam *BGV_VSUP4p5V = StsGetParam(funcindex, "BGV_VSUP4p5V");
	CParam* VREF_VSUP12V = StsGetParam(funcindex, "VREF_VSUP12V");
	CParam* VREF_VSUP36V = StsGetParam(funcindex, "VREF_VSUP36V");
	CParam* VREF_VSUP4p5V = StsGetParam(funcindex, "VREF_VSUP4p5V");
	CParam* FS_BGTC_VSUP12V = StsGetParam(funcindex, "FS_BGTC_VSUP12V");
	CParam *FS_BGV_VSUP36V = StsGetParam(funcindex, "FS_BGV_VSUP36V");
	CParam *FS_BGV_VSUP4p5V = StsGetParam(funcindex, "FS_BGV_VSUP4p5V");
	CParam* FS_VREF_VSUP12V = StsGetParam(funcindex, "FS_VREF_VSUP12V");
	CParam* FS_VREF_VSUP36V = StsGetParam(funcindex, "FS_VREF_VSUP36V");
	CParam* FS_VREF_VSUP4p5V = StsGetParam(funcindex, "FS_VREF_VSUP4p5V");

	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double results1[SITE_NUM];
	string bg_tc;
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, -1);
	delay_ms(1);
	if (DEBUG)	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();

	//before trimm need test the offset
	SPIWrite(0x04,0x0003);//switch bg to AMUX
	
	delay_ms(3);
	A5_AMUX.MeasureVI(50, 10);
	SERIAL results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);

	Enter_M_TM(0x0000, 0x0000, 0x1000);//TM44=1
	delay_ms(3);
	A5_AMUX.MeasureVI(50, 10);
	SERIAL 
	{
		results1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		g_amux_vos[SITE] = (results1[SITE] - results[SITE])/2.0;
		AMUX_VOS->SetTestResult(SITE, 0, g_amux_vos[SITE] * 1e3);//mV
	}
	cbite.SetCbiteOn(K27_220_SHRT);
	delay_ms(1);
	A5_AMUX.Set(FV, 0.5, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);//Amux capability
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MIRET);
		IAMUX_NEG->SetTestResult(SITE, 0, results[SITE] * 1e3);//mA
		
	}
	A5_AMUX.Set(FV, 1.5, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);//Amux capability
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MIRET);
		IAMUX_POS->SetTestResult(SITE, 0, results[SITE] * 1e3);//mA

	}
	cbite.SetCbiteOff(K27_220_SHRT);
	delay_ms(1);
	A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);

	SPIWrite(0x04, 0x0013);//switch bg to AMUX
	SPIWrite(0x3F, 0x7481);//switch to main otp table//for preview
	Enter_M_TM(0x0170, 0x0000, 0x0000);//enter bg testmode
	if(1)// for char test to find out the best code
	{ 
		dut.trim("BGTC").execute(measure_BGTC, spec, funcindex, funclabel, 1, treg_log_mode, "BGTC");
	//	dut.trim("BGTC").set_working(0);//force to start code
	}
	
	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		BGTC_VSUP12V->SetTestResult(SITE, 0, results[SITE] + g_amux_vos[SITE]);
	}
	dut.trim("BG_V").execute(measure_BGV, spec, funcindex, funclabel, 1, treg_log_mode, "BG_V");


	VSUP_11.Set(FV, 4.5, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);//OTP_VSUP_CFG=0

	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		BGV_VSUP4p5V->SetTestResult(SITE, 0, results[SITE]);
	}
	VSUP_11.Set(FV, 36.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		BGV_VSUP36V->SetTestResult(SITE, 0, results[SITE]);
	}
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	SPIWrite(0x3F, 0x7401);
	SPIWrite(0x04, 0x0003);//switch bg to AMUX
	SPIWrite(0x3F, 0x7481);
	Enter_M_TM(0x0180, 0x0000, 0x0000);//VREF 1V
	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		VREF_VSUP12V->SetTestResult(SITE, 0, results[SITE]);
	}
	VSUP_11.Set(FV, 4.5, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);//OTP_VSUP_CFG=0

	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		VREF_VSUP4p5V->SetTestResult(SITE, 0, results[SITE]);
	}
	VSUP_11.Set(FV, 36.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		VREF_VSUP36V->SetTestResult(SITE, 0, results[SITE]);
	}
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	//VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//delay_ms(3);
	//VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	//VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	//A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(3);
	//Enter_MAIN_TM_DIG();
	//Enter_FS_TM_DIG();

	Enter_M_TM(0x0000, 0x0000, 0x0000);
	SPIWrite(0x3F, 0x7401);
	SPIWrite(0x04, 0x0002);

	//SPIRead(0x04, rdata);
	SPIWrite(0x3F, 0x7481);
	//Enter_M_TM(0x0000, 0x0000, 0x0000);//VREF 1V
	delay_ms(1);
	dut.trim("TS_TRIM").execute(measure_TS, spec, funcindex, funclabel, 1, treg_log_mode, "TS_TRIM");
	//before trimm need test the offset
	Enter_FS_TM_DIG();
	SPIWrite(0x3F, 0x7401);
	SPIWrite(0x04, 0x0013);//switch bg to AMUX

	SPIWrite(0x7F, 0x7481);//swith to otp bank
	Enter_FS_TM(0x0032);
	if (1)
	{
		dut.trim("FS_BG_TC").execute(measure_FSBGTC, spec, funcindex, funclabel, 1, treg_log_mode, "FS_BG_TC");
		//dut.trim("FS_BG_TC").set_working(0);
	}
	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		FS_BGTC_VSUP12V->SetTestResult(SITE, 0, results[SITE]);
	}

	dut.trim("FS_BG_V").execute(measure_FSBGV, spec, funcindex, funclabel, 1, treg_log_mode, "FS_BG_V");


	VSUP_11.Set(FV, 4.5, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);//OTP_VSUP_CFG=0

	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		FS_BGV_VSUP4p5V->SetTestResult(SITE, 0, results[SITE]);
	}
	VSUP_11.Set(FV, 36.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		FS_BGV_VSUP36V->SetTestResult(SITE, 0, results[SITE]);
	}
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	SPIWrite(0x3F, 0x7401);
	SPIWrite(0x04, 0x0004);//switch bg to AMUX

	SPIWrite(0x7F, 0x7481);//swith to otp bank
	Enter_FS_TM(0x0033);
	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		FS_VREF_VSUP12V->SetTestResult(SITE, 0, results[SITE]);//0.96V
	}

	VSUP_11.Set(FV, 4.5, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);//OTP_VSUP_CFG=0

	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		FS_VREF_VSUP4p5V->SetTestResult(SITE, 0, results[SITE]);
	}
	VSUP_11.Set(FV, 36.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_ms(2);

	A5_AMUX.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		FS_VREF_VSUP36V->SetTestResult(SITE, 0, results[SITE]);//0.96V
	}

	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	




	if (DEBUG)
	{


		VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
		VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
		A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
		delay_ms(3);//for cap discharge
		power_off(DEBUG);
	}
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T09_ICT_trim(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam *ICT_VSUP36V = StsGetParam(funcindex, "ICT_VSUP36V");
	CParam *ICT_VSUP4p5V = StsGetParam(funcindex, "ICT_VSUP4p5V");

	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	if (DEBUG)
	{ 
		cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K17_FIN_FXVIA, K104_FXVI0_6_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, -1);
		delay_ms(1);
		SPIInitial(4.0, 0, 2.0, 1.9, 200);
		VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
		VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	
		delay_ms(3);
		Enter_MAIN_TM_DIG();
		Enter_FS_TM_DIG();
		SPIWrite(0x3F, 0x7481);//switch to main otp table//for preview
	}
	else
	{
		A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
		cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K17_FIN_FXVIA, K104_FXVI0_6_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, -1);
		delay_ms(1);
	}
	Enter_M_TM(0x01B0, 0x0000, 0x0000);//ict

	A0_FIN_DBG_ERR_FCCU1.Set(FV, 1.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	dut.trim("ICT").execute(measure_ICT, spec, funcindex, funclabel, 1e6, treg_log_mode, "ICT");


	VSUP_11.Set(FV, 4.5, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);//OTP_VSUP_CFG=0

	delay_ms(2);

	A0_FIN_DBG_ERR_FCCU1.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		ICT_VSUP4p5V->SetTestResult(SITE, 0, -results[SITE]*1e6);
	}
	VSUP_11.Set(FV, 36.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_ms(2);

	A0_FIN_DBG_ERR_FCCU1.MeasureVI(30, 10);
	SERIAL{
		results[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		ICT_VSUP36V->SetTestResult(SITE, 0, -results[SITE] * 1e6);
	}
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	if (DEBUG)
	{


		VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
		VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
		A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
		delay_ms(3);//for cap discharge
	}

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T11_FREQ_trim(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam *OSC_MAIN_DUTY = StsGetParam(funcindex, "OSC_MAIN_DUTY");
	CParam *VPRE_CLK_DUTY = StsGetParam(funcindex, "VPRE_CLK_DUTY");
	CParam *BOOST_CLK_DUTY = StsGetParam(funcindex, "BOOST_CLK_DUTY");
	CParam *BUCK1_CLK_DUTY = StsGetParam(funcindex, "BUCK1_CLK_DUTY");
	CParam *BUCK2_CLK_DUTY = StsGetParam(funcindex, "BUCK2_CLK_DUTY");
	CParam *BUCK3_CLK_DUTY = StsGetParam(funcindex, "BUCK3_CLK_DUTY");
	CParam *FS_CLK_DUTY = StsGetParam(funcindex, "FS_CLK_DUTY");

	CParam* OSC_MAIN_FREQ  = StsGetParam(funcindex, "OSC_MAIN_FREQ");
	CParam* VPRE_CLK_FREQ  = StsGetParam(funcindex, "VPRE_CLK_FREQ");
	CParam* BOOST_CLK_FREQ = StsGetParam(funcindex, "BOOST_CLK_FREQ");
	CParam* BUCK1_CLK_FREQ = StsGetParam(funcindex, "BUCK1_CLK_FREQ");
	CParam* BUCK2_CLK_FREQ = StsGetParam(funcindex, "BUCK2_CLK_FREQ");
	CParam* BUCK3_CLK_FREQ = StsGetParam(funcindex, "BUCK3_CLK_FREQ");
	CParam* FS_CLK_FREQ		= StsGetParam(funcindex, "FS_CLK_FREQ");
	CParam* VPRE_CLK_DUTY_0x1 = StsGetParam(funcindex, "VPRE_CLK_DUTY_0x1");
	CParam* VPRE_CLK_FREQ_0x1 = StsGetParam(funcindex, "VPRE_CLK_FREQ_0x1");
	CParam *CLK1_FSW_VSUP36V = StsGetParam(funcindex, "CLK1_FSW_VSUP36V");
	CParam *CLK1_FSW_VSUP4p5V = StsGetParam(funcindex, "CLK1_FSW_VSUP4p5V");
	CParam *CLK1_FSW_TUNE_0x04 = StsGetParam(funcindex, "CLK1_FSW_TUNE_0x04");
	CParam *CLK1_FSW_TUNE_0x04_PCT = StsGetParam(funcindex, "CLK1_FSW_TUNE_0x04_PCT");
	CParam *CLK1_FSW_TUNE_0x09 = StsGetParam(funcindex, "CLK1_FSW_TUNE_0x09");
	CParam *CLK1_FSW_TUNE_0x09_PCT = StsGetParam(funcindex, "CLK1_FSW_TUNE_0x09_PCT");
	CParam *SPSP_VSUP36V = StsGetParam(funcindex, "SPSP_VSUP36V");
	CParam *SPSP_VSUP4p5V = StsGetParam(funcindex, "SPSP_VSUP4p5V");

	CParam *SPSP_FREQ_MIN = StsGetParam(funcindex, "SPSP_FREQ_MIN");
	CParam *SPSP_FREQ_MAX = StsGetParam(funcindex, "SPSP_FREQ_MAX");
	CParam *SPSP_FREQ_AVG = StsGetParam(funcindex, "SPSP_FREQ_AVG");
	CParam *SPSP_CARR_23K = StsGetParam(funcindex, "SPSP_CARR_23K");
	CParam *SPSP_FREQ_RANGE1 = StsGetParam(funcindex, "SPSP_FREQ_RANGE1");
	CParam *SPSP_FREQ_RANGE2 = StsGetParam(funcindex, "SPSP_FREQ_RANGE2");
	CParam *SPSP_FREQ_95kHZ_MIN = StsGetParam(funcindex, "SPSP_FREQ_95kHZ_MIN");
	CParam *SPSP_FREQ_95kHZ_MAX = StsGetParam(funcindex, "SPSP_FREQ_95kHZ_MAX");
	CParam *SPSP_FREQ_95kHZ_AVG = StsGetParam(funcindex, "SPSP_FREQ_95kHZ_AVG");
	CParam *SPSP_CARR_95K = StsGetParam(funcindex, "SPSP_CARR_95K");
	CParam *SPSP_FREQ_95K_RANGE1 = StsGetParam(funcindex, "SPSP_FREQ_95K_RANGE1");
	CParam *SPSP_FREQ_95K_RANGE2 = StsGetParam(funcindex, "SPSP_FREQ_95K_RANGE2");
	CParam *CLK_CHECK_FREQ_SLOW = StsGetParam(funcindex, "CLK_CHECK_FREQ_SLOW");
	CParam *CLK_CHECK_FREQ_FAST = StsGetParam(funcindex, "CLK_CHECK_FREQ_FAST");
	
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	int use_DCM = false;
	double minfreq[SITE_NUM] = { 999999 };
	double maxfreq[SITE_NUM] = { 0 };
	double avgfreq[SITE_NUM] = { 0 };
	double freq_res[SITE_NUM] = { 0 };
	double carrfreq[SITE_NUM] = { 0 };
	string EE_str;
	ULONG uotpcode;
	ULONG muotpcode[SITE_NUM];
	ULONG data0 = 0x0000;
	if (DEBUG)
	{
		if (use_DCM)
			cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K26_FOUT_DCM, K54_VDDIO_PU, K58_DBG_PU, K57_FS0B_PSYNC_PU, -1);
		else
			cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K70_FOUT_TMUA, K54_VDDIO_PU, K59_WAKE12_PU,/*K58_DBG_PU, */K57_FS0B_PSYNC_PU,/* K32_INTB_FXVIA, K110_FXVI3_9_A, K56_INTB_PU,*/ -1);
		SPIInitial(4.0, 0, 2.0, 1.9, 200);
		delay_ms(1);
		VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
		VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

		delay_ms(15);
		Enter_MAIN_TM_DIG();
		Enter_FS_TM_DIG();

	}
	else
	{
		A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
		if (use_DCM)
			cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K26_FOUT_DCM, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, -1);
		else
			cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K70_FOUT_TMUA, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, -1);

		delay_ms(1);
		Enter_M_TM(0x0000, 0x0000, 0x0000);
		SPIWrite(0x3F, 0x7401);//switch to main register
	}
//	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	// use DCM/QTMU
	SPIWrite(0x05, 0x3800);//MUX0111
	SPIWrite(0x3F, 0x7481);//switch to main otp
			delay_ms(1);
	if(SC6295X[find_ID].useropt_burn==1)
	{
	
		for (int addr = 0; addr < 10; ++addr)
		{
			EE_str = "MUBANK" + to_string(addr);
			SERIAL uotpcode=dut.assy(EE_str.c_str()).get_start(SITE);
			if(addr==7) 
			{
	/*			SERIAL_ALL
				{
					if(m_burn_flag[SITE]==true)
						muotpcode[SITE]=uotpcode&0xF0FF;
					else
						muotpcode[SITE]=uotpcode;
				}
				SPIWrite(0x00+addr, muotpcode);*/
				SPIWrite(0x00+addr, uotpcode&0xF0FF);
			}
			else
				SPIWrite(0x00+addr, uotpcode);

		}
		

	}


	if (use_DCM)
	{
		dcm.Connect("FOUT_INTB");
		dcm.SetPinLevel("FOUT_INTB", 2.0, 1.9, 2.0, 1.9);
		dcm.SetTMUMatrix("FOUT_INTB", DCM_ALLSITE, DCM_TMU1);
		dcm.SetTMUParam("FOUT_INTB", DCM_ALLSITE, DCM_POS, 0, 0);
	

		dut.trim("CLK1_FSW").execute(measure_CLK1_FSW_DCM, spec, funcindex, funclabel, 1e-3, treg_log_mode, "CLK1_FSW");

	}
	else
	{
		ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
		ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
		ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		dut.trim("CLK1_FSW").execute(measure_CLK1_FSW_QTMU, spec, funcindex, funclabel, 1e-3, treg_log_mode, "CLK1_FSW");

	}
	if (use_DCM)
		measure_DUTY_DCM(results);
	else
	{
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		measure_DUTY_QTMU(results, freq_res);
	}	
	
	SERIAL{

		OSC_MAIN_DUTY->SetTestResult(SITE, 0, results[SITE]);//%
		OSC_MAIN_FREQ->SetTestResult(SITE, 0, freq_res[SITE]);
	}

	SPIWrite(0x3F, 0x7401);//switch to main register
	SPIWrite(0x05, 0x0800);//VPRE
	delay_us(50);
	if (use_DCM)
		measure_DUTY_DCM(results);
	else
	{
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		measure_DUTY_QTMU(results, freq_res);
	}
		
	SERIAL{

		VPRE_CLK_DUTY->SetTestResult(SITE, 0, results[SITE]);
		VPRE_CLK_FREQ->SetTestResult(SITE, 0, freq_res[SITE]);
	}
	SPIWrite(0x3F, 0x7481);
	SPIWrite(0x00, 0x2000);//freq to 2.2Mhz

	delay_us(50);
	if (use_DCM)
		measure_DUTY_DCM(results);
	else
	{
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		measure_DUTY_QTMU(results, freq_res);
	}
	SERIAL{

		VPRE_CLK_DUTY_0x1->SetTestResult(SITE, 0, results[SITE]);
		VPRE_CLK_FREQ_0x1->SetTestResult(SITE, 0, freq_res[SITE]);
	}


	SPIWrite(0x00, data0);//freq to 2.2Mhz
	SPIWrite(0x3F, 0x7401);//switch to main register
	SPIWrite(0x05, 0x1000);//BOOST
	delay_us(50);
	if (use_DCM)
		measure_DUTY_DCM(results);
	else
	{
	/*	ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
		ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 20);
		ALL_QTMU.Connect(QTMUe_RELAY_CHA);*/
		measure_DUTY_QTMU(results, freq_res);
	}
	SERIAL{

		BOOST_CLK_DUTY->SetTestResult(SITE, 0, results[SITE]);
		BOOST_CLK_FREQ->SetTestResult(SITE, 0, freq_res[SITE]);
	}

	SPIWrite(0x05, 0x1800);//BUCK1
	delay_us(50);
	if (use_DCM)
		measure_DUTY_DCM(results);
	else
	{
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		measure_DUTY_QTMU(results, freq_res);
	}
	SERIAL{

		BUCK1_CLK_DUTY->SetTestResult(SITE, 0, results[SITE]);
		BUCK1_CLK_FREQ->SetTestResult(SITE, 0, freq_res[SITE]);
	}

	SPIWrite(0x05, 0x2000);//BUCK2
	delay_us(50);
	if (use_DCM)
		measure_DUTY_DCM(results);
	else
	{
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		measure_DUTY_QTMU(results, freq_res);
	}
	SERIAL{

		BUCK2_CLK_DUTY->SetTestResult(SITE, 0, results[SITE]);
		BUCK2_CLK_FREQ->SetTestResult(SITE, 0, freq_res[SITE]);
	}

   ULONG rdata[SITE_NUM];

	SPIWrite(0x05, 0x2800);//BUCK3
	delay_us(50);

	SPIRead(0x05, rdata);//BUCK3

	if (use_DCM)
		measure_DUTY_DCM(results);
	else
	{

		measure_DUTY_QTMU(results, freq_res);
	}
	SERIAL{

		BUCK3_CLK_DUTY->SetTestResult(SITE, 0, results[SITE]);
		BUCK3_CLK_FREQ->SetTestResult(SITE, 0, freq_res[SITE]);
	}



	SPIWrite(0x05, 0x3800);

	VSUP_11.Set(FV, 4.5, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);//OTP_VSUP_CFG=0

	delay_ms(2);
	if (use_DCM)
		measure_CLK1_FSW_DCM(NULL, TREG_MEASURE_NONE, results);
	else
		measure_CLK1_FSW_QTMU(NULL, TREG_MEASURE_NONE, results);

	SERIAL{

		CLK1_FSW_VSUP4p5V->SetTestResult(SITE, 0, results[SITE]*1e-3);
	}
	VSUP_11.Set(FV, 36.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_ms(2);
	if (use_DCM)
		measure_CLK1_FSW_DCM(NULL, TREG_MEASURE_NONE, results);
	else
		measure_CLK1_FSW_QTMU(NULL, TREG_MEASURE_NONE, results);

	SERIAL{
	
		CLK1_FSW_VSUP36V->SetTestResult(SITE, 0, results[SITE] * 1e-3);
	}
		//CLK TUNE, from 0000 to1100;max0100, min 1001
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_ms(1);
	SPIWrite(0x3F, 0x7401);//switch to main register
	SPIWrite(0x05, 0x3814);
	if (use_DCM)
		measure_CLK1_FSW_DCM(NULL, TREG_MEASURE_NONE, results);
	else
		measure_CLK1_FSW_QTMU(NULL, TREG_MEASURE_NONE, results);

	SERIAL{

		CLK1_FSW_TUNE_0x04->SetTestResult(SITE, 0, results[SITE] * 1e-3);
		CLK1_FSW_TUNE_0x04_PCT->SetTestResult(SITE, 0, (g_freq_20MHz[SITE] / 48.0 - results[SITE]) /(1e-30+ g_freq_20MHz[SITE]/48.0) *100);
	
	}
	SPIWrite(0x05, 0x3819);
	if (use_DCM)
		measure_CLK1_FSW_DCM(NULL, TREG_MEASURE_NONE, results);
	else
		measure_CLK1_FSW_QTMU(NULL, TREG_MEASURE_NONE, results);

	SERIAL{

		CLK1_FSW_TUNE_0x09->SetTestResult(SITE, 0, results[SITE] * 1e-3);
		CLK1_FSW_TUNE_0x09_PCT->SetTestResult(SITE, 0, (g_freq_20MHz[SITE] / 48.0 - results[SITE]) / (1e-30 + g_freq_20MHz[SITE] / 48.0) * 100);

	}

	//delay_ms(2);
	SPIWrite(0x3F, 0x7401);//switch to main register
	SPIWrite(0x05, 0x0810);//FOUT_MUX_SEL 0111 MO_EN=1
	SPIWrite(0x3F, 0x7481);//switch to main otp
	

	
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);

	if (use_DCM)
	{

		dut.trim("SPSP").execute(measure_SPSP_DCM, spec, funcindex, funclabel, 1, treg_log_mode, "SPSP");

	}
	else
	{

		dut.trim("SPSP").execute(measure_SPSP_QTMU, spec, funcindex, funclabel, 1, treg_log_mode, "SPSP");

	}
	ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 20);
	ALL_QTMU.Connect(QTMUe_RELAY_CHA);
	spsp_freq_test(minfreq, maxfreq, avgfreq,carrfreq);
	SERIAL{

		SPSP_FREQ_MIN->SetTestResult(SITE, 0, minfreq[SITE]);
		SPSP_FREQ_MAX->SetTestResult(SITE, 0, maxfreq[SITE]);
		SPSP_FREQ_AVG->SetTestResult(SITE, 0, avgfreq[SITE]);
		SPSP_CARR_23K->SetTestResult(SITE, 0, carrfreq[SITE]);
		SPSP_FREQ_RANGE1->SetTestResult(SITE, 0,(avgfreq[SITE]- minfreq[SITE])/(avgfreq[SITE]+1e-30)*100);
		SPSP_FREQ_RANGE2->SetTestResult(SITE, 0, (avgfreq[SITE]- maxfreq[SITE])/(avgfreq[SITE]+1e-30)*100);
	}
	VSUP_11.Set(FV, 4.5, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);//OTP_VSUP_CFG=0

	delay_ms(2);
	if (use_DCM)
		measure_SPSP_DCM(NULL, TREG_MEASURE_NONE, results);
	else
		measure_SPSP_QTMU(NULL, TREG_MEASURE_NONE, results);

	SERIAL{

		SPSP_VSUP4p5V->SetTestResult(SITE, 0, results[SITE]);
	}
	VSUP_11.Set(FV, 36.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_ms(2);
	if (use_DCM)
		measure_SPSP_DCM(NULL, TREG_MEASURE_NONE, results);
	else
		measure_SPSP_QTMU(NULL, TREG_MEASURE_NONE, results);

	SERIAL{

		SPSP_VSUP36V->SetTestResult(SITE, 0, results[SITE]);
	}
	if (use_DCM)
	{
		cbite.SetCbiteOff(K26_FOUT_DCM);
		cbite.SetCbiteOn(K70_FOUT_TMUA);
	}



	//modconf=1
	SPIWrite(0x3F, 0x7401);//switch to main register

	SPIWrite(0x05, 0x8810);//FOUT_MUX_SEL 0111 MO_EN=1,mod_confg=1
	SPIWrite(0x3F, 0x7481);//switch to main otp
	ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 50);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 50);
	ALL_QTMU.Connect(QTMUe_RELAY_CHA);
	spsp_freq_test(minfreq, maxfreq, avgfreq,carrfreq);

	SERIAL{

		SPSP_FREQ_95kHZ_MIN->SetTestResult(SITE, 0, minfreq[SITE]);
		SPSP_FREQ_95kHZ_MAX->SetTestResult(SITE, 0, maxfreq[SITE]);
		SPSP_FREQ_95kHZ_AVG->SetTestResult(SITE, 0, avgfreq[SITE]);
		SPSP_CARR_95K->SetTestResult(SITE, 0, carrfreq[SITE]);
		SPSP_FREQ_95K_RANGE1->SetTestResult(SITE, 0,(avgfreq[SITE]- minfreq[SITE])/(avgfreq[SITE]+1e-30)*100);
		SPSP_FREQ_95K_RANGE2->SetTestResult(SITE, 0, (avgfreq[SITE]- maxfreq[SITE])/(avgfreq[SITE]+1e-30)*100);
	}

	if (use_DCM)
	{
		cbite.SetCbiteOn(K26_FOUT_DCM);
		cbite.SetCbiteOff(K70_FOUT_TMUA);
	}

	SPIWrite(0x3F, 0x7401);//switch to main register
//	SPIWrite(0x04, 0x0013);//switch bg to AMUX
	SPIWrite(0x05, 0x4000);//FOUT_MUX_SEL 0111 MO_EN=1,mod_confg=1
	SPIWrite(0x3F, 0x7481);//switch to main otp

	//Enter_M_TM(0x0000, 0x0000, 0x0000);
	SPIWrite(0x7F, 0x7481);//switch to main otp

	//Enter_FS_TM(0x0000);
	ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
	ALL_QTMU.Connect(QTMUe_RELAY_CHA);

	dut.trim("FS_CLK").execute(measure_FS_CLK_QTMU, spec, funcindex, funclabel, 1e-3, treg_log_mode, "FS_CLK");

	SPIWrite(0x05, 0x4000);//OSCFS
	delay_us(50);
	if (use_DCM)
		measure_DUTY_DCM(results);
	else
	{
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 20);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		measure_DUTY_QTMU(results, freq_res);
	}
	SERIAL{

		FS_CLK_DUTY->SetTestResult(SITE, 0, results[SITE]);
		FS_CLK_FREQ->SetTestResult(SITE, 0, freq_res[SITE]);
	}

	////CLK Checker
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	delay_ms(100);
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K18_FIN_DCM, K31_INTB_DCM, K58_DBG_PU, /*K56_INTB_PU,*/ K54_VDDIO_PU, /*K59_WAKE12_PU,*/ K57_FS0B_PSYNC_PU, -1);

	delay_ms(1);

	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	delay_ms(1);
	cbite.SetCbiteOn(K59_WAKE12_PU);
	delay_ms(5);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	
	//SPIWrite(0x3F, 0x7401);//switch to main register
	//SPIWrite(0x05, data0);//exit related register setting

	delay_us(50);
	
	Enter_M_TM(0x01C1, 0x0000, 0x0000);//enter tm,dmux=1
	//SPIWrite(0x01, 0x0180);//exit related register setting
	//SPIWrite(0x51, 0x0002);//exit related register setting
	SPIWrite(0x3F, 0x7481);//switch to main register
	dcm.Connect("CLK_CHK_G");
	dcm.SetPinLevel("CLK_CHK_G", 4.0, 0, 2.0, 1.9);
	//
	//dut.trim("CLK_CHECK").execute(measure_CLK_CHECK, spec, funcindex, funclabel, 1e-3, treg_log_mode, "CLK_CHECK");
	//SERIAL{

	//	CLK_CHECK_FREQ_SLOW->SetTestResult(SITE, 0, g_freq_slow[SITE]);
	//	CLK_CHECK_FREQ_FAST->SetTestResult(SITE, 0, g_freq_fast[SITE]);
	//}
	Enter_M_TM(0x0000, 0x0000, 0x0000);//enter tm

	//
	//VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	//VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	//delay_ms(10);
	//cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K72_PGOOD_DBUFF, K79_PGOOD_PU, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, -1);

	//delay_ms(1);
	//VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	//VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	//delay_ms(3);
	//Enter_MAIN_TM_DIG();
	//Enter_FS_TM_DIG();
	////FS FREQ

	//delay_ms(1);

	//SPIWrite(0x7F, 0x7481);//switch to fs otp
	//Enter_FS_TM(0x0034);
	//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
	//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
	//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 20);
	//ALL_QTMU.Connect(QTMUe_RELAY_CHA);
	//dut.trim("FS_CLK").execute(measure_FS_CLK_QTMU, spec, funcindex, funclabel, 1, treg_log_mode, "FS_CLK");
	//
	if (1)
	{
		VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
		VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
		dcm.Disconnect("CLK_CHK_G");
		delay_ms(3);//for cap discharge
		power_off(DEBUG);
	}

	efmea.fmea_checking(funcindex);
	return 0;
}
DUT_API int T13_VPRE_trim(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam *VPRE_VREF01 = StsGetParam(funcindex, "VPRE_VREF01");
	CParam *VPRE_VREF10 = StsGetParam(funcindex, "VPRE_VREF10");
	CParam *VPRE_VREF11 = StsGetParam(funcindex, "VPRE_VREF11");

	CParam *VPRE_VOUT01 = StsGetParam(funcindex, "VPRE_VOUT01");
	CParam *VPRE_VOUT10 = StsGetParam(funcindex, "VPRE_VOUT10");
	CParam *VPRE_VOUT11 = StsGetParam(funcindex, "VPRE_VOUT11");

	CParam *VPRE_IPK01 = StsGetParam(funcindex, "VPRE_IPK01");
	CParam *VPRE_IPK10 = StsGetParam(funcindex, "VPRE_IPK10");
	CParam *VPRE_IPK11 = StsGetParam(funcindex, "VPRE_IPK11");

	CParam *VPRE_IVY_MAX01 = StsGetParam(funcindex, "VPRE_IVY_MAX01");
	CParam *VPRE_IVY_MAX10 = StsGetParam(funcindex, "VPRE_IVY_MAX10");
	CParam *VPRE_IVY_MAX11 = StsGetParam(funcindex, "VPRE_IVY_MAX11");

	CParam *VPRE_SC001 = StsGetParam(funcindex, "VPRE_SC001");
	CParam *VPRE_SC010 = StsGetParam(funcindex, "VPRE_SC010");
	CParam *VPRE_SC011 = StsGetParam(funcindex, "VPRE_SC011");
	CParam *VPRE_SC100 = StsGetParam(funcindex, "VPRE_SC100");
	CParam *VPRE_SC101 = StsGetParam(funcindex, "VPRE_SC101");
	CParam *VPRE_SC110 = StsGetParam(funcindex, "VPRE_SC110");
	CParam *VPRE_SC111 = StsGetParam(funcindex, "VPRE_SC111");


	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res_r[SITE_NUM];
	ULONG m_reg_data1[4][SITE_NUM];
	ULONG rdata[SITE_NUM];
	cbite.SetOn(K24_VDDIO_ACM, K58_DBG_PU,K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, K80_PRECSP_PREFB_SHRT, K84_PRECOMP_CAP, K46_PREFB_ACM, - 1);

	delay_ms(1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(4);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	//SPIWrite(0x23, 0x5555);//read main register
	//SPIWrite(0x24, 0xAAAA);
	//SPIRead(0x23, m_reg_data1, 4);//read main register
	SPIWrite(0x04, 0x0013);
	SPIWrite(0x3F, 0x7481);//switch to main otp
	//PREFB_BUCK1FB_8.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	Enter_M_TM(0x0003, 0x0004, 0x0000); 
	OTP_M_Preview(0,2);
	dut.trim("VPRE_VREF").execute(measure_VPRE_VREF, spec, funcindex, funclabel, 1, treg_log_mode, "VPRE_VREF");
	//dut.trim("VPRE_VREF").set_working(0);
	SPIWrite(0x00, 0x4000);//633mV
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		VPRE_VREF01->SetTestResult(SITE, 0, results[SITE] );
	}

	SPIWrite(0x00, 0x8000);//683mV
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		VPRE_VREF10->SetTestResult(SITE, 0, results[SITE] );
	}
	SPIWrite(0x00, 0xC000);//833mV
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		VPRE_VREF11->SetTestResult(SITE, 0, results[SITE] );
	}
	ULONG data0 = 0x0000;
	SPIWrite(0x00, data0);

	//VPRE_EA_OFFSET
	cbite.SetOn(K24_VDDIO_ACM, K58_DBG_PU, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K32_INTB_FXVIA, K110_FXVI3_9_A, K46_PREFB_ACM, K63_CSP_FB_FPVIHL, K_FPVIH_A, K_FPVIL_A,K56_INTB_PU, /*K84_PRECOMP_CAP, */-1);
	delay_ms(1);
	Enter_M_TM(0x0003, 0x0010, 0x0000);
	OTP_M_Preview(0,3);
	SPIWrite(0x3F, 0x7401);
	//SPIWrite(0x02, 0x8000);
	
	SPIWrite(0x3F, 0x7481);
	FPVIM.Set(FV,0.02,FPVIe_100MV,FPVIe_10MA,FPVIe_RELAY_ON);//prefb l, csp h
	PREFB_BUCK1FB_8.Set(FV, 3.15, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	//will change to binary search
	dut.trim("VPRE_EA_OFFSET").execute(measure_VPRE_EA_OFFSET, spec, funcindex, funclabel, 1.0, treg_log_mode, "VPRE_EA_OFFSET");

	SPIWrite(0x00, 0x4000);//3.8V
	PREFB_BUCK1FB_8.Set(FV, 3.6, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//make sure search range greater than limit
	vth_binary_search(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA,3.6, 4.0, 3.6, 9, res_r, 1500, 0, TRIG_FALLING);

//	awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "VPRE_EA_OS01", 3.76, 3.84, 0.0005, 500, 2.0, TRIG_FALLING, res_r);
	SERIAL
	{
		
		VPRE_VOUT01->SetTestResult(SITE, 0, res_r[SITE]);
	}
	SPIWrite(0x00, 0x8000);//4.1V
	PREFB_BUCK1FB_8.Set(FV, 3.95, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	vth_binary_search(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA,3.95, 4.25, 3.95, 9, res_r, 1500, 0, TRIG_FALLING);

//	awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "VPRE_EA_OS10", 4.06, 4.14, 0.0005, 500, 2.0, TRIG_FALLING, res_r);
	SERIAL
	{

		VPRE_VOUT10->SetTestResult(SITE, 0, res_r[SITE]);
	}
	SPIWrite(0x00, 0xC000);//5.0V
	PREFB_BUCK1FB_8.Set(FV, 4.96, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	vth_binary_search(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA,4.85, 5.15, 4.85, 9, res_r, 1500, 0, TRIG_FALLING);

//	awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "VPRE_EA_OS11", 4.96, 5.04, 0.0005, 500, 2.0, TRIG_FALLING, res_r);
	SERIAL
	{

		VPRE_VOUT11->SetTestResult(SITE, 0, res_r[SITE]);
	}
	SPIWrite(0x00, data0);
	
	
	cbite.SetCbiteOn(K84_PRECOMP_CAP);
	//gm VPRE
	cbite.SetCbiteOn(K38_PRECOMP_ACM);
	cbite.SetCbiteOn(K80_PRECSP_PREFB_SHRT);
	delay_ms(1);
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FV, 0.0, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	//option, not a trim item
	//dut.trim("VPRE_EA_IOUT").execute(measure_VPRE_EA_IOUT, spec, funcindex, funclabel, 1e3, treg_log_mode, "VPRE_EA_IOUT");

	//VPRE_PK_LIM
	cbite.SetCbiteOff(K80_PRECSP_PREFB_SHRT);
	delay_ms(1);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);//close to vbos voltage
	FPVIM.Set(FV, 0.02, FPVIe_100MV, FPVIe_100UA, FPVIe_RELAY_ON);
	SPIWrite(0x00, 0x0300);
	//50mV
	dut.trim("VPRE_IPK").execute(measure_VPRE_IPK, spec, funcindex, funclabel, 1e3, treg_log_mode, "VPRE_IPK");
	
	SPIWrite(0x00, 0x0100);
	FPVIM.Set(FV, 0.02, FPVIe_1V, FPVIe_100UA, FPVIe_RELAY_ON);
	awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_100UA, "VPRE_IPK01", 0.02, 0.128, 0.0004, 50, 2.0, TRIG_FALLING, res_r);
	SERIAL
	{
		VPRE_IPK01->SetTestResult(SITE, 0, res_r[SITE]*1e3);
	}
	SPIWrite(0x00, 0x0200);
	FPVIM.Set(FV, 0.048, FPVIe_1V, FPVIe_100UA, FPVIe_RELAY_ON);
	awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_100UA, "VPRE_IPK10", 0.048, 0.192, 0.0006, 50, 2.0, TRIG_FALLING, res_r);
	SERIAL
	{
		VPRE_IPK10->SetTestResult(SITE, 0, res_r[SITE] * 1e3);
	}
	SPIWrite(0x00, data0);
	//SPIWrite(0x00, data0);
	FPVIM.Set(FV, 0.02, FPVIe_1V, FPVIe_100UA, FPVIe_RELAY_ON);
	awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_100UA, "VPRE_IPK11", 0.02, 0.12, 0.0003, 50, 2.0, TRIG_FALLING, res_r);
	SERIAL
	{
		VPRE_IPK11->SetTestResult(SITE, 0, res_r[SITE] * 1e3);
	}
	SPIWrite(0x00, data0);

	//VPRE valley current 
	Enter_M_TM(0x0003, 0x0014, 0x0000);
	//Valley MIN
	FPVIM.Set(FV, 0.0, FPVIe_100MV, FPVIe_100UA, FPVIe_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);

	dut.trim("VPRE_IVY_MIN").execute(measure_VPRE_IVY_MIN, spec, funcindex, funclabel, 1e3, treg_log_mode, "VPRE_IVY_MIN");
	
	//Valley MAX
	PRECMP_BUCK3FB_INTB_10.Set(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	FPVIM.Set(FV, 0.08, FPVIe_100MV, FPVIe_100UA, FPVIe_RELAY_ON);
	
	dut.trim("VPRE_IVY_MAX").execute(measure_VPRE_IVY_MAX, spec, funcindex, funclabel, 1e3, treg_log_mode, "VPRE_IVY_MAX",1);

	SPIWrite(0x00, 0x0100);
	FPVIM.Set(FV, 0.128, FPVIe_1V, FPVIe_100UA, FPVIe_RELAY_ON);
	awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_100UA, "VPRE_IVY_MAX01", 0.128, 0.032, 0.0008, 50, 2.0, TRIG_FALLING, res_r);
	SERIAL
	{
		VPRE_IVY_MAX01->SetTestResult(SITE, 0, res_r[SITE]*1e3);
	}
	SPIWrite(0x00, 0x0200);
	FPVIM.Set(FV, 0.048, FPVIe_1V, FPVIe_100UA, FPVIe_RELAY_ON);
	awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_100UA, "VPRE_IVY_MAX10", 0.192, 0.048, 0.0012, 50, 2.0, TRIG_FALLING, res_r);
	SERIAL
	{
		VPRE_IVY_MAX10->SetTestResult(SITE, 0, res_r[SITE] * 1e3);
	}
	SPIWrite(0x00, 0x0300);
	FPVIM.Set(FV, 0.06, FPVIe_1V, FPVIe_100UA, FPVIe_RELAY_ON);
	awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_100UA, "VPRE_IVY_MAX11", 0.24, 0.06, 0.0015, 50, 2.0, TRIG_FALLING, res_r);
	SERIAL
	{
		VPRE_IVY_MAX11->SetTestResult(SITE, 0, res_r[SITE] * 1e3);
	}
	SPIWrite(0x00, data0);
	//NEG ILMT
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	cbite.SetCbiteOff(K38_PRECOMP_ACM);
	Enter_M_TM(0x0003, 0x0018, 0x0000);
	FPVIM.Set(FV, -0.025, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_ON);

	dut.trim("VPRE_INEG").execute(measure_VPRE_INEG, spec, funcindex, funclabel, 1e3, treg_log_mode, "VPRE_INEG");

	//VPRE_SLOPE compensation
	FPVIM.Set(FV, 0.02, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_ON);
	Enter_M_TM(0x0003, 0x0024, 0x0000);
	//SPIWrite(0x3F, 0x7481);//switch to main otp
	//SPIWrite(0x00, 0x0300);
	cbite.SetCbiteOn(K38_PRECOMP_ACM);
	//cbite.SetCbiteOff(K56_INTB_PU);
	//A3_INTB.Set(FV, 1, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.6, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);


	//dut.trim("VPRE_SC").execute(measure_VPRE_SC, spec, funcindex, funclabel, 1e3, treg_log_mode, "VPRE_SC");
	dut.trim("VPRE_SC").set_working(0);
	OTP_M_Preview(3);
	//need to check the search range with different option
	SPIWrite(0x3F, 0x7481);//switch to main otp
	SPIWrite(0x00, 0x0400);//70
	SPIRead(0x00, rdata);
	measure_VPRE_SC_OPT1(0.1, 0, results);
	SERIAL
	{
		VPRE_SC001->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x00, 0x0800);//95
	measure_VPRE_SC_OPT1(0.1, 0, results);
	SERIAL
	{
		VPRE_SC010->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x00, 0x0C00);//110
	measure_VPRE_SC_OPT(0.6, 1.6, results);
	SERIAL
	{
		VPRE_SC011->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x00, 0x1000);//150
	measure_VPRE_SC_OPT(0.6, 1.8, results);
	SERIAL
	{
		VPRE_SC100->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x00, 0x1400);//190
	measure_VPRE_SC_OPT(0.6, 2.0, results);
	SERIAL
	{
		VPRE_SC101->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x00, 0x1800);//300
	measure_VPRE_SC_OPT(0.6, 2.0, results);
	SERIAL
	{
		VPRE_SC110->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x00, 0x1C00);//430
	measure_VPRE_SC_OPT(0.6, 2.6, results);
	SERIAL
	{
		VPRE_SC111->SetTestResult(SITE, 0, results[SITE]);
	}
	PREFB_BUCK1FB_8.Set(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	delay_ms(5);//for cap discharge
	FPVIM.Set(FV, 0.0, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_OFF);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	A5_AMUX.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	PREFB_BUCK1FB_8.TSet(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	STSTArming();
	efmea.fmea_checking(funcindex);
	return 0;
}
DUT_API int T15_VBOOST_trim(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam *BOOST_VREF01 = StsGetParam(funcindex, "BOOST_VREF01");
	CParam *BOOST_VREF10 = StsGetParam(funcindex, "BOOST_VREF10");
	CParam* BOOST_LSRON = StsGetParam(funcindex, "BOOST_LSRON");
	CParam* BOOST_3A = StsGetParam(funcindex, "BOOST_3A");
	CParam *BOOST_IPK = StsGetParam(funcindex, "BOOST_IPK");
	CParam *BOOST_DRV_DIDT_OPT0 = StsGetParam(funcindex, "BOOST_DRV_DIDT_OPT0");
	CParam *BOOST_VREF_SKIP = StsGetParam(funcindex, "BOOST_VREF_SKIP");
	CParam *BOOST_5p75V = StsGetParam(funcindex, "BOOST_5p75V");
	CParam *BOOST_6V = StsGetParam(funcindex, "BOOST_6V");
	

	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res_r[SITE_NUM];
	ULONG data0=0x0000;
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K50_VBOOST_FXVIB, K109_FXVI2_8_B,K80_PRECSP_PREFB_SHRT, K84_PRECOMP_CAP, K46_PREFB_ACM,K32_INTB_FXVIA, K110_FXVI3_9_A, K56_INTB_PU,-1);

	delay_ms(1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	SPIWrite(0x04, 0x0013);
	B2_PREBOOT_VBOOST.Set(FV, 3.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	//PREFB for 3.3V
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	SPIWrite(0x3F, 0x7481);//switch to main otp
	//bit26-22
	//0000 0xxx xx00 0000=>0x31
	Enter_M_TM(0x0004, 0x0040, 0x0000);
	OTP_M_Preview(0,5);
	//No need force 3.3V, will check it
	SPIWrite(0x01, data0);
	delay_ms(1);
	dut.trim("BOOST_VREF").execute(measure_BOOST_VREF, spec, funcindex, funclabel, 1.0, treg_log_mode, "BOOST_VREF");
	SPIWrite(0x01, 0x2000);//0.71875V
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BOOST_VREF01->SetTestResult(SITE, 0, results[SITE] );
	}

	SPIWrite(0x01, 0x4000);//0.75
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BOOST_VREF10->SetTestResult(SITE, 0, results[SITE] );
	}

//	ULONG data0 = 0x0000;
	SPIWrite(0x01, data0);

	//BOOST_EA_OFFSET

	//Enter_M_TM(0x0004, 0x00C0, 0x0000);
	Enter_M_TM(0x0004, 0x0080, 0x0000);
	B2_PREBOOT_VBOOST.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
		A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	dut.trim("BOOST_EA_OFFSET").execute(measure_BOOST_EA_OFFSET, spec, funcindex, funclabel, 1.0, treg_log_mode, "BOOST_EA_OFFSET");

	SPIWrite(0x01, 0x2000);//0.71875V

	vth_binary_search(B2_PREBOOT_VBOOST,A3_INTB,FXVIe_PLUS_10V,FXVIe_PLUS_100MA,5.55,5.95,5.55,8,results,100,0,TRIG_RISING);

	SERIAL
	{
		
		BOOST_5p75V->SetTestResult(SITE, 0, results[SITE] );
	}

	SPIWrite(0x01, 0x4000);//0.75
	
	vth_binary_search(B2_PREBOOT_VBOOST,A3_INTB,FXVIe_PLUS_10V,FXVIe_PLUS_100MA,5.8,6.2,5.8,8,results,100,0,TRIG_RISING);
	SERIAL
	{
	
		BOOST_6V->SetTestResult(SITE, 0, results[SITE] );
	}
	SPIWrite(0x01, data0);

	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, K46_PREFB_ACM,
		K50_VBOOST_FXVIB, K109_FXVI2_8_B, K80_PRECSP_PREFB_SHRT, K84_PRECOMP_CAP, K21_PADF_AGNDF, K32_INTB_FXVIA, K110_FXVI3_9_A, K56_INTB_PU,
		K64_PGND_FPVIH, K68_BOOSTLS_FPVIL, K_FPVIH_A, K_FPVIL_A, K17_FIN_FXVIA, K104_FXVI0_6_A ,- 1);

	delay_ms(1);

	Enter_M_TM(0x0004, 0x01C0, 0x0000);
	
	measure_RON(FPVIM, g_rdson_boost, "RDSON_BOOSTLS_PGND");
	FPVIM.Set(FV, 0, FPVIe_100MV, FPVIe_100MA, FPVIe_RELAY_ON);
	SERIAL
	{
		BOOST_LSRON->SetTestResult(SITE, 0, g_rdson_boost[SITE]);
		g_rdson_boost[SITE] = g_rdson_boost[SITE] - 24;//remove bonding wire for current limit test
	}

	Enter_M_TM(0x0004, 0x0200, 0x0000);
	B2_PREBOOT_VBOOST.Set(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	dut.trim("BOOST_CLAMPMAX").execute(measure_BOOST_CLAMPMAX, spec, funcindex, funclabel, 1.0, treg_log_mode, "BOOST_CLAMPMAX");
	
	SPIWrite(0x01, 0x0400);
	FPVIM.Set(FV, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	awg.rampv(FPVIM, A3_INTB, FPVIe_1V, FPVIe_100MA, "BOOST_CLAMPMAX", 0, -0.4, 0.001, 50, 2.0, TRIG_FALLING, res_r);

	SERIAL 
	{
	
		results[SITE] = -res_r[SITE] / g_rdson_boost[SITE]*1e3;//A
		BOOST_3A->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x01, data0);

	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	//design bug, wrong connect
	//delay_ms(3);
	//A0_FIN_DBG_ERR_FCCU1.MeasureVI(30,10);//80uA
	//SERIAL
	//{
	//	res_r[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE,MIRET);
	//	BOOST_IPK->SetTestResult(SITE, 0, -res_r[SITE]*10*1e6);//scale to uA

	//	g_rsns_boost[SITE] = g_rsns_v_boost[SITE] / res_r[SITE];//ohm
	//}

	B2_PREBOOT_VBOOST.Set(FV, 6.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	
	//A3_INTB.Set(FV, 0.5, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	dut.trim("BOOST_CLAMPMIN").execute(measure_BOOST_CLAMPMIN, spec, funcindex, funclabel, 1.0, treg_log_mode, "BOOST_CLAMPMIN");
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	//psm_ctrl, only test default, can add all if need trimming
	Enter_M_TM(0x0004, 0x0340, 0x0000);
	B2_PREBOOT_VBOOST.Set(FV, 7.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	A0_FIN_DBG_ERR_FCCU1.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	awg.rampi(A0_FIN_DBG_ERR_FCCU1, A3_INTB, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, "BOOST_DRV_DIDT_OPT0", 0, -20e-6, 0.1e-6, 20,2.0, TRIG_FALLING, res_r);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		BOOST_DRV_DIDT_OPT0->SetTestResult(SITE, 0, res_r[SITE]*1e6);
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BOOST_VREF_SKIP->SetTestResult(SITE, 0, results[SITE]);
	}

	//BOOST SLP=> will check if test needed
	B2_PREBOOT_VBOOST.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A0_FIN_DBG_ERR_FCCU1.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	cbitopen(K32_INTB_FXVIA);
	delay_ms(1);
	//Enter_M_TM(0x0004, 0x0000, 0x0000);
	Enter_M_TM(0x0004, 0x0180, 0x0000);
	//A3_INTB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	//cbite.SetCbiteOff(K32_INTB_FXVIA);
	
	//if (0)
	//{ 
	//	cbite.SetCbiteOn(K31_INTB_DCM);
	//	dcm.InitMCU("FOUT_INTB");
	//	dcm.Connect("FOUT_INTB");
	//	dcm.SetDynamicLoad("FOUT_INTB", true, 0.015, 0.015, 3.5);
	//}
	cbite.SetCbiteOn(K69_INTB_DBUFF);

	//cbite.SetCbiteOn(K56_INTB_PU);
	delay_ms(1);
	ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 0.6, QTMUe_FILTER_10MHz, 50);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.0, QTMUe_FILTER_10MHz, 10);
	ALL_QTMU.Connect(QTMUe_RELAY_CHA);


	dut.trim("BOOST_ISLP").execute(measure_BOOST_ISLP, spec, funcindex, funclabel, 1.0, treg_log_mode, "BOOST_ISLP");
	dut.trim("BOOST_ISLP").set_working(0);
	OTP_M_Preview(5,2);
	dcm.Disconnect("FOUT_INTB");
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(5);//for cap discharge

	A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);//wake12 connect to vddio.

	efmea.fmea_checking(funcindex);
	return 0;
}
DUT_API int T17_LDO12_trim(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam *LDO1_1p1V_000 = StsGetParam(funcindex, "LDO1_1p1V_000");
	CParam *LDO1_1p2V_001 = StsGetParam(funcindex, "LDO1_1p2V_001");
	CParam* LDO1_1p3V_001 = StsGetParam(funcindex, "LDO1_1p3V_001");
	CParam *LDO1IN_LEAK = StsGetParam(funcindex, "LDO1IN_LEAK");
	CParam* LDO1_1p2V_001_I0 = StsGetParam(funcindex, "LDO1_1p2V_001_I0");
	CParam* LDO1_1p3V_001_I0 = StsGetParam(funcindex, "LDO1_1p3V_001_I0");
	CParam *LDO1_1p6V_010 = StsGetParam(funcindex, "LDO1_1p6V_010");
	CParam *LDO1_1p8V_011 = StsGetParam(funcindex, "LDO1_1p8V_011");
	CParam *LDO1_1p8V_011_I20 = StsGetParam(funcindex, "LDO1_1p8V_011_I20");
	CParam *LDO1_2p5V_100 = StsGetParam(funcindex, "LDO1_2p5V_100");
	CParam *LDO1_2p8V_101 = StsGetParam(funcindex, "LDO1_2p8V_101");
	CParam *LDO1_3p3V_110 = StsGetParam(funcindex, "LDO1_3p3V_110");
	CParam *LDO1_5p0V_111 = StsGetParam(funcindex, "LDO1_5p0V_111");
	CParam *LDO2_1p1V_000 = StsGetParam(funcindex, "LDO2_1p1V_000");
	CParam *LDO2_1p2V_001 = StsGetParam(funcindex, "LDO2_1p2V_001");
	CParam *LDO2IN_LEAK = StsGetParam(funcindex, "LDO2IN_LEAK");
	CParam* LDO2_1p2V_001_I0 = StsGetParam(funcindex, "LDO2_1p2V_001_I0");
	
	CParam *LDO2_1p6V_010 = StsGetParam(funcindex, "LDO2_1p6V_010");
	CParam *LDO2_1p8V_011 = StsGetParam(funcindex, "LDO2_1p8V_011");
	CParam *LDO2_1p8V_011_I20 = StsGetParam(funcindex, "LDO2_1p8V_011_I20");
	CParam *LDO2_2p5V_100 = StsGetParam(funcindex, "LDO2_2p5V_100");
	CParam *LDO2_2p8V_101 = StsGetParam(funcindex, "LDO2_2p8V_101");
	CParam *LDO2_3p3V_110 = StsGetParam(funcindex, "LDO2_3p3V_110");
	CParam *LDO2_5p0V_111 = StsGetParam(funcindex, "LDO2_5p0V_111");
	
	CParam *LDO1_ILMT_01 = StsGetParam(funcindex, "LDO1_ILMT_01");
	CParam *LDO2_ILMT_01 = StsGetParam(funcindex, "LDO2_ILMT_01");




	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res_r[SITE_NUM];

	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K81_LDO_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K50_VBOOST_FXVIB, K109_FXVI2_8_B, K53_LDO1IN_FXVIB, K105_FXVI0_6_B, K52_LDO1_FXVIB, K107_FXVI1_7_B, K51_LDO2_FXVIB, K113_FXVI4_10_B, -1);

	delay_ms(1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	SPIWrite(0x04, 0x0013);
	SPIWrite(0x3F, 0x7481);//switch to main otp
	//bit30-27
	//0xxx x000 0000 0000=>0x31
	Enter_M_TM(0x0005, 0x1000, 0x0000);
	OTP_M_Preview(-1);//preview all options ,for 1p2 opt
	//No need force 3.3V, will check it
	B2_PREBOOT_VBOOST.TSet(FV, 3.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 3.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	delay_ms(1);
	dut.trim("LDO12_DAC").execute(measure_LDO12_DAC, spec, funcindex, funclabel, 1.0, treg_log_mode, "LDO12_DAC");
	

	SPIWrite(0x04, 0x0033);//LDO1 1.8V LDO2 1.8V
	Enter_M_TM(0x0005, 0x2800, 0x0000);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	dut.trim("LDO1_EA").execute(measure_LDO1_EA, spec, funcindex, funclabel, 1.0, treg_log_mode, "LDO1_EA");
	B0_PRESW_LDO1IN.Set(FV, 3.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.8*1.02, FXVIe_PLUS_3p6V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	SPIWrite(0x04, 0x00BB);//ILMIT=1
	dut.trim("LDO1_ILMT").execute(measure_LDO1_ILMT, spec, funcindex, funclabel, 1.0, treg_log_mode, "LDO1_ILMT");
	SPIWrite(0x04, 0x0033);//ILMIT=0
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.8*0.8, FXVIe_PLUS_3p6V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		LDO1_ILMT_01->SetTestResult(SITE, 0, -results[SITE]);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -10e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	SPIWrite(0x04, 0x0030);
	B0_PRESW_LDO1IN.TSet(FV, 2.6, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		LDO1_1p1V_000->SetTestResult(SITE, 0, results[SITE]);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	SPIWrite(0x04, 0x0011);
	B0_PRESW_LDO1IN.TSet(FV, 2.7, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	//int a;
	//a=dut.sel("LDO1_1p3_OPT").get_start(5);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
	if((dut.sel("LDO1_1p3_OPT").get_start(SITE))== 1)
		LDO1_1p3V_001_I0->SetTestResult(SITE, 0, results[SITE]);
	else
		LDO1_1p2V_001_I0->SetTestResult(SITE, 0, results[SITE]);
	}

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.4, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B0_PRESW_LDO1IN.TSet(FV, 2.7, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(8);
	B0_PRESW_LDO1IN.MeasureVI(30, 10,FXVIe_PLUS_MI_X10);
	SERIAL
	{
		results[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);

		LDO1IN_LEAK->SetTestResult(SITE, 0, results[SITE]*1e6);
	}
	B0_PRESW_LDO1IN.TSet(FV, 2.7, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -10e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	delay_ms(5);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET) ;
	if (dut.sel("LDO1_1p3_OPT").get_start(SITE)== 1)
		LDO1_1p3V_001->SetTestResult(SITE, 0, results[SITE]);
	else
		LDO1_1p2V_001->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x04, 0x0032);
	B0_PRESW_LDO1IN.TSet(FV, 3.1, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		LDO1_1p6V_010->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x04, 0x0033);
	B0_PRESW_LDO1IN.TSet(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		LDO1_1p8V_011->SetTestResult(SITE, 0, results[SITE]);
	}

	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -20e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		LDO1_1p8V_011_I20->SetTestResult(SITE, 0, results[SITE]);
	}


	SPIWrite(0x04, 0x0034);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -10e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		LDO1_2p5V_100->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x04, 0x0035);
	B0_PRESW_LDO1IN.TSet(FV, 4.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		LDO1_2p8V_101->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x04, 0x0036);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -10e-3, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 4.8, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		LDO1_3p3V_110->SetTestResult(SITE, 0, results[SITE]);
	}


	SPIWrite(0x04, 0x0037);
	B0_PRESW_LDO1IN.TSet(FV, 6.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		LDO1_5p0V_111->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x04, 0x0033);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -0.1e-3, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	Enter_M_TM(0x0005, 0x4800, 0x0000);
	B4_VSUP_LDO2OUT.Set(FI, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	dut.trim("LDO2_EA").execute(measure_LDO2_EA, spec, funcindex, funclabel, 1.0, treg_log_mode, "LDO2_EA");

	B2_PREBOOT_VBOOST.Set(FV, 3.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 1.8*1.02, FXVIe_PLUS_3p6V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	SPIWrite(0x04, 0x003B);//ILMIT=1
	dut.trim("LDO2_ILMT").execute(measure_LDO2_ILMT, spec, funcindex, funclabel, 1.0, treg_log_mode, "LDO2_ILMT");
	SPIWrite(0x04, 0x0033);//ILMIT=0
	B4_VSUP_LDO2OUT.Set(FV, 1.8*0.8, FXVIe_PLUS_3p6V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		LDO2_ILMT_01->SetTestResult(SITE, 0, -results[SITE]);
	}

	B4_VSUP_LDO2OUT.Set(FI, -10e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	SPIWrite(0x04, 0x0003);
	B2_PREBOOT_VBOOST.TSet(FV, 2.6, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		LDO2_1p1V_000->SetTestResult(SITE, 0, results[SITE]);
	}

	B4_VSUP_LDO2OUT.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	SPIWrite(0x04, 0x0013);
	B2_PREBOOT_VBOOST.TSet(FV, 2.7, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	delay_ms(2);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		LDO2_1p2V_001_I0->SetTestResult(SITE, 0, results[SITE]);
	}
	B4_VSUP_LDO2OUT.Set(FV, 1.4, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B2_PREBOOT_VBOOST.TSet(FV, 2.7, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(8);
	B2_PREBOOT_VBOOST.MeasureVI(30, 10,FXVIe_PLUS_MI_X10);
	SERIAL
	{
		results[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);

		LDO2IN_LEAK->SetTestResult(SITE, 0, results[SITE]*1e6);
	}
	B2_PREBOOT_VBOOST.TSet(FV, 2.7, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, -10e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(5);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		LDO2_1p2V_001->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x04, 0x0023);
	B2_PREBOOT_VBOOST.TSet(FV, 3.1, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		LDO2_1p6V_010->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x04, 0x0033);
	B2_PREBOOT_VBOOST.TSet(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		LDO2_1p8V_011->SetTestResult(SITE, 0, results[SITE]);
	}
	B4_VSUP_LDO2OUT.Set(FI, -20e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		LDO2_1p8V_011_I20->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x04, 0x0043);
	B4_VSUP_LDO2OUT.Set(FI, -10e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.TSet(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		LDO2_2p5V_100->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x04, 0x0053);
	B2_PREBOOT_VBOOST.TSet(FV, 4.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		LDO2_2p8V_101->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x04, 0x0063);
	B4_VSUP_LDO2OUT.Set(FI, -10e-3, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.TSet(FV, 4.8, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		LDO2_3p3V_110->SetTestResult(SITE, 0, results[SITE]);
	}


	SPIWrite(0x04, 0x0073);
	B2_PREBOOT_VBOOST.TSet(FV, 6.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		LDO2_5p0V_111->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x04, 0x0033);
	B2_PREBOOT_VBOOST.TSet(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, -0.1e-3, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//consider parallel test for ldo1&2
	//B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	Enter_M_TM(0x0005, 0x0000, 0x0000);//discharge ldo,intm=1,tm=0=>ldoen=0
	delay_ms(1);
//	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
//	B4_VSUP_LDO2OUT.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	dut.trim("LDO1_SS").execute(measure_LDO1_SS, spec, funcindex, funclabel, 1.0e3, treg_log_mode, "LDO1_SS");
	//Enter_M_TM(0x0005, 0x0000, 0x0000);
	dut.trim("LDO2_SS").execute(measure_LDO2_SS, spec, funcindex, funclabel, 1.0e3, treg_log_mode, "LDO2_SS");

	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	delay_ms(5);//for cap discharge
	B2_PREBOOT_VBOOST.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	B0_PRESW_LDO1IN.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	B4_VSUP_LDO2OUT.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);

	A5_AMUX.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);

	STSTArming();
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T19_BUCK123_trim(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam *BUCK1_DAC_0x30 = StsGetParam(funcindex, "BUCK1_DAC_0x30");
	CParam *BUCK1_DAC_0x31 = StsGetParam(funcindex, "BUCK1_DAC_0x31");
	CParam *BUCK1_DAC_0x33 = StsGetParam(funcindex, "BUCK1_DAC_0x33");
	CParam *BUCK1_DAC_0x37 = StsGetParam(funcindex, "BUCK1_DAC_0x37");
	CParam *BUCK1_DAC_0x3F = StsGetParam(funcindex, "BUCK1_DAC_0x3F");
	CParam *BUCK1_DAC_0x4F = StsGetParam(funcindex, "BUCK1_DAC_0x4F");
	CParam *BUCK1_DAC_0x6F = StsGetParam(funcindex, "BUCK1_DAC_0x6F");
	CParam *BUCK1_DAC_0xAF = StsGetParam(funcindex, "BUCK1_DAC_0xAF");
	CParam *BUCK1_DAC_0x2F = StsGetParam(funcindex, "BUCK1_DAC_0x2F");
	CParam *BUCK1_DAC_0xB0 = StsGetParam(funcindex, "BUCK1_DAC_0xB0");
	CParam *BUCK1_DAC_0xD0 = StsGetParam(funcindex, "BUCK1_DAC_0xD0");
	CParam *BUCK1_DAC_0xE7 = StsGetParam(funcindex, "BUCK1_DAC_0xE7");
	CParam *BUCK1_DAC_0xFF = StsGetParam(funcindex, "BUCK1_DAC_0xFF");

	CParam *BUCK2_DAC_0x30 = StsGetParam(funcindex, "BUCK2_DAC_0x30");
	CParam *BUCK2_DAC_0x31 = StsGetParam(funcindex, "BUCK2_DAC_0x31");
	CParam *BUCK2_DAC_0x33 = StsGetParam(funcindex, "BUCK2_DAC_0x33");
	CParam *BUCK2_DAC_0x37 = StsGetParam(funcindex, "BUCK2_DAC_0x37");
	CParam *BUCK2_DAC_0x3F = StsGetParam(funcindex, "BUCK2_DAC_0x3F");
	CParam *BUCK2_DAC_0x4F = StsGetParam(funcindex, "BUCK2_DAC_0x4F");
	CParam *BUCK2_DAC_0x6F = StsGetParam(funcindex, "BUCK2_DAC_0x6F");
	CParam *BUCK2_DAC_0xAF = StsGetParam(funcindex, "BUCK2_DAC_0xAF");
	CParam *BUCK2_DAC_0x2F = StsGetParam(funcindex, "BUCK2_DAC_0x2F");
	CParam *BUCK2_DAC_0xB0 = StsGetParam(funcindex, "BUCK2_DAC_0xB0");
	CParam *BUCK2_DAC_0xD0 = StsGetParam(funcindex, "BUCK2_DAC_0xD0");
	CParam *BUCK2_DAC_0xE7 = StsGetParam(funcindex, "BUCK2_DAC_0xE7");
	CParam *BUCK2_DAC_0xFF = StsGetParam(funcindex, "BUCK2_DAC_0xFF");


	CParam *BUCK3_DAC_0x30 = StsGetParam(funcindex, "BUCK3_DAC_0x30");
	CParam *BUCK3_DAC_0x31 = StsGetParam(funcindex, "BUCK3_DAC_0x31");
	CParam *BUCK3_DAC_0x33 = StsGetParam(funcindex, "BUCK3_DAC_0x33");
	CParam *BUCK3_DAC_0x37 = StsGetParam(funcindex, "BUCK3_DAC_0x37");
	CParam *BUCK3_DAC_0x3F = StsGetParam(funcindex, "BUCK3_DAC_0x3F");
	CParam *BUCK3_DAC_0x4F = StsGetParam(funcindex, "BUCK3_DAC_0x4F");
	CParam *BUCK3_DAC_0x6F = StsGetParam(funcindex, "BUCK3_DAC_0x6F");
	CParam *BUCK3_DAC_0xAF = StsGetParam(funcindex, "BUCK3_DAC_0xAF");
	CParam *BUCK3_DAC_0x2F = StsGetParam(funcindex, "BUCK3_DAC_0x2F");
	CParam *BUCK3_DAC_0xB0 = StsGetParam(funcindex, "BUCK3_DAC_0xB0");
	CParam *BUCK3_DAC_0xD0 = StsGetParam(funcindex, "BUCK3_DAC_0xD0");
	CParam *BUCK3_DAC_0xE7 = StsGetParam(funcindex, "BUCK3_DAC_0xE7");
	CParam *BUCK3_DAC_0xFF = StsGetParam(funcindex, "BUCK3_DAC_0xFF");

	CParam *BUCK1_IPK_0x01 = StsGetParam(funcindex, "BUCK1_IPK_0x01");
	CParam *BUCK1_IPK_MIN = StsGetParam(funcindex, "BUCK1_IPK_MIN");
	CParam *BUCK1_IVY_0x01 = StsGetParam(funcindex, "BUCK1_IVY_0x01");
	CParam* BUCK1_IVY_MINI = StsGetParam(funcindex, "BUCK1_IVY_MINI");
	CParam* BUCK1_IPK_NEG = StsGetParam(funcindex, "BUCK1_IPK_NEG");
	CParam* BUCK1_HS_RON = StsGetParam(funcindex, "BUCK1_HS_RON");
	CParam* BUCK1_LS_RON = StsGetParam(funcindex, "BUCK1_LS_RON");


	CParam *BUCK2_IPK_0x01 = StsGetParam(funcindex, "BUCK2_IPK_0x01");
	CParam* BUCK2_IPK_MIN = StsGetParam(funcindex, "BUCK2_IPK_MIN");
	CParam *BUCK2_IVY_0x01 = StsGetParam(funcindex, "BUCK2_IVY_0x01");
	CParam* BUCK2_IVY_MINI = StsGetParam(funcindex, "BUCK2_IVY_MINI");
	CParam* BUCK2_IPK_NEG = StsGetParam(funcindex, "BUCK2_IPK_NEG");
	CParam* BUCK2_HS_RON = StsGetParam(funcindex, "BUCK2_HS_RON");
	CParam* BUCK2_LS_RON = StsGetParam(funcindex, "BUCK2_LS_RON");

	CParam *BUCK3_IPK_0x01 = StsGetParam(funcindex, "BUCK3_IPK_0x01");
	CParam* BUCK3_IPK_MIN = StsGetParam(funcindex, "BUCK3_IPK_MIN");
	CParam *BUCK3_IVY_0x01 = StsGetParam(funcindex, "BUCK3_IVY_0x01");
	CParam* BUCK3_IVY_MINI = StsGetParam(funcindex, "BUCK3_IVY_MINI");
	CParam* BUCK3_IPK_NEG = StsGetParam(funcindex, "BUCK3_IPK_NEG");
	CParam* BUCK3_HS_RON = StsGetParam(funcindex, "BUCK3_HS_RON");
	CParam* BUCK3_LS_RON = StsGetParam(funcindex, "BUCK3_LS_RON");

	CParam *BUCK1_EA_0x00 = StsGetParam(funcindex, "BUCK1_EA_0x00");
	CParam *BUCK1_EA_0x30 = StsGetParam(funcindex, "BUCK1_EA_0x30");
	CParam *BUCK1_EA_0x4F = StsGetParam(funcindex, "BUCK1_EA_0x4F");
	CParam *BUCK1_EA_0xD0 = StsGetParam(funcindex, "BUCK1_EA_0xD0");
	CParam *BUCK1_EA_0xE7 = StsGetParam(funcindex, "BUCK1_EA_0xE7");
	CParam *BUCK1_EA_0xFF = StsGetParam(funcindex, "BUCK1_EA_0xFF");

	CParam *BUCK2_EA_0x00 = StsGetParam(funcindex, "BUCK2_EA_0x00");
	CParam *BUCK2_EA_0x30 = StsGetParam(funcindex, "BUCK2_EA_0x30");
	CParam *BUCK2_EA_0x4F = StsGetParam(funcindex, "BUCK2_EA_0x4F");
	CParam *BUCK2_EA_0xD0 = StsGetParam(funcindex, "BUCK2_EA_0xD0");
	CParam *BUCK2_EA_0xE7 = StsGetParam(funcindex, "BUCK2_EA_0xE7");
	CParam *BUCK2_EA_0xFF = StsGetParam(funcindex, "BUCK2_EA_0xFF");

	CParam *BUCK3_EA_0x00 = StsGetParam(funcindex, "BUCK3_EA_0x00");
	CParam *BUCK3_EA_0x30 = StsGetParam(funcindex, "BUCK3_EA_0x30");
	CParam *BUCK3_EA_0x4F = StsGetParam(funcindex, "BUCK3_EA_0x4F");
	CParam *BUCK3_EA_0xD0 = StsGetParam(funcindex, "BUCK3_EA_0xD0");
	CParam *BUCK3_EA_0xE7 = StsGetParam(funcindex, "BUCK3_EA_0xE7");
	CParam *BUCK3_EA_0xFF = StsGetParam(funcindex, "BUCK3_EA_0xFF");

	CParam *BUCK1_LOOP_GM_0x01 = StsGetParam(funcindex, "BUCK1_LOOP_GM_0x01");
	CParam *BUCK1_LOOP_GM_0x10 = StsGetParam(funcindex, "BUCK1_LOOP_GM_0x10");
	CParam *BUCK1_LOOP_GM_0x11 = StsGetParam(funcindex, "BUCK1_LOOP_GM_0x11");

	CParam *BUCK2_LOOP_GM_0x01 = StsGetParam(funcindex, "BUCK2_LOOP_GM_0x01");
	CParam *BUCK2_LOOP_GM_0x10 = StsGetParam(funcindex, "BUCK2_LOOP_GM_0x10");
	CParam *BUCK2_LOOP_GM_0x11 = StsGetParam(funcindex, "BUCK2_LOOP_GM_0x11");

	CParam *BUCK3_LOOP_GM_0x01 = StsGetParam(funcindex, "BUCK3_LOOP_GM_0x01");
	CParam *BUCK3_LOOP_GM_0x10 = StsGetParam(funcindex, "BUCK3_LOOP_GM_0x10");
	CParam *BUCK3_LOOP_GM_0x11 = StsGetParam(funcindex, "BUCK3_LOOP_GM_0x11");

	CParam *BUCK1_SLOP_0x01 = StsGetParam(funcindex, "BUCK1_SLOP_0x01");
	CParam *BUCK1_SLOP_0x10 = StsGetParam(funcindex, "BUCK1_SLOP_0x10");

	CParam *BUCK2_SLOP_0x01 = StsGetParam(funcindex, "BUCK2_SLOP_0x01");
	CParam *BUCK2_SLOP_0x10 = StsGetParam(funcindex, "BUCK2_SLOP_0x10");

	CParam *BUCK3_SLOP_0x01 = StsGetParam(funcindex, "BUCK3_SLOP_0x01");
	CParam *BUCK3_SLOP_0x10 = StsGetParam(funcindex, "BUCK3_SLOP_0x10");



	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double res_r[SITE_NUM];

		string EE_str;
			ULONG uotpcode;
		ULONG data0=0x0000;
	cbite.SetOn(K24_VDDIO_ACM,K82_BUCK_CAPS,/*  K81_LDO_CAPS,*/K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K56_INTB_PU, K32_INTB_FXVIA, K110_FXVI3_9_A, - 1);

	delay_ms(1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	SPIWrite(0x04, 0x0013);
	SPIWrite(0x3F, 0x7481);//switch to main otp
			bk12mult=0;
		if(SC6295X[find_ID].useropt_burn==1)
		{
			for (int addr = 0; addr < 10; ++addr)
			{
				EE_str = "MUBANK" + to_string(addr);
				SERIAL uotpcode=dut.assy(EE_str.c_str()).get_start(SITE);
				SPIWrite(0x00+addr, uotpcode);
				if((addr==4) &&((uotpcode&0x2000)==0x2000)) 
					bk12mult =1;
			
			

			}

		}

	//bit34-31 BUCK1
	//x000 0000 0000 0000
	//x000 0000 0000 0xxx
	BUCK123.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	
	Enter_M_TM(0x0006, 0x0000, 0x0003);
	OTP_M_Preview(0, 8);
	SPIWrite(0x01, 0x00FF);//MAX
	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	STSTArming();

	dut.trim("BUCK1_DAC").execute(measure_BUCK1_DAC, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK1_DAC");
	SPIWrite(0x01, 0x0030);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL 
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0x30->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x01, 0x0031);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0x31->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x01, 0x0033);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0x33->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x01, 0x0037);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0x37->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x01, 0x003F);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0x3F->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x01, 0x004F);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0x4F->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x01, 0x006F);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0x6F->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x01, 0x00AF);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0xAF->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x01, 0x002F);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0x2F->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x01, 0x00B0);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0xB0->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x01, 0x00D0);//1.8V
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0xD0->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x01, 0x00E7);//
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0xE7->SetTestResult(SITE, 0, results[SITE]);
	}


	SPIWrite(0x01, 0x00FF);//
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK1_DAC_0xFF->SetTestResult(SITE, 0, results[SITE]);
	}
	if(SC6295X[find_ID].useropt_burn==1)
	{
		
		SERIAL uotpcode=(dut.assy("MUBANK4").get_start(SITE))&0xDFFF;
		if(bk12mult==1) SPIWrite(0x04, uotpcode);

	}
	Enter_M_TM(0x0007, 0x0000, 0x0030);
	SPIWrite(0x02, 0xFF00);


	dut.trim("BUCK2_DAC").execute(measure_BUCK2_DAC, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK2_DAC");
	SPIWrite(0x02, 0x3000);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0x30->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x3100);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0x31->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x3300);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0x33->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x3700);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0x37->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x3F00);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0x3F->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x4F00);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0x4F->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x6F00);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0x6F->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0xAF00);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0xAF->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x2F00);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0x2F->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0xB000);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0xB0->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0xD000);//1.8V*0.8
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0xD0->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0xE700);//
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0xE7->SetTestResult(SITE, 0, results[SITE]);
	}


	SPIWrite(0x02, 0xFF00);//1.66
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK2_DAC_0xFF->SetTestResult(SITE, 0, results[SITE]);
	}
	if(SC6295X[find_ID].useropt_burn==1)
	{
		
		SERIAL uotpcode=(dut.assy("MUBANK4").get_start(SITE)) ;
		if(bk12mult==1) SPIWrite(0x04, uotpcode);

	}
	Enter_M_TM(0x0008, 0x0000, 0x0300);
	SPIWrite(0x02, 0x00FF);
	dut.trim("BUCK3_DAC").execute(measure_BUCK3_DAC, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK3_DAC");

	SPIWrite(0x02, 0x0030);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0x30->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x0031);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0x31->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x0033);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0x33->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x0037);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0x37->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x003F);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0x3F->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x004F);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0x4F->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x006F);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0x6F->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x02, 0x00AF);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0xAF->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x002F);//0.635V
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0x2F->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x00B0);//1.28V
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0xB0->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x00D0);//1.8V
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0xD0->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x00E7);//
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0xE7->SetTestResult(SITE, 0, results[SITE]);
	}


	SPIWrite(0x02, 0x00FF);//
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		BUCK3_DAC_0xFF->SetTestResult(SITE, 0, results[SITE]);
	}
		//set buck123 to 1.28V



	cbite.SetOn(K24_VDDIO_ACM,K82_BUCK_CAPS, /* K81_LDO_CAPS,*/K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
	K56_INTB_PU, K32_INTB_FXVIA, K110_FXVI3_9_A, K67_SW_FPVIL, K65_BUCK1IN_FPVIH, K_FPVIH_A, K_FPVIL_A, -1);
	delay_ms(1);
	Enter_M_TM(0x0006, 0x8000, 0x0004);//BUCK1 ILMT

	SPIWrite(0x01, 0x00B0);//1.6V ,buffer 1.28V

	//fb voltage lower than target-0.1
	PREFB_BUCK1FB_8.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	//BUCK1 HS RDSON
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.Set(FI, 1.0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.MeasureVI(30, 10);
	FPVIM.Set(FI, 0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	SERIAL
	{
		res1[SITE] = FPVIM.GetMeasResult(SITE, MVRET);
		res2[SITE] = FPVIM.GetMeasResult(SITE, MIRET);
		BUCK1_HS_RON->SetTestResult(SITE, 0, res1[SITE]/ (res2[SITE]+1e-30)*1e3);//mohm

	}
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);

		SPIWrite(0x04, data0);
	dut.trim("BUCK1_IPK").execute(measure_BUCK1_IPK, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK1_IPK");

	SPIWrite(0x04, 0x1000);// switch to 5A
	//will check pogo pin peformance ,if can take the high current
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK1_IPK01", 4.0, 6.0, 0.01, 10, 2.0, TRIG_FALLING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	//FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL
	{
		
		BUCK1_IPK_0x01->SetTestResult(SITE, 0, results[SITE]);
	}
		/////-------BUCK1 IMINI PK  LIMIT---------
	SPIWrite(0x04, data0);
	PREFB_BUCK1FB_8.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_1A, "BUCK1_IPKMINI", -0.1, -0.9, 0.005, 10, 2.0, TRIG_RISING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL
	{
		g_ilmt_pkmini_buck1[SITE] = results[SITE];
		BUCK1_IPK_MIN->SetTestResult(SITE, 0, -results[SITE]);
	}
	
		//-------ACC VBUCK1---------
	// accuracy test at same test mode
		

	Enter_M_TM(0x0006, 0x8000, 0x0004);//BUCK1  ACC
		//PRECSP_BUCK2FB_9.Set(FV, 1.57, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);

	PREFB_BUCK1FB_8.TSet(FV, 1.57, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	dut.trim("BUCK1_EA").execute(measure_BUCK1_EA, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK1_EA");
	SPIWrite(0x01, data0);//0.5V
	PREFB_BUCK1FB_8.TSet(FV, 0.47, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_EA00", 0.47, 0.53, 0.0004, 1000, 2.0, TRIG_FALLING, results);
	vth_binary_search(PREFB_BUCK1FB_8,A3_INTB,ACM200_3p6V,ACM200_100MA,0.47,0.53, 0.47,8,results,1000,0,TRIG_FALLING);

	SERIAL
	{
		BUCK1_EA_0x00->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x01, 0x0030);//0.8V
	PREFB_BUCK1FB_8.TSet(FV, 0.77, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_EA30", 0.77, 0.83, 0.0004, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, 0.77, 0.83, 0.77, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK1_EA_0x30->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x01, 0x004F);//0.99375V
	PREFB_BUCK1FB_8.TSet(FV, 0.963, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_EA4F", 0.963, 1.023, 0.0004, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, 0.963, 1.023, 0.963, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK1_EA_0x4F->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x01, 0x00D0);//1.8V
	PREFB_BUCK1FB_8.TSet(FV, 1.77, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_EAD0", 1.77, 1.83, 0.0005, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, 1.77, 1.83, 1.77, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK1_EA_0xD0->SetTestResult(SITE, 0, results[SITE]);
	}
		
	//check if high vout need high buck in
	BUCK1IN_2.Set(FV, 3.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	BUCK1IN_2.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	SPIWrite(0x01, 0x00E7);//2.95V
	PREFB_BUCK1FB_8.TSet(FV, 2.9, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK1_EAE7", 2.9, 3.0, 0.0008, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_100MA, 2.9, 3.0, 2.9, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK1_EA_0xE7->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x01, 0x00FF);//2.95V
	PREFB_BUCK1FB_8.TSet(FV, 4.06, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
//	awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "BUCK1_EAFF", 4.06, 4.24, 0.001, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, 4.06, 4.24, 4.06, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK1_EA_0xFF->SetTestResult(SITE, 0, results[SITE]);
	}

	PREFB_BUCK1FB_8.TSet(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	SPIWrite(0x01, 0x00B0);
	BUCK1IN_2.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON, 1.0);


	//------loop gm_EABUCK1-----------
	SPIWrite(0x03, data0);
	Enter_M_TM(0x0006, 0x8000, 0x0000);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	/*if (SC6295X[find_ID].name == "SC62595Q_HW")
	{
		 dut.trim("BUCK1_LOOP_GM").set_working(3);
		 OTP_M_Preview(10);
		 measure_BUCK1_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
		 
		SERIAL
		{
			StsGetParam(funcindex, "BUCK1_LOOP_GM_STEP3")->SetTestResult(SITE, 0, results[SITE]);
		}
	}
	else
	{*/
	    dut.trim("BUCK1_LOOP_GM").execute(measure_BUCK1_LOOP_GM, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK1_LOOP_GM");
	//}

	SPIWrite(0x03, 0x4000);
	measure_BUCK1_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
	SERIAL
	{
		BUCK1_LOOP_GM_0x01->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x03, 0x8000);
	measure_BUCK1_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
	SERIAL
	{
		BUCK1_LOOP_GM_0x10->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x03, 0xC000);
	measure_BUCK1_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
	SERIAL
	{
		BUCK1_LOOP_GM_0x11->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x03, data0);
	PREFB_BUCK1FB_8.TSet(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);

	//------BUCK1 SLOPE Test-----------
	Enter_M_TM(0x0006, 0x0000, 0x0001);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);//only test at option 00?
	dut.trim("BUCK1_SLOP").execute(measure_BUCK1_SLOP, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK1_SLOP");
	
	SPIWrite(0x03, 0x0040);//0.47uh
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK1_SLOP01", 0.0, 3.0, 0.015, 10, 2.0, TRIG_FALLING, results);
	SERIAL
	{
		BUCK1_SLOP_0x01->SetTestResult(SITE, 0, g_ilmt_pk_buck1[SITE]-results[SITE]);
	}

	SPIWrite(0x03, 0x0080);//1.5uh
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK1_SLOP10", -0.9, 4.0, 0.015, 10, 2.0, TRIG_FALLING, results);
	SERIAL
	{
		BUCK1_SLOP_0x10->SetTestResult(SITE, 0, g_ilmt_pk_buck1[SITE]-results[SITE]);
	}
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SPIWrite(0x03, data0);




	///------BUCK1_IVY-------
	cbite.SetCbiteOff(K65_BUCK1IN_FPVIH);
	delay_ms(1);
	cbite.SetCbiteOn(K64_PGND_FPVIH);
	delay_ms(1);
	SPIWrite(0x04, data0);
	Enter_M_TM(0x0006, 0x0000, 0x0005);
	//BUCK1 LS RDSON
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.Set(FI, 1.0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.MeasureVI(30, 10);
	FPVIM.Set(FI, 0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	SERIAL
	{
		res1[SITE] = FPVIM.GetMeasResult(SITE, MVRET);
		res2[SITE] = FPVIM.GetMeasResult(SITE, MIRET);
		BUCK1_LS_RON->SetTestResult(SITE, 0, res1[SITE] / (res2[SITE] + 1e-30) * 1e3);//mohm

	}
	dut.trim("BUCK1_IPK").save_working();
	dut.trim("BUCK1_IPK").set_working(7);//set IPK to MAX, avoid IVY current not increase

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	dut.trim("BUCK1_IVY").execute(measure_BUCK1_IVY, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK1_IVY");
	dut.trim("BUCK1_IPK").restore_working();
	OTP_M_Preview(9);
	SPIWrite(0x04, 0x1000);// switch to 5A
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK1_IVY01", 4.0, 6.0, 0.01, 10, 2.0, TRIG_RISING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL
	{

		BUCK1_IVY_0x01->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x04, data0);
	/////-------BUCK1 IVY  MINI---------
	Enter_M_TM(0x0006, 0x0000, 0x0005);//BUCK1 ILMT
	delay_ms(1);
	PREFB_BUCK1FB_8.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_1A, "BUCK1_IVY_MINI", -0.1, -0.9, 0.005, 10, 2.0, TRIG_FALLING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	SERIAL
	{

		BUCK1_IVY_MINI->SetTestResult(SITE, 0, results[SITE]);
	}
	/////-------BUCK1 NEG  LIMIT---------
	Enter_M_TM(0x0006, 0x8000, 0x0005);//BUCK1 ILMT
	delay_ms(1);
	PREFB_BUCK1FB_8.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK1_IPKNEG", -0.5, -3.0, 0.01, 10, 2.0, TRIG_FALLING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	SERIAL
	{

		BUCK1_IPK_NEG->SetTestResult(SITE, 0, results[SITE]);
	}

	//���������Ȳ�


	cbite.SetOn(K24_VDDIO_ACM,K82_BUCK_CAPS, /* K81_LDO_CAPS,*/K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K56_INTB_PU, K32_INTB_FXVIA, K110_FXVI3_9_A, K_FPVIH_C, K_FPVIL_C, -1);
	delay_ms(1);
	PRECSP_BUCK2FB_9.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//dual phase----pkmin buck2
	Enter_M_TM(0x0007, 0x0000, 0x0048);
	SPIWrite(0x04, 0xA000);//multiphase
	PREFB_BUCK1FB_8.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	dut.trim("BUCK2_DP_IMINPK").execute(measure_BUCK2_DP_IMINPK, spec, funcindex, funclabel, 1e3, treg_log_mode, "BUCK2_DP_IMINPK");
	
	PREFB_BUCK1FB_8.Set(FV, 1.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.Set(FV, 1.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	dut.trim("BUCK2_DP_IMAXPK").execute(measure_BUCK2_DP_IMAXPK, spec, funcindex, funclabel, 1e3, treg_log_mode, "BUCK2_DP_IMAXPK");
	//design bug to set 0 for default
	dut.trim("BUCK2_DP_IMAXPK").set_working(0);
	OTP_M_Preview(12);
	SPIWrite(0x04, data0);
	Enter_M_TM(0x0007, 0x0000, 0x0048);
	SPIWrite(0x02, 0xB0B0);
	delay_ms(1);

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.Set(FI, 1.0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.MeasureVI(30, 10);
	FPVIM.Set(FI, 0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	SERIAL
	{
		res1[SITE] = FPVIM.GetMeasResult(SITE, MVRET);
		res2[SITE] = FPVIM.GetMeasResult(SITE, MIRET);
		BUCK2_HS_RON->SetTestResult(SITE, 0, res1[SITE] / (res2[SITE] + 1e-30) * 1e3);//mohm

	}
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	dut.trim("BUCK2_IPK").execute(measure_BUCK2_IPK, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK2_IPK");

	SPIWrite(0x04, 0x0800);// switch to 5A
	//will check pogo pin peformance ,if can take the high current
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK2_IPK01", 4.0, 6.0, 0.01, 10, 2.0, TRIG_FALLING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL
	{

		BUCK2_IPK_0x01->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x04, data0);
	///---------BUCK2 IMINI PK------
	PRECSP_BUCK2FB_9.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_1A, "BUCK2_IPKMINI", -0.1, -0.9, 0.005, 10, 2.0, TRIG_RISING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL
	{
		//g_ilmt_pkmini_buck1[SITE] = results[SITE];
		BUCK2_IPK_MIN->SetTestResult(SITE, 0, -results[SITE]);
	}


	// accuracy test at same test mode
	PRECSP_BUCK2FB_9.Set(FV, 1.57, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	dut.trim("BUCK2_EA").execute(measure_BUCK2_EA, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK2_EA");
	SPIWrite(0x02, data0);//0.5V
	PRECSP_BUCK2FB_9.Set(FV, 0.47, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK2_EA00", 0.47, 0.53, 0.0004, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, 0.47, 0.53, 0.47, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK2_EA_0x00->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x3000);//0.8V
	PRECSP_BUCK2FB_9.Set(FV, 0.77, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK2_EA30", 0.77, 0.83, 0.0004, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, 0.77, 0.83, 0.77, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK2_EA_0x30->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x4F00);//0.99375V
	PRECSP_BUCK2FB_9.Set(FV, 0.963, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK2_EA4F", 0.963, 1.023, 0.0004, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, 0.963, 1.023, 0.963, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK2_EA_0x4F->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0xD000);//1.8V
	PRECSP_BUCK2FB_9.Set(FV, 1.77, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
//	awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK2_EAD0", 1.77, 1.83, 0.0005, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, 1.77, 1.83, 1.77, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK2_EA_0xD0->SetTestResult(SITE, 0, results[SITE]);
	}
//	BUCK2IN_3.Set(FV, 3.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
//	BUCK2IN_3.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	SPIWrite(0x02, 0xE700);//2.95V
	PRECSP_BUCK2FB_9.Set(FV, 2.9, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK2_EAE7", 2.9, 3.0, 0.0008, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_100MA, 2.9, 3.0, 2.9, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK2_EA_0xE7->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0xFF00);//2.95V
	PRECSP_BUCK2FB_9.Set(FV, 4.06, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_10V, ACM200_100MA, "BUCK2_EAFF", 4.06, 4.24, 0.001, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECSP_BUCK2FB_9, A3_INTB, ACM200_10V, ACM200_100MA, 4.06, 4.24, 4.06, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK2_EA_0xFF->SetTestResult(SITE, 0, results[SITE]);
	}

	PRECSP_BUCK2FB_9.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	SPIWrite(0x02, 0xB0B0);
//	BUCK2IN_3.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//------loop gm_EABUCK2-----------

	Enter_M_TM(0x0007, 0x0000, 0x0008);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	/*if (SC6295X[find_ID].name == "SC62595Q_HW")
	{
		 dut.trim("BUCK2_LOOP_GM").set_working(3);
		 OTP_M_Preview(12);
		 measure_BUCK2_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
		 
		SERIAL
		{
			StsGetParam(funcindex, "BUCK2_LOOP_GM_STEP3")->SetTestResult(SITE, 0, results[SITE]);
		}

	}
	else
	{*/
	     dut.trim("BUCK2_LOOP_GM").execute(measure_BUCK2_LOOP_GM, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK2_LOOP_GM");
	//}

	SPIWrite(0x03, 0x1000);
	measure_BUCK2_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
	SERIAL
	{
		BUCK2_LOOP_GM_0x01->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x03, 0x2000);
	measure_BUCK2_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
	SERIAL
	{
		BUCK2_LOOP_GM_0x10->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x03, 0x3000);
	measure_BUCK2_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
	SERIAL
	{
		BUCK2_LOOP_GM_0x11->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x03, data0);
	PRECSP_BUCK2FB_9.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);

	//------BUCK2 SLOPE Test-----------
	Enter_M_TM(0x0007, 0x0000, 0x0010);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);//only test at option 00?
	dut.trim("BUCK2_SLOP").execute(measure_BUCK2_SLOP, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK2_SLOP");

	SPIWrite(0x03, 0x0010);//0.47uh
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK2_SLOP01", 0.0, 3.0, 0.015, 10, 2.0, TRIG_FALLING, results);
	SERIAL
	{
		BUCK2_SLOP_0x01->SetTestResult(SITE, 0, g_ilmt_pk_buck2[SITE]-results[SITE]);
	}

	SPIWrite(0x03, 0x0020);//1.5uh
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK2_SLOP10", -0.9, 4.0, 0.015, 10, 2.0, TRIG_FALLING, results);
	SERIAL
	{
		BUCK2_SLOP_0x10->SetTestResult(SITE, 0, g_ilmt_pk_buck2[SITE]-results[SITE]);
	}
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);


	SPIWrite(0x03, data0);





	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, /*K81_LDO_CAPS,*/K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
	K56_INTB_PU, K32_INTB_FXVIA, K110_FXVI3_9_A, K64_PGND_FPVIH, K_FPVIH_A, K_FPVIL_C, -1);
	delay_ms(1);
	PRECSP_BUCK2FB_9.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	SPIWrite(0x04, data0);
	Enter_M_TM(0x0007, 0x0000, 0x0050);
	//BUCK2 LS RDSON
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.Set(FI, 1.0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.MeasureVI(30, 10);
	FPVIM.Set(FI, 0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	SERIAL
	{
		res1[SITE] = FPVIM.GetMeasResult(SITE, MVRET);
		res2[SITE] = FPVIM.GetMeasResult(SITE, MIRET);
		BUCK2_LS_RON->SetTestResult(SITE, 0, res1[SITE] / (res2[SITE] + 1e-30) * 1e3);//mohm

	}
	dut.trim("BUCK2_IPK").save_working();
	dut.trim("BUCK2_IPK").set_working(7);//set IPK to MAX, avoid IVY current not increase

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	dut.trim("BUCK2_IVY").execute(measure_BUCK2_IVY, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK2_IVY");
	dut.trim("BUCK2_IPK").restore_working();
	OTP_M_Preview(11);
	SPIWrite(0x04, 0x0800);// switch to 5A
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK2_IVY01", 4.0, 6.0, 0.01, 10, 2.0, TRIG_RISING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL
	{

		BUCK2_IVY_0x01->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x04, data0);
	/////-------BUCK2 IVY  mini---------
//	Enter_M_TM(0x0007, 0x0000, 0x0050);
	delay_ms(1);
	PRECSP_BUCK2FB_9.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_1A, "BUCK2_IVY_MINI", -0.1, -0.9, 0.005, 10, 2.0, TRIG_FALLING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	SERIAL
	{

		BUCK2_IVY_MINI->SetTestResult(SITE, 0, results[SITE]);
	}
	/////-------BUCK2 NEG  LIMIT---------
	Enter_M_TM(0x0007, 0x0000, 0x0058);
	delay_ms(1);
	PRECSP_BUCK2FB_9.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK2_IPKNEG", -0.5, -3.0, 0.01, 10, 2.0, TRIG_FALLING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	SERIAL
	{

		BUCK2_IPK_NEG->SetTestResult(SITE, 0, results[SITE]);
	}
	cbite.SetOn(K24_VDDIO_ACM,K82_BUCK_CAPS, /* K81_LDO_CAPS,*/K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K56_INTB_PU, K32_INTB_FXVIA, K110_FXVI3_9_A, K_FPVIH_B, K_FPVIL_B, -1);
	delay_ms(1);
	Enter_M_TM(0x0008, 0x0000, 0x0480);
	SPIWrite(0x02, 0xB0B0);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	//BUCK3 HS RDSON
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.Set(FI, 1.0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.MeasureVI(30, 10);
	FPVIM.Set(FI, 0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	SERIAL
	{
		res1[SITE] = FPVIM.GetMeasResult(SITE, MVRET);
		res2[SITE] = FPVIM.GetMeasResult(SITE, MIRET);
		BUCK3_HS_RON ->SetTestResult(SITE, 0, res1[SITE] / (res2[SITE] + 1e-30) * 1e3);//mohm

	}
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	dut.trim("BUCK3_IPK").execute(measure_BUCK3_IPK, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK3_IPK");
	SPIWrite(0x04, 0x0400);// switch to 5A
	//will check pogo pin peformance ,if can take the high current
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK3_IPK01", 4.0, 6.0, 0.01, 10, 2.0, TRIG_FALLING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL
	{

		BUCK3_IPK_0x01->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x04, data0);
	///---------BUCK3 IMINI PK------
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_1A, "BUCK3_IPKMINI", -0.1, -0.9, 0.005, 10, 2.0, TRIG_RISING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL
	{
		//g_ilmt_pkmini_buck1[SITE] = results[SITE];
		BUCK3_IPK_MIN->SetTestResult(SITE, 0, -results[SITE]);
	}
		//-------ACC VBUCK3---------
	//Enter_M_TM(0x0008, 0x0000, 0x0480);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.57, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	dut.trim("BUCK3_EA").execute(measure_BUCK3_EA, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK3_EA");
	SPIWrite(0x02, data0);//0.5V

	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.47, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK3_EA00", 0.47, 0.53, 0.0004, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, 0.47, 0.53, 0.47, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK3_EA_0x00->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x0030);//0.8V
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.77, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK3_EA30", 0.77, 0.83, 0.0004, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, 0.77, 0.83, 0.77, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK3_EA_0x30->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x004F);//0.99375V
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.963, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK3_EA4F", 0.963, 1.023, 0.0004, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, 0.963, 1.023, 0.963, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK3_EA_0x4F->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x00D0);//1.8V
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.77, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK3_EAD0", 1.77, 1.83, 0.0005, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, 1.77, 1.83, 1.77, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK3_EA_0xD0->SetTestResult(SITE, 0, results[SITE]);
	}
	BUCK3IN_4.Set(FV, 3.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	BUCK3IN_4.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	SPIWrite(0x02, 0x00E7);//2.95V
	PRECMP_BUCK3FB_INTB_10.Set(FV, 2.9, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "BUCK3_EAE7", 2.9, 3.0, 0.0008, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, 2.9, 3.0, 2.9, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK3_EA_0xE7->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x02, 0x00FF);//2.95V
	PRECMP_BUCK3FB_INTB_10.Set(FV, 4.06, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_10V, ACM200_100MA, "BUCK3_EAFF", 4.06, 4.24, 0.001, 30, 2.0, TRIG_FALLING, results);
	vth_binary_search(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_10V, ACM200_100MA, 4.06, 4.24, 4.06, 8, results, 1000, 0, TRIG_FALLING);

	SERIAL
	{
		BUCK3_EA_0xFF->SetTestResult(SITE, 0, results[SITE]);
	}

	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	SPIWrite(0x02, 0x00B0);
	BUCK3IN_4.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//------loop gm_EABUCK2-----------

	Enter_M_TM(0x0008, 0x0000, 0x0080);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	/*if (SC6295X[find_ID].name == "SC62595Q_HW")
	{
		 dut.trim("BUCK3_LOOP_GM").set_working(3);
		 OTP_M_Preview(14);
		 measure_BUCK3_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
		 
		SERIAL
		{
			StsGetParam(funcindex, "BUCK3_LOOP_GM_STEP3")->SetTestResult(SITE, 0, results[SITE]);
		}
	}
	else
	{*/
    	dut.trim("BUCK3_LOOP_GM").execute(measure_BUCK3_LOOP_GM, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK3_LOOP_GM");
	//}

	SPIWrite(0x03, 0x0400);
	measure_BUCK3_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
	SERIAL
	{
		BUCK3_LOOP_GM_0x01->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x03, 0x0800);
	measure_BUCK3_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
	SERIAL
	{
		BUCK3_LOOP_GM_0x10->SetTestResult(SITE, 0, results[SITE]);
	}

	SPIWrite(0x03, 0x0C00);
	measure_BUCK3_LOOP_GM(NULL, TREG_MEASURE_NONE, results);
	SERIAL
	{
		BUCK3_LOOP_GM_0x11->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x03, data0);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//------BUCK3 SLOPE Test-----------
	Enter_M_TM(0x0008, 0x0000, 0x0100);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);//only test at option 00?
	dut.trim("BUCK3_SLOP").execute(measure_BUCK3_SLOP, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK3_SLOP");

	SPIWrite(0x03, 0x0004);//0.47uh
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK3_SLOP01", 0.0, 3.0, 0.015, 10, 2.0, TRIG_FALLING, results);
	SERIAL
	{
		BUCK3_SLOP_0x01->SetTestResult(SITE, 0, g_ilmt_pk_buck3[SITE] - results[SITE]);
	}

	SPIWrite(0x03, 0x0008);//1.5uh
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK3_SLOP10", -0.9, 4.0, 0.015, 10, 2.0, TRIG_FALLING, results);
	SERIAL
	{
		BUCK3_SLOP_0x10->SetTestResult(SITE, 0, g_ilmt_pk_buck3[SITE] - results[SITE]);
	}
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SPIWrite(0x03, data0);
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, /*K81_LDO_CAPS,*/K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K56_INTB_PU, K32_INTB_FXVIA, K110_FXVI3_9_A, K64_PGND_FPVIH, K_FPVIH_A, K_FPVIL_B, -1);
	delay_ms(1);

	SPIWrite(0x04, data0);
	Enter_M_TM(0x0008, 0x0000, 0x0500);
	//BUCK3 LS RDSON
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.Set(FI, 1.0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	delay_ms(1);
	FPVIM.MeasureVI(30, 10);
	FPVIM.Set(FI, 0, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
	SERIAL
	{
		res1[SITE] = FPVIM.GetMeasResult(SITE, MVRET);
		res2[SITE] = FPVIM.GetMeasResult(SITE, MIRET);
		BUCK3_LS_RON->SetTestResult(SITE, 0, res1[SITE] / (res2[SITE] + 1e-30) * 1e3);//mohm

	}
	dut.trim("BUCK3_IPK").save_working();
	dut.trim("BUCK3_IPK").set_working(7);//set IPK to MAX, avoid IVY current not increase

	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	dut.trim("BUCK3_IVY").execute(measure_BUCK3_IVY, spec, funcindex, funclabel, 1.0, treg_log_mode, "BUCK3_IVY");
	dut.trim("BUCK3_IPK").restore_working();
	OTP_M_Preview(13);
	SPIWrite(0x04, 0x0400);// switch to 5A
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK3_IVY01", 4.0, 6.0, 0.01, 10, 2.0, TRIG_RISING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL
	{

		BUCK3_IVY_0x01->SetTestResult(SITE, 0, results[SITE]);
	}
	SPIWrite(0x04, data0);
	//------------------
	/////-------BUCK3 IVY  MINI---------
	Enter_M_TM(0x0008, 0x0000, 0x0500);//BUCK1 ILMT
	delay_ms(1);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_1A, "BUCK3_IVY_MIN", -0.1, -0.9, 0.005, 10, 2.0, TRIG_FALLING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	SERIAL
	{

		BUCK3_IVY_MINI->SetTestResult(SITE, 0, results[SITE]);
	}
		/////-------BUCK3 NEG  LIMIT---------
	Enter_M_TM(0x0008, 0x0000, 0x0580);//BUCK1 ILMT
	delay_ms(1);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.7, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	awg.rampi(FPVIM, A3_INTB, FPVIe_1V, FPVIe_10A, "BUCK3_IPKNEG", -0.5, -3.0, 0.01, 10, 2.0, TRIG_FALLING, results);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10A, FPVIe_RELAY_ON);
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	SERIAL
	{

		BUCK3_IPK_NEG->SetTestResult(SITE, 0, results[SITE]);
	}

	//--------------------
	FPVIM.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_OFF);
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);


	delay_ms(5);//for cap discharge
	A3_INTB.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	A5_AMUX.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	VDDIO_VBOOST_0.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	VSUP_11.TSet(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_OFF);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	PRECSP_BUCK2FB_9.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);

	STSTArming();
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T21_BANK_BURN(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam *eFUSE_MBANK0_PGM = StsGetParam(funcindex, "eFUSE_MBANK0_PGM");
	CParam *eFUSE_MBANK1_PGM = StsGetParam(funcindex, "eFUSE_MBANK1_PGM");
	CParam *eFUSE_MBANK2_PGM = StsGetParam(funcindex, "eFUSE_MBANK2_PGM");
	CParam *eFUSE_MBANK3_PGM = StsGetParam(funcindex, "eFUSE_MBANK3_PGM");
	CParam *eFUSE_MBANK4_PGM = StsGetParam(funcindex, "eFUSE_MBANK4_PGM");
	CParam *eFUSE_MBANK5_PGM = StsGetParam(funcindex, "eFUSE_MBANK5_PGM");
	CParam *eFUSE_MBANK6_PGM = StsGetParam(funcindex, "eFUSE_MBANK6_PGM");
	CParam *eFUSE_MBANK7_PGM = StsGetParam(funcindex, "eFUSE_MBANK7_PGM");
	CParam *eFUSE_MBANK8_PGM = StsGetParam(funcindex, "eFUSE_MBANK8_PGM");
	CParam *eFUSE_MBANK9_PGM = StsGetParam(funcindex, "eFUSE_MBANK9_PGM");
	CParam *eFUSE_MBANK10_PGM = StsGetParam(funcindex, "eFUSE_MBANK10_PGM");
	CParam *eFUSE_MBANK11_PGM = StsGetParam(funcindex, "eFUSE_MBANK11_PGM");
	CParam *eFUSE_MBANK12_PGM = StsGetParam(funcindex, "eFUSE_MBANK12_PGM");
	CParam *eFUSE_MBANK13_PGM = StsGetParam(funcindex, "eFUSE_MBANK13_PGM");
	CParam *eFUSE_MBANK14_PGM = StsGetParam(funcindex, "eFUSE_MBANK14_PGM");
	CParam *eFUSE_MBANK15_PGM = StsGetParam(funcindex, "eFUSE_MBANK15_PGM");
	CParam *eFUSE_FSBANK0_PGM = StsGetParam(funcindex, "eFUSE_FSBANK0_PGM");
	CParam *eFUSE_M_PGM_IQ = StsGetParam(funcindex, "eFUSE_M_PGM_IQ");
	CParam *eFUSE_M_PGM_IQ_RMS = StsGetParam(funcindex, "eFUSE_M_PGM_IQ_RMS");
	CParam *eFUSE_FS_PGM_IQ = StsGetParam(funcindex, "eFUSE_FS_PGM_IQ");
	CParam *eFUSE_FS_PGM_IQ_RMS = StsGetParam(funcindex, "eFUSE_FS_PGM_IQ_RMS");

	CParam *eFUSE_MBANK0_READ1 = StsGetParam(funcindex, "eFUSE_MBANK0_READ1");
	CParam *eFUSE_MBANK1_READ1 = StsGetParam(funcindex, "eFUSE_MBANK1_READ1");
	CParam *eFUSE_MBANK2_READ1 = StsGetParam(funcindex, "eFUSE_MBANK2_READ1");
	CParam *eFUSE_MBANK3_READ1 = StsGetParam(funcindex, "eFUSE_MBANK3_READ1");
	CParam *eFUSE_MBANK4_READ1 = StsGetParam(funcindex, "eFUSE_MBANK4_READ1");
	CParam *eFUSE_MBANK5_READ1 = StsGetParam(funcindex, "eFUSE_MBANK5_READ1");
	CParam *eFUSE_MBANK6_READ1 = StsGetParam(funcindex, "eFUSE_MBANK6_READ1");
	CParam *eFUSE_MBANK7_READ1 = StsGetParam(funcindex, "eFUSE_MBANK7_READ1");
	CParam *eFUSE_MBANK8_READ1 = StsGetParam(funcindex, "eFUSE_MBANK8_READ1");
	CParam *eFUSE_MBANK9_READ1 = StsGetParam(funcindex, "eFUSE_MBANK9_READ1");
	CParam *eFUSE_MBANK10_READ1 = StsGetParam(funcindex, "eFUSE_MBANK10_READ1");
	CParam *eFUSE_MBANK11_READ1 = StsGetParam(funcindex, "eFUSE_MBANK11_READ1");
	CParam *eFUSE_MBANK12_READ1 = StsGetParam(funcindex, "eFUSE_MBANK12_READ1");
	CParam *eFUSE_MBANK13_READ1 = StsGetParam(funcindex, "eFUSE_MBANK13_READ1");
	CParam *eFUSE_MBANK14_READ1 = StsGetParam(funcindex, "eFUSE_MBANK14_READ1");
	CParam *eFUSE_MBANK15_READ1 = StsGetParam(funcindex, "eFUSE_MBANK15_READ1");
	CParam *eFUSE_FSBANK0_READ1 = StsGetParam(funcindex, "eFUSE_FSBANK0_READ1");
	CParam *PROGRAM_M_Enable = StsGetParam(funcindex, "PROGRAM_M_Enable");
	CParam *PROGRAM_FS_Enable = StsGetParam(funcindex, "PROGRAM_FS_Enable");
	CParam *PGM_READ_COMP = StsGetParam(funcindex, "PGM_READ_COMP");

	CParam *START_VS_READ_OPT1 = StsGetParam(funcindex, "START_VS_READ_OPT1");
	CParam* M_UOTP_BURN_F = StsGetParam(funcindex, "M_UOTP_BURN_F");
	CParam* FS_UOTP_BURN_F = StsGetParam(funcindex, "FS_UOTP_BURN_F");
	CParam* M_UOTP_BURN_F1 = StsGetParam(funcindex, "M_UOTP_BURN_F1");
	CParam* FS_UOTP_BURN_F1 = StsGetParam(funcindex, "FS_UOTP_BURN_F1");

	
	
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	string EE_str;
	int program_vs_read[SITE_NUM];
	int start_vs_read_opt[SITE_NUM];
	double burn_iq[SITE_NUM] = { 0 };
	double burnIq[SITE_NUM][800];
	double burn_iq_sigma[SITE_NUM] = { 0 };
	double burn_iq1[SITE_NUM] = { 0 };
	double burnIq1[SITE_NUM][800];
	double burn_iq_sigma1[SITE_NUM] = { 0 };
	ULONG m_otp_data[10][SITE_NUM];
	ULONG fs_otp_data[5][SITE_NUM];

	ULONG m_trim_data[16][SITE_NUM];
	ULONG fs_trim_data[SITE_NUM];
	ULONG motp_burn_data[SITE_NUM];
	ULONG fsotp_burn_data[SITE_NUM];
	int trim_data[10][SITE_NUM];
	ULONG uotpcode;
	ULONG wrdata[SITE_NUM] = { 0 };
	ULONG wrdata1[SITE_NUM] = { 0 };
	map<unsigned int, map<string, unsigned int>> node_map;	// map<site, map<node_name, value>>
	CParam *EE_Params[BANK_NUM] = { eFUSE_MBANK0_PGM, eFUSE_MBANK1_PGM, eFUSE_MBANK2_PGM, eFUSE_MBANK3_PGM, eFUSE_MBANK4_PGM, eFUSE_MBANK5_PGM, eFUSE_MBANK6_PGM, eFUSE_MBANK7_PGM, eFUSE_MBANK8_PGM, eFUSE_MBANK9_PGM,
		eFUSE_MBANK10_PGM, eFUSE_MBANK11_PGM, eFUSE_MBANK12_PGM, eFUSE_MBANK13_PGM, eFUSE_MBANK14_PGM, eFUSE_MBANK15_PGM, eFUSE_FSBANK0_PGM };
	CParam *EE_Reads[BANK_NUM] = { eFUSE_MBANK0_READ1, eFUSE_MBANK1_READ1, eFUSE_MBANK2_READ1, eFUSE_MBANK3_READ1, eFUSE_MBANK4_READ1, eFUSE_MBANK5_READ1, eFUSE_MBANK6_READ1, eFUSE_MBANK7_READ1, eFUSE_MBANK8_READ1, eFUSE_MBANK9_READ1,
		eFUSE_MBANK10_READ1, eFUSE_MBANK11_READ1, eFUSE_MBANK12_READ1, eFUSE_MBANK13_READ1, eFUSE_MBANK14_READ1, eFUSE_MBANK15_READ1, eFUSE_FSBANK0_READ1 };
	string m_param_str_array1[] = { "M_OTP_00_F", "M_OTP_01_F", "M_OTP_02_F", "M_OTP_03_F", "M_OTP_04_F", "M_OTP_05_F", "M_OTP_06_F", "M_OTP_07_F", "M_OTP_08_F", "M_OTP_09_F" };
	string fs_param_str_array1[] = { "FS_OTP_00_F", "FS_OTP_01_F", "FS_OTP_02_F", "FS_OTP_03_F", "FS_OTP_04_F" };
	string m_param_str_array1_1[] = { "M_OTP_00_F1", "M_OTP_01_F1", "M_OTP_02_F1", "M_OTP_03_F1", "M_OTP_04_F1", "M_OTP_05_F1", "M_OTP_06_F1", "M_OTP_07_F1", "M_OTP_08_F1", "M_OTP_09_F1" };
	string fs_param_str_array1_1[] = { "FS_OTP_00_F1", "FS_OTP_01_F1", "FS_OTP_02_F1", "FS_OTP_03_F1", "FS_OTP_04_F1" };
	if (QC || !DO_TRIM)   return 0;



	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K54_VDDIO_PU, K59_WAKE12_PU, -1);//will check if need the caps.
	delay_ms(1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(15);//will check delay time
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	SPIWrite(0x3F, 0x7481);//switch to main otp table
	SPIWrite(0x7F, 0x7481);//switch to main otp table
	//adjust working code

	//will add ��żУ��


	OTP_M_Preview();//preview all bits
	OTP_FS_Preview();
	SPIRead(0x002A, wrdata);
	for (int reg = 0; reg < BANK_NUM-1; ++reg){

		EE_str = "MBANK" + to_string(reg);

		SERIAL
		{
			if (m_burn_flag[SITE] == true)
			{
				dut.assy(EE_str.c_str()).copy_work_to_prog(SITE);//untrimmed,copy work to prog
			}

		}

	}
	SERIAL{
		if (fs_burn_flag[SITE] == true)
		{
			dut.assy("FSBANK0").copy_work_to_prog(SITE);
		}
	}


		SERIAL{
		if (m_burn_flag[SITE])
		{
			wrdata[SITE] = 0x0001;
		}
		else
		{
			wrdata[SITE] = 0x0000;
		}

		if (fs_burn_flag[SITE])
		{
			wrdata1[SITE] = 0x0001;
		}
		else
		{
			wrdata1[SITE] = 0x0000;
		}

	}

	VSUP_11.MeasureVI(300, 20, MEAS_AWG);//3.8ms confirmed by design

	STSEnableMeas(&VSUP_11);
	//Main area program
	SPIWrite_SYNC(0x3C, wrdata);
	STSAWGRun();

	SERIAL{
		burn_iq[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		for (int i = 0; i < 300; i++)
			burnIq[SITE][i] = VSUP_11.GetMeasResult(SITE, MIRET, i);
		burn_iq_sigma[SITE] = sigma_cal(burnIq[SITE], 300);
	}


		delay_ms(2);
	VSUP_11.MeasureVI(100, 20, MEAS_AWG);

	STSEnableMeas(&VSUP_11);

	SPIWrite_SYNC(0x7C, wrdata1);
	STSAWGRun();

	SERIAL{
		burn_iq1[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		for (int i = 0; i < 100; i++)
			burnIq1[SITE][i] = VSUP_11.GetMeasResult(SITE, MIRET, i);
		burn_iq_sigma1[SITE] = sigma_cal(burnIq1[SITE], 100);
	}

		SERIAL{
		eFUSE_M_PGM_IQ->SetTestResult(SITE, 0, burn_iq[SITE] * 1e3);//scale to ma
		eFUSE_M_PGM_IQ_RMS->SetTestResult(SITE, 0, burn_iq_sigma[SITE] * 1e3);
		eFUSE_FS_PGM_IQ->SetTestResult(SITE, 0, burn_iq[SITE] * 1e3);//scale to ma
		eFUSE_FS_PGM_IQ_RMS->SetTestResult(SITE, 0, burn_iq_sigma[SITE] * 1e3);
		PROGRAM_M_Enable->SetTestResult(SITE, 0, m_burn_flag[SITE]);
		PROGRAM_FS_Enable->SetTestResult(SITE, 0, fs_burn_flag[SITE]);
	}

	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_ms(5);
	if (SC6295X[find_ID].useropt_burn==1)//for otp program
	{
		cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K54_VDDIO_PU, K58_DBG_PU, -1);//will check if need the caps.
		delay_ms(1);
		VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
		VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
		//need debug =high

		delay_ms(5);//will check delay time
		cbite.SetCbiteOn(K59_WAKE12_PU);
		delay_ms(15);
	
		//add Main OTP program;only program ,not datalog
		Enter_MAIN_UOTP_PGM();
		delay_ms(2);
		//SPIWrite(0x3F, 0x0080);
		//set working code here;
		for (int addr = 0; addr < 10; ++addr)
		{
			EE_str = "MUBANK" + to_string(addr);
			SERIAL uotpcode=dut.assy(EE_str.c_str()).get_start(SITE);
			SPIWrite(0x00+addr, uotpcode);

		}
			SPIRead(0x00, m_otp_data, 10);// ead user otp1
		//setting 0x1F
		SPIWrite(0x1F, 0x0007);
		//program..
		SPIRead(0x3E, fs_trim_data);
		SERIAL{
		if (user_otp_burn_flag[SITE])
		{
			wrdata[SITE] = 0xA500;//ecc check
		}
		else
		{
			wrdata[SITE] = 0x0000;
		}
		}
		SPIWrite(0x3E, wrdata);
		delay_ms(1);
		SPIRead(0x3E, fs_trim_data);
		SERIAL{
		if (user_otp_burn_flag[SITE])
		{
			wrdata[SITE] = 0xC300;
		}
		else
		{
			wrdata[SITE] = 0x0000;
		}
		}
		SPIWrite(0x3E, wrdata);
		//program delay 8ms
		delay_ms(12);//more time for margin
		//program fs otp
		Enter_FS_UOTP_PGM();
		delay_ms(2);
		//SPIWrite(0x7F, 0x0080);
		//set working code here;
		for (int addr = 0; addr < 5; ++addr)
		{
			EE_str = "FUBANK" + to_string(addr);
			SERIAL uotpcode = dut.assy(EE_str.c_str()).get_start(SITE);
			SPIWrite(0x40 + addr, uotpcode);

		}

		//setting 0x4F
		SPIWrite(0x4F, 0x0007);
		//program..

		SERIAL{
		if (user_otp_burn_flag[SITE])
		{
			wrdata[SITE] = 0xA500;//ecc check
		}
		else
		{
			wrdata[SITE] = 0x0000;
		}
		}
		SPIWrite(0x7E, wrdata);
		delay_ms(1);
		SERIAL{
		if (user_otp_burn_flag[SITE])
		{
			wrdata[SITE] = 0xC300;
		}
		else
		{
			wrdata[SITE] = 0x0000;
		}
		}
		SPIWrite(0x7E, wrdata);
		//program delay 8ms
		delay_ms(7);//more time for margin

		VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
		VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
		delay_ms(5);
	}


	//power down and restart

	
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K54_VDDIO_PU, K59_WAKE12_PU, -1);//will check if need the caps.
	delay_ms(1);

	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(15);//will check delay time
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();

	SPIWrite(0x3F, 0x7481);//switch to main otp table
	SPIRead(0x00, m_otp_data, 10);// ead user otp1
	SPIRead(0x20, m_trim_data, 16);//read trim data
	SPIRead(0x1F, motp_burn_data);
	SPIWrite(0x7F, 0x7481);//switch to fs otp table
	SPIRead(0x40, fs_otp_data, 5);//read fs user otp
	SPIRead(0x50, fs_trim_data);//read trim data
	SPIRead(0x4F, fsotp_burn_data);
	SERIAL
	{
		program_vs_read[SITE] = 0;
		start_vs_read_opt[SITE] = 0;
	}
	SERIAL
	{

		// main
		for (int addr = 0; addr < BANK_NUM - 1; ++addr)
		{

			EE_str = "MBANK" + to_string(addr);
			dut.assy(EE_str.c_str()).set_read_back((m_trim_data[addr][SITE]), SITE);
			program_vs_read[SITE] += dut.assy(EE_str.c_str()).comp_prog_to_read(SITE);


			EE_Reads[addr]->SetTestResult(SITE, 0, m_trim_data[addr][SITE]);
			EE_Params[addr]->SetTestResult(SITE, 0, dut.assy(EE_str.c_str()).get_programmed(SITE));

			for (unsigned int node_no = 0; node_no < dut.assy(EE_str.c_str()).count(); ++node_no){
				string node_name(dut.assy(EE_str.c_str())[node_no].get_node_name());

				if (dut.find(node_name.c_str()) == FOUND_TRIM)									// judge if it is trim node, not sel node
					node_map[SITE][node_name] = dut.trim(node_name.c_str()).get_read_back(SITE);
				else if (dut.find(node_name.c_str()) == FOUND_SEL)
				{
					node_map[SITE][node_name] = dut.sel(node_name.c_str()).get_read_back(SITE);
					if ((strcmp(node_name.c_str(), "DIEID_X") != 0) && (strcmp(node_name.c_str(), "DIEID_Y") != 0) && (strcmp(node_name.c_str(), "WAFER_ID") != 0))
						start_vs_read_opt[SITE] += dut.sel(node_name.c_str()).get_read_back(SITE) ^ dut.sel(node_name.c_str()).get_start(SITE);//should 0

				}
			}
		}

		//fs
		EE_str = "FSBANK0";
		dut.assy(EE_str.c_str()).set_read_back((fs_trim_data[SITE]), SITE);
		program_vs_read[SITE] += dut.assy(EE_str.c_str()).comp_prog_to_read(SITE);
		EE_Reads[BANK_NUM - 1]->SetTestResult(SITE, 0, fs_trim_data[SITE]);
		EE_Params[BANK_NUM - 1]->SetTestResult(SITE, 0, dut.assy(EE_str.c_str()).get_programmed(SITE));


		for (unsigned int node_no = 0; node_no < dut.assy(EE_str.c_str()).count(); ++node_no){
			string node_name(dut.assy(EE_str.c_str())[node_no].get_node_name());

			if (dut.find(node_name.c_str()) == FOUND_TRIM)									// judge if it is trim node, not sel node
				node_map[SITE][node_name] = dut.trim(node_name.c_str()).get_read_back(SITE);
			else if (dut.find(node_name.c_str()) == FOUND_SEL)
			{
				node_map[SITE][node_name] = dut.sel(node_name.c_str()).get_read_back(SITE);

				if((strcmp(node_name.c_str(),"DIEID_X")!=0) && (strcmp(node_name.c_str(), "DIEID_Y") != 0) && (strcmp(node_name.c_str(), "WAFER_ID") != 0))
				start_vs_read_opt[SITE] += dut.sel(node_name.c_str()).get_read_back(SITE) ^ dut.sel(node_name.c_str()).get_start(SITE);//should 0

			}

		}
	}
		for (map<unsigned int, map<string, unsigned int>>::iterator it_site = node_map.begin(); it_site != node_map.end(); ++it_site){
			for (map<string, unsigned int>::iterator it_node = it_site->second.begin(); it_node != it_site->second.end(); ++it_node){
				if (it_node->first.find("dummy") != string::npos)	continue;

				string param_str = it_node->first + "_FINAL";
				StsGetParam(funcindex, param_str.c_str())->SetTestResult(it_site->first, 0, it_node->second);
			}
		}
		SERIAL{
			PGM_READ_COMP->SetTestResult(SITE, 0, program_vs_read[SITE]);
			START_VS_READ_OPT1->SetTestResult(SITE, 0, start_vs_read_opt[SITE]);
		}

		SERIAL{
			if(SC6295X[find_ID].useropt_burn==0)
			{
	

				for (int addr = 0; addr < 10; ++addr)
					StsGetParam(funcindex, m_param_str_array1[addr].c_str())->SetTestResult(SITE, 0, m_otp_data[addr][SITE]);
				for (int addr = 0; addr < 5; ++addr)
					StsGetParam(funcindex, fs_param_str_array1[addr].c_str())->SetTestResult(SITE, 0, fs_otp_data[addr][SITE]);
	

			}
			else
			{
			
				for (int addr = 0; addr < 10; ++addr)
				{
					EE_str = "MUBANK" + to_string(addr);
					uotpcode=dut.assy(EE_str.c_str()).get_start(SITE);
					StsGetParam(funcindex, m_param_str_array1[addr].c_str())->SetTestResult(SITE, 0, m_otp_data[addr][SITE] ^ uotpcode);
				}
					
				for (int addr = 0; addr < 5; ++addr)
				{
						EE_str = "FUBANK" + to_string(addr);
					uotpcode=dut.assy(EE_str.c_str()).get_start(SITE);
					StsGetParam(funcindex, fs_param_str_array1[addr].c_str())->SetTestResult(SITE, 0, fs_otp_data[addr][SITE]^ uotpcode);
				}

		
			}
	
			if(SC6295X[find_ID].useropt_burn==0)
			{
				M_UOTP_BURN_F->SetTestResult(SITE, 0, motp_burn_data[SITE]);
				FS_UOTP_BURN_F->SetTestResult(SITE, 0, fsotp_burn_data[SITE]);
			}
			else
			{
				M_UOTP_BURN_F1->SetTestResult(SITE, 0, motp_burn_data[SITE]);
				FS_UOTP_BURN_F1->SetTestResult(SITE, 0, fsotp_burn_data[SITE]);
			}

		}
		VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

		VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);

		delay_ms(5);
		power_off(1);
		efmea.fmea_checking(funcindex);
		return 0;
	
}

DUT_API int T24_TEST_SCANCHAIN(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam* MLOGIC_STUCKAT = StsGetParam(funcindex, "MLOGIC_STUCKAT");
	CParam* MLOGIC_STUCKAT_VBOXL = StsGetParam(funcindex, "MLOGIC_STUCKAT_VBOXL");
	CParam* MLOGIC_STUCKAT_VBOXH = StsGetParam(funcindex, "MLOGIC_STUCKAT_VBOXH");
	CParam* MLOGIC_STUCKAT_NORMAL_V = StsGetParam(funcindex, "MLOGIC_STUCKAT_NORMAL_V");
	CParam* MLOGIC_STUCKAT_NORMAL_I = StsGetParam(funcindex, "MLOGIC_STUCKAT_NORMAL_I");
	CParam* MLOGIC_STUCKAT_VBOXL_V = StsGetParam(funcindex, "MLOGIC_STUCKAT_VBOXL_V");
	CParam* MLOGIC_STUCKAT_VBOXL_I = StsGetParam(funcindex, "MLOGIC_STUCKAT_VBOXL_I");
	CParam* MLOGIC_STUCKAT_VBOXH_V = StsGetParam(funcindex, "MLOGIC_STUCKAT_VBOXH_V");
	CParam* MLOGIC_STUCKAT_VBOXH_I = StsGetParam(funcindex, "MLOGIC_STUCKAT_VBOXH_I");
	CParam* MSCAN_STUCKAT = StsGetParam(funcindex, "MSCAN_STUCKAT");
	CParam* MSCAN_STUCKAT_V = StsGetParam(funcindex, "MSCAN_STUCKAT_V");
	CParam* MSCAN_STUCKAT_I = StsGetParam(funcindex, "MSCAN_STUCKAT_I");
	CParam* MSCAN_IDDQ_PRE = StsGetParam(funcindex,  "MSCAN_IDDQ_PRE");
	CParam* MSCAN_IDDQ_POST = StsGetParam(funcindex, "MSCAN_IDDQ_POST");
	CParam* MSCAN_IDDQ_PRE1 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE1");
	CParam* MSCAN_IDDQ_PRE2 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE2");
	CParam* MSCAN_IDDQ_PRE3 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE3");
	CParam* MSCAN_IDDQ_PRE4 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE4");
	CParam* MSCAN_IDDQ_PRE5 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE5");
	CParam* MSCAN_IDDQ_PRE6 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE6");
	CParam* MSCAN_IDDQ_PRE7 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE7");
	CParam* MSCAN_IDDQ_PRE8 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE8");
	CParam* MSCAN_IDDQ_PRE9 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE9");
	CParam* MSCAN_IDDQ_PRE10 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE10");
	CParam* MSCAN_IDDQ_PRE11 = StsGetParam(funcindex, "MSCAN_IDDQ_PRE11");
	CParam* MSCAN_IDDQ_PRE_Delta = StsGetParam(funcindex, "MSCAN_IDDQ_PRE_Delta");
	CParam* MSCAN_IDDQ_POST1 = StsGetParam(funcindex, "MSCAN_IDDQ_POST1");
	CParam* MSCAN_IDDQ_POST2 = StsGetParam(funcindex, "MSCAN_IDDQ_POST2");
	CParam* MSCAN_IDDQ_POST3 = StsGetParam(funcindex, "MSCAN_IDDQ_POST3");
	CParam* MSCAN_IDDQ_POST4 = StsGetParam(funcindex, "MSCAN_IDDQ_POST4");
	CParam* MSCAN_IDDQ_POST5 = StsGetParam(funcindex, "MSCAN_IDDQ_POST5");
	CParam* MSCAN_IDDQ_POST6 = StsGetParam(funcindex, "MSCAN_IDDQ_POST6");
	CParam* MSCAN_IDDQ_POST7 = StsGetParam(funcindex, "MSCAN_IDDQ_POST7");
	CParam* MSCAN_IDDQ_POST8 = StsGetParam(funcindex, "MSCAN_IDDQ_POST8");
	CParam* MSCAN_IDDQ_POST9 = StsGetParam(funcindex, "MSCAN_IDDQ_POST9");
	CParam* MSCAN_IDDQ_POST10 = StsGetParam(funcindex, "MSCAN_IDDQ_POST10");
	CParam* MSCAN_IDDQ_POST11 = StsGetParam(funcindex, "MSCAN_IDDQ_POST11");
	CParam* MSCAN_IDDQ_POST_Delta = StsGetParam(funcindex, "MSCAN_IDDQ_POST_Delta");
	CParam* MSCAN_IDDQ_PREPOST_Delta1 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta1");
	CParam* MSCAN_IDDQ_PREPOST_Delta2 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta2");
	CParam* MSCAN_IDDQ_PREPOST_Delta3 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta3");
	CParam* MSCAN_IDDQ_PREPOST_Delta4 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta4");
	CParam* MSCAN_IDDQ_PREPOST_Delta5 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta5");
	CParam* MSCAN_IDDQ_PREPOST_Delta6 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta6");
	CParam* MSCAN_IDDQ_PREPOST_Delta7 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta7");
	CParam* MSCAN_IDDQ_PREPOST_Delta8 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta8");
	CParam* MSCAN_IDDQ_PREPOST_Delta9 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta9");
	CParam* MSCAN_IDDQ_PREPOST_Delta10 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta10");
	CParam* MSCAN_IDDQ_PREPOST_Delta11 = StsGetParam(funcindex, "MSCAN_IDDQ_PREPOST_Delta11");
	CParam* FSLOGIC_STUCKAT = StsGetParam(funcindex, "FSLOGIC_STUCKAT");
	CParam* FSLOGIC_STUCKAT_VBOXL = StsGetParam(funcindex, "FSLOGIC_STUCKAT_VBOXL");
	CParam* FSLOGIC_STUCKAT_VBOXH = StsGetParam(funcindex, "FSLOGIC_STUCKAT_VBOXH");
	CParam* FSLOGIC_STUCKAT_NORMAL_V = StsGetParam(funcindex, "FSLOGIC_STUCKAT_NORMAL_V");
	CParam* FSLOGIC_STUCKAT_NORMAL_I = StsGetParam(funcindex, "FSLOGIC_STUCKAT_NORMAL_I");
	CParam* FSLOGIC_STUCKAT_VBOXL_V = StsGetParam(funcindex, "FSLOGIC_STUCKAT_VBOXL_V");
	CParam* FSLOGIC_STUCKAT_VBOXL_I = StsGetParam(funcindex, "FSLOGIC_STUCKAT_VBOXL_I");
	CParam* FSLOGIC_STUCKAT_VBOXH_V = StsGetParam(funcindex, "FSLOGIC_STUCKAT_VBOXH_V");
	CParam* FSLOGIC_STUCKAT_VBOXH_I = StsGetParam(funcindex, "FSLOGIC_STUCKAT_VBOXH_I");	
	CParam* FSSCAN_STUCKAT = StsGetParam(funcindex, "FSSCAN_STUCKAT");
	CParam* FSSCAN_STUCKAT_V = StsGetParam(funcindex, "FSSCAN_STUCKAT_V");
	CParam* FSSCAN_STUCKAT_I = StsGetParam(funcindex, "FSSCAN_STUCKAT_I");
	CParam* FSSCAN_IDDQ_PRE = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE");
	CParam* FSSCAN_IDDQ_POST = StsGetParam(funcindex, "FSSCAN_IDDQ_POST");
	CParam* FSSCAN_IDDQ_PRE1 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE1");
	CParam* FSSCAN_IDDQ_PRE2 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE2");
	CParam* FSSCAN_IDDQ_PRE3 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE3");
	CParam* FSSCAN_IDDQ_PRE4 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE4");
	CParam* FSSCAN_IDDQ_PRE5 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE5");
	CParam* FSSCAN_IDDQ_PRE6 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE6");
	CParam* FSSCAN_IDDQ_PRE7 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE7");
	CParam* FSSCAN_IDDQ_PRE8 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE8");
	CParam* FSSCAN_IDDQ_PRE9 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE9");
	CParam* FSSCAN_IDDQ_PRE10 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE10");
	CParam* FSSCAN_IDDQ_PRE11 = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE11");
	CParam* FSSCAN_IDDQ_PRE_Delta = StsGetParam(funcindex, "FSSCAN_IDDQ_PRE_Delta");
	CParam* FSSCAN_IDDQ_POST1 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST1");
	CParam* FSSCAN_IDDQ_POST2 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST2");
	CParam* FSSCAN_IDDQ_POST3 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST3");
	CParam* FSSCAN_IDDQ_POST4 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST4");
	CParam* FSSCAN_IDDQ_POST5 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST5");
	CParam* FSSCAN_IDDQ_POST6 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST6");
	CParam* FSSCAN_IDDQ_POST7 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST7");
	CParam* FSSCAN_IDDQ_POST8 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST8");
	CParam* FSSCAN_IDDQ_POST9 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST9");
	CParam* FSSCAN_IDDQ_POST10 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST10");
	CParam* FSSCAN_IDDQ_POST11 = StsGetParam(funcindex, "FSSCAN_IDDQ_POST11");
	CParam* FSSCAN_IDDQ_POST_Delta = StsGetParam(funcindex, "FSSCAN_IDDQ_POST_Delta");
	CParam* FSSCAN_IDDQ_PREPOST_Delta1 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta1");
	CParam* FSSCAN_IDDQ_PREPOST_Delta2 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta2");
	CParam* FSSCAN_IDDQ_PREPOST_Delta3 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta3");
	CParam* FSSCAN_IDDQ_PREPOST_Delta4 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta4");
	CParam* FSSCAN_IDDQ_PREPOST_Delta5 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta5");
	CParam* FSSCAN_IDDQ_PREPOST_Delta6 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta6");
	CParam* FSSCAN_IDDQ_PREPOST_Delta7 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta7");
	CParam* FSSCAN_IDDQ_PREPOST_Delta8 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta8");
	CParam* FSSCAN_IDDQ_PREPOST_Delta9 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta9");
	CParam* FSSCAN_IDDQ_PREPOST_Delta10 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta10");
	CParam* FSSCAN_IDDQ_PREPOST_Delta11 = StsGetParam(funcindex, "FSSCAN_IDDQ_PREPOST_Delta11");
	//}}AFX_STS_PARAM_PROTOTYPES



	double vdd = 5.0;
	//	double vres[SITE_NUM];
	double ires[SITE_NUM];
	double vres[SITE_NUM];
	double ipre[19][SITE_NUM];
	double ipost[19][SITE_NUM];
	double idelta[19][SITE_NUM];
	ULONG failcount[SITE_NUM] = { 99};
	ULONG rdata[SITE_NUM];
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K54_VDDIO_PU, K59_WAKE12_PU, /*K58_DBG_PU, */K18_FIN_DCM, K8_SCL_SDA_DCM, -1);//will check if need the caps.
	delay_ms(1);
	SPIInitial(5.0, 0, 1.6, 1.5, 200);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time
	//	VBOS_1.MeasureVI(1000, 10);
	delay_ms(5);//will check delay time
	Enter_MAIN_SCAN_DIG();
	delay_ms(1);
	//Enter_FS_TM_DIG();
//	SPIRead(0x00, rdata);
	SPIWrite(0x3D, 0x0003); //
//	SPIRead(0x00, rdata);
	//dcm.Disconnect("SPI_G");
	dcm.Connect("SCAN_PINS");
	
	//VBOX L
	vdd = 5.0;
	VSUP_11.Set(FV, 12, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time


	delay_us(1000);
	SCAN_TEST(VBOS_1, 5.2, "SCAN_PINS", "MISO_D", "MTS2_START", "MTS2_STOP", 2000, 210, ires, vres, failcount);
	dcm.SaveFailMap(0);
	SERIAL
	{
		MLOGIC_STUCKAT_VBOXL_V->SetTestResult(SITE, 0, vres[SITE]);
		MLOGIC_STUCKAT_VBOXL_I->SetTestResult(SITE, 0, ires[SITE] * 1e3);
		MLOGIC_STUCKAT_VBOXL->SetTestResult(SITE, 0, failcount[SITE]);

	}
	vdd = 5.0;
	//VBOX NORMAL
	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time
	VSUP_11.Set(FV, 12, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_us(1000);
	SCAN_TEST(VBOS_1, 5.2, "SCAN_PINS", "MISO_D", "MTS1_START", "MTS1_STOP", 300, 10, ires, vres, failcount);
	SERIAL
	{
		MSCAN_STUCKAT_V->SetTestResult(SITE, 0, vres[SITE]);
		MSCAN_STUCKAT_I->SetTestResult(SITE, 0, ires[SITE] * 1e3);
		MSCAN_STUCKAT->SetTestResult(SITE, 0, failcount[SITE]);

	}
	delay_us(1000);
	//VBOX NORMAL
//	if (test_stage == 1)
//	{
	SCAN_TEST(VBOS_1, vdd, "SCAN_PINS", "MISO_D", "MTS2_START", "MTS2_STOP", 2000, 210, ires, vres, failcount);

	SERIAL
	{
		MLOGIC_STUCKAT_NORMAL_V->SetTestResult(SITE, 0, vres[SITE]);
		MLOGIC_STUCKAT_NORMAL_I->SetTestResult(SITE, 0, ires[SITE] * 1e3);
		MLOGIC_STUCKAT->SetTestResult(SITE, 0, failcount[SITE]);

	}
	//}
	VBOS_1.Set(FV, 5.25, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time
	//VSUP_11.Set(FV, 6.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);

	vdd = 5.25;
	string start;
	string stop;
	string paraname;
	string paradelta;
	ULONG failcount_iddq[SITE_NUM];
	int starnum = 1;
	int stopnum = 11;
	//dcm.SetPinLevel("SCAN_PINS", 4.0, 0, 2.4, 1.0);
	for (int i = starnum; i < (stopnum + 1); i++)
	{
		if (i == starnum)
			start = "MIDDQ_START";
		else
			start = "MIDDQ" + to_string(i - 1);
		if (i == stopnum)
			stop = "MIDDQ_STOP";
		else
			stop = "MIDDQ" + to_string(i);
		paraname = "MSCAN_IDDQ_PRE" + to_string(i);

		SCAN_TEST(VBOS_1, vdd, "SCAN_PINS", "MISO_D", start.c_str(), stop.c_str(), 30, 10, ires, vres, failcount, 1);

		SERIAL{
			StsGetParam(funcindex, paraname.c_str())->SetTestResult(SITE, 0, ires[SITE] * 1e6);
			if (i == starnum)
			{
				failcount_iddq[SITE] = failcount[SITE];
			}
			else
			{

				failcount_iddq[SITE] += failcount[SITE];
			}
			ipre[i][SITE] = ires[SITE];
		}
	}
	SERIAL{

		MSCAN_IDDQ_PRE->SetTestResult(SITE, 0, failcount_iddq[SITE]);
	}
		//VBOX H
	vdd = 5.25;
	VBOS_1.Set(FV, vdd, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON,1.0);//will check VBOS startup time
	//VSUP_11.Set(FV, vdd, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);

	delay_us(1000);
	SCAN_TEST(VBOS_1, vdd, "SCAN_PINS", "MISO_D", "MTS2_START", "MTS2_STOP", 2000, 210, ires, vres, failcount);

	SERIAL
	{
		MLOGIC_STUCKAT_VBOXH_V->SetTestResult(SITE, 0, vres[SITE]);
		MLOGIC_STUCKAT_VBOXH_I->SetTestResult(SITE, 0, ires[SITE] * 1e3);
		MLOGIC_STUCKAT_VBOXH->SetTestResult(SITE, 0, failcount[SITE]);

	}
	vdd = 5.25;
//	VSUP_11.Set(FV, 6.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	VBOS_1.Set(FV, vdd, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON,1.0);//will check VBOS startup time



	delay_us(1000);

	for (int i = starnum; i < (stopnum + 1); i++)
	{
		if (i == starnum)
			start = "MIDDQ_START";
		else
			start = "MIDDQ" + to_string(i - 1);
		if (i == stopnum)
			stop = "MIDDQ_STOP";
		else
			stop = "MIDDQ" + to_string(i);
		paraname = "MSCAN_IDDQ_POST" + to_string(i);
		paradelta = "MSCAN_IDDQ_PREPOST_Delta" + to_string(i);
		SCAN_TEST(VBOS_1, vdd, "SCAN_PINS", "MISO_D", start.c_str(), stop.c_str(), 30, 10, ires, vres, failcount, 1);

		SERIAL{
			StsGetParam(funcindex, paraname.c_str())->SetTestResult(SITE, 0, ires[SITE] * 1e6);
			if (i == starnum)
			{
				failcount_iddq[SITE] = failcount[SITE];
			}
			else
			{

				failcount_iddq[SITE] += failcount[SITE];
			}
			ipost[i][SITE] = ires[SITE];
			idelta[i][SITE] = ipost[i][SITE] - ipre[i][SITE];

			StsGetParam(funcindex, paradelta.c_str())->SetTestResult(SITE, 0, idelta[i][SITE] * 1e6);
		}
	}
	SERIAL{

		MSCAN_IDDQ_POST->SetTestResult(SITE, 0, failcount_iddq[SITE]);
	}

	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	VBOS_1.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time
	VDDIO_VBOOST_0.Set(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(15);
	SPIInitial(5.0, 0, 1.6, 1.5, 100);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time
	//	VBOS_1.MeasureVI(1000, 10);
	delay_ms(15);//will check delay time
	//Enter_MAIN_TM_DIG();
	//Enter_FS_TM_DIG();
	//SPIRead(0x00, rdata);
	Enter_FS_SCAN_DIG();

	//SPIWrite(0x7C, 0x00C0);//f_efuse_vdd_alwayson=1,force_vbos2vreg3=1 connect dvdd2 to vbos for scan test and stres
	//delay_ms(1);
	//SPIWrite(0x7F, 0x7400);
	delay_ms(1);
	SPIWrite(0x7D, 0x0003); //scan fs
	//SPIRead(0x00, rdata);
	dcm.Connect("SCAN_PINS");
	
	//VBOX L
	vdd = 5.0;
//	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time


	delay_us(1000);
	SCAN_TEST(VBOS_1, 5.2, "SCAN_PINS", "MISO_D", "FSTS2_START", "FSTS2_STOP", 2000, 110, ires, vres, failcount);
	dcm.SaveFailMap(0);
	SERIAL
	{
		FSLOGIC_STUCKAT_VBOXL_V->SetTestResult(SITE, 0, vres[SITE]);
		FSLOGIC_STUCKAT_VBOXL_I->SetTestResult(SITE, 0, ires[SITE] * 1e3);
		FSLOGIC_STUCKAT_VBOXL->SetTestResult(SITE, 0, failcount[SITE]);

	}
	vdd = 5.2;
	//VBOX NORMAL
	VBOS_1.Set(FV, vdd, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time
	//VSUP_11.Set(FV, vdd, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	delay_us(1000);
	SCAN_TEST(VBOS_1, vdd, "SCAN_PINS", "MISO_D", "FSTS1_START", "FSTS1_STOP", 300, 10, ires, vres, failcount);
	SERIAL
	{
		FSSCAN_STUCKAT_V->SetTestResult(SITE, 0, vres[SITE]);
		FSSCAN_STUCKAT_I->SetTestResult(SITE, 0, ires[SITE] * 1e3);
		FSSCAN_STUCKAT->SetTestResult(SITE, 0, failcount[SITE]);

	}
	delay_us(1000);
	//VBOX NORMAL
//	if (test_stage == 1)
//	{
	SCAN_TEST(VBOS_1, vdd, "SCAN_PINS", "MISO_D", "FSTS2_START", "FSTS2_STOP", 2000, 110, ires, vres, failcount);

	SERIAL
	{
		FSLOGIC_STUCKAT_NORMAL_V->SetTestResult(SITE, 0, vres[SITE]);
		FSLOGIC_STUCKAT_NORMAL_I->SetTestResult(SITE, 0, ires[SITE] * 1e3);
		FSLOGIC_STUCKAT->SetTestResult(SITE, 0, failcount[SITE]);

	}
	//}
	VBOS_1.Set(FV, 5.25, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time
	//VSUP_11.Set(FV, 6.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);

	vdd = 5.25;
	//string start;
	//string stop;
	//string paraname;
	//string paradelta;
	//ULONG failcount_iddq[SITE_NUM];
	 starnum = 1;
	 stopnum = 11;
	//dcm.SetPinLevel("SCAN_PINS", 4.0, 0, 2.4, 1.0);
	for (int i = starnum; i < (stopnum + 1); i++)
	{
		if (i == starnum)
			start = "FSIDDQ_START";
		else
			start = "FSIDDQ" + to_string(i - 1);
		if (i == stopnum)
			stop = "FSIDDQ_STOP";
		else
			stop = "FSIDDQ" + to_string(i);
		paraname = "FSSCAN_IDDQ_PRE" + to_string(i);

		SCAN_TEST(VBOS_1, vdd, "SCAN_PINS", "MISO_D", start.c_str(), stop.c_str(), 30, 10, ires, vres, failcount, 1);

		SERIAL{
			StsGetParam(funcindex, paraname.c_str())->SetTestResult(SITE, 0, ires[SITE] * 1e6);
			if (i == starnum)
			{
				failcount_iddq[SITE] = failcount[SITE];
			}
			else
			{

				failcount_iddq[SITE] += failcount[SITE];
			}
			ipre[i][SITE] = ires[SITE];
		}
	}
	SERIAL{

		FSSCAN_IDDQ_PRE->SetTestResult(SITE, 0, failcount_iddq[SITE]);
	}
		//VBOX H
	vdd = 6.0;
	VBOS_1.Set(FV, vdd, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time
	//VSUP_11.Set(FV, vdd, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);

	delay_us(1000);
	SCAN_TEST(VBOS_1, vdd, "SCAN_PINS", "MISO_D", "FSTS2_START", "FSTS2_STOP", 2000, 110, ires, vres, failcount);

	SERIAL
	{
		FSLOGIC_STUCKAT_VBOXH_V->SetTestResult(SITE, 0, vres[SITE]);
		FSLOGIC_STUCKAT_VBOXH_I->SetTestResult(SITE, 0, ires[SITE] * 1e3);
		FSLOGIC_STUCKAT_VBOXH->SetTestResult(SITE, 0, failcount[SITE]);

	}
	vdd = 5.25;
//	VSUP_11.Set(FV, 6.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	VBOS_1.Set(FV, vdd, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//will check VBOS startup time



	delay_us(1000);

	for (int i = starnum; i < (stopnum + 1); i++)
	{
		if (i == starnum)
			start = "FSIDDQ_START";
		else
			start = "FSIDDQ" + to_string(i - 1);
		if (i == stopnum)
			stop = "FSIDDQ_STOP";
		else
			stop = "FSIDDQ" + to_string(i);
		paraname = "FSSCAN_IDDQ_POST" + to_string(i);
		paradelta = "FSSCAN_IDDQ_PREPOST_Delta" + to_string(i);
		SCAN_TEST(VBOS_1, vdd, "SCAN_PINS", "MISO_D", start.c_str(), stop.c_str(), 30, 10, ires, vres, failcount, 1);

		SERIAL{
			StsGetParam(funcindex, paraname.c_str())->SetTestResult(SITE, 0, ires[SITE] * 1e6);
			if (i == starnum)
			{
				failcount_iddq[SITE] = failcount[SITE];
			}
			else
			{

				failcount_iddq[SITE] += failcount[SITE];
			}
			ipost[i][SITE] = ires[SITE];
			idelta[i][SITE] = ipost[i][SITE] - ipre[i][SITE];

			StsGetParam(funcindex, paradelta.c_str())->SetTestResult(SITE, 0, idelta[i][SITE] * 1e6);
		}
	}
	SERIAL{

		FSSCAN_IDDQ_POST->SetTestResult(SITE, 0, failcount_iddq[SITE]);
	}
	power_off(1);
	// TODO: Add your function code here


	return 0;
}

DUT_API int T25_POWER_SUPPLY_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam *ISUP_OFF_12V = StsGetParam(funcindex, "ISUP_OFF_12V");
	CParam *ISUP_OFF_40V = StsGetParam(funcindex, "ISUP_OFF_40V");
	CParam *ISUP_READY_12V = StsGetParam(funcindex, "ISUP_READY_12V");
	CParam *ISUP_READY_12V_TM = StsGetParam(funcindex, "ISUP_READY_12V_TM");

	CParam *VSUP_UV7_F = StsGetParam(funcindex, "VSUP_UV7_F");
	CParam *VSUP_UV7_R = StsGetParam(funcindex, "VSUP_UV7_R");
	CParam *VSUP_UV7_HYS = StsGetParam(funcindex, "VSUP_UV7_HYS");
	CParam *VSUP_UVH_R_0x00 = StsGetParam(funcindex, "VSUP_UVH_R_0x00");
	CParam *VSUP_UVH_F_0x00 = StsGetParam(funcindex, "VSUP_UVH_F_0x00");
	CParam *VSUP_UVH_HYS_0x00 = StsGetParam(funcindex, "VSUP_UVH_HYS_0x00");
	CParam *VSUP_UVH_R_0x01 = StsGetParam(funcindex, "VSUP_UVH_R_0x01");
	CParam *VSUP_UVH_F_0x01 = StsGetParam(funcindex, "VSUP_UVH_F_0x01");
	CParam *VSUP_UVH_HYS_0x01 = StsGetParam(funcindex, "VSUP_UVH_HYS_0x01");

	CParam *VSUP_UVL_R_0x00 = StsGetParam(funcindex, "VSUP_UVL_R_0x00");
	CParam *VSUP_UVL_F_0x00 = StsGetParam(funcindex, "VSUP_UVL_F_0x00");
	CParam *VSUP_UVL_HYS_0x00 = StsGetParam(funcindex, "VSUP_UVL_HYS_0x00");
	CParam *VSUP_UVL_R_0x01 = StsGetParam(funcindex, "VSUP_UVL_R_0x01");
	CParam *VSUP_UVL_F_0x01 = StsGetParam(funcindex, "VSUP_UVL_F_0x01");
	CParam *VSUP_UVL_HYS_0x01 = StsGetParam(funcindex, "VSUP_UVL_HYS_0x01");

	CParam *ISUP_OFF_60V = StsGetParam(funcindex, "ISUP_OFF_60V");

	CParam *ISUP_OFF_65V = StsGetParam(funcindex, "ISUP_OFF_65V");
	CParam *WAKE12_LEAK_0V = StsGetParam(funcindex, "WAKE12_LEAK_0V");
	CParam* PRESW_LEAK_0V = StsGetParam(funcindex, "PRESW_LEAK_0V");
	CParam* PREBOOT_LEAK_0V = StsGetParam(funcindex, "PREBOOT_LEAK_0V");
	CParam* PRESW_LEAK_65V = StsGetParam(funcindex, "PRESW_LEAK_65V");
	CParam* PREBOOT_LEAK_70V = StsGetParam(funcindex, "PREBOOT_LEAK_70V");



	CParam* WAKE1_LEAK_36V_AMUX_R34 = StsGetParam(funcindex, "WAKE1_LEAK_36V_AMUX_R34");
	CParam* AMUX_R_WAKE1_BRIDGE = StsGetParam(funcindex, "AMUX_R_WAKE1_BRIDGE");

	CParam *WAKE1_LEAK_36V = StsGetParam(funcindex, "WAKE1_LEAK_36V");
	CParam *WAKE1_Ratio34_36V = StsGetParam(funcindex, "WAKE1_Ratio34_36V");

	CParam *ISUP_READY_36V = StsGetParam(funcindex, "ISUP_READY_36V");
	CParam *WAKE2_LEAK_36V = StsGetParam(funcindex, "WAKE2_LEAK_36V");
	CParam *WAKE2_Ratio20_36V = StsGetParam(funcindex, "WAKE2_Ratio20_36V");

	CParam* WAKE2_LEAK_36V_AMUX_R34 = StsGetParam(funcindex, "WAKE2_LEAK_36V_AMUX_R34");
	CParam* AMUX_R_WAKE2_BRIDGE = StsGetParam(funcindex, "AMUX_R_WAKE2_BRIDGE");

	CParam *WAKE1_LEAK_60V = StsGetParam(funcindex, "WAKE1_LEAK_60V");
	CParam *ISUP_READY_60V = StsGetParam(funcindex, "ISUP_READY_60V");
	CParam *WAKE2_LEAK_60V = StsGetParam(funcindex, "WAKE2_LEAK_60V");

	CParam* AMUX_VSUP60V_R34_V = StsGetParam(funcindex, "AMUX_VSUP60V_R34_V");
	CParam* AMUX_VSUP60V_R34 = StsGetParam(funcindex, "AMUX_VSUP60V_R34");
	CParam* AMUX_VSUP60V_R34_OS = StsGetParam(funcindex, "AMUX_VSUP60V_R34_OS");
	CParam* AMUX_VSUP60V_R20_V = StsGetParam(funcindex, "AMUX_VSUP60V_R20_V");
	CParam* AMUX_VSUP60V_R20 = StsGetParam(funcindex, "AMUX_VSUP60V_R20");
	CParam* AMUX_VSUP60V_R20_OS = StsGetParam(funcindex, "AMUX_VSUP60V_R20_OS");

	CParam *VSUP_OVP_R = StsGetParam(funcindex, "VSUP_OVP_R");
	CParam *VSUP_OVP_F = StsGetParam(funcindex, "VSUP_OVP_F");
	CParam *VSUP_OVP_HYS = StsGetParam(funcindex, "VSUP_OVP_HYS");


	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM] = {0};
	double res1[SITE_NUM] = { 0 };
	double res2[SITE_NUM] = { 0 };
	ULONG data0 = 0x0000;
	ULONG rdata[SITE_NUM] = { 0 };
	cbite.SetOn(K24_VDDIO_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, K21_PADF_AGNDF ,- 1);
	delay_ms(1);
	if (DEBUG)	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100UA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0.0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	delay_ms(5);
	VSUP_11.MeasureVI(30,10);
	
	SERIAL
	{
		results[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		
		ISUP_OFF_12V->SetTestResult(SITE, 0, results[SITE] * 1e6);//uA
	}

	VSUP_11.Set(FV, 40.0, ACM200_40V, ACM200_100UA, ACM200_RELAY_ON,1.0);

	delay_ms(6);
	VSUP_11.MeasureVI(30, 10);

	SERIAL
	{
		results[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);

		ISUP_OFF_40V->SetTestResult(SITE, 0, results[SITE] * 1e6);//uA
	}
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(1);



	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K32_INTB_FXVIA, K110_FXVI3_9_A, K54_VDDIO_PU, K59_WAKE12_PU, K56_INTB_PU,K57_FS0B_PSYNC_PU, -1);
	delay_ms(1);
	//test Isup ready, need to check setup & test more voltages
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(14);
	VSUP_11.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);

		ISUP_READY_12V->SetTestResult(SITE, 0, results[SITE] * 1e3);//mA
	}
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	delay_ms(1);
	//SPIWrite(0x3F, 0x7403);//switch to main otp
	//SPIWrite(0x7F, 0x7403);//switch to main otp
	VSUP_11.MeasureVI(30, 10);//with spi
	SERIAL
	{
		results[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);

		ISUP_READY_12V_TM->SetTestResult(SITE, 0, results[SITE] * 1e3);//mA
	}
	SPIWrite(0x3F, 0x7481);//switch to main otp
	Enter_M_TM(0x0021, 0x0000, 0x0000);
	VSUP_11.Set(FV, 8.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	awg.rampv2(VSUP_11, A3_INTB, ACM200_20V, ACM200_100MA, "vsup_uv7_f", 8.0, 7.0, 7.0, 8.0, 0.005, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{
		VSUP_UV7_F->SetTestResult(SITE, 0, res1[SITE]);
		VSUP_UV7_R->SetTestResult(SITE, 0, res2[SITE]);
		VSUP_UV7_HYS->SetTestResult(SITE, 0, res2[SITE] - res1[SITE]);
	}
	Enter_M_TM(0x0031, 0x0000, 0x0000);
	SPIWrite(0x08, data0);
	VSUP_11.Set(FV, 4.4, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON,1.0);
	awg.rampv2(VSUP_11, A3_INTB, ACM200_20V, ACM200_100MA, "Vsup_uvh1", 4.4, 5.4, 5.4, 4.4, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);

	SERIAL
	{
		VSUP_UVH_R_0x00->SetTestResult(SITE, 0, res1[SITE]);
		VSUP_UVH_F_0x00->SetTestResult(SITE, 0, res2[SITE]);
		VSUP_UVH_HYS_0x00->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	SPIWrite(0x08, 0x8000);
	awg.rampv2(VSUP_11, A3_INTB, ACM200_20V, ACM200_100MA, "Vsup_uvh2", 5.7, 6.7, 6.7, 5.7, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);

	SERIAL
	{
		VSUP_UVH_R_0x01->SetTestResult(SITE, 0, res1[SITE]);
		VSUP_UVH_F_0x01->SetTestResult(SITE, 0, res2[SITE]);
		VSUP_UVH_HYS_0x01->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	SPIWrite(0x08, data0);

	Enter_M_TM(0x0041, 0x0000, 0x0000);
	VSUP_11.Set(FV, 3.8, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	awg.rampv2(VSUP_11, A3_INTB, ACM200_20V, ACM200_100MA, "Vsup_uvl1", 3.8, 4.6, 4.6, 3.8, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);

	SERIAL
	{
		VSUP_UVL_R_0x00->SetTestResult(SITE, 0, res1[SITE]);
		VSUP_UVL_F_0x00->SetTestResult(SITE, 0, res2[SITE]);
		VSUP_UVL_HYS_0x00->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	SPIWrite(0x08, 0x8000);
	VSUP_11.Set(FV, 5.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	awg.rampv2(VSUP_11, A3_INTB, ACM200_20V, ACM200_100MA, "Vsup_uvl2", 5.0, 6.0, 6.0, 5.0, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);

	SERIAL
	{
		VSUP_UVL_R_0x01->SetTestResult(SITE, 0, res1[SITE]);
		VSUP_UVL_F_0x01->SetTestResult(SITE, 0, res2[SITE]);
		VSUP_UVL_HYS_0x01->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	

	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_OFF);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);

	//vsup ovp 63V



	cbite.SetOn(K30_INTB_ACM, K49_VSUP2_FXVIB, K113_FXVI4_10_B, K0_WAKE2_FXVIB, K47_WAKE1_FXVIB, K111_FXVI3_9_B,/*K60_WAKE12_PD,*/
		K23_FXVI_STACK, K21_PADF_AGNDF, K42_PRESW_FXVIB , K105_FXVI0_6_B, K44_PREBOOT_FXVIB , K109_FXVI2_8_B ,- 1);
	B3_WAKE12.Set(FV, 0.0, FXVIe_PLUS_40V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	PREBOOT_SW.Set(FV, 0.0, FXVIe_PLUS_40V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 30.0, FXVIe_PLUS_40V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B3_WAKE12.Set(FV, -30.0, FXVIe_PLUS_40V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON,1.0);
	PREBOOT_SW.Set(FV, -30, FXVIe_PLUS_40V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON,1.0);

	VDDIO_VBOOST_0.Set(FV, 30, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON,1.0);

	delay_ms(8);//long delay get stable value
	ALL_FXVIE.MeasureVI(30, 10);

	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);

		ISUP_OFF_60V->SetTestResult(SITE, 0, results[SITE] * 1e6);//uA


	}


	//test absmax here?
	//VDDIO_VBOOST_0.Set(FV, 35, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	B4_VSUP_LDO2OUT.Set(FV, 35.0, FXVIe_PLUS_40V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON,1.0);
	delay_ms(5);
	if (DO_CHAR || (test_stage==1 )|| (test_stage==2 )) delay_ms(25);
	ALL_FXVIE.MeasureVI(30, 10);
	//B3_WAKE12.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);

		ISUP_OFF_65V->SetTestResult(SITE, 0, results[SITE] * 1e6);//uA
		results[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);

		WAKE12_LEAK_0V->SetTestResult(SITE, 0, results[SITE] * 1e6);//uA

		results[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);

		PRESW_LEAK_0V->SetTestResult(SITE, 0, results[SITE] * 1e9);//nA

		results[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);

		PREBOOT_LEAK_0V->SetTestResult(SITE, 0, results[SITE] * 1e9);//nA
	}
	PREBOOT_SW.Set(FV, -30, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON, 1.0);
	PREBOOT_SW.Set(FV, 35, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON, 2.0);
	B2_PREBOOT_VBOOST.Set(FV, 40.0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON, 2.0);
	delay_ms(10);
	if (DO_CHAR || (test_stage==1 )) delay_ms(25);
	ALL_FXVIE.MeasureVI(30, 10);
	SERIAL
	{
	

		results[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);

		PRESW_LEAK_65V->SetTestResult(SITE, 0, results[SITE] * 1e6);//nA

		results[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);

		PREBOOT_LEAK_70V->SetTestResult(SITE, 0, results[SITE] * 1e6);//nA
	}
	B2_PREBOOT_VBOOST.Set(FV, 35.0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON, 1.0);
	PREBOOT_SW.Set(FV, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON, 2.0);
	B4_VSUP_LDO2OUT.Set(FV, 6.0, FXVIe_PLUS_40V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON, 1.0);

	
	PREBOOT_SW.Set(FV, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	cbite.SetOn(K30_INTB_ACM, K82_BUCK_CAPS,K49_VSUP2_FXVIB, K113_FXVI4_10_B, K0_WAKE2_FXVIB, K47_WAKE1_FXVIB, K111_FXVI3_9_B,/*K60_WAKE12_PD,*/
		K23_FXVI_STACK, K21_PADF_AGNDF, K2_5V_PU, K54_VDDIO_PU, K116_QVMH0, K119_QVML0, - 1);
	delay_ms(1);

	B4_VSUP_LDO2OUT.Set(FV, 6.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B3_WAKE12.Set(FV, 6.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON, 1.0);
	//A5_AMUX.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(5);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	//SPIWrite(0x3F, 0x7401);

	SPIWrite(0x04, 0x0F0F);//AMUX enalbe
	measure_QVM(res1);
	SERIAL
	{

		WAKE1_Ratio34_36V->SetTestResult(SITE, 0, 36.0 / (res1[SITE] + 1e-30));//R

	}
	SPIWrite(0x04, 0x0A10);//AMUX enalbe
	measure_QVM(res1);
	SERIAL
	{

		WAKE2_Ratio20_36V->SetTestResult(SITE, 0, 36.0 / (res1[SITE] + 1e-30));//R

	}

	SPIWrite(0x04, data0);//AMUX enalbe
	cbite.SetCbiteOff(K0_WAKE2_FXVIB);
	delay_ms(2);
	B3_WAKE12.MeasureVI(30, 10);
	SERIAL
	{


		res1[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);
		WAKE1_LEAK_36V->SetTestResult(SITE, 0, res1[SITE] * 1e6);//uA
		

	}
	
	SPIWrite(0x04, 0x4000);//AMUX enalbe

	delay_ms(2);
	B3_WAKE12.MeasureVI(30, 10);
	SERIAL
	{


		res2[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);
		WAKE1_LEAK_36V_AMUX_R34->SetTestResult(SITE, 0, res2[SITE] * 1e6);//uA
		AMUX_R_WAKE1_BRIDGE->SetTestResult(SITE, 0, 36.0/(res1[SITE] - res2[SITE]+1e-30)*1e-6);//Mohm
	}

	cbite.SetCbiteOn(K0_WAKE2_FXVIB);//will check if have spike when relay switch
	delay_ms(2);
	cbite.SetCbiteOff(K47_WAKE1_FXVIB);
	delay_ms(2);
	SPIWrite(0x04, data0);//AMUX ratio
	delay_ms(5);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	B3_WAKE12.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		ISUP_READY_36V->SetTestResult(SITE, 0, results[SITE] * 1e3);//mA

		results[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);
		WAKE2_LEAK_36V->SetTestResult(SITE, 0, results[SITE] * 1e6);//uA
	

	}
	SPIWrite(0x04, 0x4000);//AMUX enake
	delay_ms(5);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	B3_WAKE12.MeasureVI(30, 10);
	SERIAL
	{
		//results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		//ISUP_READY2_36V->SetTestResult(SITE, 0, results[SITE] * 1e3);//mA

		res2[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);
		WAKE2_LEAK_36V_AMUX_R34->SetTestResult(SITE, 0, res2[SITE] * 1e6);//uA
		AMUX_R_WAKE2_BRIDGE->SetTestResult(SITE, 0, 36.0 / (res1[SITE] - res2[SITE] + 1e-30) * 1e-6);//Mohm
	}
	SPIWrite(0x04, data0);//AMUX ratio
	B4_VSUP_LDO2OUT.Set(FV, 30, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON,1.0);
	B3_WAKE12.Set(FV, 30.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON, 1.0);
	delay_ms(5);
	//B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	B3_WAKE12.MeasureVI(30, 10);
	SERIAL
	{

		results[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);
		WAKE2_LEAK_60V->SetTestResult(SITE, 0, results[SITE] * 1e6);//uA

	}
	cbite.SetCbiteOn(K47_WAKE1_FXVIB);//will check if have spike when relay switch
	delay_ms(2);
	cbite.SetCbiteOff(K0_WAKE2_FXVIB);
	delay_ms(5);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	B3_WAKE12.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		ISUP_READY_60V->SetTestResult(SITE, 0, results[SITE] * 1e3);//mA
		results[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);
		WAKE1_LEAK_60V->SetTestResult(SITE, 0, results[SITE] * 1e6);//uA

	}

	SPIWrite(0x04, 0x300E);//divid vddio 34
	delay_ms(4);
	measure_QVM(res1);
	SERIAL
	{
		
		AMUX_VSUP60V_R34_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 34
		AMUX_VSUP60V_R34->SetTestResult(SITE, 0, 60.0 / (res1[SITE] + 1e-30));//ratio 34
		AMUX_VSUP60V_R34_OS->SetTestResult(SITE, 0, 60.0 / (res1[SITE] + 1e-30 + g_amux_vos[SITE]));//ratio 34
	}

	SPIWrite(0x04, 0x200E);//divid vddio 20
	delay_ms(4);
	measure_QVM(res1);
	SERIAL
	{

		AMUX_VSUP60V_R20_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 34
		AMUX_VSUP60V_R20->SetTestResult(SITE, 0, 60.0 / (res1[SITE] + 1e-30));//ratio 34
		AMUX_VSUP60V_R20_OS->SetTestResult(SITE, 0, 60.0 / (res1[SITE] + 1e-30 + g_amux_vos[SITE]));//ratio 34
	}
	//will check if test wake12 &Isup  absmax here


	VDDIO_VBOOST_0.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	B3_WAKE12.Set(FV, 0.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON, 1.0);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B3_WAKE12.Set(FV, 0.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);


	cbite.SetOn(K82_BUCK_CAPS, K30_INTB_ACM, K49_VSUP2_FXVIB, K113_FXVI4_10_B, K54_VDDIO_PU, K2_5V_PU,
		K59_WAKE12_PU, K56_INTB_PU, K57_FS0B_PSYNC_PU, K23_FXVI_STACK, K21_PADF_AGNDF, - 1);
	delay_ms(1);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 12.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	PRECMP_BUCK3FB_INTB_10.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(4);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	//SPIWrite(0x3F, 0x7481);//switch to main otp
	Enter_M_TM(0x0051, 0x0000, 0x0000);
	VDDIO_VBOOST_0.Set(FV, 30, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON,1.0);
	B4_VSUP_LDO2OUT.Set(FV, 30.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON,1.0);
	awg.rampv2(B4_VSUP_LDO2OUT, PRECMP_BUCK3FB_INTB_10, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, "Vsup_ovp", 30, 35.0, 35.0, 30, 0.01, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{
		VSUP_OVP_R->SetTestResult(SITE, 0, res1[SITE]+30.0);
		VSUP_OVP_F->SetTestResult(SITE, 0, res2[SITE] + 30.0);
		VSUP_OVP_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}

//test wake12 leakage at high voltage


	if (1)
	{
		B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON, 1.0);
		VDDIO_VBOOST_0.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 1.0);
	
		PRECMP_BUCK3FB_INTB_10.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);

		delay_ms(2);//for cap discharge

		B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
		VDDIO_VBOOST_0.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_OFF);
		power_off(DEBUG);
	}
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T26_SLT_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam* SLTTEST_FB1 = StsGetParam(funcindex, "SLTTEST_FB1");
	CParam* SLTTEST_FB2 = StsGetParam(funcindex, "SLTTEST_FB2");
	CParam* SLTTEST_FB3 = StsGetParam(funcindex, "SLTTEST_FB3");
	CParam* SLTTEST_VBOOST = StsGetParam(funcindex, "SLTTEST_VBOOST");
	CParam* SLTTEST_BUCK1IN = StsGetParam(funcindex, "SLTTEST_BUCK1IN");
	CParam* SLTTEST_BUCK12N = StsGetParam(funcindex, "SLTTEST_BUCK12N");
	CParam* SLTTEST_BUCK3IN = StsGetParam(funcindex, "SLTTEST_BUCK3IN");
	CParam* SLTTEST_LDO1 = StsGetParam(funcindex, "SLTTEST_LDO1");
	CParam* SLTTEST_LDO2 = StsGetParam(funcindex, "SLTTEST_LDO2");
	CParam* SLTTEST_IVSUP = StsGetParam(funcindex, "SLTTEST_IVSUP");

	CParam* SLTTEST_BUCK1_SS = StsGetParam(funcindex, "SLTTEST_BUCK1_SS");
	CParam* SLTTEST_BUCK2_SS = StsGetParam(funcindex, "SLTTEST_BUCK2_SS");
	CParam* SLTTEST_BUCK3_SS = StsGetParam(funcindex, "SLTTEST_BUCK3_SS");
	CParam* SLTTEST_VBOOST_SS = StsGetParam(funcindex, "SLTTEST_VBOOST_SS");
	CParam* SLTTEST_VPRE_SS = StsGetParam(funcindex, "SLTTEST_VPRE_SS");
	CParam* SLTTEST_LDO1_SS = StsGetParam(funcindex, "SLTTEST_LDO1_SS");
	CParam* SLTTEST_LDO2_SS = StsGetParam(funcindex, "SLTTEST_LDO2_SS");
	
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here


	ULONG m_reg_data[12][SITE_NUM];
	ULONG m_reg_data1[4][SITE_NUM];
	ULONG m_reg_data2[4][SITE_NUM];

	ULONG fs_reg_data[29][SITE_NUM];


	ULONG m_trim_data[16][SITE_NUM];
	ULONG fs_trim_data[SITE_NUM];
	ULONG data0 = 0x0000;
	ULONG rdata[SITE_NUM];
	double res[SITE_NUM];
	const int samplesize=1800;
	
	string m_param_str_array[] = { "SLT_M_REG_00", "SLT_M_REG_01", "SLT_M_REG_02", "SLT_M_REG_03", "SLT_M_REG_04", "SLT_M_REG_05", "SLT_M_REG_06", "SLT_M_REG_07", "SLT_M_REG_08", "SLT_M_REG_09", "SLT_M_REG_0A", "SLT_M_REG_0B", "SLT_M_REG_23", "SLT_M_REG_24", "SLT_M_REG_25", "SLT_M_REG_26" };
	string fs_param_str_array[] = { "SLT_FS_REG_00", "SLT_FS_REG_01", "SLT_FS_REG_02", "SLT_FS_REG_03", "SLT_FS_REG_04", "SLT_FS_REG_05", "SLT_FS_REG_06", "SLT_FS_REG_07", "SLT_FS_REG_08", "SLT_FS_REG_09", "SLT_FS_REG_0A", "SLT_FS_REG_0B", "SLT_FS_REG_0C", "SLT_FS_REG_0D", "SLT_FS_REG_0E", "SLT_FS_REG_0F",
		"SLT_FS_REG_10", "SLT_FS_REG_11", "SLT_FS_REG_12", "SLT_FS_REG_13", "SLT_FS_REG_14", "SLT_FS_REG_15", "SLT_FS_REG_16", "SLT_FS_REG_17", "SLT_FS_REG_18", "SLT_FS_REG_19", "SLT_FS_REG_1A", "SLT_FS_REG_1B", "SLT_FS_REG_1C" };

	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K81_LDO_CAPS, K84_PRECOMP_CAP, K86_BUCK_SLT, K34_BOOST_SLT, K11_PRE_SLT, K114_FXVI5_11_A, 
		K80_PRECSP_PREFB_SHRT, K83_BUCKIN_PREFB,K54_VDDIO_PU, /*K59_WAKE12_PU,*/K58_DBG_PU, K57_FS0B_PSYNC_PU,
		K51_LDO2_FXVIB, K113_FXVI4_10_B, K21_PADF_AGNDF, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K36_BUCK1FB_ACM,
		 K52_LDO1_FXVIB , K50_VBOOST_FXVIB , K107_FXVI1_7_B , K109_FXVI2_8_B  ,-1);

	delay_ms(3);
	VSUP_11.Set(FV, 12, ACM200_20V, ACM200_200MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(5);
	BUCK1IN_2.TSet(FI, -1e-6, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	BUCK2IN_3.TSet(FI, -1e-6, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	BUCK3IN_4.TSet(FI, -1e-6, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FI, -1e-6, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FI, -1e-6, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FI, -1e-6, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FI, -1e-6, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.TSet(FI, -1e-6, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, -1e-6, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(samplesize, 10,FXVIe_PLUS_MI_X1, MEAS_AWG);
	B2_PREBOOT_VBOOST.MeasureVI(samplesize, 10,FXVIe_PLUS_MI_X1, MEAS_AWG);
	B4_VSUP_LDO2OUT.MeasureVI(samplesize, 10,FXVIe_PLUS_MI_X1, MEAS_AWG);
	BUCK1IN_2.MeasureVI(samplesize, 10, MEAS_AWG);
	PREFB_BUCK1FB_8.MeasureVI(samplesize, 10, MEAS_AWG);
	PRECSP_BUCK2FB_9.MeasureVI(samplesize, 10, MEAS_AWG);
	PRECMP_BUCK3FB_INTB_10.MeasureVI(samplesize, 10, MEAS_AWG);
	VSUP_11.MeasureVI(samplesize, 10, MEAS_AWG);
	STSEnableMeas(&B1_PREGHS_PREGLS_LDO1OUT,&B2_PREBOOT_VBOOST,&B4_VSUP_LDO2OUT,&BUCK1IN_2,&PREFB_BUCK1FB_8,&PRECSP_BUCK2FB_9,
		&PRECMP_BUCK3FB_INTB_10,&VSUP_11);
	cbite.SetCbiteOn(K59_WAKE12_PU);
	
	delay_ms(15);
	Enter_MAIN_SCAN_DIG();
	Enter_FS_SCAN_DIG();
		SPIWrite(0x03, 0x001B);
	//SPIWrite(0x03, 0x0000);
	SPIWrite(0x3F, 0x7480);
	SPIWrite(0x00, 0x030A);//add more dead time to avoid restart vpre
	SPIWrite(0x01, 0x80D0);
	SPIWrite(0x02, 0xD0D0);
	SPIWrite(0x04, 0xC088);
	dut.trim("VPRE_INEG").save_working();
	dut.trim("VPRE_INEG").set_working(1);
	OTP_M_Preview(4, 1);
	dut.trim("VPRE_INEG").restore_working();
	dut.trim("VPRE_IPK").save_working();
	dut.trim("VPRE_IPK").set_working(8);
	OTP_M_Preview(2);
	//SPIWrite(0x1F, 0x0007);
	dut.trim("VPRE_IPK").restore_working();
	delay_ms(2);
	cbite.SetCbiteOff(K58_DBG_PU);
	cbite.SetCbiteOn(K61_DBG_PD);

	STSAWGRun();
	//delay_ms(2);
	measure_SS(PREFB_BUCK1FB_8,samplesize,1.8,res);
	SERIAL
	{

		SLTTEST_BUCK1_SS->SetTestResult(SITE, 0, res[SITE]);
	}
	measure_SS(PRECSP_BUCK2FB_9,samplesize,1.8,res);
	SERIAL
	{

		SLTTEST_BUCK2_SS->SetTestResult(SITE, 0, res[SITE]);
	}
	measure_SS(PRECMP_BUCK3FB_INTB_10,samplesize,1.8,res);
	SERIAL
	{

		SLTTEST_BUCK3_SS->SetTestResult(SITE, 0, res[SITE]);
	}

	measure_SS(BUCK1IN_2,samplesize,3.3,res);
	SERIAL
	{

		SLTTEST_VPRE_SS->SetTestResult(SITE, 0, res[SITE]);
	}

	measure_SS(B2_PREBOOT_VBOOST,samplesize,4.5,res);
	SERIAL
	{

		SLTTEST_VBOOST_SS->SetTestResult(SITE, 0, res[SITE]);
	}

	measure_SS(B1_PREGHS_PREGLS_LDO1OUT,samplesize,1.1,res);
	SERIAL
	{

		SLTTEST_LDO1_SS->SetTestResult(SITE, 0, res[SITE]);
	}

	measure_SS(B4_VSUP_LDO2OUT,samplesize,1.1,res);
	SERIAL
	{

		SLTTEST_LDO2_SS->SetTestResult(SITE, 0, res[SITE]);
	}
	//delay_ms(5);
	ALL_FXVIE.MeasureVI(300, 10);
	ALL_ACM.MeasureVI(300, 10);
	SPIWrite(0x3F, 0x7400);
	SPIRead(0x00, m_reg_data, 12);//read main register
	SPIRead(0x23, m_reg_data1, 4);//read main register
	//	I2CReadData(0x23, m_reg_data, 12);
	SPIRead(0x40, fs_reg_data, 29);//read fs register


	VDDIO_VBOOST_0.Set(FV,0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_20V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1.0);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(15);
	BUCK1IN_2.TSet(FV, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);
	BUCK2IN_3.TSet(FV, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);
	BUCK3IN_4.TSet(FV, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);
	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	B2_PREBOOT_VBOOST.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	
	STSTArming();
	cbite.SetCbiteOn(K85_BUCKSW_PD);
	delay_ms(30);//will check discharge
	SERIAL
	{

		res[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MVRET);
		SLTTEST_FB1->SetTestResult(SITE, 0, res[SITE]);

		res[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MVRET);
		SLTTEST_FB2->SetTestResult(SITE, 0, res[SITE]);

		res[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MVRET);
		SLTTEST_FB3->SetTestResult(SITE, 0, res[SITE]);

		res[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		SLTTEST_LDO1->SetTestResult(SITE, 0, res[SITE]);

		res[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		SLTTEST_LDO2->SetTestResult(SITE, 0, res[SITE]);

		res[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MVRET);
		SLTTEST_VBOOST->SetTestResult(SITE, 0, res[SITE]);

		res[SITE] = BUCK1IN_2.GetMeasResult(SITE, MVRET);
		SLTTEST_BUCK1IN->SetTestResult(SITE, 0, res[SITE]);

		res[SITE] = BUCK2IN_3.GetMeasResult(SITE, MVRET);
		SLTTEST_BUCK12N->SetTestResult(SITE, 0, res[SITE]);

		res[SITE] = BUCK3IN_4.GetMeasResult(SITE, MVRET);
		SLTTEST_BUCK3IN->SetTestResult(SITE, 0, res[SITE]);
		
		res[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		SLTTEST_IVSUP->SetTestResult(SITE, 0, res[SITE]*1e3);
			
		for (int addr = 0; addr < 12; ++addr)
			StsGetParam(funcindex, m_param_str_array[addr].c_str())->SetTestResult(SITE, 0, m_reg_data[addr][SITE]);
		for (int addr = 0; addr < 4; ++addr)
			StsGetParam(funcindex, m_param_str_array[addr + 12].c_str())->SetTestResult(SITE, 0, m_reg_data1[addr][SITE]);
		for (int addr = 0; addr < 29; ++addr)
			StsGetParam(funcindex, fs_param_str_array[addr].c_str())->SetTestResult(SITE, 0, fs_reg_data[addr][SITE]);



	}




	VDDIO_VBOOST_0.Set(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_20V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_OFF);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	power_off(1);
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T27_DEBUG_WAKE12_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam *DBG_FLT_TIME = StsGetParam(funcindex, "DBG_FLT_TIME");
	CParam *WAKE1_DL = StsGetParam(funcindex, "WAKE1_DL");
	CParam *WAKE1_DH = StsGetParam(funcindex, "WAKE1_DH");

	CParam *WAKE2_DL = StsGetParam(funcindex, "WAKE2_DL");
	CParam *WAKE2_DH = StsGetParam(funcindex, "WAKE2_DH");
	CParam *WAKE1_AL = StsGetParam(funcindex, "WAKE1_AL");
	CParam *WAKE2_AL = StsGetParam(funcindex, "WAKE2_AL");
	CParam *DBG_VTH_R = StsGetParam(funcindex, "DBG_VTH_R");
	CParam* WAKE1_FT = StsGetParam(funcindex, "WAKE1_FT");
	CParam* WAKE2_FT = StsGetParam(funcindex, "WAKE2_FT");
	
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	ULONG data0 = 0x0000;
	ULONG rdata[SITE_NUM];
	

	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K48_WAKE1_DCM, K1_WAKE2_DCM, K5_DBG_DCM, K32_INTB_FXVIA, K110_FXVI3_9_A,
		K54_VDDIO_PU, /*K56_INTB_PU,*/ K57_FS0B_PSYNC_PU, K59_WAKE12_PU, K58_DBG_PU, - 1);
	delay_ms(1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	//set dbg to be 5V, and set wake1/wake2 to be 5V after 12uS by pattern ,go-no-go test ,can adjust time set to sweep
	dcm.SetPinLevel("DBG_WAKE12_G",5.0,0,2.5,2.4);
	dcm.Connect("DBG_WAKE12_G");
	dcm.SetChannelStatus("DBG_WAKE12_G",DCM_LOW);//need confirm the version of DCM ,version>=0x30
	VSUP_11.Set(FV, 12, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(3);
	
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	//sweep to serach valid timing.
	DBG_TIMING(5, 40, 2, res1,0);
	SERIAL
	{

		DBG_FLT_TIME->SetTestResult(SITE, 0, res1[SITE]);

	}


		//will check if INTB need force a small voltage to test current  instead MV.
	dcm.SetPPMU("DBG_WAKE12_G", DCM_PPMU_FVMI, 0.0, DCM_PPMUIRANGE_32MA);
	delay_ms(1);
	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_32MA);
	delay_ms(4);

	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	SPIWrite(0x3F, 0x7481);//switch to main otp
	SPIRead(0x3F, rdata);
	
	Enter_M_TM(0x00F1, 0x0000, 0x0000);

	vth_binary_search("SDA_WAKE1", A3_INTB, 4.5, 2.0, 5.0, 10, res1, 200, 1, TRIG_FALLING);

	vth_binary_search("SDA_WAKE1", A3_INTB, 2.0, 4.5, 5.0, 10, res2, 200, 1, TRIG_FALLING);
	SERIAL
	{

		WAKE1_DL->SetTestResult(SITE, 0, res1[SITE]);
		WAKE1_DH->SetTestResult(SITE, 0, res2[SITE]);

	}
		//set intb to dcm, measure filter timming
		//will add in the future...
		
	dcm.SetPinLevel("SDA_WAKE1", 5.0, 0, 2.5, 2.0);
	dcm.SetChannelStatus("SDA_WAKE1", DCM_LOW);
	delay_ms(1);
	dcm.RunVectorEn("SDA_WAKE1", "WAKE1_FT_START", "WAKE1_FT_STOP");
	A3_INTB.MeasureVI(30, 10,FXVIe_PLUS_MI_X1, MEAS_AWG);
	STSEnableMeas(&A3_INTB);
	A3_INTB.SetMeasVTrig(2.5, TRIG_FALLING);
	STSAWGRun();

	SERIAL 
	{
		res1[SITE] = A3_INTB.GetMeasResult(SITE, MVRET, TRIG_RESULT);
		WAKE1_FT->SetTestResult(SITE, 0, res1[SITE]*10);

	}
	


	dcm.SetPPMU("SDA_WAKE1", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_32MA);
	Enter_M_TM(0x0101, 0x0000, 0x0000);
	vth_binary_search("FIN_WAKE2", A3_INTB, 4.5, 2, 5.0, 10, res1, 200, 1, TRIG_FALLING);
	vth_binary_search("FIN_WAKE2", A3_INTB, 2.0, 4.5, 5.0, 10, res2, 200, 1, TRIG_FALLING);
	SERIAL
	{

		WAKE2_DL->SetTestResult(SITE, 0, res1[SITE]);
		WAKE2_DH->SetTestResult(SITE, 0, res2[SITE]);

	}

	dcm.SetPinLevel("FIN_WAKE2", 5.0, 0, 2.5, 2.0);
	dcm.SetChannelStatus("FIN_WAKE2", DCM_LOW);
	delay_ms(1);
	dcm.RunVectorEn("FIN_WAKE2", "WAKE2_FT_START", "WAKE2_FT_STOP");
	A3_INTB.MeasureVI(30, 10, FXVIe_PLUS_MI_X1, MEAS_AWG);
	STSEnableMeas(&A3_INTB);
	A3_INTB.SetMeasVTrig(2.5, TRIG_FALLING);
	STSAWGRun();

	SERIAL
	{
		res1[SITE] = A3_INTB.GetMeasResult(SITE, MVRET, TRIG_RESULT);
		WAKE2_FT->SetTestResult(SITE, 0, res1[SITE] * 10);
	}
	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 0.0, DCM_PPMUIRANGE_32MA);
	delay_ms(1);
	dcm.Disconnect("DBG_WAKE12_G");

	///WAKE1 Analog low voltage threshold
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K6_DBG_FXVIA, K104_FXVI0_6_A,K32_INTB_FXVIA, K110_FXVI3_9_A, K54_VDDIO_PU, 
		K0_WAKE2_FXVIB, K111_FXVI3_9_B,/* K47_WAKE1_FXVIB,K111_FXVI3_9_B,*/ K56_INTB_PU, K57_FS0B_PSYNC_PU, -1);
	delay_ms(1);

	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	B3_WAKE12.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(4);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	B3_WAKE12.Set(FV, 1.8, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON,1.0);
	awg.rampvmi(B3_WAKE12, VSUP_11, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "WAKE1_AL", 1.8, 1.0, 0.005, 50, 1.0e-3, TRIG_FALLING, res1);
	SERIAL
	{

		WAKE1_AL->SetTestResult(SITE, 0, res1[SITE]);

	}
		///WAKE2 Analog low voltage threshold
	B3_WAKE12.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
		cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K6_DBG_FXVIA, K104_FXVI0_6_A, K32_INTB_FXVIA, K110_FXVI3_9_A, K54_VDDIO_PU,
		/*K0_WAKE2_FXVIB, K111_FXVI3_9_B,*/ K47_WAKE1_FXVIB,K111_FXVI3_9_B, K56_INTB_PU, K57_FS0B_PSYNC_PU, -1);
	delay_ms(1);

	B3_WAKE12.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(4);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	B3_WAKE12.Set(FV, 1.8, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON, 1.0);
	awg.rampvmi(B3_WAKE12, VSUP_11, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "WAKE2_AL", 1.8, 1.0, 0.01, 50, 1.0e-3, TRIG_FALLING, res1);
	SERIAL
	{

		WAKE2_AL->SetTestResult(SITE, 0, res1[SITE]);

	}
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	B3_WAKE12.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(5);
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K6_DBG_FXVIA, K104_FXVI0_6_A, K32_INTB_FXVIA, K110_FXVI3_9_A, K54_VDDIO_PU,
		K59_WAKE12_PU, K56_INTB_PU, K57_FS0B_PSYNC_PU, -1);
	delay_ms(1);

	VSUP_11.Set(FV, 12, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(4);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	Enter_M_TM(0x0061, 0x0000, 0x0000);
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 3.6, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	awg.rampv(A0_FIN_DBG_ERR_FCCU1, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "DBG_VTH", 3.6, 5.5, 0.005, 20, 2.0, TRIG_FALLING, res1);

	SERIAL
	{
	
		DBG_VTH_R->SetTestResult(SITE, 0, res1[SITE]);
		
	}

	B3_WAKE12.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_OFF);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	B3_WAKE12.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T29_SYNC_FIN_FOUT_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam *FIN1V_LEAK = StsGetParam(funcindex, "FIN1V_LEAK");
	CParam *SYNC_MIN = StsGetParam(funcindex, "SYNC_MIN");
	CParam *SYNC_MAX = StsGetParam(funcindex, "SYNC_MAX");
	CParam *SYNC_MIN_2p5M = StsGetParam(funcindex, "SYNC_MIN_2p5M");
	CParam *SYNC_MAX_2p5M = StsGetParam(funcindex, "SYNC_MAX_2p5M");

	CParam *FIN_ERR_LONG = StsGetParam(funcindex, "FIN_ERR_LONG");
	CParam *FIN_ERR_SHORT = StsGetParam(funcindex, "FIN_ERR_SHORT");

	CParam *FIN_VTH_VIL = StsGetParam(funcindex, "FIN_VTH_VIL");
	CParam *FIN_VTH_VIH = StsGetParam(funcindex, "FIN_VTH_VIH");
	CParam *FIN_VTH_HYS = StsGetParam(funcindex, "FIN_VTH_HYS");
	CParam *VFOUT_L = StsGetParam(funcindex, "VFOUT_L");
	CParam *VFOUT_H = StsGetParam(funcindex, "VFOUT_H");
	CParam *IFOUT_HIZ = StsGetParam(funcindex, "IFOUT_HIZ");


	CParam* PSYNC_VIL = StsGetParam(funcindex, "PSYNC_VIL");
	CParam* PSYNC_VIH = StsGetParam(funcindex, "PSYNC_VIH");
	CParam* PSYNC_HYS = StsGetParam(funcindex, "PSYNC_HYS");
	CParam* PSYNC_VOL = StsGetParam(funcindex, "PSYNC_VOL");
	CParam* IPSYNC_PD = StsGetParam(funcindex, "IPSYNC_PD");


	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double cap[SITE_NUM][1000];
	ULONG data0 = 0x0000;

	
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K18_FIN_DCM, K26_FOUT_DCM, K54_VDDIO_PU, K56_INTB_PU, K59_WAKE12_PU,
		K32_INTB_FXVIA, K110_FXVI3_9_A, K57_FS0B_PSYNC_PU, -1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	delay_ms(1);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(3);


	dcm.Connect("FOUT_INTB");
	dcm.Connect("FIN_WAKE2");

	dcm.SetPPMU("FIN_WAKE2", DCM_PPMU_FVMI, 1.0, DCM_PPMUIRANGE_200UA);
	delay_ms(2);
	dcm.PPMUMeasure("FIN_WAKE2", 30, 10);
	SERIAL
	{

		res1[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		FIN1V_LEAK->SetTestResult(SITE, 0, res1[SITE] * 1e6);
	}
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	if (0)
	{ 
	SPIWrite(0x05, 0x0840);//select vpre clk to fout,ext_fin_sel=1

	dcm.SetPinLevel("FOUT_INTB", 2.0, 1.9, 2.0, 1.9);
	dcm.SetTMUMatrix("FOUT_INTB", 0, DCM_TMU1);
	dcm.SetTMUMatrix("FOUT_INTB", 2, DCM_TMU1);
	dcm.SetTMUMatrix("FOUT_INTB", 4, DCM_TMU1);
	dcm.SetTMUMatrix("FOUT_INTB", 6, DCM_TMU1);
	dcm.SetTMUMatrix("FOUT_INTB", 1, DCM_TMU2);
	dcm.SetTMUMatrix("FOUT_INTB", 3, DCM_TMU2);
	dcm.SetTMUMatrix("FOUT_INTB", 5, DCM_TMU2);
	dcm.SetTMUMatrix("FOUT_INTB", 7, DCM_TMU2);

	//dcm.SetTMUParam("FOUT_INTB", DCM_ALLSITE, DCM_POS, 0, 0);



	dcm.SetPinLevel("FIN_WAKE2", 5.0, 0, 2.0, 1.9);
	dcm.SetChannelStatus("FIN_WAKE2", DCM_LOW);
	SYNC_SWEEP(300, 550, 20, res1, res2, 0);

	SERIAL
	{

		SYNC_MIN->SetTestResult(SITE, 0, res1[SITE]);
		SYNC_MAX->SetTestResult(SITE, 0, res2[SITE]);
	}
	SPIWrite(0x05, 0x0860);//select vpre clk to fout,ext_fin_sel=1,fin_div=1
	SYNC_SWEEP(2250, 2750, 30, res1, res2, 0,1);

	SERIAL
	{

		SYNC_MIN_2p5M->SetTestResult(SITE, 0, res1[SITE]);
		SYNC_MAX_2p5M->SetTestResult(SITE, 0, res2[SITE]);
	}
		//PLL LOCK
	Enter_M_TM(0x00D1, 0x0000, 0x0000);
	SPIWrite(0x3F, 0x7401);//switch to main otp
	SPIWrite(0x05, 0x1840);
	cbite.SetCbiteOff(K26_FOUT_DCM);
	delay_ms(1);
	cbite.SetCbiteOn(K70_FOUT_TMUA);
	delay_ms(1);
	ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.0, QTMUe_FILTER_PASS, 20);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.0, QTMUe_FILTER_PASS, 20);
	ALL_QTMU.Connect(QTMUe_RELAY_CHA);
	measure_PLL_QTMU(res1);
	cbite.SetCbiteOff(K70_FOUT_TMUA);
	delay_ms(1);
	cbite.SetCbiteOn(K26_FOUT_DCM);
	delay_ms(1);

	Enter_M_TM(0x0091, 0x0000, 0x0000);

	SPIWrite(0x3F, 0x7481);//switch to main otp
	SPIWrite(0x08, 0x0800);//pll_sel =1
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.MeasureVI(300, 10, FXVIe_PLUS_MI_X1, MEAS_AWG);
	STSEnableMeas(&A3_INTB);
	dcm.RunVectorEn("FIN_WAKE2", "SYNC2_START", "SYNC2_STOP");
	STSAWGRun();

	SERIAL{
		A3_INTB.BlockRead(SITE, 0, 300, cap[SITE], MVRET);
		for (int i = 10; i<300; i++)
		{
			if (cap[SITE][i]>2.0)
			{
				res1[SITE] = i*10-961;//us ;961us 401x1/417khz
				break;
			}

		}
		FIN_ERR_LONG->SetTestResult(SITE, 0, res1[SITE]);
	}
	A3_INTB.MeasureVI(300, 10, FXVIe_PLUS_MI_X1, MEAS_AWG);
	STSEnableMeas(&A3_INTB);
	dcm.RunVectorEn("FIN_WAKE2", "SYNC3_START", "SYNC3_STOP");
	STSAWGRun();

	SERIAL{
		A3_INTB.BlockRead(SITE, 0, 300, cap[SITE], MVRET);
		for (int i = 10; i<300; i++)
		{
			if (cap[SITE][i]>2.0)
			{
				res1[SITE] = i * 10 - 961;//us ;961us 401x1/417khz
				break;
			}

		}
		FIN_ERR_SHORT->SetTestResult(SITE, 0, res1[SITE]);
	}

	}

	Enter_M_TM(0x0081, 0x0000, 0x0000);
	vth_binary_search("FIN_WAKE2", A3_INTB, 1.3, 0.3, 0, 7, res1, 200, 1, TRIG_FALLING);
	vth_binary_search("FIN_WAKE2", A3_INTB, 0.3, 1.3, 0, 7, res2, 200, 1, TRIG_FALLING);
	SERIAL{
		FIN_VTH_VIL->SetTestResult(SITE, 0, res1[SITE]);
		FIN_VTH_VIH->SetTestResult(SITE, 0, res2[SITE]);
		FIN_VTH_HYS->SetTestResult(SITE, 0, res2[SITE] - res1[SITE]);
	}

	Enter_M_TM(0x00A0, 0x0000, 0x0000);
	dcm.SetPPMU("FOUT_INTB", DCM_PPMU_FIMV, 2.0e-3, DCM_PPMUIRANGE_32MA);
	delay_ms(2);
	dcm.PPMUMeasure("FOUT_INTB", 30, 10);
	SERIAL
	{

		res1[SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		VFOUT_L->SetTestResult(SITE, 0, res1[SITE] );
	}
	
	Enter_M_TM(0x00B0, 0x0000, 0x0000);
	dcm.SetPPMU("FOUT_INTB", DCM_PPMU_FIMV, -2.0e-3, DCM_PPMUIRANGE_32MA);
	delay_ms(2);
	dcm.PPMUMeasure("FOUT_INTB", 30, 10);
	SERIAL
	{

		res1[SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		VFOUT_H->SetTestResult(SITE, 0, res1[SITE]);//VDDIO-
	}
	Enter_M_TM(0x00C0, 0x0000, 0x0000);
	dcm.SetPPMU("FOUT_INTB", DCM_PPMU_FVMI, 2.5, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("FOUT_INTB", 30, 10);
	SERIAL
	{

		res1[SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		IFOUT_HIZ->SetTestResult(SITE, 0, res1[SITE]*1e9);//scale to nA,
	}
		//SYNC VIH/VIL test
	SPIWrite(0x08, data0);//pll_sel =1
	SPIWrite(0x3F, 0x7401);//switch to main otp
	SPIWrite(0x05, data0);
	dcm.Disconnect("FIN_WAKE2");
	dcm.Disconnect("FOUT_INTB");
	Enter_M_TM(0x0131, 0x0000, 0x0000);

	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K18_FIN_DCM, K26_FOUT_DCM, K54_VDDIO_PU, K56_INTB_PU, K59_WAKE12_PU,
	K32_INTB_FXVIA, K110_FXVI3_9_A, K35_PSYNC_FXVIA, K112_FXVI4_10_A, - 1);
	delay_ms(1);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A4_PSYNC_PREFB.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	
	awg.rampv2(A4_PSYNC_PREFB, A3_INTB, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, "PSYNC_VTH", 0.9, 1.9, 2.1, 1.1, 0.005, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{

		PSYNC_VIL->SetTestResult(SITE, 0, res2[SITE]);
		PSYNC_VIH->SetTestResult(SITE, 0, res1[SITE]);
		PSYNC_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);
	}
	Enter_M_TM(0x0160, 0x0000, 0x0000);
	A4_PSYNC_PREFB.Set(FI, 2.0e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	A4_PSYNC_PREFB.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE,MVRET);
		PSYNC_VOL->SetTestResult(SITE, 0, res1[SITE]);

	}
	A4_PSYNC_PREFB.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	Enter_M_TM(0x0140, 0x0000, 0x0000);
	A4_PSYNC_PREFB.Set(FV, 3.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	A4_PSYNC_PREFB.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE,MIRET);
		IPSYNC_PD->SetTestResult(SITE, 0, res1[SITE]*1e6);

	}

	A4_PSYNC_PREFB.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_OFF);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	A4_PSYNC_PREFB.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T31_INTB_AMUX_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam* R_INTB_PU = StsGetParam(funcindex, "R_INTB_PU");
	CParam* V_INTB_L = StsGetParam(funcindex, "V_INTB_L");
	CParam* AMUX_VDDIO = StsGetParam(funcindex, "AMUX_VDDIO");
	CParam* AMUX_VDDIO_V = StsGetParam(funcindex, "AMUX_VDDIO_V");
	CParam* AMUX_VSUP_R7p5 = StsGetParam(funcindex, "AMUX_VSUP_R7p5");
	CParam* AMUX_VSUP_R7p5_V = StsGetParam(funcindex, "AMUX_VSUP_R7p5_V");
	CParam* AMUX_VSUP_R14 = StsGetParam(funcindex, "AMUX_VSUP_R14");
	CParam* AMUX_VSUP_R14_V = StsGetParam(funcindex, "AMUX_VSUP_R14_V");
	CParam* AMUX_VSUP_R20 = StsGetParam(funcindex, "AMUX_VSUP_R20");
	CParam* AMUX_VSUP_R20_V = StsGetParam(funcindex, "AMUX_VSUP_R20_V");
	CParam* AMUX_VSUP_R34 = StsGetParam(funcindex, "AMUX_VSUP_R34");
	CParam* AMUX_VSUP_R34_V = StsGetParam(funcindex, "AMUX_VSUP_R34_V");
	CParam* AMUX_VSUP_R34_OS = StsGetParam(funcindex, "AMUX_VSUP_R34_OS");
	CParam* AMUX_VSUP30V_R34_V = StsGetParam(funcindex, "AMUX_VSUP30V_R34_V");
	CParam* AMUX_VSUP30V_R34 = StsGetParam(funcindex, "AMUX_VSUP30V_R34");
	CParam* AMUX_VSUP30V_R34_OS = StsGetParam(funcindex, "AMUX_VSUP30V_R34_OS");
	CParam* AMUX_VBOS_R3p5 = StsGetParam(funcindex, "AMUX_VBOS_R3p5");
	CParam* AMUX_VBOS_R3p5_V = StsGetParam(funcindex, "AMUX_VBOS_R3p5_V");
	CParam* AMUX_TEMP_V = StsGetParam(funcindex, "AMUX_TEMP_V");
	CParam* AMUX_TEMP_ACTIVE = StsGetParam(funcindex, "AMUX_TEMP_ACTIVE");
	CParam* AMUX_VSUP_R7p5_OS = StsGetParam(funcindex, "AMUX_VSUP_R7p5_OS");
	CParam* AMUX_VSUP_R14_OS = StsGetParam(funcindex, "AMUX_VSUP_R14_OS");
	CParam* AMUX_VSUP_R20_OS = StsGetParam(funcindex, "AMUX_VSUP_R20_OS");
	CParam* AMUX_VSUP16V_R7p5_V = StsGetParam(funcindex, "AMUX_VSUP16V_R7p5_V");
	CParam* AMUX_VSUP16V_R7p5 = StsGetParam(funcindex, "AMUX_VSUP16V_R7p5");
	CParam* AMUX_VSUP16V_R7p5_OS = StsGetParam(funcindex, "AMUX_VSUP16V_R7p5_OS");
	CParam* AMUX_VSUP24V_R20_V = StsGetParam(funcindex, "AMUX_VSUP24V_R20_V");
	CParam* AMUX_VSUP24V_R20 = StsGetParam(funcindex, "AMUX_VSUP24V_R20");
	CParam* AMUX_VSUP24V_R20_OS = StsGetParam(funcindex, "AMUX_VSUP24V_R20_OS");
	CParam* AMUX_VSUP30V_R14_V = StsGetParam(funcindex, "AMUX_VSUP30V_R14_V");
	CParam* AMUX_VSUP30V_R14 = StsGetParam(funcindex, "AMUX_VSUP30V_R14");
	CParam* AMUX_VSUP30V_R14_OS = StsGetParam(funcindex, "AMUX_VSUP30V_R14_OS");

	CParam* AMUX_BUCK1FB = StsGetParam(funcindex, "AMUX_BUCK1FB");
	CParam* AMUX_BUCK1FB_V = StsGetParam(funcindex, "AMUX_BUCK1FB_V");
	CParam* AMUX_BUCK2FB = StsGetParam(funcindex, "AMUX_BUCK2FB");
	CParam* AMUX_BUCK2FB_V = StsGetParam(funcindex, "AMUX_BUCK2FB_V");
	CParam* AMUX_BUCK3FB = StsGetParam(funcindex, "AMUX_BUCK3FB");
	CParam* AMUX_BUCK3FB_V = StsGetParam(funcindex, "AMUX_BUCK3FB_V");


	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double cap[SITE_NUM][MAX_SAMPLES];
	ULONG data0 = 0x0000;


	cbite.SetOn(K24_VDDIO_ACM, K2_5V_PU,  K59_WAKE12_PU, K114_FXVI5_11_A,
		K32_INTB_FXVIA, K110_FXVI3_9_A, K57_FS0B_PSYNC_PU, -1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	delay_ms(1);
	VBOS_1.Set(FV, 5.1, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(3);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	Enter_M_TM(0x01E0, 0x0000, 0x0000);
	//VDDIO_VBOOST_0.Set(FV, 3.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	A3_INTB.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	A3_INTB.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A3_INTB.GetMeasResult(SITE,MIRET);
		R_INTB_PU->SetTestResult(SITE, 0, 5.0/(-res1[SITE]+1e-30)*1e-3);//Kohm

	}
	Enter_M_TM(0x01F0, 0x0000, 0x0000);

	A3_INTB.Set(FI, 2.0e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	A3_INTB.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A3_INTB.GetMeasResult(SITE,MVRET);
		V_INTB_L->SetTestResult(SITE, 0, res1[SITE] );//V

	}
	A3_INTB.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);

	A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	Enter_M_TM(0x0000, 0x0000, 0x0000);//exit test mode
	
	SPIWrite(0x04, 0x0001);//divid vddio 2.5
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_VDDIO_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 2.5
		AMUX_VDDIO->SetTestResult(SITE, 0, 5.0/(res1[SITE]+1e-30));//ratio 2.5
	}

	SPIWrite(0x04, 0x000E);//divid vddio 7.5
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_VSUP_R7p5_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 7.5
		AMUX_VSUP_R7p5->SetTestResult(SITE, 0, 12.0 / (res1[SITE] + 1e-30));//ratio 7.5
		AMUX_VSUP_R7p5_OS->SetTestResult(SITE, 0, 12.0 / (res1[SITE] + 1e-30 + g_amux_vos[SITE]));//ratio 7.5

	}

	SPIWrite(0x04, 0x100E);//divid vddio 14
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_VSUP_R14_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 14
		AMUX_VSUP_R14->SetTestResult(SITE, 0, 12.0 / (res1[SITE] + 1e-30));//ratio 14
		AMUX_VSUP_R14_OS->SetTestResult(SITE, 0, 12.0 / (res1[SITE] + 1e-30 + g_amux_vos[SITE]));//ratio 7.5

	}
	SPIWrite(0x04, 0x200E);//divid vddio 20
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_VSUP_R20_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 20
		AMUX_VSUP_R20->SetTestResult(SITE, 0, 12.0 / (res1[SITE] + 1e-30));//ratio 20
		AMUX_VSUP_R20_OS->SetTestResult(SITE, 0, 12.0 / (res1[SITE] + 1e-30 + g_amux_vos[SITE]));//ratio 7.5

	}
	SPIWrite(0x04, 0x300E);//divid vddio 34
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_VSUP_R34_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 34
		AMUX_VSUP_R34->SetTestResult(SITE, 0, 12.0 / (res1[SITE] + 1e-30));//ratio 34
		AMUX_VSUP_R34_OS->SetTestResult(SITE, 0, 12.0 / (res1[SITE] + 1e-30+ g_amux_vos[SITE]));//ratio 34
	}

	VSUP_11.Set(FV, 16.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	SPIWrite(0x04, 0x000E);//divid vddio 7.5
	delay_ms(3);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_VSUP16V_R7p5_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 7.5
		AMUX_VSUP16V_R7p5->SetTestResult(SITE, 0, 16.0 / (res1[SITE] + 1e-30));//ratio 7.5
		AMUX_VSUP16V_R7p5_OS->SetTestResult(SITE, 0, 16.0 / (res1[SITE] + 1e-30 + g_amux_vos[SITE]));//ratio 7.5

	}

	SPIWrite(0x04, 0x200E);//divid vddio 20
	VSUP_11.Set(FV, 24.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	delay_ms(3);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_VSUP24V_R20_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 20
		AMUX_VSUP24V_R20->SetTestResult(SITE, 0, 24.0 / (res1[SITE] + 1e-30));//ratio 20
		AMUX_VSUP24V_R20_OS->SetTestResult(SITE, 0, 24.0 / (res1[SITE] + 1e-30 + g_amux_vos[SITE]));//ratio 7.5

	}

	SPIWrite(0x04, 0x100E);//divid vddio 14
	VSUP_11.Set(FV, 30.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	delay_ms(3);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_VSUP30V_R14_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 14
		AMUX_VSUP30V_R14->SetTestResult(SITE, 0, 30.0 / (res1[SITE] + 1e-30));//ratio 14
		AMUX_VSUP30V_R14_OS->SetTestResult(SITE, 0, 30.0 / (res1[SITE] + 1e-30 + g_amux_vos[SITE]));//ratio 7.5

	}

	SPIWrite(0x04, 0x300E);//divid vddio 34
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_VSUP30V_R34_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 34
		AMUX_VSUP30V_R34->SetTestResult(SITE, 0, 30.0 / (res1[SITE] + 1e-30));//ratio 34
		AMUX_VSUP30V_R34_OS->SetTestResult(SITE, 0, 30.0 / (res1[SITE] + 1e-30 + g_amux_vos[SITE]));//ratio 34
	}
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	SPIWrite(0x04, 0x000C);//divid vddio 3.5
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_VBOS_R3p5_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 
		AMUX_VBOS_R3p5->SetTestResult(SITE, 0, 5.1 / (res1[SITE] + 1e-30));//ratio 
	}
	SPIWrite(0x04, 0x0002);//temp T(��C) = [(VAMUX �C VTEMP25) / VTEMP_COEFF] + 25
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET); //25C 1.26V
		AMUX_TEMP_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 
		AMUX_TEMP_ACTIVE->SetTestResult(SITE, 0,(1.26-res1[SITE]-g_amux_vos[SITE])/3.93*1000+25.0);//current temp 
		g_temp[SITE] = (1.26 - res1[SITE]) / 3.93 * 1000 + 25.0;

	}
	cbite.SetCbiteOn(K36_BUCK1FB_ACM);
	delay_ms(1);
	PREFB_BUCK1FB_8.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	SPIWrite(0x04, 0x0005);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_BUCK1FB_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 1.0
		AMUX_BUCK1FB->SetTestResult(SITE, 0, 1.5 / (res1[SITE] + 1e-30));//ratio 1.0
	}
	cbite.SetCbiteOn(K29_BUCK2FB_ACM);
	delay_ms(1);
	PRECSP_BUCK2FB_9.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	SPIWrite(0x04, 0x0006);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_BUCK2FB_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 1.0
		AMUX_BUCK2FB->SetTestResult(SITE, 0, 1.5 / (res1[SITE] + 1e-30));//ratio 1.0

	}
	cbite.SetCbiteOn(K7_BUCK3FB_ACM);
	delay_ms(1);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.5, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	SPIWrite(0x04, 0x0007);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		AMUX_BUCK3FB_V->SetTestResult(SITE, 0, res1[SITE]);//ratio 2.5
		AMUX_BUCK3FB->SetTestResult(SITE, 0, 1.5 / (res1[SITE] + 1e-30));//ratio 2.5
	}
	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	STSTArming();
	delay_ms(1);


	//cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K2_5V_PU, K114_FXVI5_11_A, K47_WAKE1_FXVIB, K111_FXVI3_9_B,
	//	K32_INTB_FXVIA, K110_FXVI3_9_A, K57_FS0B_PSYNC_PU, -1);

	//delay_ms(1);
	//VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	//VDDIO_VBOOST_0.Set(FV, 3.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	//B3_WAKE12.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(3);
	//Enter_MAIN_TM_DIG();
	//Enter_FS_TM_DIG();
	//Enter_M_TM(0x01E0, 0x0000, 0x0000);

	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	STSTArming();
	//will test other ratio with other functions. or add later,check if can directly test


	
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_OFF);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);


	efmea.fmea_checking(funcindex);
	return 0;
}


DUT_API int T33_SPI_IIC_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam* CSB_VIL = StsGetParam(funcindex, "CSB_VIL");
	CParam* CSB_VIH = StsGetParam(funcindex, "CSB_VIH");
	CParam* CSB_HYS = StsGetParam(funcindex, "CSB_HYS");
	CParam* CSB_LEAK_H = StsGetParam(funcindex, "CSB_LEAK_H");
	CParam* CSB_RPU = StsGetParam(funcindex, "CSB_RPU");

	CParam* SCLK_VIL = StsGetParam(funcindex, "SCLK_VIL");
	CParam* SCLK_VIH = StsGetParam(funcindex, "SCLK_VIH");
	CParam* SCLK_HYS = StsGetParam(funcindex, "SCLK_HYS");
	CParam* SCLK_LEAK = StsGetParam(funcindex, "SCLK_LEAK");
	CParam* MOSI_VIL = StsGetParam(funcindex, "MOSI_VIL");
	CParam* MOSI_VIH = StsGetParam(funcindex, "MOSI_VIH");
	CParam* MOSI_HYS = StsGetParam(funcindex, "MOSI_HYS");
	CParam* MOSI_LEAK = StsGetParam(funcindex, "MOSI_LEAK");
	CParam* MOSI_RPU = StsGetParam(funcindex, "MOSI_RPU");
	CParam* MISO_VOH = StsGetParam(funcindex, "MISO_VOH");
	CParam* MISO_VOL = StsGetParam(funcindex, "MISO_VOL");
	CParam* MISO_TRI_LEAK_H = StsGetParam(funcindex, "MISO_TRI_LEAK_H");
	CParam* MISO_TRI_LEAK_L = StsGetParam(funcindex, "MISO_TRI_LEAK_L");
	CParam* SCL_VIL = StsGetParam(funcindex, "SCL_VIL");
	CParam* SCL_VIH = StsGetParam(funcindex, "SCL_VIH");
	CParam* SCL_HYS = StsGetParam(funcindex, "SCL_HYS");
	CParam* SCL_LEAK_H = StsGetParam(funcindex, "SCL_LEAK_H");
	CParam* SCL_LEAK_L = StsGetParam(funcindex, "SCL_LEAK_L");
	CParam* SDA_LEAK_H = StsGetParam(funcindex, "SDA_LEAK_H");
	CParam* SDA_VIL = StsGetParam(funcindex, "SDA_VIL");
	CParam* SDA_VIH = StsGetParam(funcindex, "SDA_VIH");
	CParam* SDA_HYS = StsGetParam(funcindex, "SDA_HYS");
	CParam* SDA_VOL = StsGetParam(funcindex, "SDA_VOL");

	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double res3[SITE_NUM];
	double res4[SITE_NUM];
	double cap[SITE_NUM][MAX_SAMPLES];
	double VDD_VOLT = 5.0;
	ULONG data0 = 0x0000;


	cbite.SetOn(K24_VDDIO_ACM, K2_5V_PU, K82_BUCK_CAPS, K59_WAKE12_PU, K114_FXVI5_11_A, K8_SCL_SDA_DCM, K56_INTB_PU, K79_PGOOD_PU,
		K32_INTB_FXVIA, K110_FXVI3_9_A, K57_FS0B_PSYNC_PU,-1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	delay_ms(1);
	
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, VDD_VOLT, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();

	Enter_M_TM(0x0409, 0x0000, 0x0000);

	vth_binary_search("CSB", A3_INTB, VDD_VOLT*0.3, VDD_VOLT*0.7, VDD_VOLT, 8, res1, 200, 1, TRIG_FALLING);//0.3*VDD
	vth_binary_search("CSB", A3_INTB, VDD_VOLT * 0.7, VDD_VOLT * 0.3, VDD_VOLT, 8, res2, 200, 1, TRIG_FALLING);//0.7*VDD
	
	SERIAL{
		CSB_VIL->SetTestResult(SITE, 0, res2[SITE]);
		CSB_VIH->SetTestResult(SITE, 0, res1[SITE]);
		CSB_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);
	}
	dcm.SetPPMU("CSB", DCM_PPMU_FVMI, VDD_VOLT, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("CSB", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		CSB_LEAK_H->SetTestResult(SITE, 0, res1[SITE] * 1e9);//nA

	}
	dcm.SetPPMU("CSB", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("CSB", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		CSB_RPU->SetTestResult(SITE, 0, VDD_VOLT/(-res1[SITE]+1e-30)*1e-3);//kohm

	}
	dcm.SetChannelStatus("CSB", DCM_HIGH);//keep high

	//SCLK
	Enter_M_TM(0x0609, 0x0000, 0x0000);

	vth_binary_search("SCLK", A3_INTB, VDD_VOLT * 0.3, VDD_VOLT * 0.7, VDD_VOLT, 8, res1, 200, 1, TRIG_FALLING);//0.3*VDD
	vth_binary_search("SCLK", A3_INTB, VDD_VOLT * 0.7, VDD_VOLT * 0.3, VDD_VOLT, 8, res2, 200, 1, TRIG_FALLING);//0.7*VDD

	SERIAL{
		SCLK_VIL->SetTestResult(SITE, 0, res2[SITE]);
		SCLK_VIH->SetTestResult(SITE, 0, res1[SITE]);
		SCLK_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);
	}
	dcm.SetPPMU("SCLK", DCM_PPMU_FVMI, VDD_VOLT, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("SCLK", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("SCLK_D", SITE);
		SCLK_LEAK->SetTestResult(SITE, 0, res1[SITE]*1e6);

	}
	dcm.SetChannelStatus("SCLK", DCM_LOW);//keep low

	//MOSI
	Enter_M_TM(0x0809, 0x0000, 0x0000);

	vth_binary_search("MOSI", A3_INTB, VDD_VOLT * 0.3, VDD_VOLT * 0.7, VDD_VOLT, 8, res1, 200, 1, TRIG_FALLING);//0.3*VDD
	vth_binary_search("MOSI", A3_INTB, VDD_VOLT * 0.7, VDD_VOLT * 0.3, VDD_VOLT, 8, res2, 200, 1, TRIG_FALLING);//0.7*VDD

	SERIAL{
		MOSI_VIL->SetTestResult(SITE, 0, res2[SITE]);
		MOSI_VIH->SetTestResult(SITE, 0, res1[SITE]);
		MOSI_HYS->SetTestResult(SITE, 0, res1[SITE]- res2[SITE]);

	}
	dcm.SetPPMU("MOSI", DCM_PPMU_FVMI, VDD_VOLT, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("MOSI", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		MOSI_LEAK->SetTestResult(SITE, 0, res1[SITE]* 1e9);//nA

	}
	dcm.SetPPMU("MOSI", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("MOSI", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		MOSI_RPU->SetTestResult(SITE, 0, VDD_VOLT / (-res1[SITE] + 1e-30) * 1e-3);//kohm

	}
	dcm.SetChannelStatus("MOSI", DCM_HIGH);//keep high

	//MISO
	Enter_M_TM(0x0A00, 0x0000, 0x0000);
	dcm.SetPPMU("MISO", DCM_PPMU_FIMV, 2.0e-3, DCM_PPMUIRANGE_32MA);
	delay_ms(2);
	dcm.PPMUMeasure("MISO", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		MISO_VOL->SetTestResult(SITE, 0, res1[SITE] );//V

	}
	dcm.SetPPMU("MISO", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_32MA);
	Enter_M_TM(0x0C00, 0x0000, 0x0000);
	dcm.SetPPMU("MISO", DCM_PPMU_FIMV, -2.0e-3, DCM_PPMUIRANGE_32MA);
	delay_ms(2);
	dcm.PPMUMeasure("MISO", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		MISO_VOH->SetTestResult(SITE, 0, res1[SITE]);//V

	}
	dcm.SetPPMU("MISO", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_32MA);
	Enter_M_TM(0x0E00, 0x0000, 0x0000);
	dcm.SetPPMU("MISO", DCM_PPMU_FVMI, VDD_VOLT, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("MISO", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		MISO_TRI_LEAK_H->SetTestResult(SITE, 0, res1[SITE]*1e9);//nA

	}

	dcm.SetPPMU("MISO", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("MISO", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		MISO_TRI_LEAK_L->SetTestResult(SITE, 0, res1[SITE] * 1e9);//nA

	}

	Enter_M_TM(0x1009, 0x0000, 0x0000);

	dcm.Connect("I2C_G");
	dcm.SetPPMU("I2C_G", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);
	//dcm.SetPinLevel("I2C_G", 5.0, 0, 2.0, 1.9);
	vth_binary_search("SCL_DBG", A3_INTB, 0.5, 1.6, 1.6, 8, res1, 200, 1, TRIG_FALLING);//0.3*VDD
	vth_binary_search("SCL_DBG", A3_INTB, 1.6, 0.5, 1.6, 8, res2, 200, 1, TRIG_FALLING);//0.7*VDD

	SERIAL{
		SCL_VIL->SetTestResult(SITE, 0, res2[SITE]);
		SCL_VIH->SetTestResult(SITE, 0, res1[SITE]);
		SCL_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FVMI, VDD_VOLT, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("SCL_DBG", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		SCL_LEAK_H->SetTestResult(SITE, 0, res1[SITE] * 1e9);//nA

	}
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_200UA);
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("SCL_DBG", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		SCL_LEAK_L->SetTestResult(SITE, 0, res1[SITE] * 1e9);//nA

	}
	dcm.SetPPMU("SDA_WAKE1", DCM_PPMU_FVMI, VDD_VOLT, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.PPMUMeasure("SDA_WAKE1", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		SDA_LEAK_H->SetTestResult(SITE, 0, res1[SITE] * 1e9);//nA

	}
	Enter_M_TM(0x1209, 0x0000, 0x0000);

	vth_binary_search("SDA_WAKE1", A3_INTB, 0.5, 1.6, 1.6, 7, res1, 200, 1, TRIG_FALLING);//0.3*VDD
	vth_binary_search("SDA_WAKE1", A3_INTB, 1.6, 0.5, 1.6, 7, res2, 200, 1, TRIG_FALLING);//0.7*VDD

	SERIAL{
		SDA_VIH->SetTestResult(SITE, 0, res1[SITE]);
		SDA_VIL->SetTestResult(SITE, 0, res2[SITE]);
		SDA_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	Enter_M_TM(0x1409, 0x0000, 0x0000);
	dcm.SetPPMU("SDA_WAKE1", DCM_PPMU_FIMV, 20e-3, DCM_PPMUIRANGE_32MA);
	delay_ms(2);
	dcm.PPMUMeasure("SDA_WAKE1", 30, 10);
	SERIAL{
		res1[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		SDA_VOL->SetTestResult(SITE, 0, res1[SITE] );//nA

	}
	dcm.SetPPMU("SDA_WAKE1", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);
	Enter_M_TM(0x0000, 0x0000, 0x0000);
	


	dcm.Disconnect("I2C_G");



	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_OFF);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	power_off(DEBUG);

	efmea.fmea_checking(funcindex);
	return 0;
}
DUT_API int T35_FCCU12_VCOREMON_VDDIO_VMON1234_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam* FCCU1_VIH = StsGetParam(funcindex, "FCCU1_VIH");
	CParam* FCCU1_VIL = StsGetParam(funcindex, "FCCU1_VIL");
	CParam* FCCU1_HYS = StsGetParam(funcindex, "FCCU1_HYS");
	CParam* FCCU2_VIH = StsGetParam(funcindex, "FCCU2_VIH");
	CParam* FCCU2_VIL = StsGetParam(funcindex, "FCCU2_VIL");
	CParam* FCCU2_HYS = StsGetParam(funcindex, "FCCU2_HYS");
	CParam* FCCU1_Rpd = StsGetParam(funcindex, "FCCU1_Rpd");
	CParam* I_FCCU2_Rpd = StsGetParam(funcindex, "I_FCCU2_Rpd");
	CParam* I_FCCU1_Rpu = StsGetParam(funcindex, "I_FCCU1_Rpu");
	CParam* FCCU2_Rpu = StsGetParam(funcindex, "FCCU2_Rpu");
	CParam* FCCU_Ratio = StsGetParam(funcindex, "FCCU_Ratio");
	
	CParam* VDDIO_OV_12p_R = StsGetParam(funcindex, "VDDIO_OV_12p_R");
	CParam* VDDIO_OV_12p_F = StsGetParam(funcindex, "VDDIO_OV_12p_F");
	CParam* VDDIO_OV_12p_HYS = StsGetParam(funcindex, "VDDIO_OV_12p_HYS");
	CParam* VDDIO_OV_4p5_R = StsGetParam(funcindex, "VDDIO_OV_4p5_R");
	CParam* VDDIO_OV_4p5_F = StsGetParam(funcindex, "VDDIO_OV_4p5_F");
	CParam* VDDIO_OV_4p5_HYS = StsGetParam(funcindex, "VDDIO_OV_4p5_HYS");
	CParam* VDDIO_OV_STEP = StsGetParam(funcindex, "VDDIO_OV_STEP");
	CParam* VDDIO_UV_4p5_R = StsGetParam(funcindex, "VDDIO_UV_4p5_R");
	CParam* VDDIO_UV_4p5_F = StsGetParam(funcindex, "VDDIO_UV_4p5_F");
	CParam* VDDIO_UV_4p5_HYS = StsGetParam(funcindex, "VDDIO_UV_4p5_HYS");
	CParam* VDDIO_UV_12p_R = StsGetParam(funcindex, "VDDIO_UV_12p_R");
	CParam* VDDIO_UV_12p_F = StsGetParam(funcindex, "VDDIO_UV_12p_F");
	CParam* VDDIO_UV_12p_HYS = StsGetParam(funcindex, "VDDIO_UV_12p_HYS");
	CParam* VDDIO_UV_STEP = StsGetParam(funcindex, "VDDIO_UV_STEP");
	CParam* I_VDDIO_V3p3 = StsGetParam(funcindex, "I_VDDIO_V3p3");

	CParam* VCOREMON_OV_12p_R = StsGetParam(funcindex, "VCOREMON_OV_12p_R");
	CParam* VCOREMON_OV_12p_F = StsGetParam(funcindex, "VCOREMON_OV_12p_F");
	CParam* VCOREMON_OV_12p_HYS = StsGetParam(funcindex, "VCOREMON_OV_12p_HYS");
	CParam* VCOREMON_OV_4p5_R = StsGetParam(funcindex, "VCOREMON_OV_4p5_R");
	CParam* VCOREMON_OV_4p5_F = StsGetParam(funcindex, "VCOREMON_OV_4p5_F");
	CParam* VCOREMON_OV_4p5_HYS = StsGetParam(funcindex, "VCOREMON_OV_4p5_HYS");
	CParam* VCOREMON_OV_STEP = StsGetParam(funcindex, "VCOREMON_OV_STEP");
	CParam* VCOREMON_UV_4p5_R = StsGetParam(funcindex, "VCOREMON_UV_4p5_R");
	CParam* VCOREMON_UV_4p5_F = StsGetParam(funcindex, "VCOREMON_UV_4p5_F");
	CParam* VCOREMON_UV_4p5_HYS = StsGetParam(funcindex, "VCOREMON_UV_4p5_HYS");
	CParam* VCOREMON_UV_12p_R = StsGetParam(funcindex, "VCOREMON_UV_12p_R");
	CParam* VCOREMON_UV_12p_F = StsGetParam(funcindex, "VCOREMON_UV_12p_F");
	CParam* VCOREMON_UV_12p_HYS = StsGetParam(funcindex, "VCOREMON_UV_12p_HYS");
	CParam* VCOREMON_UV_STEP = StsGetParam(funcindex, "VCOREMON_UV_STEP");
	CParam* I_VCOREMON_V1p8 = StsGetParam(funcindex, "I_VCOREMON_V1p8");
	CParam* R_VCOREMON = StsGetParam(funcindex, "R_VCOREMON");

	CParam* VMON1_OV_12p_R = StsGetParam(funcindex, "VMON1_OV_12p_R");
	CParam* VMON1_OV_12p_F = StsGetParam(funcindex, "VMON1_OV_12p_F");
	CParam* VMON1_OV_12p_HYS = StsGetParam(funcindex, "VMON1_OV_12p_HYS");
	CParam* VMON1_OV_4p5_R = StsGetParam(funcindex, "VMON1_OV_4p5_R");
	CParam* VMON1_OV_4p5_F = StsGetParam(funcindex, "VMON1_OV_4p5_F");
	CParam* VMON1_OV_4p5_HYS = StsGetParam(funcindex, "VMON1_OV_4p5_HYS");
	CParam* VMON1_OV_STEP = StsGetParam(funcindex, "VMON1_OV_STEP");
	CParam* VMON1_UV_4p5_R = StsGetParam(funcindex, "VMON1_UV_4p5_R");
	CParam* VMON1_UV_4p5_F = StsGetParam(funcindex, "VMON1_UV_4p5_F");
	CParam* VMON1_UV_4p5_HYS = StsGetParam(funcindex, "VMON1_UV_4p5_HYS");
	CParam* VMON1_UV_12p_R = StsGetParam(funcindex, "VMON1_UV_12p_R");
	CParam* VMON1_UV_12p_F = StsGetParam(funcindex, "VMON1_UV_12p_F");
	CParam* VMON1_UV_12p_HYS = StsGetParam(funcindex, "VMON1_UV_12p_HYS");
	CParam* VMON1_UV_STEP = StsGetParam(funcindex, "VMON1_UV_STEP");
	CParam* I_VMON1_V0p8 = StsGetParam(funcindex, "I_VMON1_V0p8");
	CParam* R_VMON1 = StsGetParam(funcindex, "R_VMON1");

	CParam* VMON2_OV_12p_R = StsGetParam(funcindex, "VMON2_OV_12p_R");
	CParam* VMON2_OV_12p_F = StsGetParam(funcindex, "VMON2_OV_12p_F");
	CParam* VMON2_OV_12p_HYS = StsGetParam(funcindex, "VMON2_OV_12p_HYS");
	CParam* VMON2_OV_4p5_R = StsGetParam(funcindex, "VMON2_OV_4p5_R");
	CParam* VMON2_OV_4p5_F = StsGetParam(funcindex, "VMON2_OV_4p5_F");
	CParam* VMON2_OV_4p5_HYS = StsGetParam(funcindex, "VMON2_OV_4p5_HYS");
	CParam* VMON2_OV_STEP = StsGetParam(funcindex, "VMON2_OV_STEP");
	CParam* VMON2_UV_4p5_R = StsGetParam(funcindex, "VMON2_UV_4p5_R");
	CParam* VMON2_UV_4p5_F = StsGetParam(funcindex, "VMON2_UV_4p5_F");
	CParam* VMON2_UV_4p5_HYS = StsGetParam(funcindex, "VMON2_UV_4p5_HYS");
	CParam* VMON2_UV_12p_R = StsGetParam(funcindex, "VMON2_UV_12p_R");
	CParam* VMON2_UV_12p_F = StsGetParam(funcindex, "VMON2_UV_12p_F");
	CParam* VMON2_UV_12p_HYS = StsGetParam(funcindex, "VMON2_UV_12p_HYS");
	CParam* VMON2_UV_STEP = StsGetParam(funcindex, "VMON2_UV_STEP");
	CParam* I_VMON2_V0p8 = StsGetParam(funcindex, "I_VMON2_V0p8");
	CParam* R_VMON2 = StsGetParam(funcindex, "R_VMON2");

	CParam* VMON3_OV_12p_R = StsGetParam(funcindex, "VMON3_OV_12p_R");
	CParam* VMON3_OV_12p_F = StsGetParam(funcindex, "VMON3_OV_12p_F");
	CParam* VMON3_OV_12p_HYS = StsGetParam(funcindex, "VMON3_OV_12p_HYS");
	CParam* VMON3_OV_4p5_R = StsGetParam(funcindex, "VMON3_OV_4p5_R");
	CParam* VMON3_OV_4p5_F = StsGetParam(funcindex, "VMON3_OV_4p5_F");
	CParam* VMON3_OV_4p5_HYS = StsGetParam(funcindex, "VMON3_OV_4p5_HYS");
	CParam* VMON3_OV_STEP = StsGetParam(funcindex, "VMON3_OV_STEP");
	CParam* VMON3_UV_4p5_R = StsGetParam(funcindex, "VMON3_UV_4p5_R");
	CParam* VMON3_UV_4p5_F = StsGetParam(funcindex, "VMON3_UV_4p5_F");
	CParam* VMON3_UV_4p5_HYS = StsGetParam(funcindex, "VMON3_UV_4p5_HYS");
	CParam* VMON3_UV_12p_R = StsGetParam(funcindex, "VMON3_UV_12p_R");
	CParam* VMON3_UV_12p_F = StsGetParam(funcindex, "VMON3_UV_12p_F");
	CParam* VMON3_UV_12p_HYS = StsGetParam(funcindex, "VMON3_UV_12p_HYS");
	CParam* VMON3_UV_STEP = StsGetParam(funcindex, "VMON3_UV_STEP");
	CParam* I_VMON3_V0p8 = StsGetParam(funcindex, "I_VMON3_V0p8");
	CParam* R_VMON3 = StsGetParam(funcindex, "R_VMON3");

	CParam* VMON4_OV_12p_R = StsGetParam(funcindex, "VMON4_OV_12p_R");
	CParam* VMON4_OV_12p_F = StsGetParam(funcindex, "VMON4_OV_12p_F");
	CParam* VMON4_OV_12p_HYS = StsGetParam(funcindex, "VMON4_OV_12p_HYS");
	CParam* VMON4_OV_4p5_R = StsGetParam(funcindex, "VMON4_OV_4p5_R");
	CParam* VMON4_OV_4p5_F = StsGetParam(funcindex, "VMON4_OV_4p5_F");
	CParam* VMON4_OV_4p5_HYS = StsGetParam(funcindex, "VMON4_OV_4p5_HYS");
	CParam* VMON4_OV_STEP = StsGetParam(funcindex, "VMON4_OV_STEP");
	CParam* VMON4_UV_4p5_R = StsGetParam(funcindex, "VMON4_UV_4p5_R");
	CParam* VMON4_UV_4p5_F = StsGetParam(funcindex, "VMON4_UV_4p5_F");
	CParam* VMON4_UV_4p5_HYS = StsGetParam(funcindex, "VMON4_UV_4p5_HYS");
	CParam* VMON4_UV_12p_R = StsGetParam(funcindex, "VMON4_UV_12p_R");
	CParam* VMON4_UV_12p_F = StsGetParam(funcindex, "VMON4_UV_12p_F");
	CParam* VMON4_UV_12p_HYS = StsGetParam(funcindex, "VMON4_UV_12p_HYS");
	CParam* VMON4_UV_STEP = StsGetParam(funcindex, "VMON4_UV_STEP");
	CParam* I_VMON4_V0p8 = StsGetParam(funcindex, "I_VMON4_V0p8");
	CParam* R_VMON4 = StsGetParam(funcindex, "R_VMON4");
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double res3[SITE_NUM];
	double res4[SITE_NUM];
	double cap[SITE_NUM][MAX_SAMPLES];
	double VDD_VOLT = 5.0;
	ULONG data0 = 0x0000;
	ULONG rdata[SITE_NUM];
	cbite.SetOn(K24_VDDIO_ACM, K2_5V_PU, K82_BUCK_CAPS, K59_WAKE12_PU, K56_INTB_PU, K79_PGOOD_PU, K14_VCOREMON_FXVIB,K115_FXVI5_11_B,
		K32_INTB_FXVIA, K110_FXVI3_9_A, K57_FS0B_PSYNC_PU, K28_FCCU12_FXVIA, K104_FXVI0_6_A, K106_FXVI1_7_A, K15_PGOOD_FXVIA, K108_FXVI2_8_A, -1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	delay_ms(1);

	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, VDD_VOLT, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(15);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();

	//FCCU1/2--FS

	Enter_FS_TM(0x003A);
	A2_PGOOD.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A0_FIN_DBG_ERR_FCCU1.Set(FV, VDD_VOLT * 0.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.Set(FV, VDD_VOLT * 0.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	awg.rampv2(A0_FIN_DBG_ERR_FCCU1, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "FCCU1_VTH", VDD_VOLT * 0.3, VDD_VOLT * 0.7, VDD_VOLT * 0.7, VDD_VOLT * 0.3, 0.01, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		FCCU1_VIH->SetTestResult(SITE, 0, res1[SITE]);
		FCCU1_VIL->SetTestResult(SITE, 0, res2[SITE]);
		FCCU1_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	Enter_FS_TM(0x003B);
	awg.rampv2(A1_FOUT_RSTB_FCCU2, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "FCCU2_VTH", VDD_VOLT * 0.3, VDD_VOLT * 0.7, VDD_VOLT * 0.7, VDD_VOLT * 0.3, 0.01, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		FCCU2_VIH->SetTestResult(SITE, 0, res1[SITE]);
		FCCU2_VIL->SetTestResult(SITE, 0, res2[SITE]);
		FCCU2_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	Enter_FS_TM(0x0000);

	A0_FIN_DBG_ERR_FCCU1.Set(FV, VDD_VOLT, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.Set(FV, VDD_VOLT, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	A0_FIN_DBG_ERR_FCCU1.MeasureVI(30, 10);
	A1_FOUT_RSTB_FCCU2.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		FCCU1_Rpd->SetTestResult(SITE, 0, VDD_VOLT / (res1[SITE] + 1e-30) * 1e-3);//800Kohm
		res2[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		I_FCCU2_Rpd->SetTestResult(SITE, 0,res2[SITE]* 1e9);//leakage

	}

	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	A0_FIN_DBG_ERR_FCCU1.MeasureVI(30, 10);
	A1_FOUT_RSTB_FCCU2.MeasureVI(30, 10);
	SERIAL
	{
		res3[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		I_FCCU1_Rpu->SetTestResult(SITE, 0, res3[SITE] * 1e9);//leakage


		res4[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		FCCU2_Rpu->SetTestResult(SITE, 0, VDD_VOLT / (-res4[SITE] + 1e-30) * 1e-3);//200kOHm
		FCCU_Ratio->SetTestResult(SITE, 0, -res4[SITE] / (res1[SITE] + 1e-30));//4

	}
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);
	A1_FOUT_RSTB_FCCU2.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);


	//VDDIO OV UV
	Enter_FS_TM(0x0005);
	SPIWrite(0x7F, 0x7401);
	SPIWrite(0x57, 0x00FF);//12%
	SPIWrite(0x58, 0xFF00);//12%
	SPIRead(0x57, rdata);//12%
	VDDIO_VBOOST_0.Set(FV, 3.3 * 1.08, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);

	delay_ms(1);
	awg.rampv2(VDDIO_VBOOST_0, A2_PGOOD, ACM200_10V, ACM200_100MA, "VDDIO_OV1", 3.3 * 1.08, 3.3 * 1.16, 3.3 * 1.16, 3.3 * 1.08, 0.002, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		VDDIO_OV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 3.3 - 1) * 100);//12%
		VDDIO_OV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 3.3 - 1) * 100);
		VDDIO_OV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 3.3 ) * 100);

	}
	SPIWrite(0x57, data0);//4.5%
	SPIWrite(0x58, 0xFFFF);//4.5%
	VDDIO_VBOOST_0.Set(FV, 3.3 * 1.01, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	awg.rampv2(VDDIO_VBOOST_0, A2_PGOOD, ACM200_10V, ACM200_100MA, "VDDIO_OV2", 3.3 * 1.01, 3.3 * 1.12, 3.3 * 1.12, 3.3 * 1.01, 0.001, 20, 4.0, TRIG_RISING, TRIG_FALLING, res3, res4);
	SERIAL
	{
		VDDIO_OV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 3.3 - 1) * 100);//4.5%
		VDDIO_OV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 3.3 - 1) * 100);
		VDDIO_OV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 3.3) * 100);
		VDDIO_OV_STEP->SetTestResult(SITE, 0, (res1[SITE] - res3[SITE]) / 15.0 / 3.3 * 100);
	}

	Enter_FS_TM(0x0007);
	VDDIO_VBOOST_0.Set(FV, 3.3 * 0.92, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	awg.rampv2(VDDIO_VBOOST_0, A2_PGOOD, ACM200_10V, ACM200_100MA, "VDDIO_UV2", 3.3 * 0.92, 3.3 * 0.99, 3.3 * 0.99, 3.3 * 0.92, 0.001, 20, 4.0, TRIG_FALLING, TRIG_RISING, res3, res4);
	SERIAL
	{
		VDDIO_UV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 3.3 - 1) * 100);//-4.5%
		VDDIO_UV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 3.3 - 1) * 100);
		VDDIO_UV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 3.3) * 100);

	}
	SPIWrite(0x57, 0x00FF);//12%
	SPIWrite(0x58, 0xFF00);//12%
	VDDIO_VBOOST_0.Set(FV, 3.3 * 0.84, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	awg.rampv2(VDDIO_VBOOST_0, A2_PGOOD, ACM200_10V, ACM200_100MA, "VDDIO_UV1", 3.3 * 0.84, 3.3 * 0.92, 3.3 * 0.92, 3.3 * 0.84, 0.001, 20, 4.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{
		VDDIO_UV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 3.3 - 1) * 100);//-12%
		VDDIO_UV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 3.3 - 1) * 100);
		VDDIO_UV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 3.3) * 100);
		VDDIO_UV_STEP->SetTestResult(SITE, 0, (res3[SITE] - res1[SITE]) / 15.0 / 3.3 * 100);
	}
	VDDIO_VBOOST_0.Set(FV, 3.3, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(2);
	VDDIO_VBOOST_0.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE,MIRET);
		I_VDDIO_V3p3->SetTestResult(SITE, 0, res1[SITE] * 1e6);//uA
		

	}
	VDDIO_VBOOST_0.Set(FV, 3.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);

	//VCOREMON
	Enter_FS_TM(0x0001);
	SPIWrite(0x7F, 0x7481);
	SPIWrite(0x40, 0xD000);//set to 1.8V
	SPIWrite(0x7F, 0x7401);
	SPIWrite(0x57, 0xFF00);//12%
	SPIWrite(0x58, 0x00FF);//12%
	//SPIWrite(0x41, 0xFF00);//12%
	SPIWrite(0x7F, 0x7401);
	B5_VMON1234.Set(FV, 1.8 * 1.08, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VCORMON_OV1", 1.8 * 1.08, 1.8 * 1.16, 1.8 * 1.16, 1.8 * 1.08, 0.001, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		VCOREMON_OV_12p_R->SetTestResult(SITE, 0, (res1[SITE]/1.8-1)*100);//12%
		VCOREMON_OV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 1.8 - 1) * 100);
		VCOREMON_OV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE])/ 1.8) * 100);

	}
	SPIWrite(0x57, data0);//4.5%
	SPIWrite(0x58, 0xFFFF);//4.5%
	B5_VMON1234.Set(FV, 1.8 * 1.01, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VCORMON_OV2", 1.8 * 1.01, 1.8 * 1.08, 1.8 * 1.08, 1.8 * 1.01, 0.001, 20, 4.0, TRIG_RISING, TRIG_FALLING, res3, res4);
	SERIAL
	{
		VCOREMON_OV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 1.8 - 1) * 100);//4.5%
		VCOREMON_OV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 1.8 - 1) * 100);
		VCOREMON_OV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 1.8) * 100);
		VCOREMON_OV_STEP->SetTestResult(SITE, 0, (res1[SITE] - res3[SITE])/15.0/1.8*100);
	}

	Enter_FS_TM(0x0003);
	B5_VMON1234.Set(FV, 1.8 * 0.92, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VCORMON_UV2", 1.8 * 0.92, 1.8 * 0.99, 1.8 * 0.99, 1.8 * 0.92, 0.001, 20, 4.0, TRIG_FALLING, TRIG_RISING, res3, res4);
	SERIAL
	{
		VCOREMON_UV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 1.8 - 1) * 100);//-4.5%
		VCOREMON_UV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 1.8 - 1) * 100);
		VCOREMON_UV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 1.8) * 100);
				 
	}
	SPIWrite(0x57, 0xFF00);//12%
	SPIWrite(0x58, 0x00FF);//12%
	B5_VMON1234.Set(FV, 1.8 * 0.84, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VCORMON_UV1", 1.8 * 0.84, 1.8 * 0.92, 1.8 * 0.92, 1.8 * 0.84, 0.001, 20, 4.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{
		VCOREMON_UV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 1.8 - 1) * 100);//-12%
		VCOREMON_UV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 1.8 - 1) * 100);
		VCOREMON_UV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 1.8) * 100);
		VCOREMON_UV_STEP->SetTestResult(SITE, 0, (res3[SITE] - res1[SITE]) / 15.0 / 1.8 * 100);
	}
	B5_VMON1234.Set(FV, 1.8, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = B5_VMON1234.GetMeasResult(SITE,MIRET);
		I_VCOREMON_V1p8->SetTestResult(SITE, 0, res1[SITE]*1e6 );//uA
		R_VCOREMON->SetTestResult(SITE, 0, 1.8/(res1[SITE] +1e-30)*1e-6);//2M��

	}

	///VMON1
	cbite.SetCbiteOff(K14_VCOREMON_FXVIB);
	delay_ms(1);
	cbite.SetCbiteOn(K13_VMON1_FXVIB);
	delay_ms(1);
	Enter_FS_TM(0x0009);
	SPIWrite(0x7F, 0x7481);
	SPIWrite(0x43, 0x000F);//Enable VMONx
	SPIWrite(0x7F, 0x7401);
	SPIWrite(0x59, 0xFF00);//12%
	SPIWrite(0x5A, 0x00FF);//12%

	B5_VMON1234.Set(FV, 0.8 * 1.08, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON1_OV1", 0.8 * 1.08, 0.8 * 1.16, 0.8 * 1.16, 0.8 * 1.08, 0.0005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		VMON1_OV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 0.8 - 1) * 100);//12%
		VMON1_OV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 0.8 - 1) * 100);
		VMON1_OV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 0.8) * 100);

	}
	SPIWrite(0x59, data0);//4.5%
	SPIWrite(0x5A, 0xFFFF);//4.5%
	B5_VMON1234.Set(FV, 0.8 * 1.01, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON1_OV2", 0.8 * 1.01, 0.8 * 1.08, 0.8 * 1.08, 0.8 * 1.01, 0.0005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res3, res4);
	SERIAL
	{
		VMON1_OV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 0.8 - 1) * 100);//4.5%
		VMON1_OV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 0.8 - 1) * 100);
		VMON1_OV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 0.8) * 100);
		VMON1_OV_STEP->SetTestResult(SITE, 0, (res1[SITE] - res3[SITE]) / 15.0 / 0.8 * 100);
	}

	Enter_FS_TM(0x000B);
	B5_VMON1234.Set(FV, 0.8 * 0.92, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON1_UV2", 0.8 * 0.92, 0.8 * 0.99, 0.8 * 0.99, 0.8 * 0.92, 0.0005, 20, 4.0, TRIG_FALLING, TRIG_RISING, res3, res4);
	SERIAL
	{
		VMON1_UV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 0.8 - 1) * 100);//-4.5%
		VMON1_UV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 0.8 - 1) * 100);
		VMON1_UV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 0.8 ) * 100);

	}
	SPIWrite(0x59, 0xFF00);//12%
	SPIWrite(0x5A, 0x00FF);//12%
	B5_VMON1234.Set(FV, 0.8 * 0.84, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON1_UV1", 0.8 * 0.84, 0.8 * 0.92, 0.8 * 0.92, 0.8 * 0.84, 0.0005, 20, 4.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{
		VMON1_UV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 0.8 - 1) * 100);//-12%
		VMON1_UV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 0.8 - 1) * 100);
		VMON1_UV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 0.8) * 100);
		VMON1_UV_STEP->SetTestResult(SITE, 0, (res3[SITE] - res1[SITE]) / 15.0 / 0.8 * 100);
	}
	B5_VMON1234.Set(FV, 0.8, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = B5_VMON1234.GetMeasResult(SITE,MIRET);
		I_VMON1_V0p8->SetTestResult(SITE, 0, res1[SITE] * 1e6);//uA
		R_VMON1->SetTestResult(SITE, 0, 0.8 / (res1[SITE] + 1e-30) * 1e-6);//2M��

	}
		///VMON2
	cbite.SetCbiteOff(K13_VMON1_FXVIB);
	delay_ms(1);
	cbite.SetCbiteOn(K12_VMON2_FXVIB);
	delay_ms(1);
	Enter_FS_TM(0x000D);
	SPIWrite(0x59, 0x00FF);//12%
	SPIWrite(0x5A, 0xFF00);//12%
	B5_VMON1234.Set(FV, 0.8 * 1.08, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON2_OV1", 0.8 * 1.08, 0.8 * 1.16, 0.8 * 1.16, 0.8 * 1.08, 0.0005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		VMON2_OV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 0.8 - 1) * 100);//12%
		VMON2_OV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 0.8 - 1) * 100);
		VMON2_OV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 0.8) * 100);

	}
	SPIWrite(0x59, data0);//4.5%
	SPIWrite(0x5A, 0xFFFF);//4.5%
	B5_VMON1234.Set(FV, 0.8 * 1.01, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON2_OV2", 0.8 * 1.01, 0.8 * 1.08, 0.8 * 1.08, 0.8 * 1.01, 0.0005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res3, res4);
	SERIAL
	{
		VMON2_OV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 0.8 - 1) * 100);//4.5%
		VMON2_OV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 0.8 - 1) * 100);
		VMON2_OV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 0.8) * 100);
		VMON2_OV_STEP->SetTestResult(SITE, 0, (res1[SITE] - res3[SITE]) / 15.0 / 0.8 * 100);
	}

	Enter_FS_TM(0x000F);
	B5_VMON1234.Set(FV, 0.8 * 0.92, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON2_UV2", 0.8 * 0.92, 0.8 * 0.99, 0.8 * 0.99, 0.8 * 0.92, 0.0005, 20, 4.0, TRIG_FALLING, TRIG_RISING, res3, res4);
	SERIAL
	{
		VMON2_UV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 0.8 - 1) * 100);//-4.5%
		VMON2_UV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 0.8 - 1) * 100);
		VMON2_UV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 0.8) * 100);

	}
	SPIWrite(0x59, 0x00FF);//12%
	SPIWrite(0x5A, 0xFF00);//12%
	B5_VMON1234.Set(FV, 0.8 * 0.84, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON2_UV1", 0.8 * 0.84, 0.8 * 0.92, 0.8 * 0.92, 0.8 * 0.84, 0.0005, 20, 4.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{
		VMON2_UV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 0.8 - 1) * 100);//-12%
		VMON2_UV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 0.8 - 1) * 100);
		VMON2_UV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 0.8) * 100);
		VMON2_UV_STEP->SetTestResult(SITE, 0, (res3[SITE] - res1[SITE]) / 15.0 / 0.8 * 100);
	}
	B5_VMON1234.Set(FV, 0.8, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = B5_VMON1234.GetMeasResult(SITE,MIRET);
		I_VMON2_V0p8->SetTestResult(SITE, 0, res1[SITE] * 1e6);//uA
		R_VMON2->SetTestResult(SITE, 0, 0.8 / (res1[SITE] + 1e-30) * 1e-6);//2M��

	}
		///VMON3
	cbite.SetCbiteOff(K12_VMON2_FXVIB);
	delay_ms(1);
	cbite.SetCbiteOn(K10_VMON3_FXVIB);
	delay_ms(1);
	Enter_FS_TM(0x0011);
	SPIWrite(0x5B, 0xFF00);//12%
	SPIWrite(0x5C, 0x00FF);//12%
	B5_VMON1234.Set(FV, 0.8 * 1.08, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON3_OV1", 0.8 * 1.08, 0.8 * 1.16, 0.8 * 1.16, 0.8 * 1.08, 0.0005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		VMON3_OV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 0.8 - 1) * 100);//12%
		VMON3_OV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 0.8 - 1) * 100);
		VMON3_OV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 0.8) * 100);

	}
	SPIWrite(0x5B, data0);//4.5%
	SPIWrite(0x5C, 0xFFFF);//4.5%
	B5_VMON1234.Set(FV, 0.8 * 1.01, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON3_OV2", 0.8 * 1.01, 0.8 * 1.08, 0.8 * 1.08, 0.8 * 1.01, 0.0005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res3, res4);
	SERIAL
	{
		VMON3_OV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 0.8 - 1) * 100);//4.5%
		VMON3_OV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 0.8 - 1) * 100);
		VMON3_OV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 0.8) * 100);
		VMON3_OV_STEP->SetTestResult(SITE, 0, (res1[SITE] - res3[SITE]) / 15.0 / 0.8 * 100);
	}

	Enter_FS_TM(0x0013);
	B5_VMON1234.Set(FV, 0.8 * 0.92, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON3_UV2", 0.8 * 0.92, 0.8 * 0.99, 0.8 * 0.99, 0.8 * 0.92, 0.0005, 20, 4.0, TRIG_FALLING, TRIG_RISING, res3, res4);
	SERIAL
	{
		VMON3_UV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 0.8 - 1) * 100);//-4.5%
		VMON3_UV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 0.8 - 1) * 100);
		VMON3_UV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 0.8) * 100);

	}
	SPIWrite(0x5B, 0xFF00);//12%
	SPIWrite(0x5C, 0x00FF);//12%
	B5_VMON1234.Set(FV, 0.8 * 0.84, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON3_UV1", 0.8 * 0.84, 0.8 * 0.92, 0.8 * 0.92, 0.8 * 0.84, 0.0005, 20, 4.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{
		VMON3_UV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 0.8 - 1) * 100);//-12%
		VMON3_UV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 0.8 - 1) * 100);
		VMON3_UV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 0.8) * 100);
		VMON3_UV_STEP->SetTestResult(SITE, 0, (res3[SITE] - res1[SITE]) / 15.0 / 0.8 * 100);
	}
	B5_VMON1234.Set(FV, 0.8, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = B5_VMON1234.GetMeasResult(SITE,MIRET);
		I_VMON3_V0p8->SetTestResult(SITE, 0, res1[SITE] * 1e6);//uA
		R_VMON3->SetTestResult(SITE, 0, 0.8 / (res1[SITE] + 1e-30) * 1e-6);//2M��

	}
		///VMON4
	cbite.SetCbiteOff(K10_VMON3_FXVIB);
	delay_ms(1);
	cbite.SetCbiteOn(K9_VMON4_FXVIB);
	delay_ms(1);
	Enter_FS_TM(0x0015);
	SPIWrite(0x5B, 0x00FF);//12%
	SPIWrite(0x5C, 0xFF00);//12%
	B5_VMON1234.Set(FV, 0.8 * 1.08, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON4_OV1", 0.8 * 1.08, 0.8 * 1.16, 0.8 * 1.16, 0.8 * 1.08, 0.0005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		VMON4_OV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 0.8 - 1) * 100);//12%
		VMON4_OV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 0.8 - 1) * 100);
		VMON4_OV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 0.8) * 100);

	}
	SPIWrite(0x5B, data0);//4.5%
	SPIWrite(0x5C, 0xFFFF);//4.5%
	B5_VMON1234.Set(FV, 0.8 * 1.01, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON4_OV2", 0.8 * 1.01, 0.8 * 1.08, 0.8 * 1.08, 0.8 * 1.01, 0.0005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res3, res4);
	SERIAL
	{
		VMON4_OV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 0.8 - 1) * 100);//4.5%
		VMON4_OV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 0.8 - 1) * 100);
		VMON4_OV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 0.8) * 100);
		VMON4_OV_STEP->SetTestResult(SITE, 0, (res1[SITE] - res3[SITE]) / 15.0 / 0.8 * 100);
	}

	Enter_FS_TM(0x0017);
	B5_VMON1234.Set(FV, 0.8 * 0.92, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON4_UV2", 0.8 * 0.92, 0.8 * 0.99, 0.8 * 0.99, 0.8 * 0.92, 0.0005, 20, 4.0, TRIG_FALLING, TRIG_RISING, res3, res4);
	SERIAL
	{
		VMON4_UV_4p5_R->SetTestResult(SITE, 0, (res3[SITE] / 0.8 - 1) * 100);//-4.5%
		VMON4_UV_4p5_F->SetTestResult(SITE, 0, (res4[SITE] / 0.8 - 1) * 100);
		VMON4_UV_4p5_HYS->SetTestResult(SITE, 0, ((res3[SITE] - res4[SITE]) / 0.8) * 100);

	}
	SPIWrite(0x5B, 0x00FF);//12%
	SPIWrite(0x5C, 0xFF00);//12%
	B5_VMON1234.Set(FV, 0.8 * 0.84, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	awg.rampv2(B5_VMON1234, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "VMON4_UV1", 0.8 * 0.84, 0.8 * 0.92, 0.8 * 0.92, 0.8 * 0.84, 0.0005, 20, 4.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{
		VMON4_UV_12p_R->SetTestResult(SITE, 0, (res1[SITE] / 0.8 - 1) * 100);//-12%
		VMON4_UV_12p_F->SetTestResult(SITE, 0, (res2[SITE] / 0.8 - 1) * 100);
		VMON4_UV_12p_HYS->SetTestResult(SITE, 0, ((res1[SITE] - res2[SITE]) / 0.8) * 100);
		VMON4_UV_STEP->SetTestResult(SITE, 0, (res3[SITE] - res1[SITE]) / 15.0 / 0.8 * 100);
	}
	B5_VMON1234.Set(FV, 0.8, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = B5_VMON1234.GetMeasResult(SITE,MIRET);
		I_VMON4_V0p8->SetTestResult(SITE, 0, res1[SITE] * 1e6);//uA
		R_VMON4->SetTestResult(SITE, 0, 0.8 / (res1[SITE] + 1e-30) * 1e-6);//2M��

	}

	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	STSTArming();
	//will test other ratio with other functions. or add later,check if can directly test



	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_OFF);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);


	efmea.fmea_checking(funcindex);
	return 0;
}
DUT_API int T37_ERMON_PGOOD_RSTB_FS0B_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam* ERRMON_VIH = StsGetParam(funcindex, "ERRMON_VIH");
	CParam* ERRMON_VIL = StsGetParam(funcindex, "ERRMON_VIL");
	CParam* ERRMON_HYS = StsGetParam(funcindex, "ERRMON_HYS");
	CParam* IERRMON_PD = StsGetParam(funcindex, "IERRMON_PD");
	CParam* ERRMON_Rpd = StsGetParam(funcindex, "ERRMON_Rpd");
	CParam* IERRMON_PU = StsGetParam(funcindex, "IERRMON_PU");

	CParam* PGOOD_VIH = StsGetParam(funcindex, "PGOOD_VIH");
	CParam* PGOOD_VIL = StsGetParam(funcindex, "PGOOD_VIL");
	CParam* PGOOD_HYS = StsGetParam(funcindex, "PGOOD_HYS");
	CParam* PGOOD_VOL = StsGetParam(funcindex, "PGOOD_VOL");
	CParam* PGOOD_RPD = StsGetParam(funcindex, "PGOOD_RPD");
	CParam* PGOOD_ILMT = StsGetParam(funcindex, "PGOOD_ILMT");
	
	CParam* RSTB_VIH = StsGetParam(funcindex, "RSTB_VIH");
	CParam* RSTB_VIL = StsGetParam(funcindex, "RSTB_VIL");
	CParam* RSTB_HYS = StsGetParam(funcindex, "RSTB_HYS");
	CParam* RSTB_VOL = StsGetParam(funcindex, "RSTB_VOL");
	CParam* IRSTB_LIM = StsGetParam(funcindex, "IRSTB_LIM");
	CParam* RSTB_RPD = StsGetParam(funcindex, "RSTB_RPD");


	CParam* FS0B_VIH = StsGetParam(funcindex, "FS0B_VIH");
	CParam* FS0B_VIL = StsGetParam(funcindex, "FS0B_VIL");
	CParam* FS0B_HYS = StsGetParam(funcindex, "FS0B_HYS");
	CParam* FS0B_VOL = StsGetParam(funcindex, "FS0B_VOL");
	CParam* IFS0B_LIM = StsGetParam(funcindex, "IFS0B_LIM");
	CParam* FS0B_RPD = StsGetParam(funcindex, "FS0B_RPD");
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double res3[SITE_NUM];
	double res4[SITE_NUM];
	double cap[SITE_NUM][MAX_SAMPLES];
	double VDD_VOLT = 5.0;
	ULONG data0 = 0x0000;
	ULONG rdata[SITE_NUM];

	cbite.SetOn(K24_VDDIO_ACM, K2_5V_PU, K82_BUCK_CAPS, K59_WAKE12_PU, /*K79_PGOOD_PU,*/ K37_ERRMON_FXVIA, K104_FXVI0_6_A,
		K16_RSTB_FXVIA,K106_FXVI1_7_A,/*K57_FS0B_PSYNC_PU,*/K55_RSTB_PU, K15_PGOOD_FXVIA, K108_FXVI2_8_A, -1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	delay_ms(1);
	
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, VDD_VOLT, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(1);
	A2_PGOOD.Set(FI, 2.0e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	delay_ms(2);
	A2_PGOOD.MeasureVI(30, 10);

	SERIAL
	{
		res1[SITE] = A2_PGOOD.GetMeasResult(SITE, MVRET);
		PGOOD_VOL->SetTestResult(SITE, 0, res1[SITE]);//

	}

	A2_PGOOD.Set(FV, 3.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	delay_ms(5);
	A2_PGOOD.MeasureVI(3000, 100);

	SERIAL
	{
		res1[SITE] = A2_PGOOD.GetMeasResult(SITE, MIRET);
		PGOOD_ILMT->SetTestResult(SITE, 0, res1[SITE] * 1e3);//

	}
	A2_PGOOD.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	//cbite.SetCbiteOff(K60_WAKE12_PD);
	cbite.SetCbiteOn(K79_PGOOD_PU);
	//delay_ms(2);
	//cbite.SetCbiteOn(K59_WAKE12_PU);
	
//	delay_ms(1);
	
	delay_ms(15);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();

	//ERRMON
	//SPIWrite(0x7F, 0x7481);
	//SPIWrite(0x43, 0x0020);//Enable VMONx
	Enter_FS_TM(0x001B);
	
	SPIRead(0x43, rdata);
	A2_PGOOD.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 1.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	awg.rampv2(A0_FIN_DBG_ERR_FCCU1, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "ERRMON_VTH", 1, 2, 2, 1, 0.005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		ERRMON_VIH->SetTestResult(SITE, 0, res1[SITE]);
		ERRMON_VIL->SetTestResult(SITE, 0, res2[SITE]);
		ERRMON_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	Enter_FS_TM(0x0000);

	A0_FIN_DBG_ERR_FCCU1.Set(FV, VDD_VOLT, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	A0_FIN_DBG_ERR_FCCU1.MeasureVI(30, 10);

	SERIAL
	{
		res1[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		IERRMON_PD->SetTestResult(SITE, 0, res1[SITE]  * 1e6);//10uA
		ERRMON_Rpd->SetTestResult(SITE, 0, VDD_VOLT / (res1[SITE] + 1e-30) * 1e-3);//800Kohm

	}

	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	A0_FIN_DBG_ERR_FCCU1.MeasureVI(30, 10);

	SERIAL
	{
		res3[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		IERRMON_PU->SetTestResult(SITE, 0, res3[SITE] * 1e9);//

	}
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);

	//PGOOD
	cbite.SetCbiteOff(K79_PGOOD_PU);
	delay_ms(1);
	Enter_FS_TM(0x001C);
	A1_FOUT_RSTB_FCCU2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A2_PGOOD.Set(FV, 1.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	awg.rampv2(A2_PGOOD, A1_FOUT_RSTB_FCCU2, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "PGOOD_VTH", 1.0, 2.0, 2.0, 1.0, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		PGOOD_VIH->SetTestResult(SITE, 0, res1[SITE]);
		PGOOD_VIL->SetTestResult(SITE, 0, res2[SITE]);
		PGOOD_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	
	A2_PGOOD.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	Enter_FS_TM(0x001E);
	A2_PGOOD.Set(FV, 3.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(2);
	A2_PGOOD.MeasureVI(30, 10);

	SERIAL
	{
		res1[SITE] = A2_PGOOD.GetMeasResult(SITE, MIRET);
		PGOOD_RPD->SetTestResult(SITE, 0, 3.0/(res1[SITE]+1e-30)*1e-3);//400kohm

	}
	A2_PGOOD.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	cbite.SetCbiteOff(K55_RSTB_PU);
	delay_ms(1);
	//RSTB

	Enter_FS_TM(0x0022);

	cbite.SetCbiteOn(K79_PGOOD_PU);
	delay_ms(1);
	A2_PGOOD.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.Set(FV, 1.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	awg.rampv2(A1_FOUT_RSTB_FCCU2, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "PGOOD_VTH", 1.0, 2.0, 2.0, 1.0, 0.005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		RSTB_VIH->SetTestResult(SITE, 0, res1[SITE]);
		RSTB_VIL->SetTestResult(SITE, 0, res2[SITE]);
		RSTB_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	Enter_FS_TM(0x0023);
	A1_FOUT_RSTB_FCCU2.Set(FI, 2.0e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	delay_ms(2);
	A1_FOUT_RSTB_FCCU2.MeasureVI(30, 10);

	SERIAL
	{
		res1[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MVRET);
		RSTB_VOL->SetTestResult(SITE, 0, res1[SITE]);//

	}

	A1_FOUT_RSTB_FCCU2.Set(FV, 3.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	A1_FOUT_RSTB_FCCU2.MeasureVI(30, 10);

	SERIAL
	{
		res1[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		IRSTB_LIM->SetTestResult(SITE, 0, res1[SITE]*1e3);//mA

	}

	A1_FOUT_RSTB_FCCU2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	Enter_FS_TM(0x0024);
	A1_FOUT_RSTB_FCCU2.Set(FV, 3.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(2);
	A1_FOUT_RSTB_FCCU2.MeasureVI(30, 10);

	SERIAL
	{
		res1[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		RSTB_RPD->SetTestResult(SITE, 0, 3.0 / (res1[SITE] + 1e-30) * 1e-3);//400kohm

	}
	A1_FOUT_RSTB_FCCU2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);

	//FS0B

	Enter_FS_TM(0x002C);
	A2_PGOOD.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A4_PSYNC_PREFB.Set(FV, 1.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	awg.rampv2_FO(A4_PSYNC_PREFB, A2_PGOOD, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "FS0B_VTH", 1.0, 2.0, 2.0, 1.0, 0.005, 20, 4.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{
		FS0B_VIH->SetTestResult(SITE, 0, res1[SITE]);
		FS0B_VIL->SetTestResult(SITE, 0, res2[SITE]);
		FS0B_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);

	}
	Enter_FS_TM(0x002D);
	A4_PSYNC_PREFB.Set(FI, 2.0e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);

	delay_ms(2);
	A4_PSYNC_PREFB.MeasureVI(30, 10);

	SERIAL
	{
		res1[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MVRET);
		FS0B_VOL->SetTestResult(SITE, 0, res1[SITE]);//

	}

	A4_PSYNC_PREFB.Set(FV, 3.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(2);
	A4_PSYNC_PREFB.MeasureVI(30, 10);

	SERIAL
	{
		res1[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MIRET);
		IFS0B_LIM->SetTestResult(SITE, 0, res1[SITE] * 1e3);//mA

	}

	A4_PSYNC_PREFB.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);

	Enter_FS_TM(0x002E);
	A4_PSYNC_PREFB.Set(FV, 3.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);

	delay_ms(2);
	A4_PSYNC_PREFB.MeasureVI(30, 10);

	SERIAL
	{
		res1[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MIRET);
		FS0B_RPD->SetTestResult(SITE, 0, 3.0 / (res1[SITE] + 1e-30) * 1e-6);//400kohm

	}
	A4_PSYNC_PREFB.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);


	//will test other ratio with other functions. or add later,check if can directly test



	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	VSUP_11.TSet(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_OFF);
	A3_INTB.TSet(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	VDDIO_VBOOST_0.TSet(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A2_PGOOD.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	A4_PSYNC_PREFB.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	STSTArming();
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T39_VBOOST_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam* VBOOST_DIV8_5V = StsGetParam(funcindex, "VBOOST_DIV8_5V");
	CParam* VBOOST_DIV8_5V_Ratio = StsGetParam(funcindex, "VBOOST_DIV8_5V_Ratio");
	CParam* VBOOST_BG = StsGetParam(funcindex, "VBOOST_BG");
	CParam* VBOOST_DIV4 = StsGetParam(funcindex, "VBOOST_DIV4");
	CParam* VBOOST_DIV8_5p75V = StsGetParam(funcindex, "VBOOST_DIV8_5p75V");
	CParam* VBOOST_DIV8_5p75V_Ratio = StsGetParam(funcindex, "VBOOST_DIV8_5p75V_Ratio");
	CParam* VBOOST_DIV8_6V = StsGetParam(funcindex, "VBOOST_DIV8_6V");
	CParam* VBOOST_DIV8_6V_Ratio = StsGetParam(funcindex, "VBOOST_DIV8_6V_Ratio");
	CParam* BOOST_SSTIME = StsGetParam(funcindex, "BOOST_SSTIME");
	CParam* BOOST_SSDONE = StsGetParam(funcindex, "BOOST_SSDONE");
	CParam* BOOST_VCOMP_HCLAMP = StsGetParam(funcindex, "BOOST_VCOMP_HCLAMP");
	CParam* BOOST_VCOMP_LCLAMP = StsGetParam(funcindex, "BOOST_VCOMP_LCLAMP");

	CParam* VBOOST_UV_ABS_R = StsGetParam(funcindex, "VBOOST_UV_ABS_R");
	CParam* VBOOST_UV_ABS_F = StsGetParam(funcindex, "VBOOST_UV_ABS_F");
	CParam* VBOOST_UV_ABS_HYS = StsGetParam(funcindex, "VBOOST_UV_ABS_HYS");
	CParam* VBOOST_UV_REL_R = StsGetParam(funcindex, "VBOOST_UV_REL_R");
	CParam* VBOOST_UV_REL_F = StsGetParam(funcindex, "VBOOST_UV_REL_F");
	CParam* VBOOST_UV_REL_HYS = StsGetParam(funcindex, "VBOOST_UV_REL_HYS");
	CParam* VBOOST_OV_ABS_R = StsGetParam(funcindex, "VBOOST_OV_ABS_R");
	CParam* VBOOST_OV_ABS_F = StsGetParam(funcindex, "VBOOST_OV_ABS_F");
	CParam* VBOOST_OV_ABS_HYS = StsGetParam(funcindex, "VBOOST_OV_ABS_HYS");
	CParam* VBOOST_OV_REL_R = StsGetParam(funcindex, "VBOOST_OV_REL_R");
	CParam* VBOOST_OV_REL_F = StsGetParam(funcindex, "VBOOST_OV_REL_F");
	CParam* VBOOST_OV_REL_HYS = StsGetParam(funcindex, "VBOOST_OV_REL_HYS");
	
	CParam* BOOST_LS_OV_R = StsGetParam(funcindex, "BOOST_LS_OV_R");
	CParam* BOOST_LS_OV_F = StsGetParam(funcindex, "BOOST_LS_OV_F");
	CParam* BOOST_LS_OV_HYS = StsGetParam(funcindex, "BOOST_LS_OV_HYS");
	CParam* IBOOST_CLAMP_PRE = StsGetParam(funcindex, "IBOOST_CLAMP_PRE");

	CParam* BOOST_CLAMP_ZENER_OV = StsGetParam(funcindex, "BOOST_CLAMP_ZENER_OV");
	CParam* BOOST_CLAMP_VOLT = StsGetParam(funcindex, "BOOST_CLAMP_VOLT");
	CParam* IBOOST_CLAMP_POST = StsGetParam(funcindex, "IBOOST_CLAMP_POST");
	CParam* IBOOST_CLAMP_Delta = StsGetParam(funcindex, "IBOOST_CLAMP_Delta");

	CParam* TSD_R = StsGetParam(funcindex, "TSD_R");
	CParam* TSD_F = StsGetParam(funcindex, "TSD_F");
	CParam* TSD_HYS = StsGetParam(funcindex, "TSD_HYS");
	CParam* BOOST_FSW_DCM = StsGetParam(funcindex, "BOOST_FSW_DCM");
	CParam* BOOST_MAXTON_DCM = StsGetParam(funcindex, "BOOST_MAXTON_DCM");
	CParam* BOOST_FSW_DCM1 = StsGetParam(funcindex, "BOOST_FSW_DCM1");
	CParam* BOOST_MINTON_DCM = StsGetParam(funcindex, "BOOST_MINTON_DCM");
	CParam* BOOST_FSW_DCM1_0x01 = StsGetParam(funcindex, "BOOST_FSW_DCM1_0x01");
	CParam* BOOST_MINTON_DCM_0x01 = StsGetParam(funcindex, "BOOST_MINTON_DCM_0x01");

	
		
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double res3[SITE_NUM];
	double res4[SITE_NUM];
	double cap[SITE_NUM][1000];
	ULONG data0 = 0x0000;
	ULONG rdata[SITE_NUM];
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, K56_INTB_PU,
		K50_VBOOST_FXVIB, K109_FXVI2_8_B, K3_BOOSTLS_ACM, K80_PRECSP_PREFB_SHRT, K45_PREFB_FXVIA, K112_FXVI4_10_A, K84_PRECOMP_CAP,
		K32_INTB_FXVIA, K110_FXVI3_9_A, K46_PREFB_ACM,K17_FIN_FXVIA, K104_FXVI0_6_A, -1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	delay_ms(1);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(4);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	SPIWrite(0x04, 0x0013);//setting AMUX to single output
	//A4_PSYNC_PREFB.Set(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	SPIWrite(0x3F, 0x7481);//switch to main otp
	//bit26-22
	//0000 0xxx xx00 0000=>0x31
	Enter_M_TM(0x0004, 0x0100, 0x0000);

	//No need force 3.3V, will check it
	B2_PREBOOT_VBOOST.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		VBOOST_DIV8_5V->SetTestResult(SITE, 0, results[SITE]);
		VBOOST_DIV8_5V_Ratio->SetTestResult(SITE, 0, results[SITE]/5.0);
	}

	Enter_M_TM(0x0004, 0x0500, 0x0000);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		VBOOST_BG->SetTestResult(SITE, 0, results[SITE]);
		
	}

	Enter_M_TM(0x0004, 0x0540, 0x0000);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		VBOOST_DIV4->SetTestResult(SITE, 0, results[SITE]);
		
	}
	Enter_M_TM(0x0004, 0x0100, 0x0000);
	B2_PREBOOT_VBOOST.Set(FV, 5.75, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		VBOOST_DIV8_5p75V->SetTestResult(SITE, 0, results[SITE]);
		VBOOST_DIV8_5p75V_Ratio->SetTestResult(SITE, 0, results[SITE] / 5.75);
	}
	B2_PREBOOT_VBOOST.Set(FV, 6.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = A5_AMUX.GetMeasResult(SITE, MVRET) + g_amux_vos[SITE];
		VBOOST_DIV8_6V->SetTestResult(SITE, 0, results[SITE]);
		VBOOST_DIV8_6V_Ratio->SetTestResult(SITE, 0, results[SITE] / 6.0);
	}

		//soft start ,ssdone
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);


	SPIWrite(0x30, 0x0004);
	A3_INTB.MeasureVI(300, 10, FXVIe_PLUS_MI_X1,MEAS_AWG);

	STSEnableMeas(&A3_INTB);
	///Enter_M_TM(0x0004, 0x0140, 0x0000);//check if need sync fucntion
	SPIWrite_SYNC(0x31, 0x0140);

	STSAWGRun();


	SERIAL{
		A3_INTB.BlockRead(SITE, 0, 300, cap[SITE], MVRET);
		res1[SITE] = 0;
		res2[SITE] = 0;
		for (int i = 5; i < 100; i++)
		{
			if (cap[SITE][i] < 2.0)
			{
				res1[SITE] = i ;//
				break;
				
			}

		}
		for (int i = 299; i  > 5; i--)
		{
			if (cap[SITE][i] < 2.0)
			{
				res2[SITE] = i;//
				break;

			}

		}
		results[SITE] = res2[SITE] - res1[SITE];
		BOOST_SSTIME->SetTestResult(SITE, 0, res1[SITE]*10);//ss time
		BOOST_SSDONE->SetTestResult(SITE, 0, res2[SITE] * 10);//us
	}
	///VComp Hclamp/Lclamp
	B2_PREBOOT_VBOOST.Set(FV, 5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON,0.5);
	Enter_M_TM(0x0004, 0x0240, 0x0000);
	SPIWrite(0x01, data0);
	delay_ms(1);
	awg.rampv(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "BOOST_HCLAMP", 5.0, 3.5, 0.005, 50, 2.0, TRIG_FALLING, res1);

	SERIAL
	{
		BOOST_VCOMP_HCLAMP->SetTestResult(SITE, 0, res1[SITE]);
		
	}
		//add highest version?

	Enter_M_TM(0x0004, 0x0280, 0x0000);
	delay_ms(1);
	B2_PREBOOT_VBOOST.Set(FV, 4.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON, 0.5);
	awg.rampv(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "BOOST_LCLAMP", 4.5, 6.0, 0.005, 50, 2.0, TRIG_FALLING, res1);

	SERIAL
	{
		BOOST_VCOMP_LCLAMP->SetTestResult(SITE, 0, res1[SITE]);
	}

	//Vboost UV
	Enter_M_TM(0x0004, 0x02C0, 0x0000);
	delay_ms(1);
	B2_PREBOOT_VBOOST.Set(FV, 3.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON, 0.5);
	awg.rampv2(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "BOOST_UV", 3.0, 4.0,4.0,3.0, 0.005, 50, 2.0, TRIG_RISING, TRIG_FALLING, res1,res2);

	SERIAL
	{

		VBOOST_UV_ABS_R->SetTestResult(SITE, 0, res1[SITE]);//3.5
		VBOOST_UV_ABS_F->SetTestResult(SITE, 0, res2[SITE]);
		VBOOST_UV_ABS_HYS->SetTestResult(SITE, 0, res1[SITE]- res2[SITE]);
	}
	SPIWrite(0x07, 0x0040);
	B2_PREBOOT_VBOOST.Set(FV, 3.85, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON, 0.5);
	awg.rampv2(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "BOOST_UV1", 3.85, 4.85, 4.85, 3.85, 0.005, 50, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);

	SERIAL
	{

		VBOOST_UV_REL_R->SetTestResult(SITE, 0, res1[SITE] / 5.0 * 100.0);//87%
		VBOOST_UV_REL_F->SetTestResult(SITE, 0, res2[SITE] / 5.0 * 100.0);
		VBOOST_UV_REL_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]) / 5.0 * 100.0);
	}
	SPIWrite(0x07, data0);

	//Vboost OV
	Enter_M_TM(0x0004, 0x0300, 0x0000);
	delay_ms(1);
	B2_PREBOOT_VBOOST.Set(FV, 6.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON, 0.5);
	awg.rampv2(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "BOOST_OV", 6.3, 7.3, 7.3, 6.3, 0.005, 50, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{
		VBOOST_OV_ABS_R->SetTestResult(SITE, 0, res1[SITE]);//
		VBOOST_OV_ABS_F->SetTestResult(SITE, 0, res2[SITE]);
		VBOOST_OV_ABS_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]));
	}

	SPIWrite(0x07, 0x0040);
	B2_PREBOOT_VBOOST.Set(FV, 6.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON, 0.5);
	awg.rampv2(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "BOOST_OV1", 5.15, 6.25, 6.25, 5.15, 0.005, 50, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{
		VBOOST_OV_REL_R->SetTestResult(SITE, 0, res1[SITE]/5.0*100.0);//
		VBOOST_OV_REL_F->SetTestResult(SITE, 0, res2[SITE] / 5.0 * 100.0);
		VBOOST_OV_REL_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE] )/ 5.0 * 100.0);
	}
	SPIWrite(0x07, data0);
	B2_PREBOOT_VBOOST.Set(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON, 0.5);

	//BOOST LS OVP
	Enter_M_TM(0x0004, 0x0400, 0x0000);
	BUCK3SW_BOOSTLS_7.Set(FV, 7.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON,0.5);
	awg.rampv2(BUCK3SW_BOOSTLS_7, A3_INTB, ACM200_10V, ACM200_100MA, "BOOST_LS_OVP", 7.0, 8.0, 8.0, 7.0, 0.004, 500, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{
		BOOST_LS_OV_R->SetTestResult(SITE, 0, res1[SITE] );//7.66
		BOOST_LS_OV_F->SetTestResult(SITE, 0, res2[SITE] );
		BOOST_LS_OV_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]));
	}

	//BOOST LS CLAMP
	Enter_M_TM(0x0004, 0x0580, 0x0000);
	BUCK3SW_BOOSTLS_7.Set(FV, 5.0, ACM200_40V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(2);
	BUCK3SW_BOOSTLS_7.MeasureVI(30, 10);
	SERIAL
	{
		res3[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		IBOOST_CLAMP_PRE->SetTestResult(SITE, 0, res3[SITE]*1e6);//7.66
	

	}
	BUCK3SW_BOOSTLS_7.Set(FV, 7.3, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.SetClamp(30, 30);
	BUCK3SW_BOOSTLS_7.Set(FV, 13, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	awg.rampv(BUCK3SW_BOOSTLS_7, A3_INTB, ACM200_40V, ACM200_100MA, "BOOST_CLAMP", 13, 19, 0.02, 50, 2.0, TRIG_FALLING, res1);
	//should be current clamped when set a high voltage
	BUCK3SW_BOOSTLS_7.Set(FV, 30, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	delay_ms(1);//short time for avoid heat up
	BUCK3SW_BOOSTLS_7.MeasureVI(30, 10);
	SERIAL
	{
		BOOST_CLAMP_ZENER_OV->SetTestResult(SITE, 0, res1[SITE]);//7.66
		res2[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MVRET);
		BOOST_CLAMP_VOLT->SetTestResult(SITE, 0, res2[SITE]);
	
	}
	BUCK3SW_BOOSTLS_7.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	BUCK3SW_BOOSTLS_7.SetClamp(100, 100);
	BUCK3SW_BOOSTLS_7.Set(FV, 5.0, ACM200_40V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(2);
	BUCK3SW_BOOSTLS_7.MeasureVI(30, 10);
	SERIAL
	{
		res4[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		IBOOST_CLAMP_POST->SetTestResult(SITE, 0, res4[SITE] * 1e6);//7.66
		IBOOST_CLAMP_Delta->SetTestResult(SITE, 0, (res4[SITE]-res3[SITE]) * 1e6);//7.66

	}
	BUCK3SW_BOOSTLS_7.Set(FV, 0, ACM200_40V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);

	//VBOOST TSD
	Enter_M_TM(0x0004, 0x0380, 0x0000);
	delay_ms(1);
	if (DO_CHAR || (test_stage==1 ))
	{
		A0_FIN_DBG_ERR_FCCU1.Set(FI, 10e-6, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		awg.rampi2(A0_FIN_DBG_ERR_FCCU1, A3_INTB, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, "BOOST_TSD", 10e-6, -20.0e-6, -20.0e-6, 10e-6, 0.05e-6, 200, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	}
	else
	{
		A0_FIN_DBG_ERR_FCCU1.Set(FI, -3.0e-6, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		awg.rampi2(A0_FIN_DBG_ERR_FCCU1, A3_INTB, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, "BOOST_TSD", -3.0e-6, -11.0e-6, -11.0e-6, -3.0e-6, 0.05e-6, 200, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	}
	//will check if need to change 25C to other temperature for high/low temperature test
	SERIAL
	{
		TSD_R->SetTestResult(SITE, 0, g_temp[SITE] -res1[SITE]/1.0e-6*21);//
		TSD_F->SetTestResult(SITE, 0, g_temp[SITE] - res2[SITE] / 1.0e-6*21);
		TSD_HYS->SetTestResult(SITE, 0, -(res1[SITE] - res2[SITE])/1.0e-6*21);
	}
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);


	if (1)
	{ 
		//VBOOST FREQ
		//will check SLT test, if slt test not ok, will chage L5 to a resistor for this function test
		cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, K56_INTB_PU,
			K50_VBOOST_FXVIB, K109_FXVI2_8_B, K80_PRECSP_PREFB_SHRT, K45_PREFB_FXVIA, K112_FXVI4_10_A, /*K31_INTB_DCM,*/ K84_PRECOMP_CAP, 
			K21_PADF_AGNDF, /*K110_FXVI3_9_A,*/ K73_PRESW_BOOSTLS_TMU, K34_BOOST_SLT, K81_LDO_CAPS, K85_BUCKSW_PD, -1);

	
		delay_ms(1);
		B2_PREBOOT_VBOOST.Set(FV, 2.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
		//B2_PREBOOT_VBOOST.SetClamp(30,30);
		A4_PSYNC_PREFB.Set(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);

		delay_ms(2);

		Enter_M_TM(0x0004, 0x03C0, 0x0000);
		SPIWrite(0x3F, 0x7481);
		//SPIWrite(0x00, 0x0300);

		SPIRead(0x01, rdata);
		SPIWrite(0x3F, 0x7401);
		SPIWrite(0x03, 0xC000);
		SPIWrite(0x3F, 0x7481);
		delay_ms(12);
	
		ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_B);
	/*	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 1.5, QTMUe_FILTER_PASS, 5);
		ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 1.5, QTMUe_FILTER_PASS, 5);*/
		ALL_QTMU.Connect(QTMUe_RELAY_CHB);
	


		measure_ON_OFF_QTMU(res3, res1,QTMUe_NEG,QTMUe_POS,1.0,1.5);


		SERIAL
		{
			BOOST_FSW_DCM->SetTestResult(SITE, 0, res1[SITE]);//khz 
		
			BOOST_MAXTON_DCM->SetTestResult(SITE, 0, res3[SITE]*1e3);//ns
	
		}
			
		B2_PREBOOT_VBOOST.Set(FV, 5.8, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON, 0.5);
		delay_ms(8);
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_B);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHB);

		measure_ON_OFF_QTMU(res3, res1,QTMUe_NEG,QTMUe_POS,2.0,2.0);
		SERIAL
		{
			BOOST_FSW_DCM1->SetTestResult(SITE, 0, res1[SITE]);//khz 2.2Mhz
	
			BOOST_MINTON_DCM->SetTestResult(SITE, 0, res3[SITE] * 1e3);//350ns

		}
		SPIWrite(0x03, 0x0200);
				
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_B);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHB);

		measure_ON_OFF_QTMU(res3, res1,QTMUe_NEG,QTMUe_POS,2.5,2.5);
		SERIAL
		{
			BOOST_FSW_DCM1_0x01->SetTestResult(SITE, 0, res1[SITE]);//khz 2.2Mhz
	
			BOOST_MINTON_DCM_0x01->SetTestResult(SITE, 0, res3[SITE] * 1e3);//350ns

		}
	}
	Enter_M_TM(0x0000, 0x0000, 0x0000);
	delay_ms(1);
	//dcm.Disconnect("FOUT_INTB");
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A4_PSYNC_PREFB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	
	delay_ms(5);//for cap discharge

	A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	A3_INTB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	A4_PSYNC_PREFB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T41_VBOS_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam* VBOS_POR_R = StsGetParam(funcindex, "VBOS_POR_R");
	CParam* VBOS_POR_F = StsGetParam(funcindex, "VBOS_POR_F");
	CParam* VBOS_POR_HYS = StsGetParam(funcindex, "VBOS_POR_HYS");
	CParam* VBOS_UVL_R = StsGetParam(funcindex, "VBOS_UVL_R");
	CParam* VBOS_UVL_F = StsGetParam(funcindex, "VBOS_UVL_F");
	CParam* VBOS_UVL_HYS = StsGetParam(funcindex, "VBOS_UVL_HYS");
	CParam* VBOS_UVH_R = StsGetParam(funcindex, "VBOS_UVH_R");
	CParam* VBOS_UVH_F = StsGetParam(funcindex, "VBOS_UVH_F");
	CParam* VBOS_UVH_HYS = StsGetParam(funcindex, "VBOS_UVH_HYS");
	CParam* VSUP_H_R = StsGetParam(funcindex, "VSUP_H_R");
	CParam* VSUP_H_F = StsGetParam(funcindex, "VSUP_H_F");
	CParam* VSUP_H_HYS = StsGetParam(funcindex, "VSUP_H_HYS");

	CParam* VBOOST_UV4_R = StsGetParam(funcindex, "VBOOST_UV4_R");
	CParam* VBOOST_UV4_F = StsGetParam(funcindex, "VBOOST_UV4_F");
	CParam* VBOOST_UV4_HYS = StsGetParam(funcindex, "VBOOST_UV4_HYS");
	CParam* VBOS_FB = StsGetParam(funcindex, "VBOS_FB");
	CParam* VBOS_FB_RATIO = StsGetParam(funcindex, "VBOS_FB_RATIO");
	CParam* VPRE_UV4_R = StsGetParam(funcindex, "VPRE_UV4_R");
	CParam* VPRE_UV4_F = StsGetParam(funcindex, "VPRE_UV4_F");
	CParam* VPRE_UV4_HYS = StsGetParam(funcindex, "VPRE_UV4_HYS");
	CParam* VBOS_VBG_1p0 = StsGetParam(funcindex, "VBOS_VBG_1p0");

	CParam* VBOOST_H1_R = StsGetParam(funcindex, "VBOOST_H1_R");
	CParam* VBOOST_H1_F = StsGetParam(funcindex, "VBOOST_H1_F");
	CParam* VBOOST_H1_HYS = StsGetParam(funcindex, "VBOOST_H1_HYS");

	CParam* VBOOST_H2_R = StsGetParam(funcindex, "VBOOST_H2_R");
	CParam* VBOOST_H2_F = StsGetParam(funcindex, "VBOOST_H2_F");
	CParam* VBOOST_H2_HYS = StsGetParam(funcindex, "VBOOST_H2_HYS");

	CParam* VBOOST_H3_R = StsGetParam(funcindex, "VBOOST_H3_R");
	CParam* VBOOST_H3_F = StsGetParam(funcindex, "VBOOST_H3_F");
	CParam* VBOOST_H3_HYS = StsGetParam(funcindex, "VBOOST_H3_HYS");


	CParam* EN_VSUP_LDO_R = StsGetParam(funcindex, "EN_VSUP_LDO_R");
	CParam* EN_VSUP_LDO_F = StsGetParam(funcindex, "EN_VSUP_LDO_F");
	CParam* EN_VSUP_LDO_HYS = StsGetParam(funcindex, "EN_VSUP_LDO_HYS");

	CParam* EN_VBOOST_LDO1_R = StsGetParam(funcindex, "EN_VBOOST_LDO1_R");
	CParam* EN_VBOOST_LDO1_F = StsGetParam(funcindex, "EN_VBOOST_LDO1_F");
	CParam* EN_VBOOST_LDO1_HYS = StsGetParam(funcindex, "EN_VBOOST_LDO1_HYS");

	CParam* EN_VBOOST_LDO2_R = StsGetParam(funcindex, "EN_VBOOST_LDO2_R");
	CParam* EN_VBOOST_LDO2_F = StsGetParam(funcindex, "EN_VBOOST_LDO2_F");
	CParam* EN_VBOOST_LDO2_HYS = StsGetParam(funcindex, "EN_VBOOST_LDO2_HYS");

	CParam* EN_VPRE_LDO_R = StsGetParam(funcindex, "EN_VPRE_LDO_R");
	CParam* EN_VPRE_LDO_F = StsGetParam(funcindex, "EN_VPRE_LDO_F");
	CParam* EN_VPRE_LDO_HYS = StsGetParam(funcindex, "EN_VPRE_LDO_HYS");

	CParam* ILMT_IVBOS_VSUP = StsGetParam(funcindex, "ILMT_IVBOS_VSUP");
	CParam* ILMT_VBOS_IVSUP = StsGetParam(funcindex, "ILMT_VBOS_IVSUP");
	CParam* VBOS_VSUP_I0 = StsGetParam(funcindex, "VBOS_VSUP_I0");
	CParam* VBOS_VSUP_I40MA = StsGetParam(funcindex, "VBOS_VSUP_I40MA");
	CParam* ILMT_IVBOS_VBOOST = StsGetParam(funcindex, "ILMT_IVBOS_VBOOST");
	CParam* ILMT_VBOS_IBOOST = StsGetParam(funcindex, "ILMT_VBOS_IBOOST");
	CParam* VBOS_VBOOST_I0 = StsGetParam(funcindex, "VBOS_VBOOST_I0");
	CParam* VBOS_VBOOST_I40MA = StsGetParam(funcindex, "VBOS_VBOOST_I40MA");
	CParam* ILMT_IVBOS_VPRE = StsGetParam(funcindex, "ILMT_IVBOS_VPRE");
	CParam* ILMT_VBOS_IVPRE = StsGetParam(funcindex, "ILMT_VBOS_IVPRE");
	CParam* VBOS_VPRE_I0 = StsGetParam(funcindex, "VBOS_VPRE_I0");
	CParam* VBOS_VPRE_I40MA = StsGetParam(funcindex, "VBOS_VPRE_I40MA");
	CParam* VBOS_OVP_R = StsGetParam(funcindex, "VBOS_OVP_R");
	CParam* VBOS_OVP_F = StsGetParam(funcindex, "VBOS_OVP_F");
	CParam* VBOS_OVP_HYS = StsGetParam(funcindex, "VBOS_OVP_HYS");
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double res3[SITE_NUM];
	double res4[SITE_NUM];
	double cap[SITE_NUM][1000];
	ULONG data0 = 0x0000;
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS,K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, K56_INTB_PU,
	K32_INTB_FXVIA, K110_FXVI3_9_A, K50_VBOOST_FXVIB, K109_FXVI2_8_B, K46_PREFB_ACM ,-1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	delay_ms(1);
	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_200MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(4);
	double trigvalue;
	//------------VBOS POR---------------
	VBOS_1.Set(FV, 2.0, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON,0.5);

	delay_ms(2);
	VSUP_11.MeasureVI(30, 10);
	SERIAL trigvalue= VSUP_11.GetMeasResult(SITE, MIRET);
	
	if (DO_CHAR || (test_stage==1 ))
		awg.rampmi2(VBOS_1, VSUP_11, ACM200_10V, ACM200_200MA, "VBOS_POR", 2.0, 2.7, 2.6, 2.0, 0.003, 20, trigvalue+15e-3, TRIG_RISING, TRIG_FALLING, res1, res2);
	else
		awg.rampmi2(VBOS_1, VSUP_11, ACM200_10V, ACM200_200MA, "VBOS_POR", 2.0, 2.7, 2.6, 2.0, 0.003, 20, 35e-3, TRIG_RISING, TRIG_FALLING, res1, res2);

	SERIAL
	{
		VBOS_POR_R->SetTestResult(SITE, 0, res1[SITE]);//3.5
		VBOS_POR_F->SetTestResult(SITE, 0, res2[SITE]);
		VBOS_POR_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);
	}

		//--------------------VBOS UVL--------------
	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();

	//bit17-14
	//xx00 0000 0000 0000=>0x30
	//0000 0000 0000 00xx=>0x31
	Enter_M_TM(0x8002, 0x0000, 0x0000);

	VBOS_1.Set(FV, 3.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	awg.rampv2(VBOS_1, A3_INTB, ACM200_10V, ACM200_100MA, "VBOS_UVL", 3.0, 3.8, 3.8, 3.0, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);

	SERIAL
	{

		VBOS_UVL_R->SetTestResult(SITE, 0, res1[SITE] );
		VBOS_UVL_F->SetTestResult(SITE, 0, res2[SITE] );
		VBOS_UVL_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]));
	}
		//VBOS UVH
	Enter_M_TM(0xC002, 0x0000, 0x0000);

	VBOS_1.Set(FV, 4.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	awg.rampv2(VBOS_1, A3_INTB, ACM200_10V, ACM200_100MA, "VBOS_UVH", 4.0, 4.8, 4.8, 4.0, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);

	SERIAL
	{

		VBOS_UVH_R->SetTestResult(SITE, 0, res1[SITE]);
		VBOS_UVH_F->SetTestResult(SITE, 0, res2[SITE]);
		VBOS_UVH_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]));
	}


	//VSUP VS VBOOST
	Enter_M_TM(0x0002, 0x0001, 0x0000);
	B2_PREBOOT_VBOOST.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	VBOS_1.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	VSUP_11.Set(FV, 4.5, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	awg.rampv2(VSUP_11, A3_INTB, ACM200_10V, ACM200_100MA, "VSUP_VBOOST", 4.5, 6.5, 6.5, 4.5, 0.01, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{

		VSUP_H_R->SetTestResult(SITE, 0, res1[SITE]);
		VSUP_H_F->SetTestResult(SITE, 0, res2[SITE]);
		VSUP_H_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]));
	}

	//VBOOST UV4
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	Enter_M_TM(0x4002, 0x0001, 0x0000);
	VBOS_1.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	B2_PREBOOT_VBOOST.Set(FV, 3.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	awg.rampv2(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "VBOOST_UV4", 3.5, 4.5, 4.5, 3.5, 0.005, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{

		VBOOST_UV4_R->SetTestResult(SITE, 0, res1[SITE]);
		VBOOST_UV4_F->SetTestResult(SITE, 0, res2[SITE]);
		VBOOST_UV4_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]));
	}
	B2_PREBOOT_VBOOST.Set(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	//VPRE UV4
	
	Enter_M_TM(0x8002, 0x0001, 0x0000);
	PREFB_BUCK1FB_8.Set(FV, 3.5, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	SPIWrite(0x04, 0x0013);//switch bg to AMUX
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE,MVRET);
		VBOS_FB->SetTestResult(SITE, 0, res1[SITE]);
		VBOS_FB_RATIO->SetTestResult(SITE, 0, res1[SITE]/5.0);
	
	}
	awg.rampv2(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "VPRE_UV4", 3.5, 4.5, 4.5, 3.5, 0.005, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{

		VPRE_UV4_R->SetTestResult(SITE, 0, res1[SITE]);
		VPRE_UV4_F->SetTestResult(SITE, 0, res2[SITE]);
		VPRE_UV4_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]));
	}
	//VBOOST H
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);

	Enter_M_TM(0xC002, 0x0001, 0x0000);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE,MVRET);
		VBOS_VBG_1p0->SetTestResult(SITE, 0, res1[SITE]+g_amux_vos[SITE]);
		

	}
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	B2_PREBOOT_VBOOST.Set(FV, 3.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	awg.rampv2(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "VBOOST_H1", 3.0, 3.5, 3.5, 3.0, 0.003, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{

		VBOOST_H1_R->SetTestResult(SITE, 0, res1[SITE]);
		VBOOST_H1_F->SetTestResult(SITE, 0, res2[SITE]);
		VBOOST_H1_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]));
	}
	PREFB_BUCK1FB_8.Set(FV, 4.1, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);

	B2_PREBOOT_VBOOST.Set(FV, 3.8, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	awg.rampv2(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "VBOOST_H2", 3.8, 4.4, 4.4, 3.8, 0.003, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{

		VBOOST_H2_R->SetTestResult(SITE, 0, res1[SITE]);
		VBOOST_H2_F->SetTestResult(SITE, 0, res2[SITE]);
		VBOOST_H2_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]));
	}

	PREFB_BUCK1FB_8.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);

	B2_PREBOOT_VBOOST.Set(FV, 4.7, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	awg.rampv2(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "VBOOST_H3", 4.7, 5.3, 5.3, 4.7, 0.003, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);

	SERIAL
	{

		VBOOST_H3_R->SetTestResult(SITE, 0, res1[SITE]);
		VBOOST_H3_F->SetTestResult(SITE, 0, res2[SITE]);
		VBOOST_H3_HYS->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]));
	}
	//----------EN VSUP LDO---------
	//vsup>7v����vpre��vboost��ѡ�ߵģ�ǰ��������������4v�������������4v��ѡvsup��
	//vsup < 7v����vsup vboost vpre��ѡ��ߵġ���ʵ�ʾ��Ǵ�vsup��vboost��ѡһ����Ϊvsup��Ȼ����vpre

	Enter_M_TM(0x0002, 0x0002, 0x0000);
	PREFB_BUCK1FB_8.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	B2_PREBOOT_VBOOST.Set(FV, 6.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	VSUP_11.Set(FV, 7.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 7.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	awg.rampv2(VSUP_11, A3_INTB, ACM200_10V, ACM200_100MA, "EN_VSUP_LDO", 7.0, 5.5, 5.5, 7.0, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{

		EN_VSUP_LDO_R->SetTestResult(SITE, 0, res1[SITE]);
		EN_VSUP_LDO_F->SetTestResult(SITE, 0, res2[SITE]);
		EN_VSUP_LDO_HYS->SetTestResult(SITE, 0, (res2[SITE] - res1[SITE]));
	}
		//----------EN VBOOST LDO---------
	VSUP_11.Set(FV, 7.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);

	Enter_M_TM(0x4002, 0x0002, 0x0000);
	PREFB_BUCK1FB_8.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	B2_PREBOOT_VBOOST.Set(FV, 6.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	awg.rampv2(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "EN_VBOOST_LDO", 5.5, 4.5, 4.5, 5.5, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{

		EN_VBOOST_LDO1_R->SetTestResult(SITE, 0, res1[SITE]);
		EN_VBOOST_LDO1_F->SetTestResult(SITE, 0, res2[SITE]);
		EN_VBOOST_LDO1_HYS->SetTestResult(SITE, 0, (res2[SITE] - res1[SITE]));
	}				 
	VSUP_11.Set(FV, 5.5, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	awg.rampv2(B2_PREBOOT_VBOOST, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "EN_VBOOST_LDO2", 6.0, 5.0, 5.0, 6.0, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{

		EN_VBOOST_LDO2_R->SetTestResult(SITE, 0, res1[SITE]);
		EN_VBOOST_LDO2_F->SetTestResult(SITE, 0, res2[SITE]);
		EN_VBOOST_LDO2_HYS->SetTestResult(SITE, 0, (res2[SITE] - res1[SITE]));
	}
		//----------EN VPRE LDO---------
	
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);

	Enter_M_TM(0x8002, 0x0002, 0x0000);
	PREFB_BUCK1FB_8.Set(FV, 5.5, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	B2_PREBOOT_VBOOST.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	awg.rampv2(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "EN_VPRE_LDO", 5.5, 4.5, 4.5, 5.5, 0.005, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL
	{

		EN_VPRE_LDO_R->SetTestResult(SITE, 0, res1[SITE]);
		EN_VPRE_LDO_F->SetTestResult(SITE, 0, res2[SITE]);
		EN_VPRE_LDO_HYS->SetTestResult(SITE, 0, (res2[SITE] - res1[SITE]));
	}
	Enter_M_TM(0x0002, 0x0002, 0x0000);
	//----------VBOS TEST  VSUP---------
	PREFB_BUCK1FB_8.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	B2_PREBOOT_VBOOST.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	VSUP_11.Set(FV, 6.6, ACM200_20V, ACM200_200MA, ACM200_RELAY_ON);//<7V
	//Enter_M_TM(0xC002, 0x0002, 0x0000);
	VBOS_1.Set(FV, 4.6, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON, 0.5);
	delay_ms(2);
	VBOS_1.MeasureVI(30, 10);
	VSUP_11.MeasureVI(30, 10);
	SERIAL
	{

		res1[SITE] = VBOS_1.GetMeasResult(SITE,MIRET);
		ILMT_IVBOS_VSUP->SetTestResult(SITE, 0, -res1[SITE]*1e3);//mA 80
		res1[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		ILMT_VBOS_IVSUP->SetTestResult(SITE, 0, res1[SITE] * 1e3);
	}

	VBOS_1.SetClamp(20, 20);
	delay_ms(3);
	VBOS_1.MeasureVI(30, 10);
	SERIAL
	{

		res1[SITE] = VBOS_1.GetMeasResult(SITE, MVRET);
		VBOS_VSUP_I40MA->SetTestResult(SITE, 0, res1[SITE]);

	}

	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON, 0.5);
	VBOS_1.SetClamp(100,100);
	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	VBOS_1.Set(FV, 4.8, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	//VBOS_1.Set(FI, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	delay_ms(4);
	VBOS_1.MeasureVI(30, 10);
	SERIAL
	{

		res1[SITE] = VBOS_1.GetMeasResult(SITE,MVRET);
		VBOS_VSUP_I0->SetTestResult(SITE, 0, res1[SITE]);

	}
	//VBOS_1.Set(FV, 4.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	//VBOS_1.Set(FI, -40e-3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);

	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON, 0.5);
	//VBOS_1.SetClamp(100, 100);
	//VBOS_1.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	//Enter_M_TM(0x0000, 0x0000, 0x0000);
	//----------VBOS TEST  VBOOST---------
	PREFB_BUCK1FB_8.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	B2_PREBOOT_VBOOST.Set(FV, 6.5, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	VSUP_11.Set(FV, 8.0, ACM200_20V, ACM200_200MA, ACM200_RELAY_ON);
	delay_ms(2);
	//Enter_M_TM(0x0002, 0x0003, 0x0000);
	VBOS_1.Set(FV, 4.6, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON, 0.5);
	delay_ms(2);
	VBOS_1.MeasureVI(30, 10);
	B2_PREBOOT_VBOOST.MeasureVI(30, 10);
	SERIAL
	{

		res1[SITE] = VBOS_1.GetMeasResult(SITE,MIRET);
		ILMT_IVBOS_VBOOST->SetTestResult(SITE, 0, -res1[SITE] * 1e3);
		res1[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);
		ILMT_VBOS_IBOOST->SetTestResult(SITE, 0, res1[SITE] * 1e3);
	}
	VBOS_1.SetClamp(20, 20);
	delay_ms(3);
	VBOS_1.MeasureVI(30, 10);
	SERIAL
	{

		res1[SITE] = VBOS_1.GetMeasResult(SITE, MVRET);
		VBOS_VBOOST_I40MA->SetTestResult(SITE, 0, res1[SITE]);

	}
	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON, 0.5);

	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	//VBOS_1.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON, 0.5);
	delay_ms(2);
	VBOS_1.MeasureVI(30, 10);
	SERIAL
	{

		res1[SITE] = VBOS_1.GetMeasResult(SITE,MVRET);
		VBOS_VBOOST_I0->SetTestResult(SITE, 0, res1[SITE]);

	}
	VBOS_1.SetClamp(100, 100);
	//VBOS_1.Set(FI, -40e-3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);

	//VBOS_1.Set(FI, -0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON, 0.5);


	//----------VBOS TEST  VPRE---------
	PREFB_BUCK1FB_8.Set(FV, 6.0, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON, 0.5);
	B2_PREBOOT_VBOOST.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	VSUP_11.Set(FV, 8.0, ACM200_20V, ACM200_200MA, ACM200_RELAY_ON);
	delay_ms(2);
	//Enter_M_TM(0x4002, 0x0003, 0x0000);
	VBOS_1.Set(FV, 4.6, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON, 0.5);
	delay_ms(2);
	VBOS_1.MeasureVI(30, 10);
	PREFB_BUCK1FB_8.MeasureVI(30, 10);
	SERIAL
	{

		res1[SITE] = VBOS_1.GetMeasResult(SITE,MIRET);
		ILMT_IVBOS_VPRE->SetTestResult(SITE, 0, -res1[SITE] * 1e3);
		res1[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		ILMT_VBOS_IVPRE->SetTestResult(SITE, 0, res1[SITE] * 1e3);
	}

	VBOS_1.SetClamp(20, 20);
	delay_ms(3);
	VBOS_1.MeasureVI(30, 10);
	SERIAL
	{

		res1[SITE] = VBOS_1.GetMeasResult(SITE, MVRET);
		VBOS_VPRE_I40MA->SetTestResult(SITE, 0, res1[SITE]);

	}

	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON, 0.5);

	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	delay_ms(2);
	VBOS_1.MeasureVI(30, 10);
	SERIAL
	{

		res1[SITE] = VBOS_1.GetMeasResult(SITE,MVRET);
		VBOS_VPRE_I0->SetTestResult(SITE, 0, res1[SITE]);


	}
	VBOS_1.SetClamp(100, 100);
	//VBOS_1.Set(FI, -40e-3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	//delay_ms(2);
	//VBOS_1.MeasureVI(30, 10);

	//VBOS_1.Set(FI, -0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	//VBOS OVST
	Enter_M_TM(0x0000, 0x0000, 0x0000);
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON, 0.5);
	B2_PREBOOT_VBOOST.Set(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	VSUP_11.Set(FV, 8.0, ACM200_20V, ACM200_200MA, ACM200_RELAY_ON);
	VBOS_1.Set(FV, 5.5, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	Enter_M_TM(0x01A1, 0x0000, 0x0000);
	delay_ms(1);
	awg.rampv2(VBOS_1, A3_INTB, ACM200_10V, ACM200_100MA, "VBOS_OVP", 5.7, 7.3, 7.3,5.5, 0.005, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{

		VBOS_OVP_R->SetTestResult(SITE, 0, res1[SITE]);
		VBOS_OVP_F->SetTestResult(SITE, 0, res2[SITE]);
		VBOS_OVP_HYS->SetTestResult(SITE, 0, res1[SITE]- res2[SITE]);

	}

	A4_PSYNC_PREFB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	VBOS_1.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(5);//for cap discharge

	A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	A3_INTB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	A4_PSYNC_PREFB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	VBOS_1.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_OFF);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T43_VPRE_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam* VPRE_OVP_ABS_R = StsGetParam(funcindex, "VPRE_OVP_ABS_R");
	CParam* VPRE_OVP_ABS_F = StsGetParam(funcindex, "VPRE_OVP_ABS_F");
	CParam* VPRE_OVP_ABS_HYS = StsGetParam(funcindex, "VPRE_OVP_ABS_HYS");

	CParam* VPRE_OVP_REL_R = StsGetParam(funcindex, "VPRE_OVP_REL_R");
	CParam* VPRE_OVP_REL_F = StsGetParam(funcindex, "VPRE_OVP_REL_F");
	CParam* VPRE_OVP_REL_HYS = StsGetParam(funcindex, "VPRE_OVP_REL_HYS");
	CParam* VPRE_VREF0p8 = StsGetParam(funcindex, "VPRE_VREF0p8");

	CParam* VPRE_UVH_ABS_R = StsGetParam(funcindex, "VPRE_UVH_ABS_R");
	CParam* VPRE_UVH_ABS_F = StsGetParam(funcindex, "VPRE_UVH_ABS_F");
	CParam* VPRE_UVH_ABS_HYS = StsGetParam(funcindex, "VPRE_UVH_ABS_HYS");

	CParam* VPRE_UVH_REL_R = StsGetParam(funcindex, "VPRE_UVH_REL_R");
	CParam* VPRE_UVH_REL_F = StsGetParam(funcindex, "VPRE_UVH_REL_F");
	CParam* VPRE_UVH_REL_HYS = StsGetParam(funcindex, "VPRE_UVH_REL_HYS");

	CParam* VPRE_DIV6 = StsGetParam(funcindex, "VPRE_DIV6");
	CParam* VPRE_UVL_ABS_R = StsGetParam(funcindex, "VPRE_UVL_ABS_R");
	CParam* VPRE_UVL_ABS_F = StsGetParam(funcindex, "VPRE_UVL_ABS_F");
	CParam* VPRE_UVL_ABS_HYS = StsGetParam(funcindex, "VPRE_UVL_ABS_HYS");

	CParam* VPRE_GAIN_VCOMP1 = StsGetParam(funcindex, "VPRE_GAIN_VCOMP1");
	CParam* VPRE_GAIN_VCOMP2 = StsGetParam(funcindex, "VPRE_GAIN_VCOMP2");
	CParam* VPRE_GAIN = StsGetParam(funcindex, "VPRE_GAIN");

	CParam* VPRE_IGM = StsGetParam(funcindex, "VPRE_IGM");
	CParam* VPRE_EA_IOUT_MAX = StsGetParam(funcindex, "VPRE_EA_IOUT_MAX");
	CParam* VPRE_COMPH_0x00 = StsGetParam(funcindex, "VPRE_COMPH_0x00");
	CParam* VPRE_COMPL_0x00 = StsGetParam(funcindex, "VPRE_COMPL_0x00");
	CParam* VPRE_COMPH_0x01 = StsGetParam(funcindex, "VPRE_COMPH_0x01");
	CParam* VPRE_COMPH_0x10 = StsGetParam(funcindex, "VPRE_COMPH_0x10");
	CParam* VPRE_COMPH_0x11 = StsGetParam(funcindex, "VPRE_COMPH_0x11");
	CParam* VPRE_SSDONE = StsGetParam(funcindex, "VPRE_SSDONE");
	CParam* VPRE_SS = StsGetParam(funcindex, "VPRE_SS");
	CParam* VPRE_GHS_IPU_0x00 = StsGetParam(funcindex, "VPRE_GHS_IPU_0x00");
	CParam* VPRE_GHS_RPU_0x00 = StsGetParam(funcindex, "VPRE_GHS_RPU_0x00");
	CParam* VPRE_GHS_IPU_0x01 = StsGetParam(funcindex, "VPRE_GHS_IPU_0x01");
	CParam* VPRE_GHS_RPU_0x01 = StsGetParam(funcindex, "VPRE_GHS_RPU_0x01");
	CParam* VPRE_GHS_IPU_0x10 = StsGetParam(funcindex, "VPRE_GHS_IPU_0x10");
	CParam* VPRE_GHS_RPU_0x10 = StsGetParam(funcindex, "VPRE_GHS_RPU_0x10");
	CParam* VPRE_GHS_RPU_0x11 = StsGetParam(funcindex, "VPRE_GHS_RPU_0x11");
	CParam* VPRE_GHS_IPD_0x00 = StsGetParam(funcindex, "VPRE_GHS_IPD_0x00");
	CParam* VPRE_GHS_RPD_0x00 = StsGetParam(funcindex, "VPRE_GHS_RPD_0x00");
	CParam* VPRE_GHS_IPD_0x01 = StsGetParam(funcindex, "VPRE_GHS_IPD_0x01");
	CParam* VPRE_GHS_RPD_0x01 = StsGetParam(funcindex, "VPRE_GHS_RPD_0x01");
	CParam* VPRE_GHS_IPD_0x10 = StsGetParam(funcindex, "VPRE_GHS_IPD_0x10");
	CParam* VPRE_GHS_RPD_0x10 = StsGetParam(funcindex, "VPRE_GHS_RPD_0x10");
	CParam* VPRE_GHS_RPD_0x11 = StsGetParam(funcindex, "VPRE_GHS_RPD_0x11");
	CParam* SW_SHORT2H = StsGetParam(funcindex, "SW_SHORT2H");
	CParam* VPRE_GLS_IPU_0x00 = StsGetParam(funcindex, "VPRE_GLS_IPU_0x00");
	CParam* VPRE_GLS_RPU_0x00 = StsGetParam(funcindex, "VPRE_GLS_RPU_0x00");
	CParam* VPRE_GLS_RPU_0x01 = StsGetParam(funcindex, "VPRE_GLS_RPU_0x01");
	CParam* VPRE_GLS_RPU_0x10 = StsGetParam(funcindex, "VPRE_GLS_RPU_0x10");
	CParam* VPRE_GLS_RPU_0x11 = StsGetParam(funcindex, "VPRE_GLS_RPU_0x11");
	CParam* VPRE_GLS_IPD_0x00 = StsGetParam(funcindex, "VPRE_GLS_IPD_0x00");
	CParam* VPRE_GLS_RPD_0x00 = StsGetParam(funcindex, "VPRE_GLS_RPD_0x00");
	CParam* VPRE_GLS_IPD_0x01 = StsGetParam(funcindex, "VPRE_GLS_IPD_0x01");
	CParam* VPRE_GLS_RPD_0x01 = StsGetParam(funcindex, "VPRE_GLS_RPD_0x01");
	CParam* VPRE_GLS_IPD_0x10 = StsGetParam(funcindex, "VPRE_GLS_IPD_0x10");
	CParam* VPRE_GLS_RPD_0x10 = StsGetParam(funcindex, "VPRE_GLS_RPD_0x10");
	CParam* VPRE_GLS_RPD_0x11 = StsGetParam(funcindex, "VPRE_GLS_RPD_0x11");
	CParam* VPRE_PREFB_DIS_R = StsGetParam(funcindex, "VPRE_PREFB_DIS_R");
	CParam* VPRE_PREBOOT_DIS_R = StsGetParam(funcindex, "VPRE_PREBOOT_DIS_R");
	CParam* VPRE_PREGLS_DIS_R = StsGetParam(funcindex, "VPRE_PREGLS_DIS_R");
	CParam* VPRE_PREGHS_DIS_R = StsGetParam(funcindex, "VPRE_PREGHS_DIS_R");
	CParam* VPRE_DT_HL = StsGetParam(funcindex, "VPRE_DT_HL");
	CParam* VPRE_DT_LH = StsGetParam(funcindex, "VPRE_DT_LH");
	CParam* VPRE_DT_HL_0x11 = StsGetParam(funcindex, "VPRE_DT_HL_0x11");
	CParam* VPRE_DT_LH_0x11 = StsGetParam(funcindex, "VPRE_DT_LH_0x11");
	CParam* VPRE_DT_HL_0x10 = StsGetParam(funcindex, "VPRE_DT_HL_0x10");
	CParam* VPRE_DT_LH_0x10 = StsGetParam(funcindex, "VPRE_DT_LH_0x10");
	CParam* VPRE_DT_HL_0x01 = StsGetParam(funcindex, "VPRE_DT_HL_0x01");
	CParam* VPRE_DT_LH_0x01 = StsGetParam(funcindex, "VPRE_DT_LH_0x01");

	CParam* VPRE_DT_HL_0x01_10 = StsGetParam(funcindex, "VPRE_DT_HL_0x01_10");
	CParam* VPRE_DT_LH_0x01_10 = StsGetParam(funcindex, "VPRE_DT_LH_0x01_10");
	CParam* VPRE_DT_HL_0x01_10_DELTA = StsGetParam(funcindex, "VPRE_DT_HL_0x01_10_DELTA");
	CParam* VPRE_DT_LH_0x01_10_DELTA = StsGetParam(funcindex, "VPRE_DT_LH_0x01_10_DELTA");
	CParam* VPRE_DT_HL_0x01_01 = StsGetParam(funcindex, "VPRE_DT_HL_0x01_01");
	CParam* VPRE_DT_LH_0x01_01 = StsGetParam(funcindex, "VPRE_DT_LH_0x01_01");
	CParam* VPRE_DT_HL_0x01_01_DELTA = StsGetParam(funcindex, "VPRE_DT_HL_0x01_01_DELTA");
	CParam* VPRE_DT_LH_0x01_01_DELTA = StsGetParam(funcindex, "VPRE_DT_LH_0x01_01_DELTA");
	CParam* VPRE_DT_HL_0x01_00 = StsGetParam(funcindex, "VPRE_DT_HL_0x01_00");
	CParam* VPRE_DT_LH_0x01_00 = StsGetParam(funcindex, "VPRE_DT_LH_0x01_00");
	CParam* VPRE_DT_HL_0x01_00_DELTA = StsGetParam(funcindex, "VPRE_DT_HL_0x01_00_DELTA");
	CParam* VPRE_DT_LH_0x01_00_DELTA = StsGetParam(funcindex, "VPRE_DT_LH_0x01_00_DELTA");


	CParam* VPRE_MINI_ON_TIME = StsGetParam(funcindex, "VPRE_MINI_ON_TIME");
	CParam* VPRE_MINI_ON_TIME_FREQ = StsGetParam(funcindex, "VPRE_MINI_ON_TIME_FREQ");
	CParam* VPRE_MAX_ON_TIME = StsGetParam(funcindex, "VPRE_MAX_ON_TIME");
	CParam* VPRE_MAX_ON_TIME_FREQ = StsGetParam(funcindex, "VPRE_MAX_ON_TIME_FREQ");
	CParam* VPRE_MINI_OFF_TIME = StsGetParam(funcindex, "VPRE_MINI_OFF_TIME");
	CParam* VPRE_MINI_OFF_TIME_FREQ = StsGetParam(funcindex, "VPRE_MINI_OFF_TIME_FREQ");

	
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res_r[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double res3[SITE_NUM];
	double res4[SITE_NUM];
	ULONG rdata[SITE_NUM];

	ULONG data0 = 0x0000;
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K80_PRECSP_PREFB_SHRT, K84_PRECOMP_CAP, K46_PREFB_ACM, K32_INTB_FXVIA, K110_FXVI3_9_A, -1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	delay_ms(1);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	A5_AMUX.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(5);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();

	SPIWrite(0x3F, 0x7481);//switch to main otp

	//----------VPRE OVP----------
	//0x31  0000 0000 00xx xx00
	Enter_M_TM(0x0003, 0x0004, 0x0000);
	SPIWrite(0x07, data0);
	SPIWrite(0x00, data0);
	PREFB_BUCK1FB_8.Set(FV, 5.4, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON,0.5);
	awg.rampv2(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "VPRE_OVP", 5.4, 6.6, 6.6, 5.4, 0.005, 20, 2.0, TRIG_FALLING , TRIG_RISING, res1, res2);
	SERIAL
	{
		VPRE_OVP_ABS_R->SetTestResult(SITE, 0, res1[SITE]);//6V
		VPRE_OVP_ABS_F->SetTestResult(SITE, 0, res2[SITE]);
		VPRE_OVP_ABS_HYS->SetTestResult(SITE, 0, res1[SITE] - res2[SITE]);
	}
	SPIWrite(0x07, 0x0080);
	PREFB_BUCK1FB_8.Set(FV, 3.3*1.06, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	awg.rampv2(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "VPRE_OVP2", 3.3*1.06, 3.3*1.18, 3.3*1.18, 3.3*1.06, 0.002, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{
		VPRE_OVP_REL_R->SetTestResult(SITE, 0, res1[SITE]/3.3*100);//6V
		VPRE_OVP_REL_F->SetTestResult(SITE, 0, res2[SITE] / 3.3 * 100);
		VPRE_OVP_REL_HYS->SetTestResult(SITE, 0,( res1[SITE] - res2[SITE]) / 3.3 * 100);
	}
	SPIWrite(0x07, data0);

	//----------VPRE UVH----------
	Enter_M_TM(0x0003, 0x0008, 0x0000);
	SPIWrite(0x3F, 0x7401);//switch to main otp
	SPIWrite(0x04, 0x0013);//switch bg to AMUX
	SPIWrite(0x3F, 0x7481);//switch to main otp
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE,MVRET);
		VPRE_VREF0p8->SetTestResult(SITE, 0, res1[SITE]+g_amux_vos[SITE]);//0.8V
	
	}

	PREFB_BUCK1FB_8.Set(FV, 3.2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	awg.rampv2(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "VPRE_UVH", 3.2, 2.8, 2.8, 3.2, 0.002, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{
		VPRE_UVH_ABS_R->SetTestResult(SITE, 0, res2[SITE]);
		VPRE_UVH_ABS_F->SetTestResult(SITE, 0, res1[SITE]);
		VPRE_UVH_ABS_HYS->SetTestResult(SITE, 0, res2[SITE] - res1[SITE]);
	}
	SPIWrite(0x07, 0x0080);
	PREFB_BUCK1FB_8.Set(FV, 3.3 * 0.96, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	awg.rampv2(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "VPRE_UVH2", 3.3 * 0.96, 3.3 * 0.80, 3.3 * 0.8, 3.3 * 0.96, 0.002, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{
		VPRE_UVH_REL_R->SetTestResult(SITE, 0, res2[SITE] / 3.3 * 100);//12%
		VPRE_UVH_REL_F->SetTestResult(SITE, 0, res1[SITE] / 3.3 * 100);
		VPRE_UVH_REL_HYS->SetTestResult(SITE, 0,(res2[SITE] - res1[SITE]) / 3.3 * 100);
	}
	SPIWrite(0x07, data0);

	//----------VPRE UVL----------
	//0x31  0000 0000 00xx xx00
	Enter_M_TM(0x0003, 0x000C, 0x0000);
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	delay_ms(2);
	A5_AMUX.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = A5_AMUX.GetMeasResult(SITE,MVRET);//1/6 VPRE_FB=3.3/6=0.55V
		VPRE_DIV6->SetTestResult(SITE, 0, res1[SITE] + g_amux_vos[SITE]);

	}

	PREFB_BUCK1FB_8.Set(FV, 2.8, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON, 0.5);
	awg.rampv2(PREFB_BUCK1FB_8, A3_INTB, ACM200_10V, ACM200_100MA, "VPRE_UVL", 2.8, 2.4, 2.4, 2.8, 0.002, 20, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	SERIAL
	{
		VPRE_UVL_ABS_R->SetTestResult(SITE, 0, res2[SITE]);
		VPRE_UVL_ABS_F->SetTestResult(SITE, 0, res1[SITE]);
		VPRE_UVL_ABS_HYS->SetTestResult(SITE, 0, res2[SITE] - res1[SITE]);
	}


	//VPRE amplifier gain
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K32_INTB_FXVIA, K110_FXVI3_9_A, K38_PRECOMP_ACM,K46_PREFB_ACM, K63_CSP_FB_FPVIHL, K_FPVIH_A, K_FPVIL_A, K56_INTB_PU, K84_PRECOMP_CAP, -1);
	delay_ms(1);
	
	//---------- VPRE EA GAIN-----------
	Enter_M_TM(0x0003, 0x0010, 0x0000);
	SPIWrite(0x00, 0x0300);//150mV for VPRE ILMT
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FV, 0.01, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.6, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_us(200);
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "GAIN_COMP0", 0.6, 2.0, 0.005, 20, 2.0, TRIG_RISING  , res1);

	FPVIM.Set(FV, 0.03, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 2.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_us(200);
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "GAIN_COMP1", 2.0, 0.6, 0.005, 20, 2.0, TRIG_FALLING, res2);
	SERIAL
	{
		VPRE_GAIN_VCOMP1->SetTestResult(SITE, 0, res1[SITE]);
		VPRE_GAIN_VCOMP2->SetTestResult(SITE, 0, res2[SITE]);
		VPRE_GAIN->SetTestResult(SITE, 0, (res2[SITE] - res1[SITE])/0.02);//gain=6.2
	}
		//------VPRE EA GM------------
	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	FPVIM.Set(FV, 0.0, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_ON);
	PREFB_BUCK1FB_8.Set(FV, 3.25, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	PRECMP_BUCK3FB_INTB_10.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);

	}
	PREFB_BUCK1FB_8.Set(FV, 3.2, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	PRECMP_BUCK3FB_INTB_10.MeasureVI(30, 10);
	SERIAL{
		res2[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);

		results[SITE] = (res1[SITE] - res2[SITE]) / 0.05 * 6.0*1e3;
		VPRE_IGM->SetTestResult(SITE, 0, results[SITE]);
	}
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);
	PRECMP_BUCK3FB_INTB_10.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);//max Iout of EA
		VPRE_EA_IOUT_MAX->SetTestResult(SITE, 0, -res1[SITE]*1e6);
	}
	FPVIM.Set(FV, 0.0, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_OFF);
		
	//-------------COMP H----------
	Enter_M_TM(0x0003, 0x001C, 0x0000);
	//0x31  0000 0000 00xx xx00
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.8, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_us(200);
	awg.rampv2(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "COMP_H_L", 0.6, 1.2, 1.0, 0.5, 0.003, 20, 2.0, TRIG_RISING, TRIG_FALLING, res1, res2);
	SERIAL{
	
		VPRE_COMPH_0x00->SetTestResult(SITE, 0, res1[SITE]);
		VPRE_COMPL_0x00->SetTestResult(SITE, 0, res2[SITE]);
	}
	SPIWrite(0x00, 0x0100);//VPREILIM =01
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "COMP_H01", 0.9, 1.6, 0.003, 20, 2.0, TRIG_FALLING, res1);
	SERIAL{

	VPRE_COMPH_0x01->SetTestResult(SITE, 0, res1[SITE]);
	
	}

	SPIWrite(0x00, 0x0200);//VPREILIM =10
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "COMP_H10", 1.25, 1.9, 0.003, 20, 2.0, TRIG_FALLING, res1);
	SERIAL{

	VPRE_COMPH_0x10->SetTestResult(SITE, 0, res1[SITE]);

	}

	SPIWrite(0x00, 0x0300);//VPREILIM =11
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_100MA, "COMP_H11", 1.4, 2.1, 0.003, 20, 2.0, TRIG_FALLING, res1);
	SERIAL{

	VPRE_COMPH_0x11->SetTestResult(SITE, 0, res1[SITE]);

	}
	SPIWrite(0x00, data0);
	//SPIWrite(0x06, 0x0080);
	//-------------VPRE  SS---------
	PRECMP_BUCK3FB_INTB_10.Set(FI, -1e-7, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	
	measure_VPRE_SS(res1, res2);
	SERIAL
	{
		VPRE_SSDONE->SetTestResult(SITE, 0, res1[SITE] * 10);//us
		VPRE_SS->SetTestResult(SITE, 0, res2[SITE] * 10);//us
	}
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_OFF);

	//--------------IPRE_GATE_DRV_pull up------------------------
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, K46_PREFB_ACM,
			K32_INTB_FXVIA, K110_FXVI3_9_A, K38_PRECOMP_ACM, K80_PRECSP_PREFB_SHRT, K43_PREGHS_FXVIB, K107_FXVI1_7_B,
		 K56_INTB_PU, K84_PRECOMP_CAP, K42_PRESW_FXVIB, K105_FXVI0_6_B, K44_PREBOOT_FXVIB, K109_FXVI2_8_B, K21_PADF_AGNDF ,-1);
	delay_ms(1);

	
		//0x31  0000 0000 00xx xx00
	B2_PREBOOT_VBOOST.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	Enter_M_TM(0x0003, 0x001C, 0x0000);
	SPIWrite(0x3F, 0x7401);//switch to main reg
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,0.5);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GHS_IPU_0x00->SetTestResult(SITE, 0, -res1[SITE]*1e3);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);

	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B2_PREBOOT_VBOOST.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		res2[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MVRET);
		res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);

		VPRE_GHS_RPU_0x00->SetTestResult(SITE, 0, -(res2[SITE] - res1[SITE]) / (res_r[SITE]+1e-30));
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);

//	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
//	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
//	ghs code1
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	SPIWrite(0x03, 0x0001);
	Enter_M_TM(0x0003, 0x002C, 0x0000);
	delay_ms(1);
	Enter_M_TM(0x0003, 0x001C, 0x0000);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GHS_IPU_0x01->SetTestResult(SITE, 0, -res1[SITE] * 1e3);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);

	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B2_PREBOOT_VBOOST.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		res2[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MVRET);
		res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GHS_RPU_0x01->SetTestResult(SITE, 0, -(res2[SITE] - res1[SITE]) / (res_r[SITE] + 1e-30));
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	//ghs code2
	SPIWrite(0x03, 0x0002);
	Enter_M_TM(0x0003, 0x002C, 0x0000);
	delay_ms(1);
	Enter_M_TM(0x0003, 0x001C, 0x0000);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);

	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GHS_IPU_0x10->SetTestResult(SITE, 0, -res1[SITE] * 1e3);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);

	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B2_PREBOOT_VBOOST.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		res2[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MVRET);
		res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GHS_RPU_0x10->SetTestResult(SITE, 0, -(res2[SITE] - res1[SITE]) / (res_r[SITE] + 1e-30));
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	//ghs code3, only check rpu�� need high current resource for 1A
	SPIWrite(0x03, 0x0003);
	Enter_M_TM(0x0003, 0x002C, 0x0000);
	delay_ms(1);
	Enter_M_TM(0x0003, 0x001C, 0x0000);
	delay_ms(1);
	
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);
	
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B2_PREBOOT_VBOOST.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		res2[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MVRET);
		res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GHS_RPU_0x11->SetTestResult(SITE, 0, -(res2[SITE] - res1[SITE]) / (res_r[SITE] + 1e-30));
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	

	//ghs PD code0
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	SPIWrite(0x03, data0);

	delay_ms(1);
	Enter_M_TM(0x0003, 0x0020, 0x0000);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,0.5);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GHS_IPD_0x00->SetTestResult(SITE, 0, res1[SITE] * 1e3);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON, 0.5);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
//	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B0_PRESW_LDO1IN.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		res2[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MVRET);
		res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GHS_RPD_0x00->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]) / (res_r[SITE] + 1e-30));
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	////ghs code1
	//SPIWrite(0x03, 0x0005);
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	//SERIAL{
	//	res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
	//	VPRE_GHS_IPD_0x01->SetTestResult(SITE, 0, res1[SITE] * 1e3);
	//}
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(2);
	//B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	//B0_PRESW_LDO1IN.MeasureVI(30, 10);
	//SERIAL{
	//	res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
	//	res2[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MVRET);
	//	res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
	//	VPRE_GHS_RPD_0x01->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]) / (res_r[SITE] + 1e-30));
	//}
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	////ghs code2
	//SPIWrite(0x03, 0x000A);
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	//SERIAL{
	//	res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
	//	VPRE_GHS_IPD_0x10->SetTestResult(SITE, 0, res1[SITE] * 1e3);
	//}
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	//delay_ms(2);
	//B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	//B0_PRESW_LDO1IN.MeasureVI(30, 10);
	//SERIAL{
	//	res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
	//	res2[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MVRET);
	//	res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
	//	VPRE_GHS_RPD_0x10->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]) / (res_r[SITE] + 1e-30));
	//}
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	////ghs code3, only check rpu�� need high current resource for 1A
	//SPIWrite(0x03, 0x000F);

	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(2);
	//B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	//B0_PRESW_LDO1IN.MeasureVI(30, 10);
	//SERIAL{
	//	res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
	//	res2[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MVRET);
	//	res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
	//	VPRE_GHS_RPD_0x11->SetTestResult(SITE, 0, (res1[SITE] - res2[SITE]) / (res_r[SITE] + 1e-30));
	//}
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);


	SPIWrite(0x00, data0);

	B0_PRESW_LDO1IN.Set(FV, 1.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	awg.rampv(B0_PRESW_LDO1IN, A3_INTB, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "SW_SHORT2H", 1.5, 4.5, 0.01, 20, 2.0, TRIG_FALLING, res1);

	SERIAL{
	
		SW_SHORT2H->SetTestResult(SITE, 0, res1[SITE]);
	}
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 5.2, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	VBOS_1.Set(FV, 5.2, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	delay_ms(1);
	cbite.SetCbiteOff(K43_PREGHS_FXVIB);
	delay_ms(1);
	cbite.SetCbiteOn(K41_PREGLS_FXVIB);
	delay_ms(1);
	//------------GLS PU---
	SPIWrite(0x03, data0);
	Enter_M_TM(0x0003, 0x0020, 0x0000);
	

	//0x31  0000 0000 00xx xx00
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	//B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);//less than 200mA
		VPRE_GLS_IPU_0x00->SetTestResult(SITE, 0, -res1[SITE] * 1e3);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.5, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	VBOS_1.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		res2[SITE] = VBOS_1.GetMeasResult(SITE, MVRET);
		VPRE_GLS_RPU_0x00->SetTestResult(SITE, 0, -(res2[SITE] - res1[SITE]) / (res_r[SITE] + 1e-30));
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);



	//---------gls PD code0
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	SPIWrite(0x03, data0);
	Enter_M_TM(0x0003, 0x001C, 0x0000);
	//Enter_M_TM(0x0003, 0x0020, 0x0000);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GLS_IPD_0x00->SetTestResult(SITE, 0, res1[SITE] * 1e3);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
//	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);

	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
	
		res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GLS_RPD_0x00->SetTestResult(SITE, 0, res1[SITE] / (res_r[SITE] + 1e-30));
	}
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	//gls code1
	SPIWrite(0x03, 0x0008);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GLS_IPD_0x01->SetTestResult(SITE, 0, res1[SITE] * 1e3);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GLS_RPD_0x01->SetTestResult(SITE, 0, res1[SITE] / (res_r[SITE] + 1e-30));
	}
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	//gls code2
	SPIWrite(0x03, 0x0010);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GLS_IPD_0x10->SetTestResult(SITE, 0, res1[SITE] * 1e3);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GLS_RPD_0x10->SetTestResult(SITE, 0, res1[SITE] / (res_r[SITE] + 1e-30));
	}


	//gls code3, only check rpu�� need high current resource for 1A
	SPIWrite(0x03, 0x0018);

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);

	SERIAL{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		res_r[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		VPRE_GLS_RPD_0x11->SetTestResult(SITE, 0, res1[SITE] / (res_r[SITE] + 1e-30));
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	//power down
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	delay_ms(1);
	VBOS_1.Set(FV, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	A5_AMUX.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	A3_INTB.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	STSTArming();
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);

	VBOS_1.Set(FV, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_OFF);
		delay_ms(1);
		//repower on
		cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, K46_PREFB_ACM,
			  K80_PRECSP_PREFB_SHRT, K41_PREGLS_FXVIB, K107_FXVI1_7_B, K56_INTB_PU, K84_PRECOMP_CAP,
			K42_PRESW_FXVIB, K105_FXVI0_6_B, K44_PREBOOT_FXVIB, K109_FXVI2_8_B, K21_PADF_AGNDF ,-1);
	delay_ms(1);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	
	delay_ms(15);
	Enter_MAIN_SCAN_DIG();
	Enter_FS_SCAN_DIG();
	//-------VPRE Discharge R------------

	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);

	SPIWrite(0x02, 0x7F00);
	SPIWrite(0x3F, 0x7400);
	//VDDIO_VBOOST_0.Set(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//delay_ms(2);
	//PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(2);
	PREFB_BUCK1FB_8.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE,MIRET);
		VPRE_PREFB_DIS_R->SetTestResult(SITE, 0, 3.3/(res1[SITE]+1e-30));//500 ohm

	}
	B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	

	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);//need keep this command to keep 0V first
	delay_ms(1);
	B2_PREBOOT_VBOOST.Set(FV, 2.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B2_PREBOOT_VBOOST.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE,MIRET);
		VPRE_PREBOOT_DIS_R->SetTestResult(SITE, 0, 2.0 / (res1[SITE] + 1e-30)*1e-3);//1.7 kohm

	}
	B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	Enter_M_TM(0x0003, 0x0030, 0x0000);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 2.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE,MIRET);
		VPRE_PREGLS_DIS_R->SetTestResult(SITE, 0, 2.0 / (res1[SITE] + 1e-30) * 1e-3);//16 kohm

	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 2.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	delay_ms(5);
	//---------VPRE Dead Time--------------
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, K46_PREFB_ACM,
			K32_INTB_FXVIA, K110_FXVI3_9_A, K62_BOOST_PRESW_VCOREMON_PD, K77_PREGHS_GLS_TMU, K80_PRECSP_PREFB_SHRT,K56_INTB_PU, K84_PRECOMP_CAP, K42_PRESW_FXVIB, K105_FXVI0_6_B, K_FPVIL_D, K21_PADF_AGNDF, -1);
	delay_ms(1);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(4);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	SPIWrite(0x03, 0x001B);
	SPIWrite(0x3F, 0x7481);//switch to main otp
	SPIWrite(0x00, data0);
	//0x31  0000 0000 00xx xx00
	FPVIM.Set(FV, 5.0, FPVIe_10V, FPVIe_100MA, FPVIe_RELAY_ON);
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);

	Enter_M_TM(0x0003, 0x002C, 0x0000);

	delay_ms(1);
	measure_ON_OFF_QTMU(res1);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_B);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res2);

	SERIAL
	{
		VPRE_DT_HL->SetTestResult(SITE, 0, res1[SITE]*1e3);//ns
		VPRE_DT_LH->SetTestResult(SITE, 0, res2[SITE] * 1e3);//ns
	}
	SPIWrite(0x00, 0x000F);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res1);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_B);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res2);
	SERIAL
	{
		VPRE_DT_HL_0x11->SetTestResult(SITE, 0, res1[SITE] * 1e3);//ns
		VPRE_DT_LH_0x11->SetTestResult(SITE, 0, res2[SITE] * 1e3);//ns
	}



	SPIWrite(0x00, 0x000A);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res1);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_B);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res2);
	SERIAL
	{
		VPRE_DT_HL_0x10->SetTestResult(SITE, 0, res1[SITE] * 1e3);//ns
		VPRE_DT_LH_0x10->SetTestResult(SITE, 0, res2[SITE] * 1e3);//ns
	}
	SPIWrite(0x00, 0x0005);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res1);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_B);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res2);
	SERIAL
	{
		VPRE_DT_HL_0x01->SetTestResult(SITE, 0, res1[SITE] * 1e3);//ns
		VPRE_DT_LH_0x01->SetTestResult(SITE, 0, res2[SITE] * 1e3);//ns
	}
	SPIWrite(0x3F, 0x7401);
	SPIWrite(0x03, 0x0012);
	delay_ms(1);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res3);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_B);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res4);
	SERIAL
	{
		VPRE_DT_HL_0x01_10->SetTestResult(SITE, 0, res3[SITE] * 1e3);//ns
		VPRE_DT_LH_0x01_10->SetTestResult(SITE, 0, res4[SITE] * 1e3);//ns
		VPRE_DT_HL_0x01_10_DELTA->SetTestResult(SITE, 0, (res3[SITE] - res1[SITE]) * 1e3);//ns
		VPRE_DT_LH_0x01_10_DELTA->SetTestResult(SITE, 0, (res4[SITE] - res2[SITE]) * 1e3);//ns
	}
	SPIWrite(0x03, 0x0009);
	delay_ms(1);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res3);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_B);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res4);
	SERIAL
	{
		VPRE_DT_HL_0x01_01->SetTestResult(SITE, 0, res3[SITE] * 1e3);//ns
		VPRE_DT_LH_0x01_01->SetTestResult(SITE, 0, res4[SITE] * 1e3);//ns
		VPRE_DT_HL_0x01_01_DELTA->SetTestResult(SITE, 0, (res3[SITE] - res1[SITE]) * 1e3);//ns
		VPRE_DT_LH_0x01_01_DELTA->SetTestResult(SITE, 0, (res4[SITE] - res2[SITE]) * 1e3);//ns
	}

	SPIWrite(0x03, data0);
	delay_ms(1);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res3);
	ALL_QTMU.SetInSource(QTMUe_DUAL_SOURCE_START_B);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.6, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHAB);
	measure_ON_OFF_QTMU(res4);
	SERIAL
	{
		VPRE_DT_HL_0x01_00->SetTestResult(SITE, 0, res3[SITE] * 1e3);//ns
		VPRE_DT_LH_0x01_00->SetTestResult(SITE, 0, res4[SITE] * 1e3);//ns
		VPRE_DT_HL_0x01_00_DELTA->SetTestResult(SITE, 0, (res3[SITE] - res1[SITE]) * 1e3);//ns
		VPRE_DT_LH_0x01_00_DELTA->SetTestResult(SITE, 0, (res4[SITE] - res2[SITE]) * 1e3);//ns
	}
	PREFB_BUCK1FB_8.Set(FV, 0.0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	FPVIM.Set(FV, 0, FPVIe_10V, FPVIe_100MA, FPVIe_RELAY_ON);
	delay_ms(5);//for cap discharge
	PREFB_BUCK1FB_8.TSet(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	FPVIM.Set(FV, 0.0, FPVIe_100MV, FPVIe_10MA, FPVIe_RELAY_OFF);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	A5_AMUX.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	FPVIM.Set(FV, 0, FPVIe_10V, FPVIe_100MA, FPVIe_RELAY_OFF);
	STSTArming();

	//mini on time
	//---------VPRE mini on time -------------
	//need low vsup to avoid high vpre
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS,  K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU, K46_PREFB_ACM,
		  K80_PRECSP_PREFB_SHRT, K84_PRECOMP_CAP,  K21_PADF_AGNDF, K11_PRE_SLT, K38_PRECOMP_ACM , K38_PRECOMP_ACM ,
		K73_PRESW_BOOSTLS_TMU ,-1);
	delay_ms(1);
	
	VSUP_11.Set(FV, 5.0, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);

	delay_ms(4);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	SPIWrite(0x03, 0x001B);
	SPIWrite(0x3F, 0x7481);//switch to main otp
	SPIWrite(0x00, 0x0300);
	//dut.trim("VPRE_IPK").save_working();
	//dut.trim("VPRE_IPK").set_working(8);
	//OTP_M_Preview(2);
	////SPIWrite(0x1F, 0x0007);
	//dut.trim("VPRE_IPK").restore_working();
	dut.trim("VPRE_INEG").save_working();
	dut.trim("VPRE_INEG").set_working(1);
	OTP_M_Preview(4, 1);
	dut.trim("VPRE_INEG").restore_working();
	Enter_M_TM(0x0003, 0x003C, 0x0000);
	//SPIWrite(0x3F, 0x7401);
	//SPIWrite(0x03, 0x001B);
	ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
	//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
	//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHA);
	
	PRECMP_BUCK3FB_INTB_10.Set(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);

	delay_ms(1);
	measure_ON_OFF_QTMU(res1, res2,QTMUe_POS,QTMUe_NEG,2.5,2.5);
	SERIAL
	{
		VPRE_MAX_ON_TIME->SetTestResult(SITE, 0, res1[SITE] * 1e3);//NS
		VPRE_MAX_ON_TIME_FREQ->SetTestResult(SITE, 0, res2[SITE]);//KHZ

	}
	//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
	//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
	//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
	//ALL_QTMU.Connect(QTMUe_RELAY_CHA);
	measure_ON_OFF_QTMU(res1, res2,QTMUe_NEG,QTMUe_POS,2.5,2.5);
	SERIAL
	{
		VPRE_MINI_OFF_TIME->SetTestResult(SITE, 0, res1[SITE] * 1e3);//NS
		VPRE_MINI_OFF_TIME_FREQ->SetTestResult(SITE, 0, res2[SITE]);//KHZ

	}
	PREFB_BUCK1FB_8.Set(FV, 3.3, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	
	/*ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
	ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
	ALL_QTMU.Connect(QTMUe_RELAY_CHA);*/

	
	delay_ms(10);
	measure_ON_OFF_QTMU(res1, res2,QTMUe_POS,QTMUe_NEG,2.5,2.5);
	SERIAL
	{
		VPRE_MINI_ON_TIME->SetTestResult(SITE, 0, res1[SITE] * 1e3);//NS
		VPRE_MINI_ON_TIME_FREQ->SetTestResult(SITE, 0, res2[SITE]);//KHZ

	}

	
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	delay_ms(1);
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	FPVIM.Set(FV, 0.0, FPVIe_100MV, FPVIe_100MA, FPVIe_RELAY_OFF);
	delay_ms(5);
	power_off(DEBUG);
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T45_BUCK123_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam* BUCK1_FB_DIS = StsGetParam(funcindex, "BUCK1_FB_DIS");
	CParam* BUCK1_TRAN_ENH_R = StsGetParam(funcindex, "BUCK1_TRAN_ENH_R");
	CParam* BUCK1_TRAN_ENH_F = StsGetParam(funcindex, "BUCK1_TRAN_ENH_F");
	CParam* BUCK1_TSD_R = StsGetParam(funcindex, "BUCK1_TSD_R");
	CParam* BUCK1_TSD_F = StsGetParam(funcindex, "BUCK1_TSD_F");
	CParam* BUCK1_TSD_HYS = StsGetParam(funcindex, "BUCK1_TSD_HYS");
	CParam* BUCK2_FB_DIS = StsGetParam(funcindex, "BUCK2_FB_DIS");
	CParam* BUCK2_TRAN_ENH_R = StsGetParam(funcindex, "BUCK2_TRAN_ENH_R");
	CParam* BUCK2_TRAN_ENH_F = StsGetParam(funcindex, "BUCK2_TRAN_ENH_F");
	CParam* BUCK2_TSD_R = StsGetParam(funcindex, "BUCK2_TSD_R");
	CParam* BUCK2_TSD_F = StsGetParam(funcindex, "BUCK2_TSD_F");
	CParam* BUCK2_TSD_HYS = StsGetParam(funcindex, "BUCK2_TSD_HYS");
	CParam* BUCK3_FB_DIS = StsGetParam(funcindex, "BUCK3_FB_DIS");
	CParam* BUCK3_TRAN_ENH_R = StsGetParam(funcindex, "BUCK3_TRAN_ENH_R");
	CParam* BUCK3_TRAN_ENH_F = StsGetParam(funcindex, "BUCK3_TRAN_ENH_F");
	CParam* BUCK3_TSD_R = StsGetParam(funcindex, "BUCK3_TSD_R");
	CParam* BUCK3_TSD_F = StsGetParam(funcindex, "BUCK3_TSD_F");
	CParam* BUCK3_TSD_HYS = StsGetParam(funcindex, "BUCK3_TSD_HYS");

	CParam* BUCK1_MINI_ON_TIME = StsGetParam(funcindex, "BUCK1_MINI_ON_TIME");
	CParam* BUCK1_MINI_ON_TIME_FREQ = StsGetParam(funcindex, "BUCK1_MINI_ON_TIME_FREQ");
	CParam* BUCK1_MINI_OFF_TIME = StsGetParam(funcindex, "BUCK1_MINI_OFF_TIME");
	CParam* BUCK1_MINI_OFF_TIME_FREQ = StsGetParam(funcindex, "BUCK1_MINI_OFF_TIME_FREQ");

	CParam* BUCK2_MINI_ON_TIME = StsGetParam(funcindex, "BUCK2_MINI_ON_TIME");
	CParam* BUCK2_MINI_ON_TIME_FREQ = StsGetParam(funcindex, "BUCK2_MINI_ON_TIME_FREQ");
	CParam* BUCK2_MINI_OFF_TIME = StsGetParam(funcindex, "BUCK2_MINI_OFF_TIME");
	CParam* BUCK2_MINI_OFF_TIME_FREQ = StsGetParam(funcindex, "BUCK2_MINI_OFF_TIME_FREQ");

	CParam* BUCK3_MINI_ON_TIME = StsGetParam(funcindex, "BUCK3_MINI_ON_TIME");
	CParam* BUCK3_MINI_ON_TIME_FREQ = StsGetParam(funcindex, "BUCK3_MINI_ON_TIME_FREQ");
	CParam* BUCK3_MINI_OFF_TIME = StsGetParam(funcindex, "BUCK3_MINI_OFF_TIME");
	CParam* BUCK3_MINI_OFF_TIME_FREQ = StsGetParam(funcindex, "BUCK3_MINI_OFF_TIME_FREQ");


	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double res_r[SITE_NUM];
	ULONG data0=0x0000;
	ULONG uotpcode;
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K81_LDO_CAPS,K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K56_INTB_PU, K32_INTB_FXVIA, K110_FXVI3_9_A, K17_FIN_FXVIA, K104_FXVI0_6_A, -1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	delay_ms(1);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	A3_INTB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();

	SPIWrite(0x3F, 0x7481);//switch to main otp
		if(SC6295X[find_ID].useropt_burn==1)
	{
		
		SERIAL uotpcode=(dut.assy("MUBANK4").get_start(SITE))&0xDFFF;
		if(bk12mult==1) SPIWrite(0x04, uotpcode);

	}
	//bit34-31 BUCK1
	//x000 0000 0000 0000
	//0000 0000 0000 0xxx
	BUCK123.Set(FV, 3.3, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	//--------BUCK1 FB Discharge--------
	Enter_M_TM(0x0006, 0x0000, 0x0003);

	PREFB_BUCK1FB_8.TSet(FV, 1.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	STSTArming();
	delay_ms(2);
	PREFB_BUCK1FB_8.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		BUCK1_FB_DIS->SetTestResult(SITE, 0,1.0/( results[SITE]+1e-30));//500ohm
	}

	PREFB_BUCK1FB_8.TSet(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	//--------BUCK1 Tran Enhance--------
	Enter_M_TM(0x0006, 0x8000, 0x0006);
		SPIWrite(0x01, data0);
	PREFB_BUCK1FB_8.TSet(FV, 0.49, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_10MA, "BUCK1_TRAN_R", 0.49, 0.56, 0.0003, 50, 2.0, TRIG_FALLING, res1);
	SERIAL
	{
	
		BUCK1_TRAN_ENH_R->SetTestResult(SITE, 0,res1[SITE]);
	}

	Enter_M_TM(0x0006, 0x0000, 0x0007);

	PREFB_BUCK1FB_8.TSet(FV, 0.51, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	awg.rampv(PREFB_BUCK1FB_8, A3_INTB, ACM200_3p6V, ACM200_10MA, "BUCK1_TRAN_F", 0.51, 0.43, 0.0003, 50, 2.0, TRIG_FALLING, res1);

	SERIAL
	{

		BUCK1_TRAN_ENH_F->SetTestResult(SITE, 0,res1[SITE]);
	}
		//---------BUCK1 TSD--------
	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	Enter_M_TM(0x0006, 0x8000, 0x0007);
	A0_FIN_DBG_ERR_FCCU1.Set(FI, 4.0e-6, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	awg.rampi2(A0_FIN_DBG_ERR_FCCU1, A3_INTB, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, "BUCK1_TSD", 4.0e-6, -20.0e-6, -20.0e-6, 4.0e-6, 0.05e-6, 200, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	//will check if need to change 25C to other temperature for high/low temperature test
	SERIAL
	{
		BUCK1_TSD_R->SetTestResult(SITE, 0, g_temp[SITE] - res1[SITE] / 1.0e-6 * 20);//
		BUCK1_TSD_F->SetTestResult(SITE, 0, g_temp[SITE] - res2[SITE] / 1.0e-6 * 20);
		BUCK1_TSD_HYS->SetTestResult(SITE, 0, -(res1[SITE] - res2[SITE]) / 1.0e-6 * 20);
	}
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);


	//--------BUCK2 FB Discharge--------
	Enter_M_TM(0x0007, 0x0000, 0x0030);


	PRECSP_BUCK2FB_9.Set(FV, 1.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	PRECSP_BUCK2FB_9.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		BUCK2_FB_DIS->SetTestResult(SITE, 0,1.0 / (results[SITE] + 1e-30));//500ohm
	}

	PRECSP_BUCK2FB_9.TSet(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	//--------BUCK2 Tran Enhance--------
	Enter_M_TM(0x0007, 0x0000, 0x0068);
		SPIWrite(0x02, data0);
	PRECSP_BUCK2FB_9.TSet(FV, 0.49, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_10MA, "BUCK2_TRAN_R", 0.49, 0.56, 0.0003, 50, 2.0, TRIG_FALLING, res1);
	SERIAL
	{

		BUCK2_TRAN_ENH_R->SetTestResult(SITE, 0,res1[SITE]);
	}

	Enter_M_TM(0x0007, 0x0000, 0x0070);

	PRECSP_BUCK2FB_9.TSet(FV, 0.51, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	awg.rampv(PRECSP_BUCK2FB_9, A3_INTB, ACM200_3p6V, ACM200_10MA, "BUCK2_TRAN_F", 0.51, 0.43, 0.0003, 50, 2.0, TRIG_FALLING, res1);

	SERIAL
	{

		BUCK2_TRAN_ENH_F->SetTestResult(SITE, 0,res1[SITE]);
	}
		//---------BUCK2 TSD--------
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	Enter_M_TM(0x0007, 0x0000, 0x0078);
	A0_FIN_DBG_ERR_FCCU1.Set(FI, 4.0e-6, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	awg.rampi2(A0_FIN_DBG_ERR_FCCU1, A3_INTB, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, "BUCK2_TSD", 4.0e-6, -20.0e-6, -20.0e-6, 4.0e-6, 0.05e-6, 200, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	//will check if need to change 25C to other temperature for high/low temperature test
	SERIAL
	{
		BUCK2_TSD_R->SetTestResult(SITE, 0, g_temp[SITE] - res1[SITE] / 1.0e-6 * 20);//
		BUCK2_TSD_F->SetTestResult(SITE, 0, g_temp[SITE] - res2[SITE] / 1.0e-6 * 20);
		BUCK2_TSD_HYS->SetTestResult(SITE, 0, -(res1[SITE] - res2[SITE]) / 1.0e-6 * 20);
	}
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);

	//--------BUCK3 FB Discharge--------
	Enter_M_TM(0x0008, 0x0000, 0x0300);


	PRECMP_BUCK3FB_INTB_10.Set(FV, 1.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	PRECMP_BUCK3FB_INTB_10.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		BUCK3_FB_DIS->SetTestResult(SITE, 0,1.0 / (results[SITE] + 1e-30));//500ohm
	}

	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	//--------BUCK3 Tran Enhance--------
	Enter_M_TM(0x0008, 0x0000, 0x0680);
		SPIWrite(0x02, data0);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0.49, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_10MA, "BUCK3_TRAN_R", 0.49, 0.56, 0.0003, 50, 2.0, TRIG_FALLING, res1);
	SERIAL
	{

		BUCK3_TRAN_ENH_R->SetTestResult(SITE, 0,res1[SITE]);
	}

	Enter_M_TM(0x0008, 0x0000, 0x0700);

	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0.5, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	awg.rampv(PRECMP_BUCK3FB_INTB_10, A3_INTB, ACM200_3p6V, ACM200_10MA, "BUCK3_TRAN_F", 0.51, 0.43, 0.0003, 50, 2.0, TRIG_FALLING, res1);

	SERIAL
	{

		BUCK3_TRAN_ENH_F->SetTestResult(SITE, 0,res1[SITE]);
	}
		//---------BUCK3 TSD--------
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	Enter_M_TM(0x0008, 0x0000, 0x0780);
	A0_FIN_DBG_ERR_FCCU1.Set(FI, 4.0e-6, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	awg.rampi2(A0_FIN_DBG_ERR_FCCU1, A3_INTB, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, "BUCK3_TSD", 4.0e-6, -20.0e-6, -20.0e-6, 4.0e-6, 0.05e-6, 200, 2.0, TRIG_FALLING, TRIG_RISING, res1, res2);
	//will check if need to change 25C to other temperature for high/low temperature test
	SERIAL
	{
		BUCK3_TSD_R->SetTestResult(SITE, 0, g_temp[SITE] - res1[SITE] / 1.0e-6 * 20);//
		BUCK3_TSD_F->SetTestResult(SITE, 0, g_temp[SITE] - res2[SITE] / 1.0e-6 * 20);
		BUCK3_TSD_HYS->SetTestResult(SITE, 0, -(res1[SITE] - res2[SITE]) / 1.0e-6 * 20);
	}
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);
	
	Enter_M_TM(0x0000, 0x0000, 0x0000);
	delay_ms(1);
	BUCK123.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(4);//discharge
	BUCK123.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);

	///FPVIM for BUCK  input
	if (1)
	{
		//------BUCK1 MINI ON TIME-----------
		cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K81_LDO_CAPS, K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
			K56_INTB_PU, K32_INTB_FXVIA, K85_BUCKSW_PD, K110_FXVI3_9_A, K76_BUCK1SW_DBUFF, K65_BUCK1IN_FPVIH, K_FPVIH_A, K66_PGND_FPVIL, K_FPVIL_A, K21_PADF_AGNDF, -1);

		delay_ms(1);
		FPVIM.Set(FV, 5.0, FPVIe_10V, FPVIe_1A, FPVIe_RELAY_ON);
		PREFB_BUCK1FB_8.TSet(FV, 2.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);//higher than 0.5V
		ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
		ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		delay_ms(1);
		Enter_M_TM(0x0006, 0x0000, 0x0002);
		delay_ms(5);
		measure_ON_OFF_QTMU_wBUFF(res1,res2,QTMUe_POS,QTMUe_NEG,2.5,2.5);
		SERIAL
		{
			BUCK1_MINI_ON_TIME->SetTestResult(SITE, 0, res1[SITE] * 1e3);//NS
			BUCK1_MINI_ON_TIME_FREQ->SetTestResult(SITE, 0, res2[SITE]);//KHZ

		}
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHA);

		PREFB_BUCK1FB_8.TSet(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);//higher than 0.5V
		delay_ms(5);
		measure_ON_OFF_QTMU_wBUFF(res1,res2,QTMUe_NEG,QTMUe_POS,2.5,2.5);
		SERIAL
		{
			BUCK1_MINI_OFF_TIME->SetTestResult(SITE, 0, res1[SITE] * 1e3);//
			BUCK1_MINI_OFF_TIME_FREQ->SetTestResult(SITE, 0, res2[SITE]);//KHZ
		}
		Enter_M_TM(0x0000, 0x0000, 0x0000);
		delay_ms(1);
		FPVIM.Set(FV, 0, FPVIe_10V, FPVIe_1A, FPVIe_RELAY_ON);
		delay_ms(1);
		FPVIM.Set(FV, 0, FPVIe_1V, FPVIe_100UA, FPVIe_RELAY_ON);
		//BUCK2 MINI ON TIME
		//switch to buck2in 
		cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K81_LDO_CAPS, K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
			K56_INTB_PU, K32_INTB_FXVIA, K85_BUCKSW_PD, K110_FXVI3_9_A, K75_BUCK2SW_DBUFF, K_FPVIH_C, K66_PGND_FPVIL, K_FPVIL_A, K21_PADF_AGNDF, -1);
		delay_ms(1);
		FPVIM.Set(FV, 5.0, FPVIe_10V, FPVIe_1A, FPVIe_RELAY_ON);
		PRECSP_BUCK2FB_9.TSet(FV, 2.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);//higher than 0.5V
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		delay_ms(1);
		Enter_M_TM(0x0007, 0x0000, 0x0020);
		delay_ms(1);
		measure_ON_OFF_QTMU_wBUFF(res1,res2,QTMUe_POS,QTMUe_NEG,2.5,2.5);
		SERIAL
		{
			BUCK2_MINI_ON_TIME->SetTestResult(SITE, 0, res1[SITE] * 1e3);//
			BUCK2_MINI_ON_TIME_FREQ->SetTestResult(SITE, 0, res2[SITE]);//

		}
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHA);

		PRECSP_BUCK2FB_9.TSet(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);//higher than 0.5V
		delay_ms(1);
		measure_ON_OFF_QTMU_wBUFF(res1,res2,QTMUe_NEG,QTMUe_POS,2.5,2.5);
		SERIAL
		{
			BUCK2_MINI_OFF_TIME->SetTestResult(SITE, 0, res1[SITE] * 1e3);//
			BUCK2_MINI_OFF_TIME_FREQ->SetTestResult(SITE, 0, res2[SITE]);//
		}
		Enter_M_TM(0x0000, 0x0000, 0x0000);
		delay_ms(1);
		FPVIM.Set(FV, 0, FPVIe_10V, FPVIe_1A, FPVIe_RELAY_ON);
		delay_ms(1);
		FPVIM.Set(FV, 0, FPVIe_1V, FPVIe_100UA, FPVIe_RELAY_ON);

		//BUCK3 MINI ON TIME
		//switch to buck3in 
		cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K81_LDO_CAPS, K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
			K56_INTB_PU, K32_INTB_FXVIA, K85_BUCKSW_PD, K110_FXVI3_9_A, K74_BUCK3SW_DBUFF, K_FPVIH_B, K66_PGND_FPVIL, K_FPVIL_A, K21_PADF_AGNDF, -1);
		delay_ms(1);
		FPVIM.Set(FV, 5.0, FPVIe_10V, FPVIe_1A, FPVIe_RELAY_ON);
		PRECMP_BUCK3FB_INTB_10.TSet(FV, 2.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);//higher than 0.5V
		//ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		//ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
		//ALL_QTMU.Connect(QTMUe_RELAY_CHA);
		delay_ms(1);
		Enter_M_TM(0x0008, 0x0000, 0x0200);
		delay_ms(1);
		measure_ON_OFF_QTMU_wBUFF(res1,res2,QTMUe_POS,QTMUe_NEG,2.5,2.5);
		SERIAL
		{
			BUCK3_MINI_ON_TIME->SetTestResult(SITE, 0, res1[SITE]*1e3);//
			BUCK3_MINI_ON_TIME_FREQ->SetTestResult(SITE, 0, res2[SITE]);//

		}
		ALL_QTMU.SetInSource(QTMUe_SINGLE_SOURCE_A);
		ALL_QTMU.Start(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.5, QTMUe_FILTER_PASS, 5);
		ALL_QTMU.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS, 5);
		ALL_QTMU.Connect(QTMUe_RELAY_CHA);

		PRECMP_BUCK3FB_INTB_10.TSet(FV, 0.0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);//higher than 0.5V
		delay_ms(1);
		measure_ON_OFF_QTMU_wBUFF(res1, res2);
		SERIAL
		{
			BUCK3_MINI_OFF_TIME->SetTestResult(SITE, 0, res1[SITE] * 1e3);//
			BUCK3_MINI_OFF_TIME_FREQ->SetTestResult(SITE, 0, res2[SITE]);//
		}
		Enter_M_TM(0x0000, 0x0000, 0x0000);
		delay_ms(1);
		FPVIM.Set(FV, 0, FPVIe_10V, FPVIe_1A, FPVIe_RELAY_ON);
		delay_ms(1);
		FPVIM.Set(FV, 0, FPVIe_1V, FPVIe_100UA, FPVIe_RELAY_ON);
	 }

	FPVIM.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_OFF);
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);


	delay_ms(5);//for cap discharge
	A3_INTB.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	A5_AMUX.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	VDDIO_VBOOST_0.TSet(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	VSUP_11.TSet(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_OFF);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	PRECSP_BUCK2FB_9.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);

	STSTArming();
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T47_LDO12_FUNC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES

	CParam* LNR_LDO1IN_MAX_VOUT_I0 = StsGetParam(funcindex, "LNR_LDO1IN_MAX_VOUT_I0");
	CParam* LNR_LDO1IN_MIN_VOUT_I0 = StsGetParam(funcindex, "LNR_LDO1IN_MIN_VOUT_I0");
	CParam* LDO1_VROP_I0 = StsGetParam(funcindex, "LDO1_VROP_I0");
	CParam* LDO1_VROP_MODE_I0 = StsGetParam(funcindex, "LDO1_VROP_MODE_I0");
	CParam* LNR_LDO1IN_MAX_VOUT_I150MA = StsGetParam(funcindex, "LNR_LDO1IN_MAX_VOUT_I150MA");
	CParam* LNR_LDO1IN_MIN_VOUT_I150MA = StsGetParam(funcindex, "LNR_LDO1IN_MIN_VOUT_I150MA");
	CParam* LDO1_LNR_150MA = StsGetParam(funcindex, "LDO1_LNR_150MA");
	CParam* LDO1_LDR_150MA = StsGetParam(funcindex, "LDO1_LDR_150MA");
	CParam* LDO1_VROP_I150mA = StsGetParam(funcindex, "LDO1_VROP_I150mA");
	CParam* LDO1_VROP_MODE_I150mA = StsGetParam(funcindex, "LDO1_VROP_MODE_I150mA");
	CParam* LNR_LDO1IN_MAX_VOUT_I400MA = StsGetParam(funcindex, "LNR_LDO1IN_MAX_VOUT_I400MA");
	CParam* LNR_LDO1IN_MIN_VOUT_I400MA = StsGetParam(funcindex, "LNR_LDO1IN_MIN_VOUT_I400MA");
	CParam* LDO1_LNR_400MA = StsGetParam(funcindex, "LDO1_LNR_400MA");
	CParam* LDO1_LDR_400MA = StsGetParam(funcindex, "LDO1_LDR_400MA");
	CParam* LDO1_VROP_I400mA = StsGetParam(funcindex, "LDO1_VROP_I400mA");
	CParam* LDO1_VROP_MODE_I400mA = StsGetParam(funcindex, "LDO1_VROP_MODE_I400mA");
	CParam* LDO1_OUT_DISCH_R = StsGetParam(funcindex, "LDO1_OUT_DISCH_R");
	CParam* LDO1_TSD_R = StsGetParam(funcindex, "LDO1_TSD_R");
	CParam* LDO1_TSD_F = StsGetParam(funcindex, "LDO1_TSD_F");
	CParam* LDO1_TSD_HYS = StsGetParam(funcindex, "LDO1_TSD_HYS");

	CParam* LNR_LDO2IN_MAX_VOUT_I0 = StsGetParam(funcindex, "LNR_LDO2IN_MAX_VOUT_I0");
	CParam* LNR_LDO2IN_MIN_VOUT_I0 = StsGetParam(funcindex, "LNR_LDO2IN_MIN_VOUT_I0");
	CParam* LDO2_VROP_I0 = StsGetParam(funcindex, "LDO2_VROP_I0");
	CParam* LDO2_VROP_MODE_I0 = StsGetParam(funcindex, "LDO2_VROP_MODE_I0");
	CParam* LNR_LDO2IN_MAX_VOUT_I150MA = StsGetParam(funcindex, "LNR_LDO2IN_MAX_VOUT_I150MA");
	CParam* LNR_LDO2IN_MIN_VOUT_I150MA = StsGetParam(funcindex, "LNR_LDO2IN_MIN_VOUT_I150MA");
	CParam* LDO2_LNR_150MA = StsGetParam(funcindex, "LDO2_LNR_150MA");
	CParam* LDO2_LDR_150MA = StsGetParam(funcindex, "LDO2_LDR_150MA");
	CParam* LDO2_VROP_I150mA = StsGetParam(funcindex, "LDO2_VROP_I150mA");
	CParam* LDO2_VROP_MODE_I150mA = StsGetParam(funcindex, "LDO2_VROP_MODE_I150mA");
	CParam* LNR_LDO2IN_MAX_VOUT_I400MA = StsGetParam(funcindex, "LNR_LDO2IN_MAX_VOUT_I400MA");
	CParam* LNR_LDO2IN_MIN_VOUT_I400MA = StsGetParam(funcindex, "LNR_LDO2IN_MIN_VOUT_I400MA");
	CParam* LDO2_LNR_400MA = StsGetParam(funcindex, "LDO2_LNR_400MA");
	CParam* LDO2_LDR_400MA = StsGetParam(funcindex, "LDO2_LDR_400MA");
	CParam* LDO2_VROP_I400mA = StsGetParam(funcindex, "LDO2_VROP_I400mA");
	CParam* LDO2_VROP_MODE_I400mA = StsGetParam(funcindex, "LDO2_VROP_MODE_I400mA");
	CParam* LDO2_OUT_DISCH_R = StsGetParam(funcindex, "LDO2_OUT_DISCH_R");
	CParam* LDO2_TSD_R = StsGetParam(funcindex, "LDO2_TSD_R");
	CParam* LDO2_TSD_F = StsGetParam(funcindex, "LDO2_TSD_F");
	CParam* LDO2_TSD_HYS = StsGetParam(funcindex, "LDO2_TSD_HYS");
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double results[SITE_NUM];
	
	double res1[SITE_NUM];
	double res2[SITE_NUM];
	double res3[SITE_NUM];
	double res4[SITE_NUM];
	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K81_LDO_CAPS, K114_FXVI5_11_A, K54_VDDIO_PU, K59_WAKE12_PU, K57_FS0B_PSYNC_PU,
		K50_VBOOST_FXVIB, K109_FXVI2_8_B, K53_LDO1IN_FXVIB, K105_FXVI0_6_B, K18_FIN_DCM, K52_LDO1_FXVIB, K107_FXVI1_7_B, K51_LDO2_FXVIB, K113_FXVI4_10_B,
		K56_INTB_PU, K32_INTB_FXVIA, K110_FXVI3_9_A,  -1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	delay_ms(1);
	VSUP_11.Set(FV, 12.0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	A3_INTB.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();

	SPIWrite(0x3F, 0x7481);//switch to main otp
	SPIWrite(0x04, 0x0033);//LDO1 1.8V LDO2 1.8V  150mA
	//bit30-27
	//0xxx x000 0000 0000=>0x31

	//check if need switch current limiation
	//No need force 3.3V, will check it
	B2_PREBOOT_VBOOST.TSet(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -10e-3, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	delay_ms(1);
	Enter_M_TM(0x0005, 0x2800, 0x0000);

	SPIWrite(0x04, 0x0033);//LDO1 1.8V LDO2 1.8V  150mA
	B0_PRESW_LDO1IN.TSet(FV, 6.5, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);

	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO1IN_MAX_VOUT_I0->SetTestResult(SITE, 0, res1[SITE]);
	}

	B0_PRESW_LDO1IN.TSet(FV, 2.3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(8);

	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		res2[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO1IN_MIN_VOUT_I0->SetTestResult(SITE, 0, res2[SITE]);
	}
//	awg.rampv(B0_PRESW_LDO1IN, B1_PREGHS_PREGLS_LDO1OUT, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "LDO1_VDROP1", 2.3, 1.8, 0.005, 20, 1.73, TRIG_RISING, results);
//	SERIAL
//	{
//		
//		LDO1_VROP_I0->SetTestResult(SITE, 0,  results[SITE]-1.73);//will check the result
//	}
	//B0_PRESW_LDO1IN.TSet(FV, 1.8, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//
	//B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	//SERIAL
	//{
	//	results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE,MVRET);
	//	LDO1_VROP_MODE_I0->SetTestResult(SITE, 0, 1.8-results[SITE]);
	//}
	B0_PRESW_LDO1IN.TSet(FV, 6.5, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -0.15, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);

	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		res3[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO1IN_MAX_VOUT_I150MA->SetTestResult(SITE, 0, res3[SITE]);
	}

	B0_PRESW_LDO1IN.TSet(FV, 2.3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);


	delay_ms(2);

	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		res4[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO1IN_MIN_VOUT_I150MA->SetTestResult(SITE, 0, res4[SITE]);
		LDO1_LNR_150MA->SetTestResult(SITE, 0, (res4[SITE]- res3[SITE])/1.8*100);
		LDO1_LDR_150MA->SetTestResult(SITE, 0, (res4[SITE] - res2[SITE]) / 1.8 * 100);
	}
		//will ttr, combine to one 
	awg.rampv(B0_PRESW_LDO1IN, B1_PREGHS_PREGLS_LDO1OUT, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "LDO1_VDROP2", 2.3, 1.7, 0.005, 20, 1.742, TRIG_FALLING, results);
	SERIAL
	{

		LDO1_VROP_I150mA->SetTestResult(SITE, 0,  results[SITE] - 1.742);//will check the result
	}

	awg.rampv(B0_PRESW_LDO1IN, B1_PREGHS_PREGLS_LDO1OUT, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "LDO1_VDROP2_mode", 2.3, 1.65, 0.005, 20, 1.65, TRIG_FALLING, results);

	
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE,MVRET);
		LDO1_VROP_MODE_I150mA->SetTestResult(SITE, 0, results[SITE] - 1.65);
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	SPIWrite(0x04, 0x00BB);//LDO1 1.8V LDO2 1.8V 400mA

	delay_ms(1);
	B0_PRESW_LDO1IN.TSet(FV, 6.5, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -0.4, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);

	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		res3[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO1IN_MAX_VOUT_I400MA->SetTestResult(SITE, 0, res3[SITE]);
	}

	B0_PRESW_LDO1IN.TSet(FV, 2.8, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	

	delay_ms(1);

	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		res4[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO1IN_MIN_VOUT_I400MA->SetTestResult(SITE, 0, res4[SITE]);
		LDO1_LNR_400MA->SetTestResult(SITE, 0, (res4[SITE] - res3[SITE]) / 1.8 * 100);
		LDO1_LDR_400MA->SetTestResult(SITE, 0, (res4[SITE] - res2[SITE]) / 1.8 * 100);
	}
	awg.rampv(B0_PRESW_LDO1IN, B1_PREGHS_PREGLS_LDO1OUT, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "LDO1_VDROP3", 2.7, 1.7, 0.005, 20, 1.742, TRIG_FALLING, results);
	SERIAL
	{

		LDO1_VROP_I400mA->SetTestResult(SITE, 0,  results[SITE] - 1.742);//will check the result
	}
	awg.rampv(B0_PRESW_LDO1IN, B1_PREGHS_PREGLS_LDO1OUT, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "LDO1_VDROP3_MODE", 2.7, 1.65, 0.005, 20, 1.65, TRIG_FALLING, results);
	SERIAL
	{

		LDO1_VROP_MODE_I400mA->SetTestResult(SITE, 0,  results[SITE] - 1.65);//will check the result
	}

	B0_PRESW_LDO1IN.TSet(FV, 3.6, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	//-----Discharge R------
	Enter_M_TM(0x0005, 0x0000, 0x0000);

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE,MIRET);
		LDO1_OUT_DISCH_R->SetTestResult(SITE, 0, 1.0/(results[SITE]+1e-30));
	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);

		//-----LDO1 TSD------
		//0xxx x000 0000 0000=>0x31
	Enter_M_TM(0x0005, 0x6800, 0x0000);
	dcm.Connect("FIN_WAKE2");
	dcm.SetPPMU("FIN_WAKE2_D", DCM_PPMU_FIMV, 3e-6, DCM_PPMUIRANGE_20UA);

	ith_binary_search("FIN_WAKE2", A3_INTB, 3e-6, -19e-6, 0, 8, res1, 1500, 1, TRIG_RISING);
	
	ith_binary_search("FIN_WAKE2", A3_INTB,-19e-6, 3e-6, 0, 8, res2, 1500, 1,TRIG_RISING);

		//will check if need to change 25C to other temperature for high/low temperature test
	SERIAL
	{
		LDO1_TSD_R->SetTestResult(SITE, 0, g_temp[SITE] - res1[SITE] / 1.0e-6 * 21);//
		LDO1_TSD_F->SetTestResult(SITE, 0, g_temp[SITE] - res2[SITE] / 1.0e-6 * 21);
		LDO1_TSD_HYS->SetTestResult(SITE, 0, -(res1[SITE] - res2[SITE]) / 1.0e-6 * 20);
	}
	//--------------LDO2 LNR LDR---------
	B2_PREBOOT_VBOOST.TSet(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, -10e-3, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	delay_ms(1);
	Enter_M_TM(0x0005, 0x4800, 0x0000);
	SPIWrite(0x04, 0x0033);//LDO1 1.8V LDO2 1.8V  150mA
	B4_VSUP_LDO2OUT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.TSet(FV, 6.5, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);

	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		res1[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO2IN_MAX_VOUT_I0->SetTestResult(SITE, 0, res1[SITE]);
	}

	B2_PREBOOT_VBOOST.TSet(FV, 2.3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);


	delay_ms(8);

	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		res2[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO2IN_MIN_VOUT_I0->SetTestResult(SITE, 0, res2[SITE]);
	}
//	awg.rampv(B2_PREBOOT_VBOOST, B4_VSUP_LDO2OUT, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "LDO2_VDROP1", 2.3, 1.8, 0.005, 20, 1.73, TRIG_RISING, results);
//	SERIAL
//	{
//
//		LDO2_VROP_I0->SetTestResult(SITE, 0,  results[SITE] - 1.73);//will check the result
//	}
	//B2_PREBOOT_VBOOST.TSet(FV, 1.8, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);

	//B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	//SERIAL
	//{
	//	results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE,MVRET);
	//	LDO2_VROP_MODE_I0->SetTestResult(SITE, 0, 1.8 - results[SITE]);
	//}
	B2_PREBOOT_VBOOST.TSet(FV, 6.5, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, -0.15, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);

	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		res3[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO2IN_MAX_VOUT_I150MA->SetTestResult(SITE, 0, res3[SITE]);
	}

	B2_PREBOOT_VBOOST.TSet(FV, 2.3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);


	delay_ms(2);

	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		res4[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO2IN_MIN_VOUT_I150MA->SetTestResult(SITE, 0, res4[SITE]);
		LDO2_LNR_150MA->SetTestResult(SITE, 0, (res4[SITE] - res3[SITE]) / 1.8 * 100);
		LDO2_LDR_150MA->SetTestResult(SITE, 0, (res4[SITE] - res2[SITE]) / 1.8 * 100);
	}

	awg.rampv(B2_PREBOOT_VBOOST, B4_VSUP_LDO2OUT, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "LDO2_VDROP2", 2.1, 1.7, 0.005, 20, 1.73, TRIG_FALLING, results);
	SERIAL
	{

		LDO2_VROP_I150mA->SetTestResult(SITE, 0,  results[SITE] - 1.73);//will check the result
	}
	awg.rampv(B2_PREBOOT_VBOOST, B4_VSUP_LDO2OUT, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "LDO2_VDROP2_MODE", 2.1, 1.7, 0.005, 20, 1.65, TRIG_FALLING, results);
	SERIAL
	{

		LDO2_VROP_MODE_I150mA->SetTestResult(SITE, 0,  results[SITE] - 1.65);//will check the result
	}
	//B2_PREBOOT_VBOOST.TSet(FV, 1.8, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//delay_ms(2);

	//B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	//SERIAL
	//{
	//	results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE,MVRET);
	//	LDO2_VROP_MODE_I150mA->SetTestResult(SITE, 0, 1.8 - results[SITE]);
	//}
	B4_VSUP_LDO2OUT.Set(FI, -0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);

	SPIWrite(0x04, 0x00BB);//LDO1 1.8V LDO2 1.8V 400mA


	B2_PREBOOT_VBOOST.TSet(FV, 6.5, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, -0.4, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);

	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		res3[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO2IN_MAX_VOUT_I400MA->SetTestResult(SITE, 0, res3[SITE]);
	}

	B2_PREBOOT_VBOOST.TSet(FV, 2.8, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);


	delay_ms(2);

	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		res4[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE,MVRET);
		LNR_LDO2IN_MIN_VOUT_I400MA->SetTestResult(SITE, 0, res4[SITE]);
		LDO2_LNR_400MA->SetTestResult(SITE, 0, (res4[SITE] - res3[SITE]) / 1.8 * 100);
		LDO2_LDR_400MA->SetTestResult(SITE, 0, (res4[SITE] - res2[SITE]) / 1.8 * 100);
	}
	awg.rampv(B2_PREBOOT_VBOOST, B4_VSUP_LDO2OUT, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "LDO2_VDROP3", 2.5, 1.7, 0.005, 20, 1.73, TRIG_FALLING, results);
	SERIAL
	{

		LDO2_VROP_I400mA->SetTestResult(SITE, 0,  results[SITE] - 1.73);//will check the result
	}
	awg.rampv(B2_PREBOOT_VBOOST, B4_VSUP_LDO2OUT, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "LDO2_VDROP3_MODE", 2.5, 1.7, 0.005, 20, 1.65, TRIG_FALLING, results);
	SERIAL
	{

		LDO2_VROP_MODE_I400mA->SetTestResult(SITE, 0,  results[SITE] - 1.65);//will check the result
	}
	//B2_PREBOOT_VBOOST.TSet(FV, 1.8, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//delay_ms(2);
	//B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	//SERIAL
	//{
	//	results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE,MVRET);
	//	LDO2_VROP_MODE_I400mA->SetTestResult(SITE, 0, 1.8 - results[SITE]);
	//}
	//B4_VSUP_LDO2OUT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);


	B2_PREBOOT_VBOOST.TSet(FV, 3.6, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	//-----Discharge R------
	Enter_M_TM(0x0005, 0x0000, 0x0000);

	B4_VSUP_LDO2OUT.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{
		results[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE,MIRET);
		LDO2_OUT_DISCH_R->SetTestResult(SITE, 0, 1.0 / (results[SITE] + 1e-30));
	}
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);

	//-----LDO2 TSD------
	//0xxx x000 0000 0000=>0x31
	Enter_M_TM(0x0005, 0x7800, 0x0000);
	dcm.Connect("FIN_WAKE2");
	dcm.SetPPMU("FIN_WAKE2_D", DCM_PPMU_FIMV, 3e-6, DCM_PPMUIRANGE_20UA);

	ith_binary_search("FIN_WAKE2", A3_INTB, 3e-6, -19e-6, 0, 8, res1, 1500, 1, TRIG_RISING);

	ith_binary_search("FIN_WAKE2", A3_INTB, -19e-6, 3e-6, 0, 8, res2, 1500,1, TRIG_RISING);

	//will check if need to change 25C to other temperature for high/low temperature test
	SERIAL
	{
		LDO2_TSD_R->SetTestResult(SITE, 0, g_temp[SITE] - res1[SITE] / 1.0e-6 * 21);//
		LDO2_TSD_F->SetTestResult(SITE, 0, g_temp[SITE] - res2[SITE] / 1.0e-6 * 21);
		LDO2_TSD_HYS->SetTestResult(SITE, 0, -(res1[SITE] - res2[SITE]) / 1.0e-6 * 20);
	}

	dcm.Disconnect("FIN_WAKE2");
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.
	delay_ms(5);//for cap discharge
	B2_PREBOOT_VBOOST.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	B0_PRESW_LDO1IN.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	B4_VSUP_LDO2OUT.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);

	A5_AMUX.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1UA, FXVIe_PLUS_RELAY_OFF);
	VSUP_11.Set(FV, 0, ACM200_40V, ACM200_100MA, ACM200_RELAY_OFF);
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);//wake12 connect to vddio.

	STSTArming();
	efmea.fmea_checking(funcindex);
	return 0;
}


DUT_API int T48_BANK_CHECK(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	
	CParam *eFUSE_MBANK0_READ2 = StsGetParam(funcindex, "eFUSE_MBANK0_READ2");
	CParam *eFUSE_MBANK1_READ2 = StsGetParam(funcindex, "eFUSE_MBANK1_READ2");
	CParam *eFUSE_MBANK2_READ2 = StsGetParam(funcindex, "eFUSE_MBANK2_READ2");
	CParam *eFUSE_MBANK3_READ2 = StsGetParam(funcindex, "eFUSE_MBANK3_READ2");
	CParam *eFUSE_MBANK4_READ2 = StsGetParam(funcindex, "eFUSE_MBANK4_READ2");
	CParam *eFUSE_MBANK5_READ2 = StsGetParam(funcindex, "eFUSE_MBANK5_READ2");
	CParam *eFUSE_MBANK6_READ2 = StsGetParam(funcindex, "eFUSE_MBANK6_READ2");
	CParam *eFUSE_MBANK7_READ2 = StsGetParam(funcindex, "eFUSE_MBANK7_READ2");
	CParam *eFUSE_MBANK8_READ2 = StsGetParam(funcindex, "eFUSE_MBANK8_READ2");
	CParam *eFUSE_MBANK9_READ2 = StsGetParam(funcindex, "eFUSE_MBANK9_READ2");
	CParam *eFUSE_MBANK10_READ2 = StsGetParam(funcindex, "eFUSE_MBANK10_READ2");
	CParam *eFUSE_MBANK11_READ2 = StsGetParam(funcindex, "eFUSE_MBANK11_READ2");
	CParam *eFUSE_MBANK12_READ2 = StsGetParam(funcindex, "eFUSE_MBANK12_READ2");
	CParam *eFUSE_MBANK13_READ2 = StsGetParam(funcindex, "eFUSE_MBANK13_READ2");
	CParam *eFUSE_MBANK14_READ2 = StsGetParam(funcindex, "eFUSE_MBANK14_READ2");
	CParam *eFUSE_MBANK15_READ2 = StsGetParam(funcindex, "eFUSE_MBANK15_READ2");
	CParam *eFUSE_FSBANK0_READ2 = StsGetParam(funcindex, "eFUSE_FSBANK0_READ2");
	CParam *PGM_READ_COMP1 = StsGetParam(funcindex, "PGM_READ_COMP1");
	CParam* M_UOTP_BURN_F2 = StsGetParam(funcindex, "M_UOTP_BURN_F2");
	CParam* FS_UOTP_BURN_F2 = StsGetParam(funcindex, "FS_UOTP_BURN_F2");

	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	string EE_str;
	int program_vs_read[SITE_NUM];
	
	ULONG m_otp_data[10][SITE_NUM];
	ULONG fs_otp_data[5][SITE_NUM];
	ULONG uotpcode;
	ULONG m_trim_data[16][SITE_NUM];
	ULONG fs_trim_data[SITE_NUM];
	int trim_data[10][SITE_NUM];
	ULONG wrdata[SITE_NUM] = { 0 };
	ULONG wrdata1[SITE_NUM] = { 0 };
	ULONG motp_burn_data[SITE_NUM];
	ULONG fsotp_burn_data[SITE_NUM];
	map<unsigned int, map<string, unsigned int>> node_map;	// map<site, map<node_name, value>>
	CParam *EE_Reads[BANK_NUM] = { eFUSE_MBANK0_READ2, eFUSE_MBANK1_READ2, eFUSE_MBANK2_READ2, eFUSE_MBANK3_READ2, eFUSE_MBANK4_READ2, eFUSE_MBANK5_READ2, eFUSE_MBANK6_READ2, eFUSE_MBANK7_READ2, eFUSE_MBANK8_READ2, eFUSE_MBANK9_READ2,
		eFUSE_MBANK10_READ2, eFUSE_MBANK11_READ2, eFUSE_MBANK12_READ2, eFUSE_MBANK13_READ2, eFUSE_MBANK14_READ2, eFUSE_MBANK15_READ2, eFUSE_FSBANK0_READ2 };
	string m_param_str_array1[] = { "M_OTP_00_F2", "M_OTP_01_F2", "M_OTP_02_F2", "M_OTP_03_F2", "M_OTP_04_F2", "M_OTP_05_F2", "M_OTP_06_F2", "M_OTP_07_F2", "M_OTP_08_F2", "M_OTP_09_F2" };
	string fs_param_str_array1[] = { "FS_OTP_00_F2", "FS_OTP_01_F2", "FS_OTP_02_F2", "FS_OTP_03_F2", "FS_OTP_04_F2" };

	cbite.SetOn(K24_VDDIO_ACM, K82_BUCK_CAPS, K54_VDDIO_PU, K59_WAKE12_PU, -1);//will check if need the caps.
	delay_ms(1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);

	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	delay_ms(15);//will check delay time
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();

	SPIWrite(0x3F, 0x7481);//switch to main otp table
	SPIRead(0x00, m_otp_data, 10);// ead user otp1
	SPIRead(0x20, m_trim_data, 16);//read trim data
	SPIRead(0x1F, motp_burn_data);
	SPIWrite(0x7F, 0x7481);//switch to fs otp table
	SPIRead(0x40, fs_otp_data, 5);//read fs user otp
	SPIRead(0x50, fs_trim_data);//read trim data
	SPIRead(0x4F, fsotp_burn_data);
	SERIAL
	{
		program_vs_read[SITE] = 0;
	
	}
	SERIAL
	{

		// main
		for (int addr = 0; addr < BANK_NUM - 1; ++addr)
		{

			EE_str = "MBANK" + to_string(addr);
			dut.assy(EE_str.c_str()).set_read_back((m_trim_data[addr][SITE]), SITE);
			program_vs_read[SITE] += dut.assy(EE_str.c_str()).comp_prog_to_read(SITE);

			EE_Reads[addr]->SetTestResult(SITE, 0, m_trim_data[addr][SITE]);

		}

		//fs
		EE_str = "FSBANK0";
		dut.assy(EE_str.c_str()).set_read_back((fs_trim_data[SITE]), SITE);
		program_vs_read[SITE] += dut.assy(EE_str.c_str()).comp_prog_to_read(SITE);
		EE_Reads[BANK_NUM - 1]->SetTestResult(SITE, 0, fs_trim_data[SITE]);


	
	}


	SERIAL{
		if (SC6295X[find_ID].useropt_burn == 0)
		{


			for (int addr = 0; addr < 10; ++addr)
				program_vs_read[SITE] += m_otp_data[addr][SITE];
				
			for (int addr = 0; addr < 5; ++addr)
				program_vs_read[SITE] += fs_otp_data[addr][SITE];
		


		}
		else
		{

			for (int addr = 0; addr < 10; ++addr)
			{
				EE_str = "MUBANK" + to_string(addr);
				uotpcode = dut.assy(EE_str.c_str()).get_start(SITE);
				program_vs_read[SITE] += (m_otp_data[addr][SITE] ^ uotpcode);
			}

			for (int addr = 0; addr < 5; ++addr)
			{
				EE_str = "FUBANK" + to_string(addr);
				uotpcode = dut.assy(EE_str.c_str()).get_start(SITE);
				program_vs_read[SITE] += (fs_otp_data[addr][SITE] ^ uotpcode);
			}


		}

		for (int addr = 0; addr < 10; ++addr)
			StsGetParam(funcindex, m_param_str_array1[addr].c_str())->SetTestResult(SITE, 0, m_otp_data[addr][SITE]);
		for (int addr = 0; addr < 5; ++addr)
			StsGetParam(funcindex, fs_param_str_array1[addr].c_str())->SetTestResult(SITE, 0, fs_otp_data[addr][SITE]);

		if (SC6295X[find_ID].useropt_burn == 0)
		{
			M_UOTP_BURN_F2->SetTestResult(SITE, 0, motp_burn_data[SITE]);
			FS_UOTP_BURN_F2->SetTestResult(SITE, 0, fsotp_burn_data[SITE]);
		}
		else
		{
			M_UOTP_BURN_F2->SetTestResult(SITE, 0, motp_burn_data[SITE]^7);
			FS_UOTP_BURN_F2->SetTestResult(SITE, 0, fsotp_burn_data[SITE]^7);
		}


	}
	SERIAL{
		PGM_READ_COMP1->SetTestResult(SITE, 0, program_vs_read[SITE]);
		
	}
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);//wake12 connect to vddio.

	VSUP_11.Set(FV, 0, ACM200_20V, ACM200_100MA, ACM200_RELAY_ON);

	delay_ms(5);
	power_off(1);
	efmea.fmea_checking(funcindex);
	return 0;

}

DUT_API int T50_POST_LEAK(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam *POST_LEAK_MISO_5V = StsGetParam(funcindex, "POST_LEAK_MISO_5V");
	CParam *POST_LEAK_SCLK_5V = StsGetParam(funcindex, "POST_LEAK_SCLK_5V");
	CParam *POST_LEAK_SCL_5V = StsGetParam(funcindex, "POST_LEAK_SCL_5V");
	CParam *POST_LEAK_FOUT_5V = StsGetParam(funcindex, "POST_LEAK_FOUT_5V");
	CParam *POST_LEAK_MOSI_5V = StsGetParam(funcindex, "POST_LEAK_MOSI_5V");
	CParam *POST_LEAK_CSB_5V = StsGetParam(funcindex, "POST_LEAK_CSB_5V");
	CParam *POST_LEAK_SDA_5V = StsGetParam(funcindex, "POST_LEAK_SDA_5V");
	CParam *POST_LEAK_FIN_5V = StsGetParam(funcindex, "POST_LEAK_FIN_5V");
	CParam *POST_LEAK_VBOS_0V = StsGetParam(funcindex, "POST_LEAK_VBOS_0V");
	CParam *POST_LEAK_BUCK1SW_0V = StsGetParam(funcindex, "POST_LEAK_BUCK1SW_0V");
	CParam *POST_LEAK_BUCK2SW_0V = StsGetParam(funcindex, "POST_LEAK_BUCK2SW_0V");
	CParam *POST_LEAK_BUCK3SW_0V = StsGetParam(funcindex, "POST_LEAK_BUCK3SW_0V");
	CParam *POST_LEAK_VSUP_12V = StsGetParam(funcindex, "POST_LEAK_VSUP_12V");
	CParam *POST_LEAK_VDDIO_5V = StsGetParam(funcindex, "POST_LEAK_VDDIO_5V");
	CParam *POST_LEAK_BUCK1IN_5V = StsGetParam(funcindex, "POST_LEAK_BUCK1IN_5V");
	CParam *POST_LEAK_BUCK2IN_5V = StsGetParam(funcindex, "POST_LEAK_BUCK2IN_5V");
	CParam *POST_LEAK_BUCK3IN_5V = StsGetParam(funcindex, "POST_LEAK_BUCK3IN_5V");
	CParam *POST_LEAK_BUCK1FB_4V = StsGetParam(funcindex, "POST_LEAK_BUCK1FB_4V");
	CParam *POST_LEAK_BUCK2FB_4V = StsGetParam(funcindex, "POST_LEAK_BUCK2FB_4V");
	CParam *POST_LEAK_BUCK3FB_4V = StsGetParam(funcindex, "POST_LEAK_BUCK3FB_4V");
	CParam *POST_LEAK_FCCU2_0p5V = StsGetParam(funcindex, "POST_LEAK_FCCU2_0p5V");
	CParam *POST_LEAK_INTB_0p5V = StsGetParam(funcindex, "POST_LEAK_INTB_0p5V");
	CParam *POST_LEAK_FCCU1_5V = StsGetParam(funcindex, "POST_LEAK_FCCU1_5V");
	CParam *POST_LEAK_PGOOD_0p5V = StsGetParam(funcindex, "POST_LEAK_PGOOD_0p5V");
	CParam *POST_LEAK_PSYNC_5V = StsGetParam(funcindex, "POST_LEAK_PSYNC_5V");
	CParam *POST_LEAK_AMUX_0p5V = StsGetParam(funcindex, "POST_LEAK_AMUX_0p5V");
	CParam *POST_LEAK_BUCK1SW_5V = StsGetParam(funcindex, "POST_LEAK_BUCK1SW_5V");
	CParam *POST_LEAK_BUCK2SW_5V = StsGetParam(funcindex, "POST_LEAK_BUCK2SW_5V");
	CParam *POST_LEAK_BUCK3SW_5V = StsGetParam(funcindex, "POST_LEAK_BUCK3SW_5V");
	CParam *POST_LEAK_VBOS2_0V = StsGetParam(funcindex, "POST_LEAK_VBOS2_0V");
	CParam *POST_LEAK_RSTB_5V = StsGetParam(funcindex, "POST_LEAK_RSTB_5V");
	CParam *POST_LEAK_ERR_5V = StsGetParam(funcindex, "POST_LEAK_ERR_5V");
	CParam* POST_LEAK_DBG_5V = StsGetParam(funcindex, "POST_LEAK_DBG_5V");
	CParam *POST_LEAK_WAKE1_0p5V = StsGetParam(funcindex, "POST_LEAK_WAKE1_0p5V");
	CParam *POST_LEAK_WAKE2_0p5V = StsGetParam(funcindex, "POST_LEAK_WAKE2_0p5V");
	CParam *POST_LEAK_VSUP2_12V = StsGetParam(funcindex, "POST_LEAK_VSUP2_12V");
	CParam *POST_LEAK_VBOS4_0V = StsGetParam(funcindex, "POST_LEAK_VBOS4_0V");
	CParam *POST_LEAK_BOOSTLS_6V = StsGetParam(funcindex, "POST_LEAK_BOOSTLS_6V");
	CParam *POST_LEAK_VBOOST_5V = StsGetParam(funcindex, "POST_LEAK_VBOOST_5V");
	CParam *POST_LEAK_PREFB_4V = StsGetParam(funcindex, "POST_LEAK_PREFB_4V");
	CParam *POST_LEAK_PRECSP_4V = StsGetParam(funcindex, "POST_LEAK_PRECSP_4V");
	CParam *POST_LEAK_PRECMP_0p3V = StsGetParam(funcindex, "POST_LEAK_PRECMP_0p3V");
	CParam *POST_LEAK_PRESW_5V = StsGetParam(funcindex, "POST_LEAK_PRESW_5V");
	CParam *POST_LEAK_PREBOOT_10V = StsGetParam(funcindex, "POST_LEAK_PREBOOT_10V");
	CParam *POST_LEAK_LDO2OUT_0V = StsGetParam(funcindex, "POST_LEAK_LDO2OUT_0V");
	CParam *POST_LEAK_VMON1_5V = StsGetParam(funcindex, "POST_LEAK_VMON1_5V");
	CParam *POST_LEAK_PREBOOT2_10V = StsGetParam(funcindex, "POST_LEAK_PREBOOT2_10V");
	CParam *POST_LEAK_VMON2_5V = StsGetParam(funcindex, "POST_LEAK_VMON2_5V");
	CParam *POST_LEAK_LDO2OUT_5V = StsGetParam(funcindex, "POST_LEAK_LDO2OUT_5V");
	CParam *POST_LEAK_VMON3_5V = StsGetParam(funcindex, "POST_LEAK_VMON3_5V");
	CParam *POST_LEAK_VMON4_5V = StsGetParam(funcindex, "POST_LEAK_VMON4_5V");
	CParam *POST_LEAK_FS0B_5V = StsGetParam(funcindex, "POST_LEAK_FS0B_5V");
	CParam *POST_LEAK_LDO1OUT_0V = StsGetParam(funcindex, "POST_LEAK_LDO1OUT_0V");
	CParam *POST_LEAK_LDO1IN_5V = StsGetParam(funcindex, "POST_LEAK_LDO1IN_5V");
	CParam *POST_LEAK_LDO1OUT_5V = StsGetParam(funcindex, "POST_LEAK_LDO1OUT_5V");
	CParam *IQPOST_LEAK_WAKE1_5V = StsGetParam(funcindex, "IQPOST_LEAK_WAKE1_5V");
	CParam *IQPOST_LEAK_WAKE2_5V = StsGetParam(funcindex, "IQPOST_LEAK_WAKE2_5V");
	CParam *IQPOST_LEAK_VBOS_0V = StsGetParam(funcindex, "IQPOST_LEAK_VBOS_0V");
	CParam *IQPOST_LEAK_BUCK1SW_0V = StsGetParam(funcindex, "IQPOST_LEAK_BUCK1SW_0V");
	CParam *IQPOST_LEAK_BUCK2SW_0V = StsGetParam(funcindex, "IQPOST_LEAK_BUCK2SW_0V");
	CParam *IQPOST_LEAK_BUCK3SW_0V = StsGetParam(funcindex, "IQPOST_LEAK_BUCK3SW_0V");
	CParam *IQPOST_LEAK_VSUP_12V = StsGetParam(funcindex, "IQPOST_LEAK_VSUP_12V");
	CParam *IQPOST_LEAK_VDDIO_5V = StsGetParam(funcindex, "IQPOST_LEAK_VDDIO_5V");
	CParam *IQPOST_LEAK_BUCK1IN_3p3V = StsGetParam(funcindex, "IQPOST_LEAK_BUCK1IN_3p3V");
	CParam *IQPOST_LEAK_BUCK2IN_3p3V = StsGetParam(funcindex, "IQPOST_LEAK_BUCK2IN_3p3V");
	CParam *IQPOST_LEAK_BUCK3IN_3p3V = StsGetParam(funcindex, "IQPOST_LEAK_BUCK3IN_3p3V");
	CParam *IQPOST_LEAK_BUCK1FB_1p8V = StsGetParam(funcindex, "IQPOST_LEAK_BUCK1FB_1p8V");
	CParam *IQPOST_LEAK_BUCK2FB_1p8V = StsGetParam(funcindex, "IQPOST_LEAK_BUCK2FB_1p8V");
	CParam *IQPOST_LEAK_BUCK3FB_1p8V = StsGetParam(funcindex, "IQPOST_LEAK_BUCK3FB_1p8V");
	CParam *IQPOST_LEAK_BUCK3FB_3p6V = StsGetParam(funcindex, "IQPOST_LEAK_BUCK3FB_3p6V");
	CParam *IQPOST_LEAK_LDO1IN_3p3V = StsGetParam(funcindex, "IQPOST_LEAK_LDO1IN_3p3V");
	CParam *IQPOST_LEAK_LDO1OUT_0p2V = StsGetParam(funcindex, "IQPOST_LEAK_LDO1OUT_0p2V");
	CParam *IQPOST_LEAK_VBOOST_3p3V = StsGetParam(funcindex, "IQPOST_LEAK_VBOOST_3p3V");
	CParam *IQPOST_LEAK_LDO2OUT_0p2V = StsGetParam(funcindex, "IQPOST_LEAK_LDO2OUT_0p2V");
	//}}AFX_STS_PARAM_PROTOTYPES

	double pinleakage[SITE_NUM];

	cbite.SetOn(K60_WAKE12_PD,K8_SCL_SDA_DCM, K18_FIN_DCM, K26_FOUT_DCM, K24_VDDIO_ACM, K4_BUCK3SW_ACM, K33_BUCK12SW_ACM, K7_BUCK3FB_ACM, K29_BUCK2FB_ACM,
		K36_BUCK1FB_ACM, K28_FCCU12_FXVIA, K15_PGOOD_FXVIA, K32_INTB_FXVIA, K35_PSYNC_FXVIA, K27_220_SHRT,
		K104_FXVI0_6_A, K106_FXVI1_7_A, K108_FXVI2_8_A, K110_FXVI3_9_A, K112_FXVI4_10_A, K114_FXVI5_11_A, -1);//vbos,buck1,2,3 in
	delay_ms(1);
	//wake12=0
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(5);
	VBOS_1.Set(FV,5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);//make floating node in stable status,will check the status if stable at full temp

	VDDIO_VBOOST_0.TSet(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	BUCK1IN_2.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2IN_3.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3IN_4.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 4.15, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 4.15, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 4.15, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK1SW_5.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2SW_6.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);

	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	A2_PGOOD.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A4_PSYNC_PREFB.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A5_AMUX.TSet(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	dcm.Connect("DCM_ALLPINS");
	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_2UA);
	dcm.SetPPMU("SCLK", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_200UA);
	VBOS_1.Set(FV,0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	VBOS_1.Set(FV,0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(25);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		POST_LEAK_MISO_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCLK_D", SITE);
		POST_LEAK_SCLK_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);//uA

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		POST_LEAK_SCL_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		POST_LEAK_FOUT_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		POST_LEAK_MOSI_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		POST_LEAK_CSB_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		POST_LEAK_SDA_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		POST_LEAK_FIN_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		POST_LEAK_VBOS_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK1SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK2SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK3SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		POST_LEAK_VSUP_12V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);



		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK1FB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK2FB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK3FB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		POST_LEAK_FCCU2_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


		pinleakage[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		POST_LEAK_FCCU1_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = A2_PGOOD.GetMeasResult(SITE, MIRET);
		POST_LEAK_PGOOD_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);

		pinleakage[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MIRET);
		POST_LEAK_PSYNC_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = A5_AMUX.GetMeasResult(SITE, MIRET);
		POST_LEAK_AMUX_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


	}

	VBOS_1.Set(FV,5.0 , ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		POST_LEAK_VDDIO_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

	
		pinleakage[SITE] = BUCK1IN_2.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK1IN_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2IN_3.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK2IN_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3IN_4.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK3IN_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


		pinleakage[SITE] = A3_INTB.GetMeasResult(SITE, MIRET);
		POST_LEAK_INTB_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);
	}
	VBOS_1.Set(FV,0 , ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	delay_ms(1);
	cbite.SetCbiteOff(K28_FCCU12_FXVIA);

	delay_ms(1);
	cbite.SetCbiteOn(K37_ERRMON_FXVIA);
	cbite.SetCbiteOn(K16_RSTB_FXVIA);
	delay_ms(1);
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	BUCK1SW_5.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2SW_6.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON); 
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	STSTArming();
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	SERIAL
	{
		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK1SW_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK2SW_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		POST_LEAK_BUCK3SW_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		POST_LEAK_VBOS2_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		POST_LEAK_RSTB_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);

		pinleakage[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		POST_LEAK_ERR_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

	}
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	



	
	BUCK1SW_5.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	BUCK2SW_6.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON, 0.5);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON, 0.5);
	VDDIO_VBOOST_0.TSet(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	STSTArming();
	delay_ms(1);
	BUCK1IN_2.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2IN_3.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3IN_4.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	A0_FIN_DBG_ERR_FCCU1.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	
	A2_PGOOD.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A3_INTB.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	A4_PSYNC_PREFB.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	A5_AMUX.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	dcm.SetPPMU("SCLK", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_200UA);
	delay_ms(1);
	cbite.SetOn(K1_WAKE2_DCM, K48_WAKE1_DCM,K5_DBG_DCM, K40_VBOOST_ACM, K3_BOOSTLS_ACM, K38_PRECOMP_ACM, K39_PRECSP_ACM,
		K46_PREFB_ACM, K42_PRESW_FXVIB, K43_PREGHS_FXVIB, K44_PREBOOT_FXVIB, K51_LDO2_FXVIB, K13_VMON1_FXVIB,
		 K105_FXVI0_6_B, K107_FXVI1_7_B, K109_FXVI2_8_B, K111_FXVI3_9_B, K113_FXVI4_10_B, K115_FXVI5_11_B, -1);//vbos,buck1,2,3 in
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(1);
	VBOS_1.TSet(FV,5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);//make floating node in stable status,will check the status if stable at full temp

	VDDIO_VBOOST_0.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 4.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 4.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0.3, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 6.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	//VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	B2_PREBOOT_VBOOST.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
	//will add dbg
	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 0.5, DCM_PPMUIRANGE_2UA);
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_20UA);
	B2_PREBOOT_VBOOST.Set(FV, 10, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON, 0.5);
	delay_ms(2);
	VBOS_1.Set(FV,0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(15);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);

	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{




		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		POST_LEAK_VSUP2_12V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		POST_LEAK_VBOS4_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		POST_LEAK_BOOSTLS_6V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		POST_LEAK_PREFB_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		POST_LEAK_PRECSP_4V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		POST_LEAK_PRECMP_0p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		POST_LEAK_PRESW_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


		pinleakage[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);
		POST_LEAK_PREBOOT_10V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		POST_LEAK_LDO2OUT_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		POST_LEAK_VMON1_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


	}
	VBOS_1.TSet(FV,5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(5);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);

	dcm.PPMUMeasure("DCM_ALLPINS", 30, 10);
	SERIAL
	{
		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		POST_LEAK_DBG_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		POST_LEAK_WAKE1_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		POST_LEAK_WAKE2_0p5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		POST_LEAK_VBOOST_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

	}
	VBOS_1.TSet(FV,0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	cbite.SetCbiteOn(K12_VMON2_FXVIB);
	cbite.SetCbiteOff(K13_VMON1_FXVIB);
	delay_ms(5);
	
	ALL_FXVIE.MeasureVI(30, 10);

	SERIAL
	{

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		POST_LEAK_VMON2_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		POST_LEAK_LDO2OUT_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

	}

	B2_PREBOOT_VBOOST.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON,0.5);
	B0_PRESW_LDO1IN.TSet(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);

	cbite.SetCbiteOff(K12_VMON2_FXVIB);

	cbite.SetCbiteOn(K10_VMON3_FXVIB);

	delay_ms(3);


	B5_VMON1234.MeasureVI(30, 10);

	SERIAL
	{


		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		POST_LEAK_VMON3_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


	}
	
	cbite.SetCbiteOn(K9_VMON4_FXVIB);
	cbite.SetCbiteOff(K10_VMON3_FXVIB);
	delay_ms(3);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		POST_LEAK_VMON4_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);


	}
	
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON, 0.5);
	B4_VSUP_LDO2OUT.Set(FV,2, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON, 0.5);
	delay_ms(5);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		POST_LEAK_FS0B_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);


	}
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON, 0.5);

		//ldo1 in
	VBOS_1.TSet(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	
	B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B0_PRESW_LDO1IN.TSet(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	STSTArming();
	delay_ms(1);
	cbite.SetCbiteOff(K42_PRESW_FXVIB);
	cbite.SetCbiteOff(K41_PREGLS_FXVIB);
	delay_ms(1);
	cbite.SetCbiteOn(K52_LDO1_FXVIB);
	cbite.SetCbiteOn(K53_LDO1IN_FXVIB);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(5);
	ALL_FXVIE.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		POST_LEAK_LDO1OUT_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);
		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		POST_LEAK_LDO1IN_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON, 0.5);
	delay_ms(5);
	ALL_FXVIE.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		POST_LEAK_LDO1OUT_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);
	
	}
	

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON, 0.5);
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 0.0, DCM_PPMUIRANGE_200UA);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	
	B4_VSUP_LDO2OUT.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.TSet(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.TSet(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	VDDIO_VBOOST_0.TSet(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);

	STSTArming();

	for (int i = 0; i < 12; i++)
		acm_grp[i].TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	for (int i = 0; i < 6; i++)
		fxvie_grp[i].TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	STSTArming();

	dcm.Disconnect("DCM_ALLPINS");
	ULONG m_reg_data1[4][SITE_NUM];
	ULONG data0=0x0000;
	//Iq power on
	cbite.SetOn(K48_WAKE1_DCM, K1_WAKE2_DCM, /*K82_BUCK_CAPS, */K24_VDDIO_ACM, K4_BUCK3SW_ACM, K33_BUCK12SW_ACM, K7_BUCK3FB_ACM, K29_BUCK2FB_ACM,
		K36_BUCK1FB_ACM, K52_LDO1_FXVIB, K53_LDO1IN_FXVIB, K51_LDO2_FXVIB, K50_VBOOST_FXVIB,
		K105_FXVI0_6_B, K107_FXVI1_7_B, K109_FXVI2_8_B, K113_FXVI4_10_B, - 1);//vbos,buck1,2,3 in
	delay_ms(1);
	SPIInitial(4.0, 0, 2.0, 1.9, 200);
	//wake12=0
	dcm.Connect("WAKE12_G");
	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 5.0, DCM_PPMUIRANGE_200UA);

	VBOS_1.Set(FV, 5.50, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	VSUP_11.Set(FV, 12.0, ACM200_20V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	VDDIO_VBOOST_0.TSet(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	STSTArming();
	delay_ms(15);//will check delay time
	Enter_MAIN_TM_DIG();
	Enter_FS_TM_DIG();
	SPIWrite(0x3F, 0x7481);//switch to main otp table
	delay_us(100);
	//dut.trim("BUCK2_SLOP").copy_start_to_work();
	//dut.trim("BUCK2_LOOP_GM").copy_start_to_work();
	dut.trim("BUCK2_DP_IMINPK").set_working(0);//for buck2 test stable iq
	//dut.trim("BUCK2_DP_IMAXPK").copy_start_to_work();
	OTP_M_Preview(12, 1);
	if(SC6295X[find_ID].useropt_burn==1)
	{
		for (int addr = 0; addr < 10; ++addr)
		{

			SPIWrite(0x00+addr, data0);

		}
	}
	//SPIWrite(0x23, 0x5555);//read main register
	//SPIWrite(0x24, 0xAAAA);
	//SPIRead(0x23, m_reg_data1, 4);//read main register
	BUCK1IN_2.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2IN_3.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3IN_4.TSet(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 1.8, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 1.8, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	//if(SC6295X[find_ID].name == "HW_SC62595Q")
	//	PRECMP_BUCK3FB_INTB_10.TSet(FV, 3.6, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	//else
		PRECMP_BUCK3FB_INTB_10.TSet(FV, 1.8, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK1SW_5.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2SW_6.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);

	B0_PRESW_LDO1IN.TSet(FV, 3.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FV, 0.2, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	B2_PREBOOT_VBOOST.TSet(FV, 3.3, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FV, 0.2, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);

	STSTArming();


	delay_ms(5);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ALL_ACM.MeasureVI(381, 10);
	ALL_FXVIE.MeasureVI(30, 10);
	dcm.PPMUMeasure("WAKE12_G", 30, 10);
	SERIAL
	{


		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		IQPOST_LEAK_WAKE1_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		IQPOST_LEAK_WAKE2_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_VBOS_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);

		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_BUCK1SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_BUCK2SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_BUCK3SW_0V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_VSUP_12V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_VDDIO_5V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK1IN_2.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_BUCK1IN_3p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK2IN_3.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_BUCK2IN_3p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = BUCK3IN_4.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_BUCK3IN_3p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_BUCK1FB_1p8V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_BUCK2FB_1p8V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
	/*	if(SC6295X[find_ID].name == "HW_SC62595Q")
			IQPOST_LEAK_BUCK3FB_3p6V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);
		else*/
			IQPOST_LEAK_BUCK3FB_1p8V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_LDO1IN_3p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_LDO1OUT_0p2V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);

		pinleakage[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_VBOOST_3p3V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e6);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		IQPOST_LEAK_LDO2OUT_0p2V->SetTestResult(SITE, 0, pinleakage[SITE] * 1e3);
	
	

	}

	dcm.SetPPMU("WAKE12_G", DCM_PPMU_FVMI, 0.0, DCM_PPMUIRANGE_200UA);
	delay_ms(1);
	VSUP_11.Set(FV, 0.0, ACM200_20V, ACM200_10MA, ACM200_RELAY_ON);
	VBOS_1.TSet(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(5);

	BUCK1IN_2.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2IN_3.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3IN_4.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK1SW_5.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK2SW_6.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	B0_PRESW_LDO1IN.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	STSTArming();
		delay_ms(5);
		if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	for (int i = 0; i < 12; i++)
		acm_grp[i].TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	for (int i = 0; i < 6; i++)
		fxvie_grp[i].TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	STSTArming();
	dcm.Disconnect("DCM_ALLPINS");

	return 0;
}
DUT_API int T52_POST_P2P_LEAK(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	CParam *POS_POSTLEAK_MISO = StsGetParam(funcindex, "POS_POSTLEAK_MISO");
	CParam *POS_POSTLEAK_SCLK = StsGetParam(funcindex, "POS_POSTLEAK_SCLK");
	CParam *POS_POSTLEAK_SCL_DBG = StsGetParam(funcindex, "POS_POSTLEAK_SCL_DBG");
	CParam *POS_POSTLEAK_FOUT = StsGetParam(funcindex, "POS_POSTLEAK_FOUT");
	CParam *POS_POSTLEAK_VBOS = StsGetParam(funcindex, "POS_POSTLEAK_VBOS");
	CParam *POS_POSTLEAK_BUCK1SW = StsGetParam(funcindex, "POS_POSTLEAK_BUCK1SW");
	CParam *POS_POSTLEAK_BUCK2SW = StsGetParam(funcindex, "POS_POSTLEAK_BUCK2SW");
	CParam *POS_POSTLEAK_BUCK3SW = StsGetParam(funcindex, "POS_POSTLEAK_BUCK3SW");
	CParam *POS_POSTLEAK_VSUP = StsGetParam(funcindex, "POS_POSTLEAK_VSUP");
	CParam *POS_POSTLEAK_FCCU1_ERR = StsGetParam(funcindex, "POS_POSTLEAK_FCCU1_ERR");
	CParam *POS_POSTLEAK_PGOOD = StsGetParam(funcindex, "POS_POSTLEAK_PGOOD");
	CParam *POS_POSTLEAK_PSYNC = StsGetParam(funcindex, "POS_POSTLEAK_PSYNC");
	CParam *POS_POSTLEAK_AMUX = StsGetParam(funcindex, "POS_POSTLEAK_AMUX");

	CParam *NEG_POSTLEAK_MISO = StsGetParam(funcindex, "NEG_POSTLEAK_MISO");
	CParam *NEG_POSTLEAK_SCLK = StsGetParam(funcindex, "NEG_POSTLEAK_SCLK");
	CParam *NEG_POSTLEAK_SCL_DBG = StsGetParam(funcindex, "NEG_POSTLEAK_SCL_DBG");
	CParam *NEG_POSTLEAK_FOUT = StsGetParam(funcindex, "NEG_POSTLEAK_FOUT");
	CParam *NEG_POSTLEAK_VBOS = StsGetParam(funcindex, "NEG_POSTLEAK_VBOS");
	CParam *NEG_POSTLEAK_BUCK1SW = StsGetParam(funcindex, "NEG_POSTLEAK_BUCK1SW");
	CParam *NEG_POSTLEAK_BUCK2SW = StsGetParam(funcindex, "NEG_POSTLEAK_BUCK2SW");
	CParam *NEG_POSTLEAK_BUCK3SW = StsGetParam(funcindex, "NEG_POSTLEAK_BUCK3SW");
	CParam *NEG_POSTLEAK_VSUP = StsGetParam(funcindex, "NEG_POSTLEAK_VSUP");
	CParam *NEG_POSTLEAK_FCCU1_ERR = StsGetParam(funcindex, "NEG_POSTLEAK_FCCU1_ERR");
	CParam *NEG_POSTLEAK_PGOOD = StsGetParam(funcindex, "NEG_POSTLEAK_PGOOD");
	CParam *NEG_POSTLEAK_PSYNC = StsGetParam(funcindex, "NEG_POSTLEAK_PSYNC");
	CParam *NEG_POSTLEAK_AMUX = StsGetParam(funcindex, "NEG_POSTLEAK_AMUX");

	CParam *POS_POSTLEAK_MOSI = StsGetParam(funcindex, "POS_POSTLEAK_MOSI");
	CParam *POS_POSTLEAK_CSB = StsGetParam(funcindex, "POS_POSTLEAK_CSB");
	CParam *POS_POSTLEAK_SDA = StsGetParam(funcindex, "POS_POSTLEAK_SDA");
	CParam *POS_POSTLEAK_FIN = StsGetParam(funcindex, "POS_POSTLEAK_FIN");
	CParam *POS_POSTLEAK_VDDIO = StsGetParam(funcindex, "POS_POSTLEAK_VDDIO");
	CParam *POS_POSTLEAK_BUCK1IN = StsGetParam(funcindex, "POS_POSTLEAK_BUCK1IN");
	CParam *POS_POSTLEAK_BUCK2IN = StsGetParam(funcindex, "POS_POSTLEAK_BUCK2IN");
	CParam *POS_POSTLEAK_BUCK3IN = StsGetParam(funcindex, "POS_POSTLEAK_BUCK3IN");
	CParam *POS_POSTLEAK_BUCK1FB = StsGetParam(funcindex, "POS_POSTLEAK_BUCK1FB");
	CParam *POS_POSTLEAK_BUCK2FB = StsGetParam(funcindex, "POS_POSTLEAK_BUCK2FB");
	CParam *POS_POSTLEAK_BUCK3FB = StsGetParam(funcindex, "POS_POSTLEAK_BUCK3FB");
	CParam *POS_POSTLEAK_FCCU2_RSTB = StsGetParam(funcindex, "POS_POSTLEAK_FCCU2_RSTB");
	CParam *POS_POSTLEAK_INTB = StsGetParam(funcindex, "POS_POSTLEAK_INTB");

	CParam *NEG_POSTLEAK_MOSI = StsGetParam(funcindex, "NEG_POSTLEAK_MOSI");
	CParam *NEG_POSTLEAK_CSB = StsGetParam(funcindex, "NEG_POSTLEAK_CSB");
	CParam *NEG_POSTLEAK_SDA = StsGetParam(funcindex, "NEG_POSTLEAK_SDA");
	CParam *NEG_POSTLEAK_FIN = StsGetParam(funcindex, "NEG_POSTLEAK_FIN");
	CParam *NEG_POSTLEAK_VDDIO = StsGetParam(funcindex, "NEG_POSTLEAK_VDDIO");
	CParam *NEG_POSTLEAK_BUCK1IN = StsGetParam(funcindex, "NEG_POSTLEAK_BUCK1IN");
	CParam *NEG_POSTLEAK_BUCK2IN = StsGetParam(funcindex, "NEG_POSTLEAK_BUCK2IN");
	CParam *NEG_POSTLEAK_BUCK3IN = StsGetParam(funcindex, "NEG_POSTLEAK_BUCK3IN");
	CParam *NEG_POSTLEAK_BUCK1FB = StsGetParam(funcindex, "NEG_POSTLEAK_BUCK1FB");
	CParam *NEG_POSTLEAK_BUCK2FB = StsGetParam(funcindex, "NEG_POSTLEAK_BUCK2FB");
	CParam *NEG_POSTLEAK_BUCK3FB = StsGetParam(funcindex, "NEG_POSTLEAK_BUCK3FB");
	CParam *NEG_POSTLEAK_FCCU2_RSTB = StsGetParam(funcindex, "NEG_POSTLEAK_FCCU2_RSTB");
	CParam *NEG_POSTLEAK_INTB = StsGetParam(funcindex, "NEG_POSTLEAK_INTB");

	CParam *POS_POSTLEAK_VBOOST = StsGetParam(funcindex, "POS_POSTLEAK_VBOOST");
	CParam *POS_POSTLEAK_PREFB = StsGetParam(funcindex, "POS_POSTLEAK_PREFB");
	CParam *POS_POSTLEAK_PRECMP = StsGetParam(funcindex, "POS_POSTLEAK_PRECMP");
	CParam *POS_POSTLEAK_PREGHS_GHL = StsGetParam(funcindex, "POS_POSTLEAK_PREGHS_GHL");
	CParam *POS_POSTLEAK_WAKE12 = StsGetParam(funcindex, "POS_POSTLEAK_WAKE12");
	CParam *POS_POSTLEAK_VMON1234 = StsGetParam(funcindex, "POS_POSTLEAK_VMON1234");

	CParam *NEG_POSTLEAK_VBOOST = StsGetParam(funcindex, "NEG_POSTLEAK_VBOOST");
	CParam *NEG_POSTLEAK_PREFB = StsGetParam(funcindex, "NEG_POSTLEAK_PREFB");
	CParam *NEG_POSTLEAK_PRECMP = StsGetParam(funcindex, "NEG_POSTLEAK_PRECMP");
	CParam *NEG_POSTLEAK_PREGHS_GHL = StsGetParam(funcindex, "NEG_POSTLEAK_PREGHS_GHL");
	CParam *NEG_POSTLEAK_WAKE12 = StsGetParam(funcindex, "NEG_POSTLEAK_WAKE12");
	CParam *NEG_POSTLEAK_VMON1234 = StsGetParam(funcindex, "NEG_POSTLEAK_VMON1234");

	CParam *POS_POSTLEAK_VBOS2 = StsGetParam(funcindex, "POS_POSTLEAK_VBOS2");
	CParam *POS_POSTLEAK_BOOSTLS = StsGetParam(funcindex, "POS_POSTLEAK_BOOSTLS");
	CParam *POS_POSTLEAK_PRECSP = StsGetParam(funcindex, "POS_POSTLEAK_PRECSP");
	CParam *POS_POSTLEAK_PRESW = StsGetParam(funcindex, "POS_POSTLEAK_PRESW");
	CParam *POS_POSTLEAK_PREBOOT = StsGetParam(funcindex, "POS_POSTLEAK_PREBOOT");
	CParam *POS_POSTLEAK_LDO2OUT = StsGetParam(funcindex, "POS_POSTLEAK_LDO2OUT");

	CParam *NEG_POSTLEAK_VBOS2 = StsGetParam(funcindex, "NEG_POSTLEAK_VBOS2");
	CParam *NEG_POSTLEAK_BOOSTLS = StsGetParam(funcindex, "NEG_POSTLEAK_BOOSTLS");
	CParam *NEG_POSTLEAK_PRECSP = StsGetParam(funcindex, "NEG_POSTLEAK_PRECSP");
	CParam *NEG_POSTLEAK_PRESW = StsGetParam(funcindex, "NEG_POSTLEAK_PRESW");
	CParam *NEG_POSTLEAK_PREBOOT = StsGetParam(funcindex, "NEG_POSTLEAK_PREBOOT");
	CParam *NEG_POSTLEAK_LDO2OUT = StsGetParam(funcindex, "NEG_POSTLEAK_LDO2OUT");


	CParam *POS_POSTLEAK_LDO1IN = StsGetParam(funcindex, "POS_POSTLEAK_LDO1IN");
	CParam *POS_POSTLEAK_SSD = StsGetParam(funcindex, "POS_POSTLEAK_SSD");
	CParam *NEG_POSTLEAK_LDO1IN = StsGetParam(funcindex, "NEG_POSTLEAK_LDO1IN");
	CParam *NEG_POSTLEAK_SSD = StsGetParam(funcindex, "NEG_POSTLEAK_SSD");

	CParam *POS_POSTLEAK_LDO1OUT = StsGetParam(funcindex, "POS_POSTLEAK_LDO1OUT");
	CParam *POS_POSTLEAK_FS0B = StsGetParam(funcindex, "POS_POSTLEAK_FS0B");
	CParam *NEG_POSTLEAK_LDO1OUT = StsGetParam(funcindex, "NEG_POSTLEAK_LDO1OUT");
	CParam *NEG_POSTLEAK_FS0B = StsGetParam(funcindex, "NEG_POSTLEAK_FS0B");


	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	double pinleakage[SITE_NUM];

	double pos_v = 0.1;
	double neg_v = -0.1;

	if (test_stage == 1)
	{
		pos_v = 0.1;
		neg_v = -0.1;
	}
	else
	{
		pos_v = 0.15;
		neg_v = -0.15;

	}
	if (DO_CHAR)
	{

		pos_v = 0.05;
		neg_v = -0.05;
	}
	cbite.SetOn(K8_SCL_SDA_DCM, K5_DBG_DCM, K18_FIN_DCM, K26_FOUT_DCM, K24_VDDIO_ACM, K4_BUCK3SW_ACM, K33_BUCK12SW_ACM, K7_BUCK3FB_ACM, K29_BUCK2FB_ACM,
		K36_BUCK1FB_ACM, K28_FCCU12_FXVIA, K37_ERRMON_FXVIA, K16_RSTB_FXVIA, K15_PGOOD_FXVIA, K32_INTB_FXVIA, K35_PSYNC_FXVIA, K27_220_SHRT,
		K104_FXVI0_6_A, K106_FXVI1_7_A, K108_FXVI2_8_A, K110_FXVI3_9_A, K112_FXVI4_10_A, K114_FXVI5_11_A, -1);//vbos,buck1,2,3 in
	delay_ms(1);
	dcm.Connect("DCM_ALLPINS");

	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	ALL_FXVIE.Set(FV, -0.1, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	ALL_ACM.Set(FV, -0.1, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
//	delay_ms(3);
	//if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	dcm.SetPPMU("EVEN_G", DCM_PPMU_FVMI, pos_v, DCM_PPMUIRANGE_2UA);
	if (DO_CHAR || (test_stage==1 ))
		EVEN1_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	else
		EVEN1_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	EVEN1_FXVIE.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A5_AMUX.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);

	dcm.PPMUMeasure("EVEN_G", 30, 10);
	EVEN1_FXVIE.MeasureVI(30, 10);
	EVEN1_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		POS_POSTLEAK_MISO->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCLK_D", SITE);
		POS_POSTLEAK_SCLK->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		POS_POSTLEAK_SCL_DBG->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		POS_POSTLEAK_FOUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_VBOS->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_BUCK1SW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_BUCK2SW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_BUCK3SW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_VSUP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_FCCU1_ERR->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A2_PGOOD.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_PGOOD->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_PSYNC->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A5_AMUX.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_AMUX->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


	}
	dcm.SetPPMU("EVEN_G", DCM_PPMU_FVMI, neg_v, DCM_PPMUIRANGE_2UA);
	if (DO_CHAR || (test_stage==1 ))
		EVEN1_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	else
		EVEN1_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	A5_AMUX.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	EVEN1_FXVIE.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A5_AMUX.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);

	dcm.PPMUMeasure("EVEN_G", 30, 10);
	EVEN1_FXVIE.MeasureVI(30, 10);
	EVEN1_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		NEG_POSTLEAK_MISO->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCLK_D", SITE);
		NEG_POSTLEAK_SCLK->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		NEG_POSTLEAK_SCL_DBG->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		NEG_POSTLEAK_FOUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_VBOS->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK1SW_5.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_BUCK1SW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2SW_6.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_BUCK2SW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_BUCK3SW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VSUP_11.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_VSUP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_FCCU1_ERR->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A2_PGOOD.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_PGOOD->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


		pinleakage[SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_PSYNC->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A5_AMUX.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_AMUX->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


	}
	dcm.SetPPMU("EVEN_G", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	EVEN1_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	A5_AMUX.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	EVEN1_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	dcm.SetPPMU("ODD_G", DCM_PPMU_FVMI, pos_v, DCM_PPMUIRANGE_2UA);
	ODD1_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	ODD1_FXVIE.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);

	dcm.PPMUMeasure("ODD_G", 30, 10);
	ODD1_FXVIE.MeasureVI(30, 10);
	ODD1_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		POS_POSTLEAK_MOSI->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		POS_POSTLEAK_CSB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		POS_POSTLEAK_SDA->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		POS_POSTLEAK_FIN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_VDDIO->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK1IN_2.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_BUCK1IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2IN_3.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_BUCK2IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3IN_4.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_BUCK3IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_BUCK1FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_BUCK2FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_BUCK3FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_FCCU2_RSTB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A3_INTB.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_INTB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}


	dcm.SetPPMU("ODD_G", DCM_PPMU_FVMI, neg_v, DCM_PPMUIRANGE_2UA);
	ODD1_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	ODD1_FXVIE.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);

	dcm.PPMUMeasure("ODD_G", 30, 10);
	ODD1_FXVIE.MeasureVI(30, 10);
	ODD1_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		NEG_POSTLEAK_MOSI->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		NEG_POSTLEAK_CSB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		NEG_POSTLEAK_SDA->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		NEG_POSTLEAK_FIN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_VDDIO->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK1IN_2.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_BUCK1IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK2IN_3.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_BUCK2IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3IN_4.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_BUCK3IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_BUCK1FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_BUCK2FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_BUCK3FB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_FCCU2_RSTB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = A3_INTB.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_INTB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}
	dcm.SetPPMU("ODD_G", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	ODD1_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	ODD1_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	cbite.SetOn(K8_SCL_SDA_DCM, K5_DBG_DCM, K18_FIN_DCM, K26_FOUT_DCM, K40_VBOOST_ACM, K3_BOOSTLS_ACM, K33_BUCK12SW_ACM, K38_PRECOMP_ACM, K39_PRECSP_ACM,
		K46_PREFB_ACM, K42_PRESW_FXVIB, K43_PREGHS_FXVIB, K41_PREGLS_FXVIB, K44_PREBOOT_FXVIB, K47_WAKE1_FXVIB, K0_WAKE2_FXVIB, K51_LDO2_FXVIB, K13_VMON1_FXVIB,
		K12_VMON2_FXVIB, K10_VMON3_FXVIB, K9_VMON4_FXVIB, K105_FXVI0_6_B, K107_FXVI1_7_B, K109_FXVI2_8_B, K111_FXVI3_9_B, K113_FXVI4_10_B, K115_FXVI5_11_B, -1);//vbos,buck1,2,3 in
	delay_ms(1);
	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	EVEN2_FXVIE.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	EVEN2_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	EVEN2_FXVIE.MeasureVI(30, 10);
	EVEN2_ACM.MeasureVI(30, 10);
	SERIAL
	{


		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_VBOOST->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_PREFB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_PRECMP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_PREGHS_GHL->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_WAKE12->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_VMON1234->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


	}


	EVEN2_FXVIE.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	EVEN2_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	EVEN2_FXVIE.MeasureVI(30, 10);
	EVEN2_ACM.MeasureVI(30, 10);
	SERIAL
	{
		pinleakage[SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_VBOOST->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_PREFB->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_PRECMP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_PREGHS_GHL->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B3_WAKE12.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_WAKE12->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_VMON1234->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);


	}
	EVEN2_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	EVEN2_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);

	ODD2_FXVIE.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	if (DO_CHAR || (test_stage==1 ))
		ODD2_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	else
		ODD2_ACM.Set(FV, pos_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ODD2_FXVIE.MeasureVI(30, 10);
	ODD2_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_VBOS2->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_BOOSTLS->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_PRECSP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_PRESW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_PREBOOT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_LDO2OUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}


	ODD2_FXVIE.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	if (DO_CHAR || (test_stage==1 ))
		ODD2_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	else
		ODD2_ACM.Set(FV, neg_v, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	ODD2_FXVIE.MeasureVI(30, 10);
	ODD2_ACM.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = VBOS_1.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_VBOS2->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_BOOSTLS->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_PRECSP->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_PRESW->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_PREBOOT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_LDO2OUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}
	ODD2_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	ODD2_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
		cbite.SetOn(K8_SCL_SDA_DCM, K5_DBG_DCM, K18_FIN_DCM, K26_FOUT_DCM, K40_VBOOST_ACM, K3_BOOSTLS_ACM, K33_BUCK12SW_ACM, K38_PRECOMP_ACM, K39_PRECSP_ACM,
		K46_PREFB_ACM, K53_LDO1IN_FXVIB, K52_LDO1_FXVIB, K44_PREBOOT_FXVIB, K47_WAKE1_FXVIB, K0_WAKE2_FXVIB,
		K105_FXVI0_6_B, K107_FXVI1_7_B, K109_FXVI2_8_B, K111_FXVI3_9_B, K113_FXVI4_10_B, K115_FXVI5_11_B, -1);//vbos,buck1,2,3 in
	delay_ms(1);

	B0_PRESW_LDO1IN.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	B0_PRESW_LDO1IN.MeasureVI(30, 10);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_LDO1IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_SSD->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}
	B0_PRESW_LDO1IN.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	B0_PRESW_LDO1IN.MeasureVI(30, 10);
	B5_VMON1234.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_LDO1IN->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B5_VMON1234.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_SSD->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, pos_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_LDO1OUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		POS_POSTLEAK_FS0B->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, neg_v, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(8);
	if (DO_CHAR || (test_stage==1 )) delay_ms(20);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B4_VSUP_LDO2OUT.MeasureVI(30, 10);
	SERIAL
	{

		pinleakage[SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_LDO1OUT->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

		pinleakage[SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MIRET);
		NEG_POSTLEAK_FS0B->SetTestResult(SITE, 0, pinleakage[SITE] * 1e9);

	}

	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);

	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2UA);
	ALL_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	ALL_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_OFF);
	dcm.Disconnect("DCM_ALLPINS");
	if (DEBUG)
	{


		dcm.InitPPMU("DCM_ALLPINS");
		dcm.Disconnect("DCM_ALLPINS");
		FPVIM.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
		for (int i = 0; i < 12; i++)
		{
			acm_grp[i].TSet(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
		}


		for (int i = 0; i < 6; i++)
		{
			fxvie_grp[i].TSet(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
		}
		STSTArming();
	}


	return 0;
}

DUT_API int T54_POST_TEST_OS(short funcindex, LPCTSTR funclabel)
{

	CParam *POST_OS_MISO = StsGetParam(funcindex, "POST_OS_MISO");
	CParam *POST_OS_MOSI = StsGetParam(funcindex, "POST_OS_MOSI");
	CParam *POST_OS_SCLK = StsGetParam(funcindex, "POST_OS_SCLK");
	CParam *POST_OS_CSB = StsGetParam(funcindex, "POST_OS_CSB");
	CParam *POST_OS_SCL = StsGetParam(funcindex, "POST_OS_SCL");
	CParam *POST_OS_SDA = StsGetParam(funcindex, "POST_OS_SDA");
	CParam *POST_OS_FIN = StsGetParam(funcindex, "POST_OS_FIN");
	CParam *POST_OS_FOUT = StsGetParam(funcindex, "POST_OS_FOUT");
	CParam *POST_OS_VDDIO = StsGetParam(funcindex, "POST_OS_VDDIO");
	CParam *POST_OS_VBOS = StsGetParam(funcindex, "POST_OS_VBOS");
	CParam *POST_OS_BUCK1IN = StsGetParam(funcindex, "POST_OS_BUCK1IN");
	CParam *POST_OS_BUCK2IN = StsGetParam(funcindex, "POST_OS_BUCK2IN");
	CParam *POST_OS_BUCK3IN = StsGetParam(funcindex, "POST_OS_BUCK3IN");
	CParam *POST_OS_BUCK1SW = StsGetParam(funcindex, "POST_OS_BUCK1SW");
	CParam *POST_OS_BUCK2SW = StsGetParam(funcindex, "POST_OS_BUCK2SW");
	CParam *POST_OS_BUCK3SW = StsGetParam(funcindex, "POST_OS_BUCK3SW");
	CParam *POST_OS_BUCK1FB = StsGetParam(funcindex, "POST_OS_BUCK1FB");
	CParam *POST_OS_BUCK2FB = StsGetParam(funcindex, "POST_OS_BUCK2FB");
	CParam *POST_OS_BUCK3FB = StsGetParam(funcindex, "POST_OS_BUCK3FB");
	CParam *POST_OS_VSUP = StsGetParam(funcindex, "POST_OS_VSUP");
	CParam *POST_OS_FCCU1 = StsGetParam(funcindex, "POST_OS_FCCU1");
	CParam *POST_OS_FCCU2 = StsGetParam(funcindex, "POST_OS_FCCU2");
	CParam *POST_OS_PGOOD = StsGetParam(funcindex, "POST_OS_PGOOD");
	CParam *POST_OS_INTB = StsGetParam(funcindex, "POST_OS_INTB");
	CParam *POST_OS_PSYNC = StsGetParam(funcindex, "POST_OS_PSYNC");
	CParam *POST_OS_AMUX = StsGetParam(funcindex, "POST_OS_AMUX");

	CParam *POST_OS_MISO_VDDIO = StsGetParam(funcindex, "POST_OS_MISO_VDDIO");
	CParam *POST_OS_FOUT_VDDIO = StsGetParam(funcindex, "POST_OS_FOUT_VDDIO");
	CParam *POST_OS_AMUX_VDDIO = StsGetParam(funcindex, "POST_OS_AMUX_VDDIO");
	CParam *POST_OS_BUCK1SW_IN = StsGetParam(funcindex, "POST_OS_BUCK1SW_IN");
	CParam *POST_OS_BUCK2SW_IN = StsGetParam(funcindex, "POST_OS_BUCK2SW_IN");
	CParam *POST_OS_BUCK3SW_IN = StsGetParam(funcindex, "POST_OS_BUCK3SW_IN");

	CParam *POST_OS_PRESW_PREBOOT = StsGetParam(funcindex, "POST_OS_PRESW_PREBOOT");
	CParam *POST_OS_PREGHS_PREBOOT = StsGetParam(funcindex, "POST_OS_PREGHS_PREBOOT");
	CParam *POST_OS_WAKE1 = StsGetParam(funcindex, "POST_OS_WAKE1");
	CParam *POST_OS_LDO2OUT = StsGetParam(funcindex, "POST_OS_LDO2OUT");
	CParam *POST_OS_VMON1 = StsGetParam(funcindex, "POST_OS_VMON1");
	CParam *POST_OS_VBOOST = StsGetParam(funcindex, "POST_OS_VBOOST");
	CParam *POST_OS_BOOSTLS = StsGetParam(funcindex, "POST_OS_BOOSTLS");
	CParam *POST_OS_PREFB = StsGetParam(funcindex, "POST_OS_PREFB");
	CParam *POST_OS_PRECSP = StsGetParam(funcindex, "POST_OS_PRECSP");
	CParam *POST_OS_PRECMP = StsGetParam(funcindex, "POST_OS_PRECMP");


	CParam *POST_OS_PREBOOT = StsGetParam(funcindex, "POST_OS_PREBOOT");
	CParam *POST_OS_PRESW_PREGHS = StsGetParam(funcindex, "POST_OS_PRESW_PREGHS");


	CParam *POST_OS_WAKE2 = StsGetParam(funcindex, "POST_OS_WAKE2");
	CParam *POST_OS_VMON2 = StsGetParam(funcindex, "POST_OS_VMON2");
	CParam *POST_OS_PREGLS = StsGetParam(funcindex, "POST_OS_PREGLS");
	CParam *POST_OS_PRECMP_VBOS = StsGetParam(funcindex, "POST_OS_PRECMP_VBOS");
	CParam *POST_OS_LDO2OUT_VBOOST = StsGetParam(funcindex, "POST_OS_LDO2OUT_VBOOST");
	CParam *POST_OS_PREGLS_VBOS = StsGetParam(funcindex, "POST_OS_PREGLS_VBOS");
	CParam *POST_OS_VMON3 = StsGetParam(funcindex, "POST_OS_VMON3");
	CParam *POST_OS_VMON4 = StsGetParam(funcindex, "POST_OS_VMON4");
	CParam *POST_OS_LDO1OUT_IN = StsGetParam(funcindex, "POST_OS_LDO1OUT_IN");
	CParam *POST_OS_ERRMON = StsGetParam(funcindex, "POST_OS_ERRMON");
	CParam *POST_OS_RSTB = StsGetParam(funcindex, "POST_OS_RSTB");
	CParam *POST_OS_FS0B = StsGetParam(funcindex, "POST_OS_FS0B");
	CParam *POST_OS_SSD = StsGetParam(funcindex, "POST_OS_SSD");
	CParam *POST_OS_DBG = StsGetParam(funcindex, "POST_OS_DBG");


	CParam *TEMP = StsGetParam(funcindex, "TEMP");

	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here

	// TODO: Add your function code here
	//************************************ Add OS classify ***********************************************
	const int PIN_NUM = 58;
	double os_result[PIN_NUM][SITE_NUM] = { 0 };
	double res[SITE_NUM] = { 0 };

	vector<string> vec_exclude;


		cbite.SetOn(K8_SCL_SDA_DCM, K18_FIN_DCM, K26_FOUT_DCM, K24_VDDIO_ACM, K4_BUCK3SW_ACM, K33_BUCK12SW_ACM, K7_BUCK3FB_ACM, K29_BUCK2FB_ACM,
		K36_BUCK1FB_ACM, K28_FCCU12_FXVIA, K15_PGOOD_FXVIA, K32_INTB_FXVIA, K35_PSYNC_FXVIA, K27_220_SHRT,
		K104_FXVI0_6_A, K106_FXVI1_7_A, K108_FXVI2_8_A, K110_FXVI3_9_A, K112_FXVI4_10_A, K114_FXVI5_11_A, -1);//vbos,buck1,2,3 in
	delay_ms(1);
	dcm.Connect("DCM_ALLPINS");

	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FIMV, -1e-3, DCM_PPMUIRANGE_2MA);
	ALL_FXVIE.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	ALL_ACM.Set(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	dcm.PPMUMeasure("DCM_ALLPINS", 10, 10);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	SERIAL
	{

		os_result[0][SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		POST_OS_MISO->SetTestResult(SITE, 0, os_result[0][SITE]);

		os_result[1][SITE] = dcm.GetPPMUMeasResult("MOSI_D", SITE);
		POST_OS_MOSI->SetTestResult(SITE, 0, os_result[1][SITE]);

		os_result[2][SITE] = dcm.GetPPMUMeasResult("SCLK_D", SITE);
		POST_OS_SCLK->SetTestResult(SITE, 0, os_result[2][SITE]);

		os_result[3][SITE] = dcm.GetPPMUMeasResult("CSB_D", SITE);
		POST_OS_CSB->SetTestResult(SITE, 0, os_result[3][SITE]);

		os_result[4][SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		POST_OS_SCL->SetTestResult(SITE, 0, os_result[4][SITE]);

		os_result[5][SITE] = dcm.GetPPMUMeasResult("SDA_WAKE1_D", SITE);
		POST_OS_SDA->SetTestResult(SITE, 0, os_result[5][SITE]);

		os_result[6][SITE] = dcm.GetPPMUMeasResult("FIN_WAKE2_D", SITE);
		POST_OS_FIN->SetTestResult(SITE, 0, os_result[6][SITE]);

		os_result[7][SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		POST_OS_FOUT->SetTestResult(SITE, 0, os_result[7][SITE]);

		os_result[8][SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MVRET);
		POST_OS_VDDIO->SetTestResult(SITE, 0, os_result[8][SITE]);

		os_result[9][SITE] = VBOS_1.GetMeasResult(SITE, MVRET);
		POST_OS_VBOS->SetTestResult(SITE, 0, os_result[9][SITE]);

		os_result[10][SITE] = BUCK1IN_2.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK1IN->SetTestResult(SITE, 0, os_result[10][SITE]);

		os_result[11][SITE] = BUCK2IN_3.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK2IN->SetTestResult(SITE, 0, os_result[11][SITE]);

		os_result[12][SITE] = BUCK3IN_4.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK3IN->SetTestResult(SITE, 0, os_result[12][SITE]);

		os_result[13][SITE] = BUCK1SW_5.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK1SW->SetTestResult(SITE, 0, os_result[13][SITE]);

		os_result[14][SITE] = BUCK2SW_6.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK2SW->SetTestResult(SITE, 0, os_result[14][SITE]);

		os_result[15][SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK3SW->SetTestResult(SITE, 0, os_result[15][SITE]);

		os_result[16][SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK1FB->SetTestResult(SITE, 0, os_result[16][SITE]);

		os_result[17][SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK2FB->SetTestResult(SITE, 0, os_result[17][SITE]);

		os_result[18][SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK3FB->SetTestResult(SITE, 0, os_result[18][SITE]);

		os_result[19][SITE] = VSUP_11.GetMeasResult(SITE, MVRET);
		POST_OS_VSUP->SetTestResult(SITE, 0, os_result[19][SITE]);

		os_result[20][SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MVRET);
		POST_OS_FCCU1->SetTestResult(SITE, 0, os_result[20][SITE]);

		os_result[21][SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MVRET);
		POST_OS_FCCU2->SetTestResult(SITE, 0, os_result[21][SITE]);

		os_result[22][SITE] = A2_PGOOD.GetMeasResult(SITE, MVRET);
		POST_OS_PGOOD->SetTestResult(SITE, 0, os_result[22][SITE]);

		os_result[23][SITE] = A3_INTB.GetMeasResult(SITE, MVRET);
		POST_OS_INTB->SetTestResult(SITE, 0, os_result[23][SITE]);

		os_result[24][SITE] = A4_PSYNC_PREFB.GetMeasResult(SITE, MVRET);
		POST_OS_PSYNC->SetTestResult(SITE, 0, os_result[24][SITE]);

		os_result[25][SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		POST_OS_AMUX->SetTestResult(SITE, 0, os_result[25][SITE]);



	}

	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
	ALL_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	ALL_ACM.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);

	dcm.SetPPMU("MISO", DCM_PPMU_FIMV, 1e-3, DCM_PPMUIRANGE_2MA);
	dcm.SetPPMU("FOUT_INTB", DCM_PPMU_FIMV, 1e-3, DCM_PPMUIRANGE_2MA);
	A5_AMUX.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	BUCK123SW.Set(FI, 1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);

	dcm.PPMUMeasure("MISO", 30, 10);
	dcm.PPMUMeasure("FOUT_INTB", 30, 10);
	A5_AMUX.MeasureVI(30, 10);
	BUCK123SW.MeasureVI(30, 10);
	SERIAL
	{

		os_result[26][SITE] = dcm.GetPPMUMeasResult("MISO_D", SITE);
		POST_OS_MISO_VDDIO->SetTestResult(SITE, 0, os_result[26][SITE]);

		os_result[27][SITE] = dcm.GetPPMUMeasResult("FOUT_INTB_D", SITE);
		POST_OS_FOUT_VDDIO->SetTestResult(SITE, 0, os_result[27][SITE]);

		os_result[28][SITE] = A5_AMUX.GetMeasResult(SITE, MVRET);
		POST_OS_AMUX_VDDIO->SetTestResult(SITE, 0, os_result[28][SITE]);

		os_result[29][SITE] = BUCK1SW_5.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK1SW_IN->SetTestResult(SITE, 0, os_result[29][SITE]);

		os_result[30][SITE] = BUCK2SW_6.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK2SW_IN->SetTestResult(SITE, 0, os_result[30][SITE]);

		os_result[31][SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MVRET);
		POST_OS_BUCK3SW_IN->SetTestResult(SITE, 0, os_result[31][SITE]);

	}

	dcm.SetPPMU("MISO", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
	dcm.SetPPMU("FOUT_INTB", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
	A5_AMUX.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	BUCK123SW.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);

	cbite.SetOn(K8_SCL_SDA_DCM, K18_FIN_DCM, K26_FOUT_DCM, K40_VBOOST_ACM, K3_BOOSTLS_ACM, K46_PREFB_ACM, K39_PRECSP_ACM, K38_PRECOMP_ACM,
		K42_PRESW_FXVIB, K43_PREGHS_FXVIB, K44_PREBOOT_FXVIB, K47_WAKE1_FXVIB, K13_VMON1_FXVIB, K51_LDO2_FXVIB,
		K105_FXVI0_6_B, K107_FXVI1_7_B, K109_FXVI2_8_B, K111_FXVI3_9_B, K113_FXVI4_10_B, K115_FXVI5_11_B, K21_PADF_AGNDF, -1);//
	delay_ms(1);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.TSet(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B3_WAKE12.TSet(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.TSet(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.TSet(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	VDDIO_VBOOST_0.TSet(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.TSet(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.TSet(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.TSet(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.TSet(FI, -1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	STSTArming();
	delay_ms(4);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);

	SERIAL
	{

		//	os_result[32][SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MVRET);
		//	POST_OS_PRESW->SetTestResult(SITE, 0, os_result[32][SITE]);

		os_result[43][SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		POST_OS_PRESW_PREGHS->SetTestResult(SITE, 0, os_result[43][SITE]);

		os_result[34][SITE] = B3_WAKE12.GetMeasResult(SITE, MVRET);
		POST_OS_WAKE1->SetTestResult(SITE, 0, os_result[34][SITE]);

		os_result[35][SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		POST_OS_LDO2OUT->SetTestResult(SITE, 0, os_result[35][SITE]);

		os_result[36][SITE] = B5_VMON1234.GetMeasResult(SITE, MVRET);
		POST_OS_VMON1->SetTestResult(SITE, 0, os_result[36][SITE]);

		os_result[37][SITE] = VDDIO_VBOOST_0.GetMeasResult(SITE, MVRET);
		POST_OS_VBOOST->SetTestResult(SITE, 0, os_result[37][SITE]);

		os_result[38][SITE] = BUCK3SW_BOOSTLS_7.GetMeasResult(SITE, MVRET);
		POST_OS_BOOSTLS->SetTestResult(SITE, 0, os_result[38][SITE]);

		os_result[39][SITE] = PREFB_BUCK1FB_8.GetMeasResult(SITE, MVRET);
		POST_OS_PREFB->SetTestResult(SITE, 0, os_result[39][SITE]);

		os_result[40][SITE] = PRECSP_BUCK2FB_9.GetMeasResult(SITE, MVRET);
		POST_OS_PRECSP->SetTestResult(SITE, 0, os_result[40][SITE]);

		os_result[41][SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MVRET);
		POST_OS_PRECMP->SetTestResult(SITE, 0, os_result[41][SITE]);


	}

	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	B0_PRESW_LDO1IN.MeasureVI(30, 10);
	SERIAL
	{

		os_result[32][SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MVRET);
		POST_OS_PRESW_PREBOOT->SetTestResult(SITE, 0, os_result[32][SITE]);

		os_result[33][SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		POST_OS_PREGHS_PREBOOT->SetTestResult(SITE, 0, os_result[33][SITE]);

	}
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B3_WAKE12.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//B2_PREBOOT_VBOOST.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	ALL_FXVIE.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);


	VDDIO_VBOOST_0.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	BUCK3SW_BOOSTLS_7.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PREFB_BUCK1FB_8.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PRECSP_BUCK2FB_9.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	cbite.SetCbiteOff(K43_PREGHS_FXVIB);
	cbite.SetCbiteOff(K42_PRESW_FXVIB);
	delay_ms(1);
	B2_PREBOOT_VBOOST.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B2_PREBOOT_VBOOST.MeasureVI(30, 10);
	SERIAL
	{

		os_result[42][SITE] = B2_PREBOOT_VBOOST.GetMeasResult(SITE, MVRET);
		POST_OS_PREBOOT->SetTestResult(SITE, 0, os_result[42][SITE]);
	}
		//cbite.SetCbiteOn(K43_PREGHS_FXVIB);
	cbite.SetCbiteOn(K42_PRESW_FXVIB);
	//delay_ms(1);
	//B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	//B0_PRESW_LDO1IN.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(2);
	//B0_PRESW_LDO1IN.MeasureVI(30, 10);
	//SERIAL
	//{

	//	os_result[43][SITE] = B0_PRESW_LDO1IN.GetMeasResult(SITE, MVRET);
	//	POST_OS_PRESW_PREGHS->SetTestResult(SITE, 0, os_result[43][SITE]);
	//}
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B2_PREBOOT_VBOOST.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	cbite.SetCbiteOn(K41_PREGLS_FXVIB);
	cbite.SetCbiteOn(K0_WAKE2_FXVIB);
	cbite.SetCbiteOn(K12_VMON2_FXVIB);
	cbite.SetCbiteOff(K43_PREGHS_FXVIB);
	cbite.SetCbiteOff(K47_WAKE1_FXVIB);
	cbite.SetCbiteOff(K13_VMON1_FXVIB);
	delay_ms(1);
	B3_WAKE12.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FI, 1e-3, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	ALL_FXVIE.MeasureVI(30, 10);
	ALL_ACM.MeasureVI(30, 10);
	//B3_WAKE12.MeasureVI(30, 10);
	//B5_VMON1234.MeasureVI(30, 10);
	//B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		os_result[44][SITE] = B3_WAKE12.GetMeasResult(SITE, MVRET);
		POST_OS_WAKE2->SetTestResult(SITE, 0, os_result[44][SITE]);
		os_result[45][SITE] = B5_VMON1234.GetMeasResult(SITE, MVRET);
		POST_OS_VMON2->SetTestResult(SITE, 0, os_result[45][SITE]);
		os_result[46][SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		POST_OS_PREGLS->SetTestResult(SITE, 0, os_result[46][SITE]);
		os_result[47][SITE] = PRECMP_BUCK3FB_INTB_10.GetMeasResult(SITE, MVRET);
		POST_OS_PRECMP_VBOS->SetTestResult(SITE, 0, os_result[47][SITE]);
		os_result[48][SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		POST_OS_LDO2OUT_VBOOST->SetTestResult(SITE, 0, os_result[48][SITE]);

	}
	B3_WAKE12.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);


	cbite.SetCbiteOn(K10_VMON3_FXVIB);
	cbite.SetCbiteOff(K12_VMON2_FXVIB);
	delay_ms(1);
	B5_VMON1234.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B5_VMON1234.MeasureVI(30, 10);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);
	SERIAL
	{
		os_result[49][SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		POST_OS_PREGLS_VBOS->SetTestResult(SITE, 0, os_result[49][SITE]);
		os_result[50][SITE] = B5_VMON1234.GetMeasResult(SITE, MVRET);
		POST_OS_VMON3->SetTestResult(SITE, 0, os_result[50][SITE]);

	}
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	cbite.SetCbiteOn(K9_VMON4_FXVIB);
	cbite.SetCbiteOff(K10_VMON3_FXVIB);
	delay_ms(1);

	B5_VMON1234.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	B5_VMON1234.MeasureVI(30, 10);

	SERIAL
	{

		os_result[51][SITE] = B5_VMON1234.GetMeasResult(SITE, MVRET);
		POST_OS_VMON4->SetTestResult(SITE, 0, os_result[51][SITE]);

	}
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	//ldo1 in /out
	cbite.SetCbiteOn(K52_LDO1_FXVIB);
	cbite.SetCbiteOn(K53_LDO1IN_FXVIB);
	cbite.SetCbiteOff(K41_PREGLS_FXVIB);
	cbite.SetCbiteOff(K10_VMON3_FXVIB);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FI, 1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	delay_ms(2);
	B1_PREGHS_PREGLS_LDO1OUT.MeasureVI(30, 10);

	SERIAL
	{

		os_result[52][SITE] = B1_PREGHS_PREGLS_LDO1OUT.GetMeasResult(SITE, MVRET);
		POST_OS_LDO1OUT_IN->SetTestResult(SITE, 0, os_result[52][SITE]);

	}
		//errmon /rstb
	cbite.SetCbiteOn(K37_ERRMON_FXVIA);
	cbite.SetCbiteOn(K16_RSTB_FXVIA);
	cbite.SetCbiteOn(K104_FXVI0_6_A);
	cbite.SetCbiteOn(K106_FXVI1_7_A);
	cbite.SetCbiteOn(K5_DBG_DCM);
	cbite.SetCbiteOff(K52_LDO1_FXVIB);
	cbite.SetCbiteOff(K53_LDO1IN_FXVIB);
	cbite.SetCbiteOff(K105_FXVI0_6_B);
	cbite.SetCbiteOff(K107_FXVI1_7_B);

	cbite.SetCbiteOff(K8_SCL_SDA_DCM);
	delay_ms(1);
	A0_FIN_DBG_ERR_FCCU1.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	B5_VMON1234.Set(FI, -1e-3, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FIMV, -1e-3, DCM_PPMUIRANGE_2MA);

	delay_ms(2);
	ALL_FXVIE.MeasureVI(30, 10);
	dcm.PPMUMeasure("SCL_DBG", 30, 10);
	//A1_FOUT_RSTB_FCCU2.MeasureVI(30, 10);

	SERIAL
	{
		os_result[53][SITE] = A0_FIN_DBG_ERR_FCCU1.GetMeasResult(SITE, MVRET);
		POST_OS_ERRMON->SetTestResult(SITE, 0, os_result[53][SITE]);
		os_result[54][SITE] = A1_FOUT_RSTB_FCCU2.GetMeasResult(SITE, MVRET);
		POST_OS_RSTB->SetTestResult(SITE, 0, os_result[54][SITE]);
		os_result[55][SITE] = B4_VSUP_LDO2OUT.GetMeasResult(SITE, MVRET);
		POST_OS_FS0B->SetTestResult(SITE, 0, os_result[55][SITE]);

		os_result[56][SITE] = dcm.GetPPMUMeasResult("SCL_DBG_D", SITE);
		POST_OS_DBG->SetTestResult(SITE, 0, os_result[56][SITE]);
		//only valid for ssd version
		if (SSD_EN)
		{
			os_result[57][SITE] = B5_VMON1234.GetMeasResult(SITE, MVRET);
			POST_OS_SSD->SetTestResult(SITE, 0, os_result[57][SITE]);
		}

	}
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	A1_FOUT_RSTB_FCCU2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B5_VMON1234.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	

	if (DEBUG)
	{


		dcm.InitPPMU("DCM_ALLPINS");
		dcm.Disconnect("DCM_ALLPINS");
		FPVIM.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
		for (int i = 0; i < 12; i++)
		{
			acm_grp[i].Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
		}


		for (int i = 0; i < 6; i++)
		{
			fxvie_grp[i].Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
		}
	}
	return 0;
}