#include "stdafx.h"
#include "BoardCheck.h"
#define		YES 	6
#define		NO		7
extern string int2str(DWORD n);

/* No repeat: board_check_repeat = -1 */
int board_check_repeat = -1; // set repeat count

void connected_site_check(BoardCheck& bc){

	//update for 8300
	double site_check_specl = 0;
	double site_check_spech = 0;
	double result[SITE_NUM] = { 0 };
	//enable all sites
	for (int site = 0; site<SITE_NUM; ++site) bc.SetSiteConnected(site, 1); // inital for site check component measure

	//can only enable valid site for engineering use
	if (DEBUG_MODE)
	{
		STSSetSiteStatus(0xFFFF);
		SERIAL{
			bc.SetSiteConnected(SITE, 1);
		}
	else
	bc.SetSiteConnected(SITE, 0);

	//bc.SetSiteConnected(0, 0);//site1 enable 
	//bc.SetSiteConnected(1, 1);//site2 enable
	//bc.SetSiteConnected(2, 1);//site3 enable
	//bc.SetSiteConnected(3, 1);//site4 disable
	//bc.SetSiteConnected(4, 0);//site4 disable
	//bc.SetSiteConnected(5, 0);//site4 disable
	//bc.SetSiteConnected(6, 0);//site4 disable
	//bc.SetSiteConnected(7, 0);//site4 disable

	}


}


BOOL board_check_function(int &nBtn, BOOL &flag_pass)
{
	//////////////////////////////////////////////////////////////////
	/* Common usage format, don't change this if no specific need   */
	BoardCheck bc;
	double result[SITE_NUM];
	string board_name;
	string board_rev;
	string board_number;
	for (int site = 0; site<SITE_NUM; ++site) result[site] = 9999;
	DWORD tnum = 1;
	double contact_res = 50.0;
	double contact_v;
	bool stoponfail = 1;
	STSSetSiteStatus(0xFFFF);
	double contact_fi = 0.01;

	//------------Board ID Check---------------
	if (1)//need latest cbit hardware version
	{
		
		//bc.Board_ID_Write("SC6259X", "A", "2");
		if (bc.Board_ID_Check("SC6259X", "A"))
		{
			bc.Board_ID_Read(&board_name, &board_rev, &board_number);
			boardid = atoi(board_number.c_str());
			//------Subboard contact check-----//
			cbite.SetOn(K87_LOCK_DCM, -1);
			delay_ms(1);
			dcm.Connect("FOUT_INTB");
			dcm.SetPPMU("FOUT_INTB", DCM_PPMU_FIMV, contact_fi, DCM_PPMUIRANGE_32MA);
			delay_ms(10);
			dcm.PPMUMeasure("FOUT_INTB", 50, 5);
			 contact_v = dcm.GetPPMUMeasResult("FOUT_INTB_D", 6);
			dcm.InitPPMU("FOUT_INTB");
			dcm.Disconnect("FOUT_INTB");
			cbite.SetOn(-1);
			if ((contact_v / contact_fi) > contact_res)
			{
				MessageBoxA(NULL, "�Ӱ��ĸ��֮��û�Ӵ��ã�������Ӱ�����·���", "�Ӱ����Ӽ��", MB_OK);

				nBtn = BTN_EXIT;
				return FALSE;
			}
		
		}
		else
		{
	
			nBtn = BTN_EXIT;
			return FALSE;
		}
	}

	//BOOL Board_ID_Check(const char* boardName, const char* rev, const char* SCLChannel, const char* SDAChannel);
	//BOOL Board_ID_Write(const char* boardName, const char* rev, const char* number, const char* SCLChannel, const char* SDAChannel);
	//BOOL Board_ID_Read(const char* boardName, const char* rev, const char* number, const char* SCLChannel, const char* SDAChannel);

	int sel_flag = NO;
	bc.ClearSiteConnected();
	while ((bc.IsNoSiteConnected() || (sel_flag == NO)) && (board_check_repeat == -1)){
		connected_site_check(bc);

		if (bc.IsNoSiteConnected() && DEBUG_MODE){
			if (MessageBoxA(NULL, "û��ʹ���κι�λ! \n��ȷ��: ���������ѡ��-��(Y)\n����˳���ѡ��-��(N)", "�����ʾ�Ի���", MB_YESNO) == IDNO){
				nBtn = BTN_EXIT;
				return FALSE;
			}
			continue;
		}
		sel_flag = YES;
	}

	if ((board_check_repeat != -1))connected_site_check(bc);//for loop test
	/* Common usage format, don't change this if no specific need   */
	//////////////////////////////////////////////////////////////////


	//////////////////////////////////////////////////////////////////
	/********************** User Define Begin ***********************/

	Cvi_config vi; // default FV,3V,0A,FOVIe_5V,FOVI_10MA,10ms,100 sample times,10 us interval

	/*** Connections and components ***/
	double spec_h = vi.v + 0.01;
	double spec_l = vi.v - 0.01;
	double cap10nF_l = 5;
	double cap10nF_h = 15;
	double cap20nF_l = 10;
	double cap20nF_h = 30;
	double cap100nF_l = 50;
	double cap100nF_h = 150;
	double cap10uF_l = 5;
	double cap10uF_h = 15;
	double cap5uF_l = 2.5;
	double cap5uF_h = 7.5;
	double cap1uF_l = 0.5;
	double cap1uF_h = 1.5;
	double cap2uF_l = 1.3;
	double cap2uF_h = 2.5;
	double cap2p2uF_l = 1.5;
	double cap2p2uF_h = 2.9;
	double cap4p7uF_l = 2.0;
	double cap4p7uF_h = 7;
	vi.init();		// default FV,3V,0A,FOVIe_5V,FOVI_10MA,10ms,100 sample times,10 us interval

	vi.v_range = FOVIe_10V;
	vi.i_range = FOVIe_10UA;
	vi.miGain = FOVIe_MI_X1;
	vi.acm_v_range = ACM_N2P18V;
	vi.acm_i_range = ACM_20UA;

	double leak_spel = -100; //nA
	double leak_speh = 300;  //nA
	//base on absmax voltage

	
	

	string acm_pins[11] = {  "ACM0_leakage", "ACM1_leakage", "ACM2_leakage", "ACM3_leakage", "ACM4_leakage", "ACM5_leakage", "ACM6_leakage", "ACM7_leakage",
		"ACM8_leakage", "ACM9_leakage", "ACM10_leakage" };

	string acm_contact[12] = { "ACM0_contact_check", "ACM1_contact_check", "ACM2_contact_check", "ACM3_contact_check", "ACM4_contact_check", "ACM5_contact_check", "ACM6_contact_check", "ACM7_contact_check",
		"ACM8_contact_check", "ACM9_contact_check", "ACM10_contact_check", "ACM11_contact_check" };
	string fxvi_pins[6] = { "A0_B0_leakage", "A1_B1_leakage", "A2_B2_leakage", "A3_B3_leakage", "A4_B4_leakage", "A5_B5_leakage" };
	string fxvi_contactA[6] = { "fxvi0_contact_check_A", "fxvi1_contact_check_A", "fxvi2_contact_check_A", "fxvi3_contact_check_A", "fxvi4_contact_check_A", "fxvi5_contact_check_A" };
	string fxvi_contactB[6] = { "fxvi0_contact_check_B", "fxvi1_contact_check_B", "fxvi2_contact_check_B", "fxvi3_contact_check_B", "fxvi4_contact_check_B", "fxvi5_contact_check_B" };

	string dcm_grps[8] = { "MISO", "MOSI", "SCLK", "CSB", "SCL_DBG", "SDA_WAKE1", "FIN_WAKE2", "FOUT_INTB" };
	string dcm_pins[8] = { "MISO_D", "MOSI_D", "SCLK_D", "CSB_D", "SCL_DBG_D", "SDA_WAKE1_D", "FIN_WAKE2_D", "FOUT_INTB_D" };
	string dcm_pins_str[8] = { "MISO leakage", "MOSI leakage", "SCLK leakage", "CSB leakage", "SCL_DBG leakage", "SDA_WAKE1 leakage", "FIN_WAKE2 leakage", "FOUT_INTB leakage" };

	//ACM200 acm_grp[12] = { VDDIO_VBOOST_0, VBOS_1, BUCK1IN_2, BUCK2IN_3, BUCK3IN_4, BUCK1SW_5, BUCK2SW_6, BUCK3SW_BOOSTLS_7, PREFB_BUCK1FB_8, PRECSP_BUCK2FB_9, PRECMP_BUCK3FB_INTB_10, VSUP_11 };
	//FXVIe_PLUS fxvie_grp[6] = { A0_FIN_DBG_ERR_FCCU1, A1_FOUT_RSTB_FCCU2, A2_PGOOD, A3_INTB, A4_PSYNC, A5_AMUX };

	//-----------------all pins leakage test----------------------


	//all pins force to 0V, then test leakages.

	cbite.SetOn(K_FXVI_A, K_FXVI_B, K22_AGNDFS_SHRT,K0_WAKE2_FXVIB, K6_DBG_FXVIA, K9_VMON4_FXVIB, K10_VMON3_FXVIB, K12_VMON2_FXVIB, K13_VMON1_FXVIB,
		K14_VCOREMON_FXVIB, K15_PGOOD_FXVIA, K16_RSTB_FXVIA, K17_FIN_FXVIA, K27_220_SHRT,K28_FCCU12_FXVIA, K35_PSYNC_FXVIA, K37_ERRMON_FXVIA,
		K41_PREGLS_FXVIB, K42_PRESW_FXVIB, K43_PREGHS_FXVIB, K44_PREBOOT_FXVIB, K45_PREFB_FXVIA, K47_WAKE1_FXVIB, K51_LDO2_FXVIB, K52_LDO1_FXVIB, K53_LDO1IN_FXVIB, - 1);
	delay_ms(1);

	double dcm_volt = 6.0;
	vi.v = 6.0;
	vi.v_range1 = FXVIe_PLUS_10V;
	vi.i_range1 = FXVIe_PLUS_10UA;
	vi.miGain1 = FXVIe_PLUS_MI_X1;
	vi.acm_v_range1 = ACM200_10V;
	vi.acm_i_range1 = ACM200_10UA;
	vi.delay = 50;//ms

	
	for (int i = 0; i < 11; i++)
		acm_grp[i].Set(FV, 0,ACM200_10V,ACM200_100UA, ACM200_RELAY_ON);
	for (int i = 0; i < 6; i++)
		fxvie_grp[i].Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);

	dcm.InitMCU("DCM_ALLPINS");
	dcm.Connect("DCM_ALLPINS");
	dcm.SetPPMU("DCM_ALLPINS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);

	//acm pins leakage test
	for (int i = 0; i < 6; i++)
	{
		bc.test_i(fxvie_grp[i], vi, tnum++, fxvi_pins[i].c_str(), leak_spel, leak_speh, "nA");
		fxvie_grp[i].Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	}
	for (int i = 0; i < 6; i++)
		fxvie_grp[i].Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);


	cbite.SetOn(K22_AGNDFS_SHRT,K3_BOOSTLS_ACM, K4_BUCK3SW_ACM, K7_BUCK3FB_ACM,K24_VDDIO_ACM, K29_BUCK2FB_ACM,
		K30_INTB_ACM, K33_BUCK12SW_ACM, K36_BUCK1FB_ACM, K38_PRECOMP_ACM, K39_PRECSP_ACM, K40_VBOOST_ACM,-1);
	delay_ms(1);
	for (int i = 0; i < 11; i++)
	{
		bc.test_i(acm_grp[i], vi, tnum++, acm_pins[i].c_str(), leak_spel, leak_speh, "nA");
		acm_grp[i].Set(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	}

	cbite.SetOn(K22_AGNDFS_SHRT, K1_WAKE2_DCM, K5_DBG_DCM, K8_SCL_SDA_DCM, K18_FIN_DCM, K26_FOUT_DCM,
		K31_INTB_DCM, K48_WAKE1_DCM, -1);
	delay_ms(1);
	//dcm pins leakage test
	for (int i = 0; i < 8; i++)
	{
		bc.test_i(dcm_grps[i].c_str(), dcm_pins[i].c_str(), tnum++, dcm_pins_str[i].c_str(), dcm_volt, leak_spel, leak_speh, "nA");
		dcm.Connect(dcm_grps[i].c_str());
		dcm.SetPPMU(dcm_grps[i].c_str(), DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
	}

	for (int i = 0; i < 11; i++)
		acm_grp[i].Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);

	dcm.InitPPMU("DCM_ALLPINS");
	dcm.Disconnect("DCM_ALLPINS");





	//-------------pin leakage end-----------//

	//------------Contact Check------------//
	cbite.SetOn(K_FXVI_B ,- 1);
	delay_ms(1);
	//contact check
	for (int i = 0; i < 6; i++)
	{
		if ((i==3) ||(i==5))
			bc.contact_check(fxvie_grp[i], tnum++, fxvi_contactB[i].c_str(), -0.5, 0.5, "NA");
		else
			bc.contact_check(fxvie_grp[i], tnum++, fxvi_contactB[i].c_str(), 0.5, 1.5, "NA");
	}
	cbite.SetOn(K_FXVI_A, -1);
	delay_ms(1);
	for (int i = 0; i < 6; i++)
	{
	
			bc.contact_check(fxvie_grp[i], tnum++, fxvi_contactA[i].c_str(), -0.5, 0.5, "NA");
	
	}

	bc.contact_checkL(fxvie_grp[0], tnum++, "FXVIe_PLUS_LOW_Contact_Check", 1.5, 2.5, "NA");

	cbite.SetOn(K22_AGNDFS_SHRT, -1);
	delay_ms(1);
	bc.contact_checkL(fxvie_grp[0], tnum++, "FXVIe_PLUS_LOW_Contact_Check", -0.5, 0.5, "NA");
	//ACM contact check
	for (int i = 0; i < 12; i++)
	{
		if ((i == 0) || ((i < 11) &&(i > 4 )))
		{
			bc.contact_check(acm_grp[i], tnum++, acm_contact[i].c_str(), -0.5, 0.5, "NA");
		}
		else
			bc.contact_check(acm_grp[i], tnum++, acm_contact[i].c_str(), 0.5, 1.5, "NA");
	}

	bc.contact_checkL(acm_grp[0], tnum++, "ACM200_LOW_Contact_Check", -0.5, 0.5, "NA");




	//-----------CAPs----------------//
	cbite.SetOn(K22_AGNDFS_SHRT, K81_LDO_CAPS, K53_LDO1IN_FXVIB, K105_FXVI0_6_B, K104_FXVI0_6_A, K52_LDO1_FXVIB, K51_LDO2_FXVIB, K106_FXVI1_7_A, K107_FXVI1_7_B, K112_FXVI4_10_A, K113_FXVI4_10_B, K21_PADF_AGNDF, -1);
	delay_ms(1);
	bc.test_cap(B0_PRESW_LDO1IN, tnum++, "LDO1IN C2,close(K53,81,104,105),4.7uF", cap4p7uF_l, cap4p7uF_h, "uF");
	bc.test_cap(B1_PREGHS_PREGLS_LDO1OUT, tnum++, "LDO1 C3C4,close(K52,81,106,107),4.8uF", cap4p7uF_l, cap4p7uF_h, "uF");
	bc.test_cap(B4_VSUP_LDO2OUT, tnum++, "LDO2 C5C6,close(K51,81,112,113),4.8uF", cap4p7uF_l, cap4p7uF_h, "uF");

	

	cbite.SetOn(K22_AGNDFS_SHRT, K82_BUCK_CAPS, K49_VSUP2_FXVIB, K112_FXVI4_10_A, K113_FXVI4_10_B, K21_PADF_AGNDF ,- 1);
	delay_ms(1);
	bc.test_cap(VBOS_1, tnum++, "VBOS C7C8,close(K22,82),4.8uF", cap4p7uF_l, cap4p7uF_h, "uF");
	bc.test_cap(B4_VSUP_LDO2OUT, tnum++, "VSUP2 C9,close(K49,112,113),4.7uF", cap4p7uF_l, cap4p7uF_h, "uF");

	bc.test_cap(BUCK1IN_2, tnum++, "BUCK1IN C12,close(K22,82),4.7uF", cap4p7uF_l, cap4p7uF_h, "uF");
	bc.test_cap(BUCK2IN_3, tnum++, "BUCK2IN C13,close(K22,82),4.7uF", cap4p7uF_l, cap4p7uF_h, "uF");
	bc.test_cap(BUCK3IN_4, tnum++, "BUCK3IN C11,close(K22,82),4.7uF", cap4p7uF_l, cap4p7uF_h, "uF");

	cbite.SetOn(K22_AGNDFS_SHRT, K82_BUCK_CAPS, K45_PREFB_FXVIA, K112_FXVI4_10_A, K21_PADF_AGNDF ,- 1);
	delay_ms(1);
	bc.test_cap(A4_PSYNC_PREFB, tnum++, "PREFB C10C38,close(K22,45,82),20.1uF", 12.0, 28.0, "uF");

	cbite.SetOn(K22_AGNDFS_SHRT, K84_PRECOMP_CAP, K38_PRECOMP_ACM, -1);//need check
	delay_ms(1);
	bc.test_cap(PRECMP_BUCK3FB_INTB_10, tnum++, "COMP C14C15,close(K22,84,38),10nF", 2.0, 30, "nF");

	cbite.SetOn(K22_AGNDFS_SHRT, K11_PRE_SLT, K42_PRESW_FXVIB, K44_PREBOOT_FXVIB, K105_FXVI0_6_B, K109_FXVI2_8_B, K21_PADF_AGNDF ,- 1);//need check
	delay_ms(1);

	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	bc.test_cap(B2_PREBOOT_VBOOST, tnum++, "PREBST_PRESW C1,close(K11,42,44,105,109),100nF", 50, 150, "nF");
	B0_PRESW_LDO1IN.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);


	cbite.SetOn(K22_AGNDFS_SHRT, K54_VDDIO_PU, K24_VDDIO_ACM,  -1);
	delay_ms(1);
	bc.test_cap(VDDIO_VBOOST_0, tnum++, "PU CAP C27,close(K22,54,24),4.7uF", cap4p7uF_l, cap4p7uF_h, "uF");
	//----------------PU/PD Matrix---------------//

	

	VDDIO_VBOOST_0.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	cbite.SetOn(K22_AGNDFS_SHRT, K24_VDDIO_ACM, K54_VDDIO_PU, K16_RSTB_FXVIA, K106_FXVI1_7_A, K55_RSTB_PU, -1);
	delay_ms(1);
	bc.test_r(A1_FOUT_RSTB_FCCU2, 20, tnum++, "R2 RSTB PU,close(K16,54,55,106) ", 0.95, 1.05, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K54_VDDIO_PU, K24_VDDIO_ACM, K30_INTB_ACM,K56_INTB_PU, -1);
	delay_ms(1);
	bc.test_r(PRECMP_BUCK3FB_INTB_10, 20, tnum++, "R3 INTB PU,close(K30,54,56) ", 0.95, 1.05, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K24_VDDIO_ACM, K54_VDDIO_PU, K57_FS0B_PSYNC_PU, -1);
	delay_ms(1);
	bc.test_r_fo(A4_PSYNC_PREFB, 20, tnum++, "R4 FS0B PU,close(K57,54) ", 0.95, 1.05, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K24_VDDIO_ACM, K54_VDDIO_PU,K57_FS0B_PSYNC_PU, K35_PSYNC_FXVIA, K112_FXVI4_10_A, -1);
	delay_ms(1);
	bc.test_r(A4_PSYNC_PREFB, 20, tnum++, "R5 PSYNC PU,close(K35,57,112,54) ", 0.95, 1.05, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K24_VDDIO_ACM, K54_VDDIO_PU,K58_DBG_PU, K6_DBG_FXVIA, K104_FXVI0_6_A, -1);
	bc.test_r(A0_FIN_DBG_ERR_FCCU1, 10, tnum++, "R6 DBG PU,close(K6,58,104,54) ", 0.95, 1.05, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K24_VDDIO_ACM, K54_VDDIO_PU,K59_WAKE12_PU, K0_WAKE2_FXVIB, K111_FXVI3_9_B, -1);
	bc.test_r(B3_WAKE12, 20, tnum++, "R8 WAKE2 PU,close(K0,59,111,54) ", 0.95, 1.05, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K24_VDDIO_ACM, K54_VDDIO_PU, K59_WAKE12_PU, K47_WAKE1_FXVIB, K111_FXVI3_9_B, -1);
	bc.test_r(B3_WAKE12, 20, tnum++, "R7 WAKE1 PU,close(K47,59,111,54) ", 0.95, 1.05, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K24_VDDIO_ACM, K54_VDDIO_PU,K78_FCCU1_PU_FCCU2_PD, K28_FCCU12_FXVIA, K104_FXVI0_6_A, -1);
	bc.test_r(A0_FIN_DBG_ERR_FCCU1, 10, tnum++, "R9 FCCU1 PU,close(K28,78,104,54) ", 0.95, 1.05, "kOhm");
	VDDIO_VBOOST_0.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);


	cbite.SetOn(K22_AGNDFS_SHRT, K62_BOOST_PRESW_VCOREMON_PD, K14_VCOREMON_FXVIB, K115_FXVI5_11_B,-1);
	delay_ms(1);
	bc.test_r(B5_VMON1234, 20, tnum++, "R12 VCOREMON PD,close(K14,15,62) ", 9.5, 10.5, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K62_BOOST_PRESW_VCOREMON_PD, K42_PRESW_FXVIB, K105_FXVI0_6_B, -1);
	delay_ms(1);
	bc.test_r(B0_PRESW_LDO1IN, 20, tnum++, "R13 PRESW PD,close(K42,62,105) ", 9.5, 10.5, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K62_BOOST_PRESW_VCOREMON_PD, K3_BOOSTLS_ACM, -1);
	delay_ms(1);
	bc.test_r(BUCK3SW_BOOSTLS_7, 20, tnum++, "R14 BOOSTLS PD,close(K3,62) ", 9.5, 10.5, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K61_DBG_PD, K6_DBG_FXVIA, K104_FXVI0_6_A ,- 1);
	delay_ms(1);
	bc.test_r(A0_FIN_DBG_ERR_FCCU1, 20, tnum++, "R15 DBG PD,close(K61,6,104) ", 9.5, 10.5, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K60_WAKE12_PD, K47_WAKE1_FXVIB, K111_FXVI3_9_B, -1);
	delay_ms(1);
	bc.test_r(B3_WAKE12, 20, tnum++, "R16 WAKE1 PD,close(K61,6,104) ", 9.5, 10.5, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K60_WAKE12_PD, K0_WAKE2_FXVIB, K111_FXVI3_9_B, -1);
	delay_ms(1);
	bc.test_r(B3_WAKE12, 20, tnum++, "R17 WAKE2 PD,close(K61,6,104) ", 9.5, 10.5, "kOhm");

	cbite.SetOn(K22_AGNDFS_SHRT, K78_FCCU1_PU_FCCU2_PD, K28_FCCU12_FXVIA, K106_FXVI1_7_A, -1);
	delay_ms(1);
	bc.test_r(A1_FOUT_RSTB_FCCU2, 20, tnum++, "R18 FCCU2 PD,close(K78,28,106) ", 9.5, 10.5, "kOhm");

	vi.i = 0.0;
	vi.mode = FI;
	vi.v_range1 = FXVIe_PLUS_10V;
	vi.i_range1 = FXVIe_PLUS_10UA;
	vi.miGain1 = FXVIe_PLUS_MI_X1;
	vi.acm_v_range1 = ACM200_10V;
	vi.acm_i_range1 = ACM200_10UA;
	vi.delay = 10;//ms

	cbite.SetOn(K22_AGNDFS_SHRT, K54_VDDIO_PU,K2_5V_PU, K24_VDDIO_ACM, -1);
	delay_ms(1);
	bc.test_v(VDDIO_VBOOST_0, tnum++, "+5V,close(K2,24) ", 4.8, 5.4, "V");
	vi.v_range1 = FXVIe_PLUS_10V;
	vi.i_range1 = FXVIe_PLUS_10MA;
	vi.miGain1 = FXVIe_PLUS_MI_X1;
	vi.acm_v_range1 = ACM200_10V;
	vi.acm_i_range1 = ACM200_10MA;
	vi.i = -0.001;
	cbite.SetOn(K22_AGNDFS_SHRT, K79_PGOOD_PU, K15_PGOOD_FXVIA, K108_FXVI2_8_A ,- 1);
	delay_ms(1);
	bc.test_v(A2_PGOOD, vi, tnum++, "+5V,close(K79,15,108) ", 4.8, 5.3, "V");
	//----------------PU/PD Matrix end------------------//

	//---------Pin/Res--Matrix--------------//
	//Pin1 wake2
	cbite.SetOn(K22_AGNDFS_SHRT, K0_WAKE2_FXVIB, K1_WAKE2_DCM, K111_FXVI3_9_B, -1);
	delay_ms(1);
	vi.i = -0.001;
	dcm.Connect("FIN_WAKE2");
	dcm.SetPPMU("FIN_WAKE2", DCM_PPMU_FVMI, 2.0, DCM_PPMUIRANGE_32MA);
	bc.test_v(B3_WAKE12, vi, tnum++, "Pin1,close(K0,1,111) ", 1.9, 2.1, "V");
	dcm.InitPPMU("FIN_WAKE2");
	dcm.Disconnect("FIN_WAKE2");

	//pin8 DBG

	cbite.SetOn(K22_AGNDFS_SHRT, K5_DBG_DCM, K6_DBG_FXVIA, K104_FXVI0_6_A, -1);
	delay_ms(1);
	vi.i = -0.001;
	dcm.Connect("SCL_DBG");
	dcm.SetPPMU("SCL_DBG", DCM_PPMU_FVMI, 2.0, DCM_PPMUIRANGE_32MA);
	bc.test_v(A0_FIN_DBG_ERR_FCCU1, vi, tnum++, "Pin8,close(K5,6,104) ", 1.9, 2.1, "V");
	dcm.InitPPMU("SCL_DBG");
	dcm.Disconnect("SCL_DBG");

	//pin20 FIN

	cbite.SetOn(K22_AGNDFS_SHRT, K17_FIN_FXVIA, K18_FIN_DCM, K104_FXVI0_6_A, -1);
	delay_ms(1);
	vi.i = -0.001;
	dcm.Connect("FIN_WAKE2");
	dcm.SetPPMU("FIN_WAKE2", DCM_PPMU_FVMI, 2.0, DCM_PPMUIRANGE_32MA);
	bc.test_v(A0_FIN_DBG_ERR_FCCU1, vi, tnum++, "Pin20,close(K17,18,104) ", 1.9, 2.1, "V");
	dcm.InitPPMU("FIN_WAKE2");
	dcm.Disconnect("FIN_WAKE2");

	cbite.SetOn(K22_AGNDFS_SHRT, K17_FIN_FXVIA, K18_FIN_DCM, K104_FXVI0_6_A, K19_AGNDF_DCM ,- 1);
	delay_ms(1);
	vi.i = -0.001;

	bc.test_v(A0_FIN_DBG_ERR_FCCU1, vi, tnum++, "Pin20,close(K17,18,104,19) ", -0.1, 0.1, "V");
	//pin22
	cbite.SetOn(K22_AGNDFS_SHRT, K19_AGNDF_DCM, -1);
	delay_ms(1);
	bc.test_r("FIN_WAKE2", "FIN_WAKE2_D", tnum++, "Pin22,close(K17,18,104,19) ", 0, 20, "Ohm");
	//stack
	cbite.SetOn(K22_AGNDFS_SHRT, K23_FXVI_STACK, -1);
	delay_ms(1);
	bc.test_cap(VDDIO_VBOOST_0, tnum++, "C25,close(K22,23),1uF", cap1uF_l, cap1uF_h, "uF");
	//stack &pin33 INTB
	cbite.SetOn(K22_AGNDFS_SHRT, K23_FXVI_STACK, K32_INTB_FXVIA, K30_INTB_ACM, K110_FXVI3_9_A ,- 1);
	delay_ms(1);
	VDDIO_VBOOST_0.Set(FV, 1.00, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	A3_INTB.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	bc.test_v(PRECMP_BUCK3FB_INTB_10, tnum++, "Pin33,Stack, close(K23,32,30,110) ", 1.99, 2.01, "V");
	A3_INTB.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	VDDIO_VBOOST_0.Set(FV, 0.00, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	A3_INTB.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	VDDIO_VBOOST_0.Set(FV, 0.00, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	//Pin33 INTB
	cbite.SetOn(K22_AGNDFS_SHRT, K31_INTB_DCM, K30_INTB_ACM, -1);
	delay_ms(1);
	vi.i = -0.001;
	dcm.Connect("FOUT_INTB");
	dcm.SetPPMU("FOUT_INTB", DCM_PPMU_FVMI, 2.0, DCM_PPMUIRANGE_32MA);
	bc.test_v(PRECMP_BUCK3FB_INTB_10,  tnum++, "Pin33,close(K22,30,31) ", 1.9, 2.1, "V");
	dcm.InitPPMU("FOUT_INTB");
	dcm.Disconnect("FOUT_INTB");


	//pin24 FOUT

	cbite.SetOn(K22_AGNDFS_SHRT, K25_FOUT_FXVIA, K26_FOUT_DCM, K106_FXVI1_7_A, -1);
	delay_ms(1);
	vi.i = -0.001;
	dcm.Connect("FOUT_INTB");
	dcm.SetPPMU("FOUT_INTB", DCM_PPMU_FVMI, 2.0, DCM_PPMUIRANGE_32MA);
	bc.test_v(A1_FOUT_RSTB_FCCU2, vi, tnum++, "Pin24,close(K25,26,106) ", 1.9, 2.1, "V");
	dcm.InitPPMU("FOUT_INTB");
	dcm.Disconnect("FOUT_INTB");

	//Pin29 AMUX

	cbite.SetOn(K22_AGNDFS_SHRT, K114_FXVI5_11_A, K116_QVMH0, K119_QVML0, - 1);
	delay_ms(1);
	
	bc.test_cap(A5_AMUX, tnum++, "C26,close(K22,114),2.2nF", 0.8, 10, "nF");

	A5_AMUX.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	ALL_QVM.Connect();

	BYTE QVM_GP1[2] = { K122_QVM_S1357, K121_QVM_S2468 };
	double tres[SITE_NUM];
	for (int grp = 0; grp < 2; grp++)
	{

		cbitclose(QVM_GP1[grp]);

		delay_ms(8);

		ALL_QVM.MeasureLADC(50, 10, QVMe_LADC_2V, QVMe_LADC_400KHz, MEAS_NORMAL);
		for (int siten = 0; siten < 4; siten++)
			tres[siten * 2 + grp] = qvm_grp[siten * 2 + grp].GetMeasResult(siten * 2 + grp)*1e3;


		cbitopen(QVM_GP1[grp]);
	}
	bc.log(tnum++, "QVM,close(K22,114,116,119)", tres, 990, 1010, "mV");
	A5_AMUX.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	A5_AMUX.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	//ALL_QVM.Disconnect();
	//Pin49 Wake1
	cbite.SetOn(K22_AGNDFS_SHRT, K47_WAKE1_FXVIB, K111_FXVI3_9_B,K48_WAKE1_DCM, -1);
	delay_ms(1);
	vi.i = -0.001;
	dcm.Connect("SDA_WAKE1");
	dcm.SetPPMU("SDA_WAKE1", DCM_PPMU_FVMI, 2.0, DCM_PPMUIRANGE_32MA);
	bc.test_v(B3_WAKE12, vi,tnum++, "Pin49,close(K22,30,31) ", 1.9, 2.1, "V");
	dcm.InitPPMU("SDA_WAKE1");
	dcm.Disconnect("SDA_WAKE1");

	//Pin53 VBOOST
	cbite.SetOn(K22_AGNDFS_SHRT, K50_VBOOST_FXVIB, K40_VBOOST_ACM, K109_FXVI2_8_B, K108_FXVI2_8_A ,- 1);
	delay_ms(1);
	vi.i = -0.001;
	B2_PREBOOT_VBOOST.Set(FV, 2.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	bc.test_v(VDDIO_VBOOST_0,  tnum++, "Pin53,close(K22,50,40,108,109) ", 1.9, 2.1, "V");
	B2_PREBOOT_VBOOST.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B2_PREBOOT_VBOOST.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);

	//-------------SLT Test----------------//

	cbite.SetOn(K22_AGNDFS_SHRT, K83_BUCKIN_PREFB, K45_PREFB_FXVIA, K112_FXVI4_10_A, - 1);
	delay_ms(1);
	A4_PSYNC_PREFB.Set(FV, 2.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	bc.test_v(BUCK1IN_2, tnum++, "SLT BUCK1IN_PREFB,close(K83,45) ", 1.99, 2.01, "V");
	bc.test_v(BUCK2IN_3, tnum++, "SLT BUCK2IN_PREFB,close(K83,45) ", 1.99, 2.01, "V");
	bc.test_v(BUCK3IN_4, tnum++, "SLT BUCK3IN_PREFB,close(K83,45) ", 1.99, 2.01, "V");
	A4_PSYNC_PREFB.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	A4_PSYNC_PREFB.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);

	cbite.SetOn(K22_AGNDFS_SHRT, K80_PRECSP_PREFB_SHRT, K45_PREFB_FXVIA, K112_FXVI4_10_A,K39_PRECSP_ACM, -1);
	delay_ms(1);
	A4_PSYNC_PREFB.Set(FV, 2.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	bc.test_v(PRECSP_BUCK2FB_9, tnum++, "SLT PRECSP_PREFB,close(K80,45,39) ", 1.99, 2.01, "V");

	A4_PSYNC_PREFB.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	A4_PSYNC_PREFB.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);

	//SLT PRE

	cbite.SetOn(K22_AGNDFS_SHRT, K11_PRE_SLT, K49_VSUP2_FXVIB, K113_FXVI4_10_B, K39_PRECSP_ACM, K41_PREGLS_FXVIB, K42_PRESW_FXVIB, K43_PREGHS_FXVIB, K104_FXVI0_6_A, K105_FXVI0_6_B, K106_FXVI1_7_A, K107_FXVI1_7_B, K21_PADF_AGNDF, -1);
	delay_ms(1);
	B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//C20
	bc.test_cap(B4_VSUP_LDO2OUT, tnum++, "C20,close(K11,49,113),4.7uF", cap4p7uF_l, cap4p7uF_h, "uF");
	//MOS DIODE
	B4_VSUP_LDO2OUT.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	vi.i = 0.001;
	bc.test_v(B0_PRESW_LDO1IN,vi, tnum++, "SLT MOS1 OFF,close(K11,49,113,42,104,105) ", 0.3, 0.6, "V");
	vi.i = -0.001;
	bc.test_v(B0_PRESW_LDO1IN, vi, tnum++, "SLT MOS2 OFF,close(K11,49,113,42,104,105,21) ", -0.6, -0.3, "V");

	cbite.SetOn(K22_AGNDFS_SHRT, K11_PRE_SLT, K49_VSUP2_FXVIB, K113_FXVI4_10_B, K39_PRECSP_ACM,  K42_PRESW_FXVIB, K43_PREGHS_FXVIB, K104_FXVI0_6_A, K105_FXVI0_6_B, K106_FXVI1_7_A, K107_FXVI1_7_B, K21_PADF_AGNDF, -1);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	vi.i = 0.001;
	vi.delay = 20;
	bc.test_v(B0_PRESW_LDO1IN, vi, tnum++, "SLT MOS1 ON,close(K11,49,113,42,104,105) ", -0.01, 0.1, "V");
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);


	cbite.SetOn(K22_AGNDFS_SHRT, K11_PRE_SLT, K45_PREFB_FXVIA, K49_VSUP2_FXVIB, K113_FXVI4_10_B, K39_PRECSP_ACM, K42_PRESW_FXVIB, K41_PREGLS_FXVIB, K104_FXVI0_6_A, K105_FXVI0_6_B, K106_FXVI1_7_A, K107_FXVI1_7_B, K21_PADF_AGNDF, -1);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	vi.i = -0.001;
	vi.delay = 20;
	bc.test_v(B0_PRESW_LDO1IN, vi, tnum++, "SLT MOS2 ON,close(K11,49,113,42,104,105,21) ", -0.1, 0.01, "V");
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);


	cbite.SetOn(K22_AGNDFS_SHRT, K11_PRE_SLT, K45_PREFB_FXVIA, K49_VSUP2_FXVIB, K113_FXVI4_10_B, K39_PRECSP_ACM, K42_PRESW_FXVIB, K43_PREGHS_FXVIB, K104_FXVI0_6_A, K105_FXVI0_6_B, K106_FXVI1_7_A, K107_FXVI1_7_B, -1);
	delay_ms(1);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B4_VSUP_LDO2OUT.Set(FV, 1.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	
	bc.test_v(PRECSP_BUCK2FB_9,tnum++, "SLT PRE L1R ON,close(K11,39,49,113,43) ", 0.98, 1.02, "V");
	B4_VSUP_LDO2OUT.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B4_VSUP_LDO2OUT.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	B1_PREGHS_PREGLS_LDO1OUT.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);

	//SLT BUCK1 /2/3

	cbite.SetOn(K22_AGNDFS_SHRT, K85_BUCKSW_PD, K4_BUCK3SW_ACM, K33_BUCK12SW_ACM, K21_PADF_AGNDF ,- 1);
	delay_ms(1);
	bc.test_r(BUCK1SW_5, 20,tnum++, "SLT BUCK1 R22,close(K85,33,21) ", 9, 12, "Ohm");
	bc.test_r(BUCK2SW_6, 20, tnum++, "SLT BUCK2 R23,close(K85,33,21) ", 9, 12, "Ohm");
	bc.test_r(BUCK3SW_BOOSTLS_7, 20, tnum++, "SLT BUCK3 R24,close(K85,4,21) ", 9, 12, "Ohm");

	cbite.SetOn(K22_AGNDFS_SHRT, K21_PADF_AGNDF,K86_BUCK_SLT, K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K21_PADF_AGNDF, -1);
	delay_ms(1);
	bc.test_cap(PREFB_BUCK1FB_8,tnum++, "SLT BUCK1 C21,close(K86,36,21) ", 13, 26, "uF");
	bc.test_cap(PRECSP_BUCK2FB_9, tnum++, "SLT BUCK2 C22,close(K86,29,21) ", 13, 26, "uF");
	bc.test_cap(PRECMP_BUCK3FB_INTB_10, tnum++, "SLT BUCK3 C23,close(K86,7,21) ", 13, 26, "uF");

	vi.v = 1.0;
	vi.acm_v_range1 = ACM200_3p6V;
	vi.acm_i_range1 = ACM200_100MA;
	vi.delay = 10;//ms
	cbite.SetOn(K22_AGNDFS_SHRT, K86_BUCK_SLT, K4_BUCK3SW_ACM, K33_BUCK12SW_ACM,K36_BUCK1FB_ACM, K29_BUCK2FB_ACM, K7_BUCK3FB_ACM, K21_PADF_AGNDF, -1);
	delay_ms(1);
	bc.test_v(PREFB_BUCK1FB_8, BUCK1SW_5,vi, tnum++, "SLT BUCK1 L2,close(K86,36,21) ", 0.99, 1.01, "V");
	bc.test_v(PRECSP_BUCK2FB_9, BUCK2SW_6, vi, tnum++, "SLT BUCK2 L3,close(K86,29,21) ", 0.99, 1.01, "V");
	bc.test_v(PRECMP_BUCK3FB_INTB_10, BUCK3SW_BOOSTLS_7, vi, tnum++, "SLT BUCK3 L4,close(K86,7,21) ", 0.99, 1.01, "V");

	//SLT Boost

	/*cbite.SetOn(K22_AGNDFS_SHRT, K34_BOOST_SLT, K85_BUCKSW_PD, K46_PREFB_ACM, K3_BOOSTLS_ACM, -1);
	delay_ms(1);
	BUCK3SW_BOOSTLS_7.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	bc.test_r(PREFB_BUCK1FB_8, 20, tnum++, "SLT BOOST R25,close(K34,85,46,3) ", 9, 12, "Ohm");
	BUCK3SW_BOOSTLS_7.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);*/

	vi.i = -0.001;
	vi.mode = FI;
	vi.v_range1 = FXVIe_PLUS_3p6V;
	vi.i_range1 = FXVIe_PLUS_10MA;
	cbite.SetOn(K22_AGNDFS_SHRT, K34_BOOST_SLT, K45_PREFB_FXVIA, K112_FXVI4_10_A, K3_BOOSTLS_ACM, -1);
	delay_ms(1);
	BUCK3SW_BOOSTLS_7.Set(FV, 0.2, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	bc.test_v(A4_PSYNC_PREFB, vi,tnum++, "SLT BOOST L5,close(K34,46,3) ", 0.19, 0.21, "V");
	BUCK3SW_BOOSTLS_7.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);


	cbite.SetOn(K22_AGNDFS_SHRT, K21_PADF_AGNDF,K81_LDO_CAPS, K50_VBOOST_FXVIB, K109_FXVI2_8_B, K108_FXVI2_8_A, K3_BOOSTLS_ACM, -1);
	delay_ms(1);
	BUCK3SW_BOOSTLS_7.Set(FV, 0.0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	bc.test_cap(B2_PREBOOT_VBOOST, tnum++, "SLT BOOST C24,close(K34,81,3,50) ", 13, 26, "uF");
	BUCK3SW_BOOSTLS_7.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	vi.i = -0.01;
	vi.mode = FI;
	vi.v_range1 = FXVIe_PLUS_3p6V;
	vi.i_range1 = FXVIe_PLUS_10MA;
	vi.delay = 40;
	cbite.SetOn(K22_AGNDFS_SHRT, K34_BOOST_SLT,K21_PADF_AGNDF, K81_LDO_CAPS, K50_VBOOST_FXVIB, K109_FXVI2_8_B, K108_FXVI2_8_A, K3_BOOSTLS_ACM, -1);
	delay_ms(1);
	BUCK3SW_BOOSTLS_7.Set(FV, 0.0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);

	bc.test_v(B2_PREBOOT_VBOOST,vi, tnum++, "SLT BOOST Diode D1,close(K34,81,3,50) ", -0.4, -0.18, "V");

	BUCK3SW_BOOSTLS_7.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);


	cbite.SetOn(K22_AGNDFS_SHRT, K34_BOOST_SLT, K50_VBOOST_FXVIB, K109_FXVI2_8_B, K108_FXVI2_8_A, K53_LDO1IN_FXVIB, K105_FXVI0_6_B, K104_FXVI0_6_A, - 1);
	delay_ms(1);
	B2_PREBOOT_VBOOST.Set(FV, 1.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	
	vi.i = -0.001;
	vi.mode = FI;
	vi.v_range1 = FXVIe_PLUS_3p6V;
	vi.i_range1 = FXVIe_PLUS_10MA;
	vi.delay = 10;
	bc.test_v(B0_PRESW_LDO1IN, vi, tnum++, "SLT VBOOST_LDO1IN,close(K34,50,53) ", 0.99, 1.01, "V");
	B2_PREBOOT_VBOOST.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	B2_PREBOOT_VBOOST.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);


	//-----------SLT END----------------//


	//--------FPVI Matrix-------------//
	cbite.SetOn(K88_FPVI1H_A, K96_FPVI0H_A, K92_FPVI1L_A, K100_FPVI0L_A, K63_CSP_FB_FPVIHL, K64_PGND_FPVIH, K65_BUCK1IN_FPVIH, K67_SW_FPVIL, K68_BOOSTLS_FPVIL, -1);
	delay_ms(1);
	//all open
	bc.contact_check(FPVIM, tnum++, "FPVI A Contact Check close(K88,96,92,100)", 2.5, 3.5, "NA");

	cbite.SetOn(K88_FPVI1H_A, K96_FPVI0H_A, K92_FPVI1L_A, K100_FPVI0L_A, K64_PGND_FPVIH, K20_PADS_ACM, K21_PADF_AGNDF, K22_AGNDFS_SHRT, -1);
	delay_ms(1);
	bc.contact_check(FPVIM, tnum++, "FPVI A Contact Check close(K88,96,64)", 2.5, 3.5, "NA");//high pass ,low fail
	
	cbite.SetOn(K88_FPVI1H_A, K96_FPVI0H_A, K92_FPVI1L_A, K100_FPVI0L_A, K66_PGND_FPVIL, K20_PADS_ACM, K21_PADF_AGNDF, K22_AGNDFS_SHRT, -1);
	delay_ms(1);
	bc.contact_check(FPVIM, tnum++, "FPVI A Contact Check close(K92,100,66)", 2.5, 3.5, "NA");//LOW pass ,high fail
	

	cbite.SetOn(K89_FPVI1H_B, K93_FPVI1L_B, K97_FPVI0H_B, K101_FPVI0L_B ,- 1);
	delay_ms(1);
	//all open
	bc.contact_check(FPVIM, tnum++, "FPVI B Contact Check close(K89,93,97,101)", 2.5, 3.5, "NA");


	cbite.SetOn(K90_FPVI1H_C, K94_FPVI1L_C, K98_FPVI0H_C, K102_FPVI0L_C, -1);
	delay_ms(1);
	//all open
	bc.contact_check(FPVIM, tnum++, "FPVI C Contact Check close(K90,94,98,102)", 2.5, 3.5, "NA");

	cbite.SetOn(K91_FPVI1H_D, K95_FPVI1L_D, K99_FPVI0H_D, K103_FPVI0L_D, -1);
	delay_ms(1);
	//all open
	bc.contact_check(FPVIM, tnum++, "FPVI D Contact Check close(K91,95,99,103)", 2.5, 3.5, "NA");

	cbite.SetOn(K91_FPVI1H_D, K95_FPVI1L_D, K99_FPVI0H_D, K103_FPVI0L_D, K42_PRESW_FXVIB, K44_PREBOOT_FXVIB, K104_FXVI0_6_A, K105_FXVI0_6_B, K108_FXVI2_8_A, K109_FXVI2_8_B ,- 1);
	delay_ms(1);
	bc.contact_check(FPVIM, tnum++, "FPVI D Contact Checkclose(K91,95,99,103,42,44)", -0.5, 0.5, "NA");


	//--------FPVI Matrix END-------------//



	//--------TMU Matrix-------------//
	//dbuff
	cbite.SetOn(K22_AGNDFS_SHRT, K30_INTB_ACM, K15_PGOOD_FXVIA, K108_FXVI2_8_A,K69_INTB_DBUFF, K72_PGOOD_DBUFF, -1);
	delay_ms(1);
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//A2_PGOOD.Set(FI, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	//A2_PGOOD.MeasureVI(30, 10);
	//A2_PGOOD.MeasureVI(4000, 10, FXVIe_PLUS_MI_X1, MEAS_AWG);
	//STSEnableMeas(&A2_PGOOD);
	//STSAWGRun(1);
	//PRECMP_BUCK3FB_INTB_10.Pulse(5.0, 1000, -500, 200, 10);

	bc.test_r(A2_PGOOD, 20, tnum++, "TMU Matrix R26,29,close(K30,15,69,72) ", 90, 110, "Ohm");

	cbite.SetOn(K22_AGNDFS_SHRT, K30_INTB_ACM, K4_BUCK3SW_ACM, K69_INTB_DBUFF, K74_BUCK3SW_DBUFF, -1);
	delay_ms(1);
	bc.test_r(BUCK3SW_BOOSTLS_7, 20, tnum++, "TMU Matrix R26,31,close(K30,4,69,74) ", 90, 110, "Ohm");
	cbite.SetOn(K22_AGNDFS_SHRT, K30_INTB_ACM, K33_BUCK12SW_ACM, K69_INTB_DBUFF,  K75_BUCK2SW_DBUFF, K76_BUCK1SW_DBUFF, -1);
	delay_ms(1);
	bc.test_r(BUCK1SW_5, 20, tnum++, "TMU Matrix R26,33,close(K30,33,69,76) ", 90, 110, "Ohm");
	bc.test_r(BUCK2SW_6, 20, tnum++, "TMU Matrix R26,32,close(K30,33,69,75) ", 90, 110, "Ohm");
	PRECMP_BUCK3FB_INTB_10.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);

	//tmua
	cbite.SetOn(K22_AGNDFS_SHRT, K25_FOUT_FXVIA, K106_FXVI1_7_A,K42_PRESW_FXVIB, K105_FXVI0_6_B, K104_FXVI0_6_A, K70_FOUT_TMUA, K73_PRESW_BOOSTLS_TMU, -1);
	delay_ms(1);
	A1_FOUT_RSTB_FCCU2.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	bc.test_r(B0_PRESW_LDO1IN, 20, tnum++, "TMU Matrix R27,30,close(K25,42,70,73) ", 90, 110, "Ohm");
	A1_FOUT_RSTB_FCCU2.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);

	cbite.SetOn(K22_AGNDFS_SHRT, K42_PRESW_FXVIB, K105_FXVI0_6_B, K104_FXVI0_6_A, K43_PREGHS_FXVIB, K106_FXVI1_7_A, K107_FXVI1_7_B, K73_PRESW_BOOSTLS_TMU, K77_PREGHS_GLS_TMU, -1);
	delay_ms(1);
	B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	bc.test_r(B1_PREGHS_PREGLS_LDO1OUT, 20, tnum++, "TMU Matrix R27,35,close(K25,43,73,77) ", 90, 110, "Ohm");
	B0_PRESW_LDO1IN.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	//tmub	
	cbite.SetOn(K22_AGNDFS_SHRT, K17_FIN_FXVIA, K104_FXVI0_6_A, K3_BOOSTLS_ACM, K71_FIN_TMUB, K73_PRESW_BOOSTLS_TMU, -1);
	delay_ms(1);
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	bc.test_r(BUCK3SW_BOOSTLS_7, 20, tnum++, "TMU Matrix R28,34,close(K17,3,71,73) ", 90, 110, "Ohm");

	cbite.SetOn(K22_AGNDFS_SHRT, K17_FIN_FXVIA, K104_FXVI0_6_A, K77_PREGHS_GLS_TMU, K71_FIN_TMUB,K41_PREGLS_FXVIB, K106_FXVI1_7_A, K107_FXVI1_7_B, -1);
	delay_ms(1);
	bc.test_r(B1_PREGHS_PREGLS_LDO1OUT, 20, tnum++, "TMU Matrix R28,36,close(K17,41,71,77) ", 90, 110, "Ohm");
	A0_FIN_DBG_ERR_FCCU1.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);

	
	double tres1[SITE_NUM];
	cbite.SetOn(K126_DBUFF_S1357, K22_AGNDFS_SHRT, K30_INTB_ACM, K69_INTB_DBUFF ,- 1);
	delay_ms(1);
	bc.test_qtmu(PRECMP_BUCK3FB_INTB_10, qtmu_grp, QTMUe_SINGLE_SOURCE_A, tnum++, "INTB Pulse,close(K126,22,30,69),QTMU_A", 950, 1050, "uS", tres1);
	
	for (int siten = 0; siten < 4; siten++)
		tres[siten * 2 + 0] = tres1[siten * 2 + 0];


	cbite.SetOn(K125_DBUFF_S2468, K22_AGNDFS_SHRT, K30_INTB_ACM, K69_INTB_DBUFF, -1);
	delay_ms(1);
	bc.test_qtmu(PRECMP_BUCK3FB_INTB_10, qtmu_grp, QTMUe_SINGLE_SOURCE_A, tnum++, "INTB Pulse,close(K126,22,30,69),QTMU_A", 950, 1050, "uS", tres1);
	for (int siten = 0; siten < 4; siten++)
		tres[siten * 2 + 1] = tres1[siten * 2 + 1];

	bc.log(tnum++, "INTB Pulse,close(K126,22,30,69),QTMU_A", tres, 950, 1050, "uS");


	//--------TMU Matrix END-------------//

	
	//*** Power off ***/
	for (int i = 0; i < 12; i++)
		acm_grp[i].Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	for (int i = 0; i < 6; i++)
		fxvie_grp[i].Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);

	dcm.InitPPMU("DCM_ALLPINS");
	dcm.InitMCU("DCM_ALLPINS");
	dcm.Disconnect("DCM_ALLPINS");
	ALL_QVM.Disconnect();
	FPVIM.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
	
	cbite.SetOn(-1);
	delay_ms(2);
	


	/*********************** User Define End ************************/
	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	/* Common usage format, don't change this if no specific need   */
	if (board_check_repeat < 0)
		bc.Display();
	nBtn = bc.get_nBtn();
	flag_pass = bc.IsCheckPass();
	bc.report();
	//////////////////////////////////////////////////////////////////


	return TRUE;
}


///////////////////////////////////////////////////////////////////////////
/* run_diags() define the boardcheck flow, as a part of boardcheck library
don't change this function if no specific need       				 */
///////////////////////////////////////////////////////////////////////////
BOOL run_diags(void)
{
	int nBtn = BTN_REDO;
	BOOL flag_pass = FALSE;

	if (MessageBoxA(NULL, "��ϼ�����ʼ! \n\n�����������ȷ�ϲ�������û����Ʒ��ѡ��-��(Y)\n����˳���ѡ��-��(N)", "�����ʾ�Ի���", MB_YESNO) == IDNO){
		PostQuitMessage(0);
		return FALSE;
	}

	if (board_check_repeat < 0){
		while ((nBtn == BTN_REDO) && (flag_pass == FALSE))
		{
			board_check_function(nBtn, flag_pass);
		}
		if ((nBtn == BTN_EXIT) || (nBtn == BTN_CANCEL))
			PostQuitMessage(0);
		if (flag_pass == TRUE)
			MessageBoxA(NULL, "��ϳɹ���\n����ȷ�ϣ���ʼ����", "�����ʾ�Ի���", MB_OK);
	}

	string message_str;
	message_str = "�ظ�����" + int2str(board_check_repeat) + "��\n����ȷ����ť��ʼ\n����������Զ��˳�\n������鿴 bc.csv";
	if (board_check_repeat > 0)
		MessageBoxA(NULL, message_str.c_str(), "�����ʾ�Ի���", MB_OK);

	while (board_check_repeat-- > 0)
	{
		board_check_function(nBtn, flag_pass);
		delay_ms(100);

		if (board_check_repeat == 1)
			PostQuitMessage(0);
	}


	return TRUE;
}
