/********************************************************************/
/*              Send  Command and Read Response Example             */
/*                                                                  */
/* This code demonstrates send command and read response data via   */
/* GPIB, serial port and VXI-11 interafcces by using VISA.	        */
/*                                                                  */
/* The general flow of the code is                                  */
/*      Open Resource Manager                                       */
/*      Open VISA Session				                            */
/*      Query Indetification Information							*/
/*      Send Command to Set Configuration                           */
/*      Send Command to Set Setpoint							    */
/*      Send Command to Head Down and Start Flow                    */
/*      Query Air Temperature								        */
/*      Send Command to Head Up and Stop Flow                       */
/*      Close the VISA Session                                      */
/********************************************************************/


//#define _CRT_SECURE_NO_DEPRECATE
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
//#include <conio.h>
#include "stdafx.h"
#include "exGPIB.h"
#include "visa.h"

#define SUCCESS 0
// VS2005���������Ӳ���->
#if defined(_MSC_VER) && (_MSC_VER == 1400)
#pragma comment(lib,"User32.lib")
extern "C" WINBASEAPI HWND WINAPI GetConsoleWindow();
#endif
// VS2005���������Ӳ���<-
#pragma comment(lib,"visa32.lib")
///NODEFAULTLIB:msvcrt.lib
static ViSession defaultRM;
static ViSession instr;
static ViStatus status; 
static ViUInt32 retCount;
static ViUInt32 writeCount;
static unsigned char buffer[100];
static char stringinput[512];
static char resourcename[50];
int csite;
BYTE sitesta1[SITE_NUM];
#define SERIAL_C \
		StsGetSiteStatus(sitesta1, SITE_NUM); \
        for(csite=0;csite<SITE_NUM;csite++) \
			if(sitesta1[csite]) \

#define AIRTEMP_CHECK_COUNT 10
#define LTIME STSGetTimeElapsed(8)
eGPIB::eGPIB(){
	char_setup();
}
void eGPIB::char_setup(){

	tempsite = -1;
	initstatus = -1;
	retest_count_limit=5;
	retest_type=0;
	retest_count=0;
	loopcount = 1;
	loopindex = 0;
	tmpcount = 1;
	tmp_grp[0] = 25;
    tmpindex=0;
    tmp_accuracy=2.0;
	cool_down_temp = -20;
	defrost_temp = 85;
	air_temp_in_valid_ranage = 2.0;
	soaktime = 15000;//ms
	cool_down_target_temp=45.0;
	 defrost_target_temp=0.0;
	 maxloopcount_captemp = 40;
	 max_temp = 205;
	 min_temp = -75;
	dieid=1;
	defrosttime = 0;
	cooldowntime = 0;
	TS = 0.5;
	KR = 2.0;
	TN = 1.2;
	TV = 0;
	debug_window_enable = false;
	gpib_enable = false;
	gpib_pause = false;
}
void eGPIB::userload(int enable_gpib){
	if (enable_gpib == 1)
	{
		gpib_enable = true;
		debug_window_enable = true;
	}
	else if (enable_gpib>1)
	{
		debug_window_enable = true; 
		gpib_enable = false;
	}
	else
	{
		debug_window_enable = false;
		gpib_enable = false;
	}


	if (enable_gpib)
	{
		// set control window
		if (AllocConsole())
		{
			SetConsoleTitleA("Debug Window");

			//freopen("conin$", "r+t", stdin); // in
			freopen("conout$", "w+t", stdout); // out
			freopen("conout$", "w+t", stderr);
			::DeleteMenu(GetSystemMenu(GetConsoleWindow(), FALSE), SC_CLOSE, MF_BYCOMMAND);
		}

		printf("Debug Window for printf output\n");
		if (gpib_enable)
			printf("Debug Window Enabled for GPIB Temp Char\n");
	}

}
void eGPIB::set_soaktime(double stime)
{
	soaktime = stime;
}
void eGPIB::cap_temp_site(int site)//-1 for all sites
{
	tempsite = site;
}

void eGPIB::userexit(){
	if (debug_window_enable)
	{ 
		fclose(stderr);
		fclose(stdin);
		fclose(stdout);
		FreeConsole();

	}
	if (gpib_enable)
	{
		status = viClose(instr);
		status = viClose(defaultRM);
	}

}
void eGPIB::tempcycle_setting(double *tempgrp, int size)
{
	for (int i = 0; i < size; i++)
		tmp_grp[i] = tempgrp[i];
	tmpcount = size;

}
void eGPIB::set_loopcount(int lcount)
{
	loopcount = lcount;
}

void eGPIB::set_accuracy(double accuracy)
{
	tmp_accuracy = accuracy;
}
eGPIB::~eGPIB(){

}
void eGPIB::add_temp_func(device_temp_read_func a_meas_func)
{
	meas_func = a_meas_func;
}
double eGPIB::get_current_temp(int state)
{
	double temp=0;
	int sitecount = 0;
	if (tempsite == -1)
	{
		SERIAL_C{
			temp += meas_func(csite, state);
			sitecount++;
		}
		temp = temp / sitecount;
	}
	else
		temp = meas_func(tempsite, state);
	return temp;
}
double eGPIB::get_set_temp()
{

	return tmp_grp[tmpindex];
}
int eGPIB::sot()
{
	printf("START\n");
	int headstaus;
	if (!gpib_enable)
		return 0;
	int ch;
	int skey = 0;

	if (_kbhit()){//����а������£���_kbhit()����������
		//for (int i = 0; i < 10;i++)
		//{ 
			ch = _getch();//ʹ��_getch()������ȡ���µļ�ֵ

			if ((ch == 83) || (ch == 115))// S or s
			{
				gpib_pause = !gpib_pause;
				//gpib_pause = 1;
				printf("S pressed, GPIB Paused = %d\n", gpib_pause);
	
			}
			if ((ch == 82) || (ch == 114))// R or r ,retest current sample from first temp.
			{
				tmpindex = 0;
				loopindex = 0;
				printf("R pressed, Retest current die from fist temp \n");
			}
	//	}
		//if (skey == 1)
	//	{

		//}

	}
	
	if (gpib_pause)
		return 0;
	if (init() == SUCCESS)
	{
		// Set setpoint
		STSSetTimeCheck(8);
		
		strcpy_s(stringinput, "HEAD?\n"); // query head status.
		SendCommandAndRead((ViBuf)stringinput);
		sprintf_s(readtemp, "%s", buffer);
		headstaus = atoi(readtemp);
	
		if (headstaus == 0)//head is up
		{
			strcpy_s(stringinput, "HEAD 1\n"); // Head Down and Start Flow
			SendCommand((ViBuf)stringinput);
			Sleep(3000);//for head
		}
		
		dut_sample();
		return 1;
	}
	else
	{
		StsMessageBox("GPIB SETUP Failed","eGPIB");
		return -1;
	}
		
}

// measure DUT temp, store in current_temp and process the loop if needed
int eGPIB::dut_sample()
{
	
	double t0;
	double t1;
	SYSTEMTIME sys;
	double elapsed_soaktime=0;
	double elapsed_starttime;


	e0 = e1 = e2 = 0;
	y0 = y1 = tmp_grp[tmpindex];

	if ((loopcount > 1) && (loopindex >= 0))//loop test found, set to last temp
	{
		strcpy_s(stringinput, "TEMP?\n"); // query Air Temperature.
		SendCommandAndRead((ViBuf)stringinput);
		sprintf_s(readtemp, "%s", buffer);
		read_temp = atof(readtemp);
		sprintf_s(stringinput, "SETP %4.2f\n", read_temp);//set to read air temp
	}
	else
		sprintf_s(stringinput, "SETP %4.2f\n", tmp_grp[tmpindex]);//set to target temp
	///strcpy_s(stringinput, "SETP -10\n");
	SendCommand((ViBuf)stringinput);
	temp_target = tmp_grp[tmpindex];

	// sample delay has elapsed, do the sampling

	current_temp = get_current_temp(0);//initial setup
	elapsed_soaktime = soaktime;
	do
	{
		TS = 0.5;
		//KR = 2.0;
		current_temp = get_current_temp(1);
		e0 = temp_target - current_temp;
		//y0=y1 + KR*(1+TS/TN+TV/TS)*e0 - KR*(1+2*TV/TS)*e1 + KR*(TV/TS)*e2;
		//  y0=y1 + KR*(1+TV/TS)*(e0+3) - KR*(1+2*TV/TS-TS/TN)*e1 + KR*(TV/TS)*e2;
		//y0=y1 + KR*(1+TS/TN+TV/TS)*e0 - KR*(1+2*TV/TS)*e1 + KR*(TV/TS)*e2;
		y0 = y1 + KR*(1 + TV / TS)*e0 - KR*(1 + 2 * TV / TS - TS / TN)*e1 + KR*(TV / TS)*e2;
		//y0 = (temp_target + 8 * e0*fabs(e0) + 19 * y1) / 20;

		if (y0<temp_target - 90)
			y0 = temp_target - 90;

		if (y0<min_temp)
			y0 = min_temp;
		if (y0>temp_target + 90)
			y0 = temp_target + 90;


		if (y0>max_temp)
			y0 = max_temp;
		if((current_temp<-100) || (current_temp >200))// if socket open,or get a wrong temp set temp to 25C
		{
			y0=25;
			printf("abnormal temperature found,please check setup.temperature force to 25C\n");
		}

		sprintf_s(stringinput, "SETP %4.2f\n", y0);//set to target temp
		///strcpy_s(stringinput, "SETP -10\n");
		SendCommand((ViBuf)stringinput);
		t0 = LTIME;
		int i;
		for (i = 0; i < maxloopcount_captemp; i++)
		{
			Sleep(100);
			strcpy_s(stringinput, "TEMP?\n"); // query Air Temperature.
			SendCommandAndRead((ViBuf)stringinput);
			sprintf_s(readtemp, "%s", buffer);
			read_temp = atof(readtemp);
			if (fabs(y0 - read_temp) < air_temp_in_valid_ranage) break;//debug to check good waiting time
	
		}
		strcpy_s(stringinput, "SETP?\n"); // query setpoint Temperature.
		SendCommandAndRead((ViBuf)stringinput);
		sprintf_s(readtemp, "%s", buffer);
		read_temp = atof(readtemp);
	/*	if (fabs(y0 - read_temp) > 1)
		{
			initstatus = -1;
			init();
		}*/


		if ((fabs(e0) < tmp_accuracy) && (elapsed_soaktime == soaktime))
		{
			elapsed_starttime = LTIME;
			elapsed_soaktime = soaktime - 1;
		}
		else if ((fabs(e0) < tmp_accuracy) && (elapsed_soaktime < soaktime))
		{
			t1 = LTIME;
			elapsed_soaktime = soaktime - (t1 - elapsed_starttime);
			if ((t1 - t0)>20000) elapsed_soaktime = soaktime;
			if (elapsed_soaktime < 0)elapsed_soaktime = 0;
		}
		else
		{
			elapsed_soaktime = soaktime;
		}
		char buff[180];
		GetLocalTime(&sys);
		sprintf_s(buff, "%02d:%02d:%02d target %4.2f act %4.2f err %4.2f forced %4.2f soaktime %4.2fs\n", sys.wHour, sys.wMinute, sys.wSecond, temp_target, current_temp, -e0, y0, elapsed_soaktime / 1e3);
		printf(buff);
		t1 = LTIME;
		TS = (t1 - t0)/1000;
		if (TS < 0.1)TS = 0.1;
		else if (TS>10) TS = 10.0;
	/*	if (i == 2)
			y1 = read_temp;
		else*/
		//init();
			y1 = y0;
		e2 = e1; e1 = e0; e0 = 0;
		int ch;
		if (_kbhit()){//����а������£���_kbhit()����������
			ch = _getch();//ʹ��_getch()������ȡ���µļ�ֵ

			if ((ch == 83) || (ch == 115))//S or s
			{

				elapsed_soaktime = 0;
				gpib_pause = 1;
				printf("Loop aborted, thermal stream will continue with last force temperature. Press S can continue current test loop\n");
			}
			else if((ch == 73) || (ch == 105))//I or i for initial
			{
				//will add some function if needed
				//reinitial manually
				initstatus = -1;
				init();
				printf("reinitial...\n");
			}
		}
			

	} while (elapsed_soaktime>0);

	get_current_temp(2);//off temp measure
	return 1;
}
int eGPIB::eot()
{
	char buff[120];
	int loopc = 10;
	int keyr=0;
	int failed=0;
	unsigned long tm1;
	if (!gpib_enable)
		return 0;
	if (gpib_pause)
		return 0;

	SERIAL_C 
	{
		if (STSGetCurrentDutSwBin(csite)!=1)
		{
			failed=1;
			if(retest_type==0)
			{
				sprintf(buff,"SITE%d test failed,do you want to retest this temperature?", csite+1);
				keyr=StsMessageBox(buff, "eGPIB",MB_YESNO);
				if (keyr==IDYES)
				{
					return 1;
				}

			}

		}

	}
	//retest_type 0 =always ask if failed, 1= continue test,don't care the fail,2=always execute retest, if the retest count > retest count limit then continue next.
	if(retest_type==2)
	{
		if(failed==1)
		{
			retest_count++;
			if(retest_count< retest_count_limit)
				return 1;
		}
	}

	loopindex++;
	if (loopindex >= loopcount)
	{
		loopindex = 0;//inital
		tmpindex++;
	}
	if (tmpindex >= tmpcount)
	{
		tmpindex = 0;
		dieid++;
		// Operation finish
		//deforest or cool down.
		if (tmp_grp[tmpcount - 1] > cool_down_target_temp)//if last temp is hot need cool down
		{
			tm1 = ((20 + (unsigned long)((tmp_grp[tmpcount - 1] - cool_down_target_temp) / 10.0)) * 1000 )/ loopc;
			if (cooldowntime != 0) tm1 = cooldowntime / loopc;
			sprintf_s(stringinput, "SETP %4.2f\n", cool_down_temp);//set to target temp
			SendCommand((ViBuf)stringinput);

			for (int i = 0; i < loopc; i++)
			{
				Sleep(tm1);
				sprintf(buff, "Cool Down Deivce... cool down temp %4.2f C, cool down time %4.2f seconds remaining...\n", cool_down_temp,(double) (loopc - i - 1)*tm1 / 1000);
				printf(buff);
			}
				

		}
		else if (tmp_grp[tmpcount - 1] < defrost_target_temp)//if last temp is cold need defrost
		{
			tm1 = ((12 + (unsigned long)((defrost_target_temp - tmp_grp[tmpcount - 1]) / 15.0)) * 1000) / loopc;
			if (defrosttime != 0) tm1 = defrosttime / loopc;
			sprintf_s(stringinput, "SETP %4.2f\n", defrost_temp);//set to target temp
			SendCommand((ViBuf)stringinput);
	
			for (int i = 0; i < loopc; i++)
			{
				Sleep(tm1);
				sprintf(buff, "Defrost Deivce...defrost temp  %4.2f C, defrost time %4.2f seconds remaining...\n", defrost_temp,(double)(loopc - i - 1)*tm1 / 1000);
				printf(buff);
			}
		}
		sprintf_s(stringinput, "SETP %4.2f\n",25.0);//set to target temp
		SendCommand((ViBuf)stringinput);
		for (int i = 10; i >0; i--)
		{
			Sleep(1000);//1sec
			sprintf(buff, "Thermal Stream set to 25C, time %d seconds remaining...\n", i);
			printf(buff);
		}
	
		strcpy_s(stringinput, "HEAD 0\n"); // Head Up and Stop Flow
		SendCommand((ViBuf)stringinput);
		Sleep(1000); // wait 1 second
		sprintf(buff,"Die ID %d test finished,Click OK to continue", dieid-1);
		StsMessageBox(buff, "eGPIB");//use hotkey instead?
	}

	return 1;
}
int eGPIB::reinit()
{
	if (!gpib_enable)
		return 0;
	char_setup();
	//initstatus = -1;
	return init();
}
int eGPIB::init()
{
	// Open seesion by instrument descriptor
	// ex :
	//		GPIB	: "GPIB0::1::INSTR"
	//		Serial	: "ASRL3::INSTR" //3-measn com3,can change to related number
	//      VXI-11	: "TCPIP0::192.168.1.6::inst0::INSTR"
	// note :
	//		Serial	: Have to setup correct baudrate both PC side and TA5000 then send command "%RM\n" to enter remote mode before others operations.
	//		VXI-11	: Have to create session in NI MAX first.

	if (initstatus == SUCCESS) 
		return initstatus ;

	status = viOpenDefaultRM(&defaultRM);
	if (status < VI_SUCCESS)
		return status;

	status = viOpen(defaultRM, "GPIB0::1::INSTR", VI_NULL, VI_NULL, &instr);
	if (status < VI_SUCCESS)
		return status;
	// Set timeout value
	status = viSetAttribute(instr, VI_ATTR_TMO_VALUE, 5000);
	status = viGetAttribute(instr, VI_ATTR_RSRC_NAME, resourcename);
	if (strcmp(resourcename, "ASRL3::INSTR") == 0)
	{
		// Set BAUD
		status = viSetAttribute(instr, VI_ATTR_ASRL_BAUD, 57600);

		// Query indentification to make sure system is ready
		strcpy_s(stringinput, "%RM\n");
		SendCommand((ViBuf)stringinput);
	}
	// Query indentification to make sure system is ready
	strcpy_s(stringinput, "*IDN?\n");
	SendCommandAndRead((ViBuf)stringinput);

	// Set configuration
	strcpy_s(stringinput, "DUTM 0\n"); // switch to Air Mode
	SendCommand((ViBuf)stringinput);

	strcpy_s(stringinput, "DSNS 0\n"); // switch DUT sensor to None for Air Mode
	SendCommand((ViBuf)stringinput);

	strcpy_s(stringinput, "FLSE 18\n"); // Set the main nozzle air flow rate.FLSE nn �C where nn is 4 �C25 scfm
	SendCommand((ViBuf)stringinput);

	sprintf_s(stringinput, "ULIM %4.2f\n", max_temp); // Set max temp
	SendCommand((ViBuf)stringinput);
	sprintf_s(stringinput, "LLIM %4.2f\n",min_temp); // Set min temp
	SendCommand((ViBuf)stringinput);
	/*RAMP
		Set the ramp rate for the currently selected setpoint, in ��C per
		minute.
		RAMP nnn.n �C where nnn.n is 0 to 999.9 in 0.1 ��C per minute steps*/
	/*	strcpy_s(stringinput, "SOAK 5\n");
	SendCommand((ViBuf)stringinput);*/
	// Operation start
	strcpy_s(stringinput, "HEAD 1\n"); // Head Down and Start Flow
	SendCommand((ViBuf)stringinput);
	Sleep(3000);//for head
	initstatus = 0;
	printf("Initial Done\n");
	return initstatus;
}
/*
* Basic function to write command out and read response data back.
*/
void eGPIB::WriteCommandAndRead(ViBuf cmd, BOOL isQuery)
{
	status = viWrite (instr, cmd, (ViUInt32)strlen(stringinput), &writeCount);
	
	// Read response data
	if(isQuery)
	{
		status = viRead (instr, buffer, 100, &retCount);
	   
		buffer[retCount] = '\0';

		//printf("Data read: %*s\n",retCount,buffer);		
	}

	Sleep(100);
}

/*
* Function for just send command out not include read response data back.
*/
void eGPIB::SendCommand(ViBuf cmd)
{
	WriteCommandAndRead(cmd, FALSE);
}

/*
* Function for send command out and read response data back.
*/
void eGPIB::SendCommandAndRead(ViBuf cmd)
{
	WriteCommandAndRead(cmd, TRUE);
}
