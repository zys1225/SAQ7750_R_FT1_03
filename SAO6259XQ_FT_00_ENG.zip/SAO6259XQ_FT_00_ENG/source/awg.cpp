/*****************************************************************************
*                                                                            *
*       Source title:   awg.h									           *
*                       (Universal functions for all SC test projects)       *
*         Written by:   Sky Fu                                                *
*        Description:			                                             *
*                                                                            *
*   Revision History:                                                        *
*                                                                            *
*     mm/dd/yy  r.rr  - Original coding.                                     *
*                                                                            *
*****************************************************************************/

/*
REVISION BLOCK:
-Rev. -- Date --------------------------------------------------
00   12/1/20  Initial.						Sky Fu

----------------------------------------------------------------
*/

#include "stdafx.h"
#include "awg.h"
AWG_FUNC::AWG_FUNC(){
	if (DEBUG_MODE)
		pat_unload = 1;
	else
		pat_unload = 0;
	delaytime = 0;//200us
	pat_loadfailed = 0;
	sts_first_load = 1;
	id = 0;
	pattern_store.clear();
	res_store.clear();
	for (int i = 0; i < SITE_NUM; i++) validsites[i] = 0;
	for (int j = 0; j < 8; j++) twait[j] = 0;
}
AWG_FUNC::~AWG_FUNC(){

}

void AWG_FUNC::awgReload()
{
	if (DEBUG_MODE)
		pat_unload = 1;
	else
		pat_unload = 0;
	pat_loadfailed = 0;
	sts_first_load = 1;
	id = 0;
	pattern_store.clear();
	res_store.clear();
	
}
void AWG_FUNC::StartLoad()
{
	STSSetTimeCheck(6);
	STSSetTimeCheck(7);
	for (int j = 0; j < 8; j++) twait[j] = 0;
	if (DEBUG_MODE)
	{
		if (pat_unload == 1)
		{

			SERIAL validsites[SITE] = 1;
		else
			validsites[SITE] = 0;
		}
		else
		{
			StsGetSiteStatus(sitesta, SITE_NUM);
			for (int i = 0; i < SITE_NUM; i++)
			{
				if (sitesta[i] != validsites[i])
				{
					awgReload();
					SERIAL validsites[SITE] = 1;
				else
					validsites[SITE] = 0;
			
				}

			}
		}
	}

}
void AWG_FUNC::EndLoad()
{
	unsigned int s;

	if (DEBUG_MODE)
	{
		if (pat_unload==1)//DEBUG_MODE-> change to  enable.
		{
			for (unsigned int i = 0; i < pattern_store.size(); i++)
			{
				for (unsigned int ritem = 0; ritem < pattern_store[i].resource.size(); ritem++)
				{
					for ( s = 0; s < res_store.size(); s++)
					{
						if (res_store[s].resource == pattern_store[i].resource[ritem])//arlready exist
						{
							res_store[s].pattern_name.push_back(pattern_store[i].pattern_name);
							res_store[s].samplecount += pattern_store[i].samplecount;
							if (res_store[s].samplecount>4096) res_store[s].reload_needed = 1;
							break;//exit for
						}
					}
					if (s == res_store.size()) //new item
					{
						temp_res.pattern_name.push_back(pattern_store[i].pattern_name);
						temp_res.samplecount = pattern_store[i].samplecount;
						temp_res.resource = pattern_store[i].resource[ritem];
						temp_res.reload_needed = 0;
						res_store.push_back(temp_res);
						temp_res.pattern_name.clear();
					}

				}
			
		
			
			
				
			}
		
		}
		if (pat_loadfailed)
			awgReload();
		else
			pat_unload = 0;//already loaded patterns
	}
	sts_first_load = 0;

}
int AWG_FUNC::res_reload_check(UINT resource)
{
	unsigned int s;
	for (s = 0; s < res_store.size(); s++)
	{
		if (res_store[s].resource == resource)//arlready exist
		{
			return res_store[s].reload_needed;
			
		}
	}
	
	return 1;
}
bool AWG_FUNC::res_pattern_reload_check(UINT resource,char *patname)
{
	unsigned int s;
	for (s = 0; s < res_store.size(); s++)
	{
		if (res_store[s].resource == resource)//arlready exist
		{
		
			break;
		
		}
	}
	if (patname != NULL)//check pattern name also
	{
		string ptname = patname;
		string ptname_o;
		int cmp_rst = 1;
		transform(ptname.begin(), ptname.end(), ptname.begin(), towupper);//same case


		for (unsigned int i = 0; i < pattern_store.size(); i++)
		{
			ptname_o = pattern_store[i].pattern_name;
			transform(ptname_o.begin(), ptname_o.end(), ptname_o.begin(), towupper);//same case
			cmp_rst = ptname_o.compare(ptname);
			if (cmp_rst == 0)
			{
				unsigned int s;
				for (s = 0; s < pattern_store[i].resource.size(); s++)
				{
					if(pattern_store[i].resource[s] == resource) //found the resource for the pattern
					return false;
				}
				//not found any resource for this pattern, need reload and update
				pattern_store[i].resource.push_back(resource);
				if (s < res_store.size())
				{
					res_store[s].samplecount += pattern_store[i].samplecount;
					res_store[s].pattern_name.push_back(ptname);
				}
				else
				{
					temp_res.pattern_name.push_back(ptname);
					temp_res.samplecount = pattern_store[i].samplecount;
					temp_res.resource = resource;
					res_store.push_back(temp_res);
					temp_res.pattern_name.clear();

				}
				return true;
			}
				
		}
		StsMessageBox("AWG Loading wrong .err01", "error", MB_OK);//eror
	}
	else if (s < res_store.size())
	{
		if (res_store[s].samplecount > 4096)
			return true;
		else
			return false;
	}
	else if(s == res_store.size())
	{
		return true;//error;
	}
		 
	return false;
}

void AWG_FUNC::Check()
{
	if (pat_unload == 1)	pat_loadfailed = 1;

}
bool AWG_FUNC::pattern_unloaded(char *patname)
{
	string ptname = patname;
	string ptname_o;
	int cmp_rst=1;
	transform(ptname.begin(), ptname.end(), ptname.begin(), towupper);//same case
	

	for (unsigned int i = 0; i < pattern_store.size(); i++)
	{
		ptname_o = pattern_store[i].pattern_name;
		transform(ptname_o.begin(), ptname_o.end(), ptname_o.begin(), towupper);//same case
		cmp_rst = ptname_o.compare(ptname);
		if (cmp_rst == 0) 
			return false;
	}
	id++;
	return true;
}

BOOL AWG_FUNC::rampi(FPVIe *fpvi_ramp, FPVIe_VRNG v_range, FPVIe_IRNG i_range, FOVIe fovi_cap, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result,  double awgStartValue, double awgStopValue){
		if (interval < 10)	return FALSE;
		if (step == 0)	return FALSE;
		if (awgStartValue == awgStopValue)
		{
			startpoint = 0;
			awgPatStart = scanStartValue;
			awgPatStop = scanStopValue;
			scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step)+1);
			patSamplesize = scanSampleSize;
		}

		else
		{
			if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
			awgPatStart = awgStartValue;
			awgPatStop = awgStopValue;
			patSamplesize = int(fabs((awgStopValue - awgStartValue) / step)+1);
			startpoint = int(fabs((awgStartValue - scanStartValue) / step));
			scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step)+1);
		}

		if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
			patSamplesize = MAX_SAMPLES;
		}
		if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
			scanSampleSize = MAX_SAMPLES;
		}
		fovi_cap.Set(FI, 0, FOVIe_10V, FOVIe_10UA, FOVIe_RELAY_ON);
		
		if (DEBUG_MODE || (pat_unload == 1))
		{
		
			if (DEBUG_MODE || (pat_unload == 1))
			{ 
				SERIAL{
				fpvi_ramp[SITE].AwgClear();//special process
				}
			}
			if (pattern_unloaded(reg_str))
			{
				temp_pattern.id = id;
				temp_pattern.pattern_name = reg_str;
				temp_pattern.samplecount = patSamplesize;
				temp_pattern.startvalue = awgPatStart;
				temp_pattern.stopvalue = awgPatStop;
				temp_pattern.stepvalue = step;
				SERIAL	temp_pattern.resource.push_back(fpvi_ramp[SITE].GetChannel());
				pattern_store.push_back(temp_pattern);
				temp_pattern.resource.clear();
			}
	/*		SERIAL
			{
				fpvi_ramp[SITE].SetAlarmMask(SITE);

				fpvi_ramp[SITE].AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
				fpvi_ramp[SITE].SetAlarmMask(SITE, false);

			}*/
					
		}
		else
		{
			if (sts_first_load == 1)
			{
				SERIAL{
					fpvi_ramp[SITE].AwgClear();//special process
				}
			}
		}
		STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

		SERIAL
		{
			fpvi_ramp[SITE].SetAlarmMask(SITE);

			fpvi_ramp[SITE].AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
			fpvi_ramp[SITE].SetAlarmMask(SITE, false);
	
		}

	
	SERIAL
	{
		fpvi_ramp[SITE].AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);

		fpvi_ramp[SITE].Set(FI, scanStartValue, v_range, i_range, FPVIe_RELAY_ON);

		fpvi_ramp[SITE].MeasureVI(scanSampleSize, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);
	}

	fovi_cap.SetMeasVTrig(trig_level, trig_mode);
	fovi_cap.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);

	SERIAL 
	{
		STSEnableAWG(&fpvi_ramp[SITE]);
		STSEnableMeas(&fpvi_ramp[SITE]);
	}
	STSEnableMeas(&fovi_cap);

	STSAWGRunTriggerStop(&fovi_cap, &fovi_cap);
	SERIAL fpvi_ramp[SITE].AwgStop();
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fovi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);

	SERIAL{

		if (((Trig_Point[SITE]) > 1) && ((Trig_Point[SITE]) < scanSampleSize - 1)){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result[SITE] = fpvi_ramp[SITE].GetMeasResult(SITE, MIRET, Trig_Point[SITE] - 1);
		}
		else
			result[SITE] = 999999;
	}

	SERIAL 
	{
		fpvi_ramp[SITE].Set(FI, 0, v_range, i_range, FPVIe_RELAY_ON);
		
	}

	return TRUE;
}
BOOL AWG_FUNC::rampv2mi(FPVIe fpvi_ramp, ACM acm_cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fpvi_ramp.Set(FV, scanStartValue, v_range, i_range, FPVIe_RELAY_ON, 1);
	//fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1)) fpvi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fpvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fpvi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL fpvi_ramp.SetAlarmMask(SITE);

	fpvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fpvi_ramp.SetAlarmMask(SITE, false);


	fpvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint, interval);
	acm_cap.SetMeasITrig(trig_level, trig_mode);

	fpvi_ramp.MeasureVI(scanSampleSize, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MI,scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&fpvi_ramp);
	STSEnableMeas(&fpvi_ramp, &acm_cap);
	//STSAWGRun();
	STSAWGRunTriggerStop(&acm_cap, &fpvi_ramp, &acm_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = fpvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampv2mi(FPVIe fpvi_ramp, FXVIe_PLUS fxvi_cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fpvi_ramp.Set(FV, scanStartValue, v_range, i_range, FPVIe_RELAY_ON, 1);
	//fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1)) fpvi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fpvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fpvi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL fpvi_ramp.SetAlarmMask(SITE);

	fpvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fpvi_ramp.SetAlarmMask(SITE, false);


	fpvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint, interval);
	fxvi_cap.SetMeasITrig(trig_level, trig_mode);

	fpvi_ramp.MeasureVI(scanSampleSize, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize, interval);

	STSEnableAWG(&fpvi_ramp);
	STSEnableMeas(&fpvi_ramp, &fxvi_cap);
	//STSAWGRun();
	STSAWGRunTriggerStop(&fxvi_cap, &fpvi_ramp, &fxvi_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MIRET,TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = fpvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampimi(FPVIe fpvi_ramp, FPVIe_VRNG v_range, FPVIe_IRNG i_range, ACM acm_cap, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue, int resetToZero){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	//	fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);

	if (DEBUG || (pat_unload == 1))
	{

		if (DEBUG || (pat_unload == 1))
		{

			fpvi_ramp.AwgClear();//special process

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fpvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}
		/*		SERIAL
		{
		fpvi_ramp.SetAlarmMask(SITE);

		fpvi_ramp.AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
		fpvi_ramp.SetAlarmMask(SITE, false);

		}*/

	}
	else
	{
		if (sts_first_load == 1)
		{

			fpvi_ramp.AwgClear();//special process

		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);


	SERIAL fpvi_ramp.SetAlarmMask(SITE);

	fpvi_ramp.AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
	SERIAL fpvi_ramp.SetAlarmMask(SITE, false);




	fpvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint /*+ scanSampleSize - 1*/, interval);

	fpvi_ramp.Set(FI, scanStartValue, v_range, i_range, FPVIe_RELAY_ON);

	fpvi_ramp.MeasureVI(scanSampleSize, interval,FPVIe_MV_X1,FPVIe_MI_X1, MEAS_AWG);
	//ISENP_SW12.MeasureVI(scanSampleSize, interval, MEAS_AWG);
	//FPVI1.MeasureVI(scanSampleSize, interval, MEAS_AWG);
	acm_cap.SetMeasITrig(trig_level, trig_mode);
	acm_cap.MeasureVI(ACM_MI,scanSampleSize, interval, MEAS_AWG);


	STSEnableAWG(&fpvi_ramp);
	STSEnableMeas(&fpvi_ramp);
	//STSEnableMeas(&ISENP_SW12);
	//STSEnableMeas(&FPVI1);
	STSEnableMeas(&acm_cap);

	STSAWGRunTriggerStop(&acm_cap, &acm_cap/*, &ISENP_SW12, &FPVI1*/);
	fpvi_ramp.AwgStop();
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);

	SERIAL{

		if (((Trig_Point[SITE]) > 1) && ((Trig_Point[SITE]) < scanSampleSize - 1)){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result[SITE] = fpvi_ramp.GetMeasResult(SITE, MIRET, Trig_Point[SITE] - 1);
		}
		else
			result[SITE] = 999999;
	}

	if (resetToZero) fpvi_ramp.Set(FI, 0, v_range, i_range, FPVIe_RELAY_ON);



	return TRUE;
}
BOOL AWG_FUNC::rampv(FOVIe fovi_ramp, ACM acm_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double *result1, double *result2, int smooth_point_size)
{
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (smooth_point_size <= 0)	return FALSE;
	startpoint = 0;
	smooth_size = smooth_point_size;
	scanSampleSize1 = int(fabs((scanStopValue1 - scanStartValue1) / step) + 1);
	scanSampleSize2 = int(fabs((scanStopValue2 - scanStartValue2) / step) + 1);
	patSamplesize = scanSampleSize1 + scanSampleSize2 + smooth_size + smooth_size;


	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		return FALSE;
	}

	fovi_ramp.Set(FV, scanStopValue2, v_range, i_range, FOVIe_RELAY_ON, 0.5);
	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_20UA,ACM_RELAY_ON);
	delay_us(200);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1))
		{
			fovi_ramp.AwgClear();

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = scanStartValue1;
			temp_pattern.stopvalue = scanStopValue2;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fovi_ramp.AwgClear();
		}
	}
	int i;
	for (i = 0; i < smooth_size; i++)
		pat[i] = scanStopValue2 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue1 - scanStopValue2);

	for (i = 0; i < scanSampleSize1; i++)
	{
		if (scanStartValue1 < scanStopValue1)
			pat[i + smooth_size] = scanStartValue1 + i*step;
		else
			pat[i + smooth_size] = scanStartValue1 - i*step;
	}
	for (i = 0; i < smooth_size; i++)
		pat[i + scanSampleSize1 + smooth_size] = scanStopValue1 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue2 - scanStopValue1);
	for (i = 0; i < scanSampleSize2; i++)
	{
		if (scanStartValue2 < scanStopValue2)
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 + i*step;
		else
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 - i*step;
	}


	//	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL fovi_ramp.SetAlarmMask(SITE);

	fovi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fovi_ramp.SetAlarmMask(SITE, false);

	fovi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize1 + smooth_size - 1, startpoint + scanSampleSize1 + smooth_size - 1, interval);

	acm_cap.SetMeasVTrig(trig_level, trig_mode1);


	fovi_ramp.MeasureVI(scanSampleSize1 + smooth_size, interval,FOVIe_MI_X1, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MV,scanSampleSize1 + smooth_size, interval, MEAS_AWG);

	STSEnableAWG(&fovi_ramp);
	STSEnableMeas(&fovi_ramp, &acm_cap);
	STSAWGRunTriggerStop(&acm_cap, &fovi_ramp, &acm_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (scanSampleSize1 + smooth_size - 2))){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result1[SITE] = fovi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result1[SITE] = 999999;
		}
	}
		//fovi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);

	fovi_ramp.AwgSelect(reg_str, startpoint + scanSampleSize1 + smooth_size, startpoint + patSamplesize - 1, startpoint + patSamplesize - 1, interval);

	acm_cap.SetMeasVTrig(trig_level, trig_mode2);

	fovi_ramp.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, FOVIe_MI_X1, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MV,(patSamplesize - scanSampleSize1 - smooth_size), interval, MEAS_AWG);

	STSEnableAWG(&fovi_ramp);
	STSEnableMeas(&fovi_ramp, &acm_cap);
	STSAWGRunTriggerStop(&acm_cap, &fovi_ramp, &acm_cap);

	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (patSamplesize - scanSampleSize1 - smooth_size - 2))){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result2[SITE] = fovi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result2[SITE] = 999999;
		}
	}
	return TRUE;
}
BOOL AWG_FUNC::rampvmi(FOVIe fovi_ramp, ACM acm_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double *result1, double *result2, int smooth_point_size)
{
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (smooth_point_size <= 0)	return FALSE;
	startpoint = 0;
	smooth_size = smooth_point_size;
	scanSampleSize1 = int(fabs((scanStopValue1 - scanStartValue1) / step) + 1);
	scanSampleSize2 = int(fabs((scanStopValue2 - scanStartValue2) / step) + 1);
	patSamplesize = scanSampleSize1 + scanSampleSize2 + smooth_size + smooth_size;


	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		return FALSE;
	}

	fovi_ramp.Set(FV, scanStopValue2, v_range, i_range, FOVIe_RELAY_ON, 0.5);
	//	fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
	delay_us(200);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1))
		{
			fovi_ramp.AwgClear();

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = scanStartValue1;
			temp_pattern.stopvalue = scanStopValue2;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fovi_ramp.AwgClear();
		}
	}
	int i;
	for (i = 0; i < smooth_size; i++)
		pat[i] = scanStopValue2 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue1 - scanStopValue2);

	for (i = 0; i < scanSampleSize1; i++)
	{
		if (scanStartValue1 < scanStopValue1)
			pat[i + smooth_size] = scanStartValue1 + i*step;
		else
			pat[i + smooth_size] = scanStartValue1 - i*step;
	}
	for (i = 0; i < smooth_size; i++)
		pat[i + scanSampleSize1 + smooth_size] = scanStopValue1 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue2 - scanStopValue1);
	for (i = 0; i < scanSampleSize2; i++)
	{
		if (scanStartValue2 < scanStopValue2)
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 + i*step;
		else
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 - i*step;
	}


	//	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL fovi_ramp.SetAlarmMask(SITE);

	fovi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fovi_ramp.SetAlarmMask(SITE, false);

	fovi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize1 + smooth_size - 1, startpoint + scanSampleSize1 + smooth_size - 1, interval);

	acm_cap.SetMeasITrig(trig_level, trig_mode1);


	fovi_ramp.MeasureVI(scanSampleSize1 + smooth_size, interval,FOVIe_MI_X1, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MI,scanSampleSize1 + smooth_size, interval, MEAS_AWG);

	STSEnableAWG(&fovi_ramp);
	STSEnableMeas(&fovi_ramp, &acm_cap);
	STSAWGRunTriggerStop(&acm_cap, &fovi_ramp, &acm_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (scanSampleSize1 + smooth_size - 2))){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result1[SITE] = pat[Trig_Point[SITE] - 2];// fovi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 2);
		}
		else {
			result1[SITE] = 999999;
		}
	}
		//fovi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);

	fovi_ramp.AwgSelect(reg_str, startpoint + scanSampleSize1 + smooth_size, startpoint + patSamplesize - 1, startpoint + patSamplesize - 1, interval);

	acm_cap.SetMeasITrig(trig_level, trig_mode2);

	fovi_ramp.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval,FOVIe_MI_X1, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MI,(patSamplesize - scanSampleSize1 - smooth_size), interval, MEAS_AWG);

	STSEnableAWG(&fovi_ramp);
	STSEnableMeas(&fovi_ramp, &acm_cap);
	STSAWGRunTriggerStop(&acm_cap, &fovi_ramp, &acm_cap);

	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (patSamplesize - scanSampleSize1 - smooth_size - 2))){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result2[SITE] = pat[startpoint + scanSampleSize1 + smooth_size + Trig_Point[SITE] - 2];// fovi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result2[SITE] = 999999;
		}
	}
	return TRUE;
}
BOOL AWG_FUNC::rampv2(ACM200 acm200_ramp, FXVIe_PLUS fxvi_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double *result1, double *result2, int smooth_point_size)
{
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (smooth_point_size <= 0)	return FALSE;
	startpoint = 0;
	smooth_size = smooth_point_size;
	scanSampleSize1 = int(fabs((scanStopValue1 - scanStartValue1) / step) + 1);
	scanSampleSize2 = int(fabs((scanStopValue2 - scanStartValue2) / step) + 1);
	patSamplesize = scanSampleSize1 + scanSampleSize2 + smooth_size + smooth_size;


	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		return FALSE;
	}

	acm200_ramp.Set(FV, scanStopValue2, v_range, i_range, ACM200_RELAY_ON, 0.5);
	//	fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
	//delay_us(200);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1))
		{
			acm200_ramp.AwgClear();

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = scanStartValue1;
			temp_pattern.stopvalue = scanStopValue2;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(acm200_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			acm200_ramp.AwgClear();
		}
	}
	int i;
	for (i = 0; i < smooth_size; i++)
		pat[i] = scanStopValue2 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue1 - scanStopValue2);

	for (i = 0; i < scanSampleSize1; i++)
	{
		if (scanStartValue1 < scanStopValue1)
			pat[i + smooth_size] = scanStartValue1 + i*step;
		else
			pat[i + smooth_size] = scanStartValue1 - i*step;
	}
	for (i = 0; i < smooth_size; i++)
		pat[i + scanSampleSize1 + smooth_size] = scanStopValue1 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue2 - scanStopValue1);
	for (i = 0; i < scanSampleSize2; i++)
	{
		if (scanStartValue2 < scanStopValue2)
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 + i*step;
		else
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 - i*step;
	}


	//	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL acm200_ramp.SetAlarmMask(SITE);

	acm200_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL acm200_ramp.SetAlarmMask(SITE, false);

	acm200_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize1 + smooth_size - 1, startpoint + scanSampleSize1 + smooth_size - 1, interval);

	fxvi_cap.SetMeasVTrig(trig_level, trig_mode1);


	acm200_ramp.MeasureVI(scanSampleSize1 + smooth_size, interval, MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize1 + smooth_size, interval,FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&acm200_ramp);
	STSEnableMeas(&acm200_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &acm200_ramp, &fxvi_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (scanSampleSize1 + smooth_size - 2))){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result1[SITE] = pat[Trig_Point[SITE] - 2];// acm200_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 2);
		}
		else {
			result1[SITE] = 999999;
		}
	}
		//acm200_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);

	acm200_ramp.AwgSelect(reg_str, startpoint + scanSampleSize1 + smooth_size, startpoint + patSamplesize - 1, startpoint + patSamplesize - 1, interval);

	fxvi_cap.SetMeasVTrig(trig_level, trig_mode2);

	acm200_ramp.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, MEAS_AWG);
	fxvi_cap.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&acm200_ramp);
	STSEnableMeas(&acm200_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &acm200_ramp, &fxvi_cap);

	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET,TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (patSamplesize - scanSampleSize1 - smooth_size - 2))){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result2[SITE] = pat[startpoint + scanSampleSize1 + smooth_size + Trig_Point[SITE] - 2];// acm200_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result2[SITE] = 999999;
		}
	}
	return TRUE;
}

BOOL AWG_FUNC::rampmi2(ACM200 acm200_ramp, ACM200 acm200_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double* result1, double* result2, int smooth_point_size)
{
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (smooth_point_size <= 0)	return FALSE;
	startpoint = 0;
	smooth_size = smooth_point_size;
	scanSampleSize1 = int(fabs((scanStopValue1 - scanStartValue1) / step) + 1);
	scanSampleSize2 = int(fabs((scanStopValue2 - scanStartValue2) / step) + 1);
	patSamplesize = scanSampleSize1 + scanSampleSize2 + smooth_size + smooth_size;


	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)) {
		return FALSE;
	}

	acm200_ramp.Set(FV, scanStopValue2, v_range, i_range, ACM200_RELAY_ON, 0.5);
	//	fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
	//delay_us(200);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1))
		{
			acm200_ramp.AwgClear();

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = scanStartValue1;
			temp_pattern.stopvalue = scanStopValue2;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(acm200_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			acm200_ramp.AwgClear();
		}
	}
	int i;
	for (i = 0; i < smooth_size; i++)
		pat[i] = scanStopValue2 + (double)(i + 1.0) / (double)(smooth_size + 1.0) * (scanStartValue1 - scanStopValue2);

	for (i = 0; i < scanSampleSize1; i++)
	{
		if (scanStartValue1 < scanStopValue1)
			pat[i + smooth_size] = scanStartValue1 + i * step;
		else
			pat[i + smooth_size] = scanStartValue1 - i * step;
	}
	for (i = 0; i < smooth_size; i++)
		pat[i + scanSampleSize1 + smooth_size] = scanStopValue1 + (double)(i + 1.0) / (double)(smooth_size + 1.0) * (scanStartValue2 - scanStopValue1);
	for (i = 0; i < scanSampleSize2; i++)
	{
		if (scanStartValue2 < scanStopValue2)
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 + i * step;
		else
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 - i * step;
	}


	//	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL acm200_ramp.SetAlarmMask(SITE);

	acm200_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL acm200_ramp.SetAlarmMask(SITE, false);

	acm200_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize1 + smooth_size - 1, startpoint + scanSampleSize1 + smooth_size - 1, interval);

	acm200_cap.SetMeasITrig(trig_level, trig_mode1);


	acm200_ramp.MeasureVI(scanSampleSize1 + smooth_size, interval, MEAS_AWG);
	acm200_cap.MeasureVI(scanSampleSize1 + smooth_size, interval, MEAS_AWG);

	STSEnableAWG(&acm200_ramp);
	STSEnableMeas(&acm200_ramp, &acm200_cap);
	STSAWGRunTriggerStop(&acm200_cap, &acm200_ramp, &acm200_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm200_cap.GetMeasResult(SITE, MIRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (scanSampleSize1 + smooth_size - 2))) {
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result1[SITE] = pat[Trig_Point[SITE] - 2];// acm200_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 2);
		}
		else {
			result1[SITE] = 999999;
		}
	}
		//acm200_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);

	acm200_ramp.AwgSelect(reg_str, startpoint + scanSampleSize1 + smooth_size, startpoint + patSamplesize - 1, startpoint + patSamplesize - 1, interval);

	acm200_cap.SetMeasITrig(trig_level, trig_mode2);

	acm200_ramp.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, MEAS_AWG);
	acm200_cap.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, MEAS_AWG);

	STSEnableAWG(&acm200_ramp);
	STSEnableMeas(&acm200_ramp, &acm200_cap);
	STSAWGRunTriggerStop(&acm200_cap, &acm200_ramp, &acm200_cap);

	SERIAL Trig_Point[SITE] = (int)acm200_cap.GetMeasResult(SITE, MIRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (patSamplesize - scanSampleSize1 - smooth_size - 2))) {
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result2[SITE] = pat[startpoint + scanSampleSize1 + smooth_size + Trig_Point[SITE] - 2];// acm200_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result2[SITE] = 999999;
		}
	}
	return TRUE;
}
BOOL AWG_FUNC::rampv2(FXVIe_PLUS fxvi_ramp, ACM200 acm200_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double *result1, double *result2, int smooth_point_size)
{
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (smooth_point_size <= 0)	return FALSE;
	startpoint = 0;
	smooth_size = smooth_point_size;
	scanSampleSize1 = int(fabs((scanStopValue1 - scanStartValue1) / step) + 1);
	scanSampleSize2 = int(fabs((scanStopValue2 - scanStartValue2) / step) + 1);
	patSamplesize = scanSampleSize1 + scanSampleSize2 + smooth_size + smooth_size;


	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		return FALSE;
	}

	fxvi_ramp.Set(FV, scanStopValue2, v_range, i_range, FXVIe_PLUS_RELAY_ON, 0.5);
	//	fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
	//delay_us(200);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1))
		{
			fxvi_ramp.AwgClear();

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = scanStartValue1;
			temp_pattern.stopvalue = scanStopValue2;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fxvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fxvi_ramp.AwgClear();
		}
	}
	int i;
	for (i = 0; i < smooth_size; i++)
		pat[i] = scanStopValue2 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue1 - scanStopValue2);

	for (i = 0; i < scanSampleSize1; i++)
	{
		if (scanStartValue1 < scanStopValue1)
			pat[i + smooth_size] = scanStartValue1 + i*step;
		else
			pat[i + smooth_size] = scanStartValue1 - i*step;
	}
	for (i = 0; i < smooth_size; i++)
		pat[i + scanSampleSize1 + smooth_size] = scanStopValue1 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue2 - scanStopValue1);
	for (i = 0; i < scanSampleSize2; i++)
	{
		if (scanStartValue2 < scanStopValue2)
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 + i*step;
		else
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 - i*step;
	}


	//	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL fxvi_ramp.SetAlarmMask(SITE);

	fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fxvi_ramp.SetAlarmMask(SITE, false);

	fxvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize1 + smooth_size - 1, startpoint + scanSampleSize1 + smooth_size - 1, interval);

	acm200_cap.SetMeasVTrig(trig_level, trig_mode1);


	fxvi_ramp.MeasureVI(scanSampleSize1 + smooth_size, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	acm200_cap.MeasureVI(scanSampleSize1 + smooth_size, interval,  MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &acm200_cap);
	STSAWGRunTriggerStop(&acm200_cap, &fxvi_ramp, &acm200_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm200_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (scanSampleSize1 + smooth_size - 2))){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result1[SITE] = pat[Trig_Point[SITE] - 2];// fxvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 2);
		}
		else {
			result1[SITE] = 999999;
		}
	}
		//fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);

	fxvi_ramp.AwgSelect(reg_str, startpoint + scanSampleSize1 + smooth_size, startpoint + patSamplesize - 1, startpoint + patSamplesize - 1, interval);

	acm200_cap.SetMeasVTrig(trig_level, trig_mode2);

	fxvi_ramp.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, FXVIe_PLUS_MI_X1,MEAS_AWG);
	acm200_cap.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &acm200_cap);
	STSAWGRunTriggerStop(&acm200_cap, &fxvi_ramp, &acm200_cap);

	SERIAL Trig_Point[SITE] = (int)acm200_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (patSamplesize - scanSampleSize1 - smooth_size - 2))){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result2[SITE] = pat[startpoint + scanSampleSize1 + smooth_size + Trig_Point[SITE] - 2];// fxvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result2[SITE] = 999999;
		}
	}
	return TRUE;
}

BOOL AWG_FUNC::rampv2(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double* result1, double* result2, int smooth_point_size)
{
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (smooth_point_size <= 0)	return FALSE;
	startpoint = 0;
	smooth_size = smooth_point_size;
	scanSampleSize1 = int(fabs((scanStopValue1 - scanStartValue1) / step) + 1);
	scanSampleSize2 = int(fabs((scanStopValue2 - scanStartValue2) / step) + 1);
	patSamplesize = scanSampleSize1 + scanSampleSize2 + smooth_size + smooth_size;


	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)) {
		return FALSE;
	}

	fxvi_ramp.Set(FV, scanStopValue2, v_range, i_range, FXVIe_PLUS_RELAY_ON, 0.5);
	//	fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
	//delay_us(200);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1))
		{
			fxvi_ramp.AwgClear();

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = scanStartValue1;
			temp_pattern.stopvalue = scanStopValue2;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fxvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fxvi_ramp.AwgClear();
		}
	}
	int i;
	for (i = 0; i < smooth_size; i++)
		pat[i] = scanStopValue2 + (double)(i + 1.0) / (double)(smooth_size + 1.0) * (scanStartValue1 - scanStopValue2);

	for (i = 0; i < scanSampleSize1; i++)
	{
		if (scanStartValue1 < scanStopValue1)
			pat[i + smooth_size] = scanStartValue1 + i * step;
		else
			pat[i + smooth_size] = scanStartValue1 - i * step;
	}
	for (i = 0; i < smooth_size; i++)
		pat[i + scanSampleSize1 + smooth_size] = scanStopValue1 + (double)(i + 1.0) / (double)(smooth_size + 1.0) * (scanStartValue2 - scanStopValue1);
	for (i = 0; i < scanSampleSize2; i++)
	{
		if (scanStartValue2 < scanStopValue2)
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 + i * step;
		else
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 - i * step;
	}


	//	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL fxvi_ramp.SetAlarmMask(SITE);

	fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fxvi_ramp.SetAlarmMask(SITE, false);

	fxvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize1 + smooth_size - 1, startpoint + scanSampleSize1 + smooth_size - 1, interval);

	fxvi_cap.SetMeasVTrig(trig_level, trig_mode1);


	fxvi_ramp.MeasureVI(scanSampleSize1 + smooth_size, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize1 + smooth_size, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &fxvi_ramp, &fxvi_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (scanSampleSize1 + smooth_size - 2))) {
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result1[SITE] = pat[Trig_Point[SITE] - 2];// fxvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 2);
		}
		else {
			result1[SITE] = 999999;
		}
	}
		//fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);

	fxvi_ramp.AwgSelect(reg_str, startpoint + scanSampleSize1 + smooth_size, startpoint + patSamplesize - 1, startpoint + patSamplesize - 1, interval);

	fxvi_cap.SetMeasVTrig(trig_level, trig_mode2);

	fxvi_ramp.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	fxvi_cap.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &fxvi_ramp, &fxvi_cap);

	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (patSamplesize - scanSampleSize1 - smooth_size - 2))) {
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result2[SITE] = pat[startpoint + scanSampleSize1 + smooth_size + Trig_Point[SITE] - 2];// fxvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result2[SITE] = 999999;
		}
	}
	return TRUE;
}

BOOL AWG_FUNC::rampi2(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double* result1, double* result2, int smooth_point_size)
{
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (smooth_point_size <= 0)	return FALSE;
	startpoint = 0;
	smooth_size = smooth_point_size;
	scanSampleSize1 = int(fabs((scanStopValue1 - scanStartValue1) / step) + 1);
	scanSampleSize2 = int(fabs((scanStopValue2 - scanStartValue2) / step) + 1);
	patSamplesize = scanSampleSize1 + scanSampleSize2 + smooth_size + smooth_size;


	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)) {
		return FALSE;
	}

	fxvi_ramp.Set(FI, scanStopValue2, v_range, i_range, FXVIe_PLUS_RELAY_ON, 0.5);
	//	fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
	//delay_us(200);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1))
		{
			fxvi_ramp.AwgClear();

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = scanStartValue1;
			temp_pattern.stopvalue = scanStopValue2;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fxvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fxvi_ramp.AwgClear();
		}
	}
	int i;
	for (i = 0; i < smooth_size; i++)
		pat[i] = scanStopValue2 + (double)(i + 1.0) / (double)(smooth_size + 1.0) * (scanStartValue1 - scanStopValue2);

	for (i = 0; i < scanSampleSize1; i++)
	{
		if (scanStartValue1 < scanStopValue1)
			pat[i + smooth_size] = scanStartValue1 + i * step;
		else
			pat[i + smooth_size] = scanStartValue1 - i * step;
	}
	for (i = 0; i < smooth_size; i++)
		pat[i + scanSampleSize1 + smooth_size] = scanStopValue1 + (double)(i + 1.0) / (double)(smooth_size + 1.0) * (scanStartValue2 - scanStopValue1);
	for (i = 0; i < scanSampleSize2; i++)
	{
		if (scanStartValue2 < scanStopValue2)
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 + i * step;
		else
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 - i * step;
	}


	//	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL fxvi_ramp.SetAlarmMask(SITE);

	fxvi_ramp.AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
	SERIAL fxvi_ramp.SetAlarmMask(SITE, false);

	fxvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize1 + smooth_size - 1, startpoint + scanSampleSize1 + smooth_size - 1, interval);

	fxvi_cap.SetMeasVTrig(trig_level, trig_mode1);


	fxvi_ramp.MeasureVI(scanSampleSize1 + smooth_size, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize1 + smooth_size, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &fxvi_ramp, &fxvi_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (scanSampleSize1 + smooth_size - 2))) {
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result1[SITE] = pat[Trig_Point[SITE] - 2];// fxvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 2);
		}
		else {
			result1[SITE] = 999999;
		}
	}
		//fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);

	fxvi_ramp.AwgSelect(reg_str, startpoint + scanSampleSize1 + smooth_size, startpoint + patSamplesize - 1, startpoint + patSamplesize - 1, interval);

	fxvi_cap.SetMeasVTrig(trig_level, trig_mode2);

	fxvi_ramp.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	fxvi_cap.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &fxvi_ramp, &fxvi_cap);

	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (patSamplesize - scanSampleSize1 - smooth_size - 2))) {
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result2[SITE] = pat[startpoint + scanSampleSize1 + smooth_size + Trig_Point[SITE] - 2];// fxvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result2[SITE] = 999999;
		}
	}
	return TRUE;
}
BOOL AWG_FUNC::rampv2_FO(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double* result1, double* result2, int smooth_point_size)
{
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (smooth_point_size <= 0)	return FALSE;
	startpoint = 0;
	smooth_size = smooth_point_size;
	scanSampleSize1 = int(fabs((scanStopValue1 - scanStartValue1) / step) + 1);
	scanSampleSize2 = int(fabs((scanStopValue2 - scanStartValue2) / step) + 1);
	patSamplesize = scanSampleSize1 + scanSampleSize2 + smooth_size + smooth_size;


	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)) {
		return FALSE;
	}

	fxvi_ramp.Set(FV, scanStopValue2, v_range, i_range, FXVIe_PLUS_RELAY_FANOUT_ON, 0.5);
	//	fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
	//delay_us(200);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1))
		{
			fxvi_ramp.AwgClear();

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = scanStartValue1;
			temp_pattern.stopvalue = scanStopValue2;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fxvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fxvi_ramp.AwgClear();
		}
	}
	int i;
	for (i = 0; i < smooth_size; i++)
		pat[i] = scanStopValue2 + (double)(i + 1.0) / (double)(smooth_size + 1.0) * (scanStartValue1 - scanStopValue2);

	for (i = 0; i < scanSampleSize1; i++)
	{
		if (scanStartValue1 < scanStopValue1)
			pat[i + smooth_size] = scanStartValue1 + i * step;
		else
			pat[i + smooth_size] = scanStartValue1 - i * step;
	}
	for (i = 0; i < smooth_size; i++)
		pat[i + scanSampleSize1 + smooth_size] = scanStopValue1 + (double)(i + 1.0) / (double)(smooth_size + 1.0) * (scanStartValue2 - scanStopValue1);
	for (i = 0; i < scanSampleSize2; i++)
	{
		if (scanStartValue2 < scanStopValue2)
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 + i * step;
		else
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 - i * step;
	}


	//	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL fxvi_ramp.SetAlarmMask(SITE);

	fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fxvi_ramp.SetAlarmMask(SITE, false);

	fxvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize1 + smooth_size - 1, startpoint + scanSampleSize1 + smooth_size - 1, interval);

	fxvi_cap.SetMeasVTrig(trig_level, trig_mode1);


	fxvi_ramp.MeasureVI(scanSampleSize1 + smooth_size, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize1 + smooth_size, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &fxvi_ramp, &fxvi_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (scanSampleSize1 + smooth_size - 2))) {
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result1[SITE] = pat[Trig_Point[SITE] - 2];// fxvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 2);
		}
		else {
			result1[SITE] = 999999;
		}
	}
		//fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);

	fxvi_ramp.AwgSelect(reg_str, startpoint + scanSampleSize1 + smooth_size, startpoint + patSamplesize - 1, startpoint + patSamplesize - 1, interval);

	fxvi_cap.SetMeasVTrig(trig_level, trig_mode2);

	fxvi_ramp.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	fxvi_cap.MeasureVI((patSamplesize - scanSampleSize1 - smooth_size), interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &fxvi_ramp, &fxvi_cap);

	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (patSamplesize - scanSampleSize1 - smooth_size - 2))) {
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result2[SITE] = pat[startpoint + scanSampleSize1 + smooth_size + Trig_Point[SITE] - 2];// fxvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result2[SITE] = 999999;
		}
	}
	return TRUE;
}
BOOL AWG_FUNC::rampvmi2(ACM acm_ramp, ACM acm_cap, ACM_IRNG i_range, char* reg_str, char* reg_str2, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double step, int interval, double trig_level, TRIG_MODE trig_mode1, TRIG_MODE trig_mode2, double *result1, double *result2, int smooth_point_size)
{
	double dv = 0.6;//delta voltage between acm_ramp /acm_cap
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (smooth_point_size <= 0)	return FALSE;
	startpoint = 0;
	smooth_size = smooth_point_size;
	scanSampleSize1 = int(fabs((scanStopValue1 - scanStartValue1) / step) + 1);
	scanSampleSize2 = int(fabs((scanStopValue2 - scanStartValue2) / step) + 1);
	patSamplesize = scanSampleSize1 + scanSampleSize2 + smooth_size + smooth_size;


	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		return FALSE;
	}

	acm_ramp.Set(FV, scanStopValue2, ACM_N2P18V, i_range, ACM_RELAY_ON, 0.5);
	acm_cap.Set(FV, scanStopValue2+ dv, ACM_N2P18V, ACM_2MA, ACM_RELAY_ON, 0.5);
	//fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
	delay_us(200);
	if (DEBUG || (pat_unload == 1))
	{


		if (DEBUG || (pat_unload == 1))
		{
			acm_ramp.AwgClear();
			acm_cap.AwgClear();
		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = scanStartValue1;
			temp_pattern.stopvalue = scanStopValue2;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(acm_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			acm_ramp.AwgClear();
			acm_cap.AwgClear();
		}
	}
	int i;
	for (i = 0; i < smooth_size; i++)
		pat[i] = scanStopValue2 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue1 - scanStopValue2);

	for (i = 0; i < scanSampleSize1; i++)
	{
		if (scanStartValue1 < scanStopValue1)
			pat[i + smooth_size] = scanStartValue1 + i*step;
		else
			pat[i + smooth_size] = scanStartValue1 - i*step;
	}
	for (i = 0; i < smooth_size; i++)
		pat[i + scanSampleSize1 + smooth_size] = scanStopValue1 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue2 - scanStopValue1);
	for (i = 0; i < scanSampleSize2; i++)
	{
		if (scanStartValue2 < scanStopValue2)
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 + i*step;
		else
			pat[i + scanSampleSize1 + smooth_size + smooth_size] = scanStartValue2 - i*step;
	}

	for (i = 0; i < smooth_size; i++)
		pat2[i] = dv+scanStopValue2 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue1 - scanStopValue2);

	for (i = 0; i < scanSampleSize1; i++)
	{
		if (scanStartValue1 < scanStopValue1)
			pat2[i + smooth_size] = dv+scanStartValue1 + i*step;
		else
			pat2[i + smooth_size] = dv+scanStartValue1 - i*step;
	}
	for (i = 0; i < smooth_size; i++)
		pat2[i + scanSampleSize1 + smooth_size] = dv+scanStopValue1 + (double)(i + 1.0) / (double)(smooth_size + 1.0)*(scanStartValue2 - scanStopValue1);
	for (i = 0; i < scanSampleSize2; i++)
	{
		if (scanStartValue2 < scanStopValue2)
			pat2[i + scanSampleSize1 + smooth_size + smooth_size] = dv+scanStartValue2 + i*step;
		else
			pat2[i + scanSampleSize1 + smooth_size + smooth_size] = dv+scanStartValue2 - i*step;
	}

	//	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL 
	{
		acm_ramp.SetAlarmMask(SITE);
		acm_cap.SetAlarmMask(SITE);
	}

	acm_ramp.AwgLoader(reg_str, FV, ACM_N2P18V, i_range, pat, patSamplesize);
	acm_cap.AwgLoader(reg_str2, FV, ACM_N2P18V, i_range, pat2, patSamplesize);
	SERIAL
	{
		acm_ramp.SetAlarmMask(SITE, false);
		acm_cap.SetAlarmMask(SITE, false);
	}

	acm_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize1 + smooth_size - 1, startpoint + scanSampleSize1 + smooth_size - 1, interval);
	acm_cap.AwgSelect(reg_str2, startpoint, startpoint + scanSampleSize1 + smooth_size - 1, startpoint + scanSampleSize1 + smooth_size - 1, interval);
	acm_cap.SetMeasITrig(trig_level, trig_mode1);

	//ISENP_SW12.MeasureVI(scanSampleSize1 + smooth_size, interval, MEAS_AWG);
	acm_ramp.MeasureVI(ACM_MV,scanSampleSize1 + smooth_size, interval, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MI,scanSampleSize1 + smooth_size, interval, MEAS_AWG);

	STSEnableAWG(&acm_ramp, &acm_cap);
	STSEnableMeas(&acm_ramp, &acm_cap);
	//STSAWGRun();
	STSAWGRunTriggerStop(&acm_cap, &acm_ramp, &acm_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);

	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (scanSampleSize1 + smooth_size - 2))){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result1[SITE] = acm_ramp.GetMeasResult(SITE, Trig_Point[SITE] - 1);
		}
		else {
			result1[SITE] = 999999;
		}
	}

	acm_ramp.AwgSelect(reg_str, startpoint + scanSampleSize1 + smooth_size, startpoint + patSamplesize - 1, startpoint + patSamplesize - 1, interval);
	acm_cap.AwgSelect(reg_str2, startpoint + scanSampleSize1 + smooth_size, startpoint + patSamplesize - 1, startpoint + patSamplesize - 1, interval);
	acm_cap.SetMeasITrig(trig_level, trig_mode2);

	acm_ramp.MeasureVI(ACM_MV,(patSamplesize - scanSampleSize1 - smooth_size), interval, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MI,(patSamplesize - scanSampleSize1 - smooth_size), interval, MEAS_AWG);

	STSEnableAWG(&acm_ramp, &acm_cap);
	STSEnableMeas(&acm_ramp, &acm_cap);
	//STSAWGRun();
	STSAWGRunTriggerStop(&acm_cap, &acm_ramp, &acm_cap);

	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < (patSamplesize - scanSampleSize1 - smooth_size - 2))){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result2[SITE] = acm_ramp.GetMeasResult(SITE, Trig_Point[SITE] - 1);
		}
		else {
			result2[SITE] = 999999;
		}
	}
	return TRUE;
}
BOOL AWG_FUNC::rampvmi(FOVIe fovi_ramp, FOVIe_VRNG v_range, FOVIe_IRNG i_range, ACM acm_cap, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	//fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);

	if (DEBUG || (pat_unload == 1))
	{

		if (DEBUG || (pat_unload == 1))
		{

			fovi_ramp.AwgClear();//special process

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}
		/*		SERIAL
		{
		fovi_ramp.SetAlarmMask(SITE);

		fovi_ramp.AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
		fovi_ramp.SetAlarmMask(SITE, false);

		}*/

	}
	else
	{
		if (sts_first_load == 1)
		{

			fovi_ramp.AwgClear();//special process

		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);


	SERIAL fovi_ramp.SetAlarmMask(SITE);

	fovi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fovi_ramp.SetAlarmMask(SITE, false);




	fovi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);

	fovi_ramp.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON);

	fovi_ramp.MeasureVI(scanSampleSize, interval,FOVIe_MI_X1, MEAS_AWG);


	acm_cap.SetMeasITrig(trig_level, trig_mode);
	acm_cap.MeasureVI(ACM_MI,scanSampleSize, interval, MEAS_AWG);


	STSEnableAWG(&fovi_ramp);
	STSEnableMeas(&fovi_ramp);

	STSEnableMeas(&acm_cap);

	STSAWGRunTriggerStop(&acm_cap, &acm_cap, &fovi_ramp);
	//fovi_ramp.AwgStop();
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);

	SERIAL{

		if (((Trig_Point[SITE]) > 1) && ((Trig_Point[SITE]) < scanSampleSize - 1)){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result[SITE] = fovi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else
			result[SITE] = 999999;
	}



	return TRUE;
}
BOOL AWG_FUNC::rampv(FOVIe fovi_ramp, FOVIe fovi_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step)+1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step)+1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step)+1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fovi_ramp.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	fovi_cap.Set(FI, 0, FOVIe_10V, FOVIe_10UA, FOVIe_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{
	

		if (DEBUG_MODE || (pat_unload == 1)) fovi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}
		

	}
	else
	{
		if (sts_first_load == 1)
		{
			fovi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL fovi_ramp.SetAlarmMask(SITE);

	fovi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fovi_ramp.SetAlarmMask(SITE, false);


	fovi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fovi_cap.SetMeasVTrig(trig_level, trig_mode);

	fovi_ramp.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	fovi_cap.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);

	STSEnableAWG(&fovi_ramp);
	STSEnableMeas(&fovi_ramp, &fovi_cap);
	STSAWGRunTriggerStop(&fovi_cap, &fovi_ramp, &fovi_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fovi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = fovi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampv(FXVIe_PLUS fxvi_ramp, ACM200 acm200_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fxvi_ramp.Set(FV, scanStartValue, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	acm200_cap.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) fxvi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fxvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fxvi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL fxvi_ramp.SetAlarmMask(SITE);

	fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fxvi_ramp.SetAlarmMask(SITE, false);


	fxvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	acm200_cap.SetMeasVTrig(trig_level, trig_mode);

	fxvi_ramp.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	acm200_cap.MeasureVI(scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &acm200_cap);
	STSAWGRunTriggerStop(&acm200_cap, &fxvi_ramp, &acm200_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm200_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = fxvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}

BOOL AWG_FUNC::rampvmi(FXVIe_PLUS fxvi_ramp, ACM200 acm200_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fxvi_ramp.Set(FV, scanStartValue, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	
	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) fxvi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fxvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fxvi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL fxvi_ramp.SetAlarmMask(SITE);

	fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fxvi_ramp.SetAlarmMask(SITE, false);


	fxvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	acm200_cap.SetMeasITrig(trig_level, trig_mode);

	fxvi_ramp.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	acm200_cap.MeasureVI(scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &acm200_cap);
	STSAWGRunTriggerStop(&acm200_cap, &fxvi_ramp, &acm200_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm200_cap.GetMeasResult(SITE, MIRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = pat[Trig_Point[SITE] - 1];;
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}

BOOL AWG_FUNC::rampvmi(ACM200 acm200_ramp, FXVIe_PLUS fxvi_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double* result, double awgStartValue, double awgStopValue) {
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)) {
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)) {
		scanSampleSize = MAX_SAMPLES;
	}
	acm200_ramp.Set(FV, scanStartValue, v_range, i_range, ACM200_RELAY_ON);

	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) acm200_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(acm200_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			acm200_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL acm200_ramp.SetAlarmMask(SITE);

	acm200_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL acm200_ramp.SetAlarmMask(SITE, false);


	acm200_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fxvi_cap.SetMeasITrig(trig_level, trig_mode);

	acm200_ramp.MeasureVI(scanSampleSize, interval, MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize, interval,FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&acm200_ramp);
	STSEnableMeas(&acm200_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &acm200_ramp, &fxvi_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MIRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)) {
			result[SITE] = pat[Trig_Point[SITE] - 1];// acm200_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampvmi(ACM200 acm200_ramp, ACM200 acm200_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double* result, double awgStartValue, double awgStopValue) {
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)) {
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)) {
		scanSampleSize = MAX_SAMPLES;
	}
	acm200_ramp.Set(FV, scanStartValue, v_range, i_range, ACM200_RELAY_ON);

	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) acm200_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(acm200_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			acm200_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL acm200_ramp.SetAlarmMask(SITE);

	acm200_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL acm200_ramp.SetAlarmMask(SITE, false);


	acm200_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	acm200_cap.SetMeasITrig(trig_level, trig_mode);

	acm200_ramp.MeasureVI(scanSampleSize, interval, MEAS_AWG);
	acm200_cap.MeasureVI(scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&acm200_ramp);
	STSEnableMeas(&acm200_ramp, &acm200_cap);
	STSAWGRunTriggerStop(&acm200_cap, &acm200_ramp, &acm200_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm200_cap.GetMeasResult(SITE, MIRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)) {
			result[SITE] = acm200_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampv(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fxvi_ramp.Set(FV, scanStartValue, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	//fxvi_cap.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) fxvi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fxvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fxvi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL fxvi_ramp.SetAlarmMask(SITE);

	fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fxvi_ramp.SetAlarmMask(SITE, false);


	fxvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fxvi_cap.SetMeasVTrig(trig_level, trig_mode);

	fxvi_ramp.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &fxvi_ramp, &fxvi_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = fxvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}

BOOL AWG_FUNC::rampv(ACM200 acm200_ramp, ACM200 acm200_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	acm200_ramp.Set(FV, scanStartValue, v_range, i_range, ACM200_RELAY_ON);
	acm200_cap.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) acm200_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(acm200_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			acm200_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL acm200_ramp.SetAlarmMask(SITE);

	acm200_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL acm200_ramp.SetAlarmMask(SITE, false);


	acm200_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	acm200_cap.SetMeasVTrig(trig_level, trig_mode);

	acm200_ramp.MeasureVI(scanSampleSize, interval, MEAS_AWG);
	acm200_cap.MeasureVI(scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&acm200_ramp);
	STSEnableMeas(&acm200_ramp, &acm200_cap);
	STSAWGRunTriggerStop(&acm200_cap, &acm200_ramp, &acm200_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm200_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = acm200_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}

BOOL AWG_FUNC::rampv(ACM200 acm200_ramp, FXVIe_PLUS fxvi_cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	acm200_ramp.Set(FV, scanStartValue, v_range, i_range, ACM200_RELAY_ON);
	fxvi_cap.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) acm200_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(acm200_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			acm200_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL acm200_ramp.SetAlarmMask(SITE);

	acm200_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL acm200_ramp.SetAlarmMask(SITE, false);


	acm200_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint, interval);
	fxvi_cap.SetMeasVTrig(trig_level, trig_mode);

	acm200_ramp.MeasureVI(scanSampleSize, interval, MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&acm200_ramp);
	STSEnableMeas(&acm200_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &acm200_ramp, &fxvi_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = acm200_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}

BOOL AWG_FUNC::rampi(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fxvi_ramp.Set(FI, scanStartValue, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	fxvi_cap.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) fxvi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fxvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fxvi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL fxvi_ramp.SetAlarmMask(SITE);

	fxvi_ramp.AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
	SERIAL fxvi_ramp.SetAlarmMask(SITE, false);


	fxvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fxvi_cap.SetMeasVTrig(trig_level, trig_mode);

	fxvi_ramp.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1,MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &fxvi_ramp, &fxvi_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = fxvi_ramp.GetMeasResult(SITE, MIRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}

BOOL AWG_FUNC::rampi(FPVIe fpvi_ramp, FXVIe_PLUS fxvi_cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fpvi_ramp.Set(FI, scanStartValue, v_range, i_range, FPVIe_RELAY_ON);
	//fxvi_cap.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) fpvi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fpvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fpvi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL fpvi_ramp.SetAlarmMask(SITE);

	fpvi_ramp.AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
	SERIAL fpvi_ramp.SetAlarmMask(SITE, false);

	//stop at 0
	fpvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint, interval);
	fxvi_cap.SetMeasVTrig(trig_level, trig_mode);

	fpvi_ramp.MeasureVI(scanSampleSize, interval,FPVIe_MV_X1,FPVIe_MI_X1, MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fpvi_ramp);
	STSEnableMeas(&fpvi_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &fpvi_ramp, &fxvi_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = fpvi_ramp.GetMeasResult(SITE, MIRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampss(FXVIe_PLUS fxvi_ramp, FXVIe_PLUS fxvi_cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, int count, int interval, double trig_level1, double trig_level2, TRIG_MODE trig_mode, double *result){
	if (interval < 10)	return FALSE;
	

	startpoint = 0;
	awgPatStart = scanStartValue;
	awgPatStop = scanStopValue;
	scanSampleSize = count;
	patSamplesize = scanSampleSize;
	



	if ((patSamplesize <= 10) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 10) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fxvi_ramp.Set(FV, scanStartValue, v_range, i_range, FXVIe_PLUS_RELAY_ON);

	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) fxvi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
		
			temp_pattern.resource.push_back(fxvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fxvi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], 10, 1, awgPatStart, awgPatStop);
	STSAWGCreateRampData(&pat[10], patSamplesize-10, 1, awgPatStop, awgPatStop);
	SERIAL fxvi_ramp.SetAlarmMask(SITE);

	fxvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fxvi_ramp.SetAlarmMask(SITE, false);


	fxvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);

	fxvi_ramp.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fxvi_ramp);
	STSEnableMeas(&fxvi_ramp, &fxvi_cap);
	STSAWGRun();
	double t1[SITE_NUM] = {0};
	double t2[SITE_NUM] = { 0 };
	SERIAL{
		fxvi_cap.BlockRead(SITE, 0, count, cap[SITE], MVRET);
		if (trig_mode == TRIG_RISING)
		{
			for (int i = 0; i<scanSampleSize; i++)
			{
				if (cap[SITE][i]>trig_level1)
				{
					t1[SITE] = i;
					break;
				}
				
			}
			for (int i = 0; i<scanSampleSize; i++)
			{
				if (cap[SITE][i]>trig_level2)
				{
					t2[SITE] = i;
					break;
				}

			}
			result[SITE] = (t2[SITE] - t1[SITE])*interval;
		}
		else
		{
			for (int i = 0; i<scanSampleSize; i++)
			{
				if (cap[SITE][i]<trig_level1)
				{
					t1[SITE] = i;
					break;
				}

			}
			for (int i = 0; i<scanSampleSize; i++)
			{
				if (cap[SITE][i]<trig_level2)
				{
					t2[SITE] = i;
					break;
				}

			}
			result[SITE] = (t2[SITE] - t1[SITE])*interval;
		}
		
	}

	return TRUE;
}

BOOL AWG_FUNC::rampv(FPVIe fpvi_ramp, FXVIe_PLUS fxvi_cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fpvi_ramp.Set(FV, scanStartValue, v_range, i_range, FPVIe_RELAY_ON);
	fxvi_cap.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1)) fpvi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fpvi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			fpvi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	SERIAL fpvi_ramp.SetAlarmMask(SITE);

	fpvi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fpvi_ramp.SetAlarmMask(SITE, false);


	fpvi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fxvi_cap.SetMeasVTrig(trig_level, trig_mode);

	fpvi_ramp.MeasureVI(scanSampleSize, interval,FPVIe_MV_X1,FPVIe_MI_X1,MEAS_AWG);
	fxvi_cap.MeasureVI(scanSampleSize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&fpvi_ramp);
	STSEnableMeas(&fpvi_ramp, &fxvi_cap);
	STSAWGRunTriggerStop(&fxvi_cap, &fpvi_ramp, &fxvi_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fxvi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = pat[Trig_Point[SITE] - 1];// fpvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}

BOOL AWG_FUNC::rampv(FOVIe fovi_ramp, ACM acm_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fovi_ramp.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON,0.5);
	delay_ms(2);
	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_20UA, ACM_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{

		if (DEBUG_MODE || (pat_unload == 1)) fovi_ramp.AwgClear();
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}


	
		
	}
	else
	{
		if (sts_first_load == 1)
		{
			fovi_ramp.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL	fovi_ramp.SetAlarmMask(SITE);
	fovi_ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL fovi_ramp.SetAlarmMask(SITE, false);


	fovi_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	acm_cap.SetMeasVTrig(trig_level, trig_mode);

	fovi_ramp.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MV, scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&fovi_ramp);
	STSEnableMeas(&fovi_ramp, &acm_cap);
	STSAWGRunTriggerStop(&acm_cap, &fovi_ramp, &acm_cap);
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			result[SITE] = fovi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampvmi(FOVIe *fovi_ramp, ACM *acm_ramp, char* reg_str, double *scanStartValue, double *scanStopValue, int *sizeofparameter, FOVIe_VRNG *v_range, FOVIe_IRNG *i_range, ACM_IRNG *acm_i_range, int measure_enable, int backToStart_enable, double ramptime, double waittime, double results[][SITE_NUM]){

	//purpose: ramp up/down all resource at same time with differet vrange and irange and different type resoure.
	//avoid resource setup sequence abnormal. avoid over stress.
	//only support sample size =80, can change manual,or improve program.
	if (ramptime < 0)	return FALSE;
	if ((fovi_ramp == NULL) && (acm_ramp == NULL)) return FALSE;
	double interval;
	int backSampleSize = 0;
	startpoint = 0;
	int measureSampleSize = 10;
	int rampSamplesize = 80;
	interval = ramptime * 1000 / rampSamplesize;
	if (backToStart_enable) backSampleSize = 10;
	//can change to 80 if debug result not good. currrent delay is about 100Xinterval>10ms.can short the samplesize to short the waiting time.
	if (interval < 100)interval = 100;
	if (measure_enable)
	{
		patSamplesize = 80 + int(waittime * 10) + measureSampleSize;

	}	
	else
		patSamplesize = 80;
	scanSampleSize = patSamplesize;
	//check if startvlaue are same or size=1
	double first_start_value=0;
	double first_stop_value = 0;
	FOVIe_VRNG first_fovi_vrange;
	FOVIe_IRNG first_fovi_irange;
	ACM_IRNG first_acm_irange;
	double start_value = 0;
	double stop_value = 0;
	FOVIe_VRNG fovi_vrange;
	FOVIe_IRNG fovi_irange;
	ACM_IRNG acm_irange;
	int same_startvalue = 1;
	int same_fovi_vrange = 1;
	int same_fovi_irange = 1;
	int same_acm_irange = 1;
	int same_stopvalue = 1;
	int inti = 0;//start point for acm resource
	if (fovi_ramp != NULL)
	{
		for (int k = 0; k < sizeofparameter[2]; k++)
		{
			if (k == 0)
				first_start_value = scanStartValue[0];
			else if (first_start_value != scanStartValue[k])
			{
				same_startvalue = 0;
				break;
			}
		}
		for (int k = 0; k < sizeofparameter[4]; k++)
		{
			if (k == 0)
				first_fovi_vrange = v_range[0];
			else if (first_fovi_vrange != v_range[k])
			{
				same_fovi_vrange = 0;
				break;
			}
		}
		for (int k = 0; k < sizeofparameter[5]; k++)
		{
			if (k == 0)
				first_fovi_irange = i_range[0];
			else if (first_fovi_irange != i_range[k])
			{
				same_fovi_irange = 0;
				break;
			}
		}
		for (int k = 0; k < sizeofparameter[3]; k++)
		{
			if (k == 0)
				first_stop_value = scanStopValue[0];
			else if (first_stop_value != scanStopValue[k])
			{
				same_stopvalue = 0;
				break;
			}
		}
		for (int i = 0; i < sizeofparameter[0]; i++)
		{
			if (same_startvalue)start_value = scanStartValue[0];
			else start_value = scanStartValue[i];
			if (same_fovi_vrange)fovi_vrange = v_range[0];
			else fovi_vrange = v_range[i];
			if (same_fovi_irange)fovi_irange = i_range[0];
			else fovi_irange = i_range[i];

			fovi_ramp[i].Set(FV, start_value, fovi_vrange, fovi_irange, FOVIe_RELAY_ON);
		}
		
		inti = sizeofparameter[0] ;
	}
	if (acm_ramp != NULL)
	{
		for (int k = 0; k < sizeofparameter[2]; k++)
		{
			if (k == 0)
				first_start_value = scanStartValue[0];
			else if (first_start_value != scanStartValue[k])
			{
				same_startvalue = 0;
				break;
			}
		}
		for (int k = 0; k < sizeofparameter[3]; k++)
		{
			if (k == 0)
				first_stop_value = scanStopValue[0];
			else if (first_stop_value != scanStopValue[k])
			{
				same_stopvalue = 0;
				break;
			}
		}
		for (int k = 0; k < sizeofparameter[6]; k++)
		{
			if (k == 0)
				first_acm_irange = acm_i_range[0];
			else if (first_acm_irange != acm_i_range[k])
			{
				same_acm_irange = 0;
				break;
			}
		}

	
		for (int i = 0; i < sizeofparameter[1]; i++)
		{
			if (same_startvalue)start_value = scanStartValue[0];
			else start_value = scanStartValue[inti+i];

			if (same_acm_irange)acm_irange = acm_i_range[0];
			else acm_irange = acm_i_range[i];

			acm_ramp[i].Set(FV, start_value, ACM_N2P18V, acm_irange, ACM_RELAY_ON);
		}
		
	}
	string reg_str_cmp(reg_str);
	string reg_str_new;
	char reg_new[1024] = { 0 };
	if (DEBUG_MODE || (pat_unload == 1))
	{
		if (fovi_ramp != NULL)
		{
			for (int i = 0; i < sizeofparameter[0]; i++)
			{
				if (DEBUG_MODE || (pat_unload == 1)) fovi_ramp[i].AwgClear();

			}
			if (pattern_unloaded(reg_new))
			{
				temp_pattern.id = id;
				temp_pattern.pattern_name = reg_str_new;
				temp_pattern.samplecount = patSamplesize;
				temp_pattern.startvalue = awgPatStart;
				temp_pattern.stopvalue = awgPatStop;
				temp_pattern.stepvalue = 0;
				for (int j = 0; j < sizeofparameter[0]; j++) 
					temp_pattern.resource.push_back(fovi_ramp[j].GetChannel());
				pattern_store.push_back(temp_pattern);
				temp_pattern.resource.clear();

			}
		}
		if (acm_ramp != NULL)
		{
			for (int i = 0; i < sizeofparameter[1]; i++)
			{

				if (DEBUG_MODE || (pat_unload == 1)) acm_ramp[i].AwgClear();
			}
			if (pattern_unloaded(reg_new))
			{
				temp_pattern.id = id;
				temp_pattern.pattern_name = reg_str_new;
				temp_pattern.samplecount = patSamplesize;
				temp_pattern.startvalue = awgPatStart;
				temp_pattern.stopvalue = awgPatStop;
				temp_pattern.stepvalue = 0;
				for (int j = 0; j < sizeofparameter[1]; j++)
					temp_pattern.resource.push_back(acm_ramp[j].GetChannel());
				pattern_store.push_back(temp_pattern);
				temp_pattern.resource.clear();
			}
		}
	}
	else
	{
		if (sts_first_load == 1)
		{
			if (fovi_ramp != NULL)
			{
				for (int i = 0; i < sizeofparameter[0]; i++)
				{
					fovi_ramp[i].AwgClear();

				}

			}
			if (acm_ramp != NULL)
			{
				for (int i = 0; i < sizeofparameter[1]; i++)
				{

					acm_ramp[i].AwgClear();
				}
			}
		}
	}
	if (fovi_ramp != NULL)
	{
		for (int i = 0; i < sizeofparameter[0]; i++)
		{

			if (same_startvalue)awgPatStart = scanStartValue[0];
			else awgPatStart = scanStartValue[i];
			if (same_stopvalue)awgPatStop = scanStopValue[0];
			else awgPatStop = scanStopValue[i];
			if (same_fovi_vrange)fovi_vrange = v_range[0];
			else fovi_vrange = v_range[i];
			if (same_fovi_irange)fovi_irange = i_range[0];
			else fovi_irange = i_range[i];
			reg_str_new = reg_str_cmp + to_string(0);
			strncpy_s(reg_new, reg_str_new.c_str(), sizeof(reg_new) - 1);
			for (int m = 0; m < rampSamplesize; m++)
				pat[m] = awgPatStart + (awgPatStop - awgPatStart) *m / (rampSamplesize - 1);
			for (int m = rampSamplesize; m < patSamplesize; m++)
				pat[m] = awgPatStop;

			if (backToStart_enable)
			{
				for (int m = 0; m < backSampleSize; m++)
					pat[m + patSamplesize] = awgPatStop + (awgPatStart - awgPatStop) *m / (backSampleSize - 1);
			}

		
			SERIAL	fovi_ramp[i].SetAlarmMask(SITE);
		
			fovi_ramp[i].AwgLoader(reg_new, FV, fovi_vrange, fovi_irange, pat, patSamplesize + backSampleSize);
			SERIAL	fovi_ramp[i].SetAlarmMask(SITE, false);
		
		}
	}
	if (acm_ramp != NULL)
	{
		for (int i = 0; i < sizeofparameter[1]; i++)
		{

			if (same_startvalue)awgPatStart = scanStartValue[0];
			else awgPatStart = scanStartValue[inti + i];
			if (same_stopvalue)awgPatStop = scanStopValue[0];
			else awgPatStop = scanStopValue[inti + i];
			if (same_acm_irange)acm_irange = acm_i_range[0];
			else acm_irange = acm_i_range[i];
			reg_str_new = reg_str_cmp + to_string(inti);
			strncpy_s(reg_new, reg_str_new.c_str(), sizeof(reg_new) - 1);
			for (int m = 0; m < rampSamplesize; m++)
				pat[m] = awgPatStart + (awgPatStop - awgPatStart) *m / (rampSamplesize - 1);
			for (int m = rampSamplesize; m < patSamplesize; m++)
				pat[m] = awgPatStop;
		
			if (backToStart_enable)
			{
				for (int m = 0; m < backSampleSize; m++)
					pat[m + patSamplesize] = awgPatStop + (awgPatStart - awgPatStop) *m / (backSampleSize - 1);
			}

			SERIAL	acm_ramp[i].SetAlarmMask(SITE);
			acm_ramp[i].AwgLoader(reg_new, FV, ACM_N2P18V, acm_irange, pat, patSamplesize + backSampleSize);
			SERIAL	acm_ramp[i].SetAlarmMask(SITE, false);
		}
	}


	
	if (fovi_ramp != NULL)
	{
		for (int i = 0; i < sizeofparameter[0]; i++)
		{
			reg_str_new = reg_str_cmp + to_string(0);
			strncpy_s(reg_new, reg_str_new.c_str(), sizeof(reg_new) - 1);
			fovi_ramp[i].AwgSelect(reg_new, startpoint, startpoint + scanSampleSize + backSampleSize - 1, startpoint + scanSampleSize + backSampleSize - 1, interval);
			STSEnableAWG(&fovi_ramp[i]);
			if (measure_enable)
			{
				fovi_ramp[i].MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
				STSEnableMeas(&fovi_ramp[i]);
			}
		}
	}
	if (acm_ramp != NULL)
	{
		for (int i = 0; i < sizeofparameter[1]; i++)
		{
			
			reg_str_new = reg_str_cmp + to_string(inti);
			strncpy_s(reg_new, reg_str_new.c_str(), sizeof(reg_new) - 1);
			acm_ramp[i].AwgSelect(reg_new, startpoint, startpoint + scanSampleSize + backSampleSize - 1, startpoint + scanSampleSize + backSampleSize - 1, interval);
			STSEnableAWG(&acm_ramp[i]);
			if (measure_enable)
			{
				acm_ramp[i].MeasureVI(ACM_MI, scanSampleSize, interval, MEAS_AWG);
				STSEnableMeas(&acm_ramp[i]);
			}
				
		}
	}
	StsAWGRun();
	delay_us(delaytime);
	//only get the latest measureSampleSize samples result;
	if (measure_enable){
		if (fovi_ramp != NULL)
		{
			for (int i = 0; i < sizeofparameter[0]; i++)
			{
				SERIAL	
				{
					results[i][SITE] = 0;
					fovi_ramp[i].BlockRead(SITE, scanSampleSize - measureSampleSize-1, measureSampleSize, cap[SITE], MIRET);
					for (int j = 0; j < measureSampleSize; j++)
						results[i][SITE] += cap[SITE][j] / measureSampleSize;
				}

			}
			
		}
		if (acm_ramp != NULL)
		{
			for (int i = 0; i < sizeofparameter[1]; i++)
			{
				SERIAL
				{
					results[inti + i][SITE] = 0;
					acm_ramp[i].BlockRead(SITE, scanSampleSize - measureSampleSize - 1, measureSampleSize, cap[SITE]);
					for (int j = 0; j < measureSampleSize; j++)
						results[inti+i][SITE] += cap[SITE][j] / measureSampleSize;
				}
			}
		}
			
	}


	return TRUE;
}
BOOL AWG_FUNC::rampv(FOVIe fovi_ramp1, FOVIe fovi_ramp2, FOVIe fovi_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step)+1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step)+1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step)+1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fovi_ramp1.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	fovi_ramp2.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	fovi_cap.Set(FI, 0, FOVIe_10V, FOVIe_10UA, FOVIe_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{


		if (DEBUG_MODE || (pat_unload == 1))
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp1.GetChannel());
			temp_pattern.resource.push_back(fovi_ramp2.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}
	

	}
	else
	{
		if (sts_first_load == 1)
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
	}

	
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE);
		fovi_ramp2.SetAlarmMask(SITE);

	}
		fovi_ramp1.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
		fovi_ramp2.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE,false);
		fovi_ramp2.SetAlarmMask(SITE, false);

	}


	

	fovi_ramp1.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fovi_ramp2.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);

	fovi_cap.SetMeasVTrig(trig_level, trig_mode);


	fovi_ramp1.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	fovi_ramp2.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	fovi_cap.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);

	STSEnableAWG(&fovi_ramp1, &fovi_ramp2);
	STSEnableMeas(&fovi_ramp1, &fovi_ramp2, &fovi_cap);
	STSAWGRunTriggerStop(&fovi_cap, &fovi_ramp1, &fovi_ramp2, &fovi_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fovi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result[SITE] = fovi_ramp1.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampi(ACM acm_ramp, ACM acm_cap, ACM_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue , double awgStopValue ){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	acm_ramp.Set(FI, scanStartValue, ACM_N2P18V, i_range, ACM_RELAY_ON,0.5);
	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_20UA, ACM_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{

		//STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
		if (DEBUG_MODE || (pat_unload == 1))
		{
			acm_ramp.AwgClear();
		
		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(acm_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
	
		}


	}
	else
	{
		if (sts_first_load == 1)
		{
			acm_ramp.AwgClear();
		}
	}

	
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL acm_ramp.SetAlarmMask(SITE);
	acm_ramp.AwgLoader(reg_str, FI, ACM_N2P18V, i_range, pat, patSamplesize);	
	SERIAL acm_ramp.SetAlarmMask(SITE, false);


	acm_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);

	acm_cap.SetMeasVTrig(trig_level, trig_mode);


	acm_ramp.MeasureVI(ACM_MI,scanSampleSize, interval, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MV, scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&acm_ramp);
	STSEnableMeas(&acm_ramp,  &acm_cap);
	STSAWGRunTriggerStop(&acm_cap, &acm_ramp,  &acm_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result[SITE] = acm_ramp.GetMeasResult(SITE,Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampv(ACM acm_ramp, ACM acm_cap, ACM_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	acm_ramp.Set(FV, scanStartValue, ACM_N2P18V, i_range, ACM_RELAY_ON, 0.5);
	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_20UA, ACM_RELAY_ON);
	delay_ms(1);
	if (DEBUG_MODE || (pat_unload == 1))
	{

		
		if (DEBUG_MODE || (pat_unload == 1))
		{
			acm_ramp.AwgClear();

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(acm_ramp.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}
	

	}
	else
	{
		if (sts_first_load == 1)
		{
			acm_ramp.AwgClear();
		}
	}

	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL acm_ramp.SetAlarmMask(SITE);

	acm_ramp.AwgLoader(reg_str, FV, ACM_N2P18V, i_range, pat, patSamplesize);
	SERIAL acm_ramp.SetAlarmMask(SITE, false);

	acm_ramp.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);

	acm_cap.SetMeasVTrig(trig_level, trig_mode);


	acm_ramp.MeasureVI(ACM_MV, scanSampleSize, interval, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MV, scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&acm_ramp);
	STSEnableMeas(&acm_ramp, &acm_cap);
	STSAWGRunTriggerStop(&acm_cap, &acm_ramp, &acm_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result[SITE] = acm_ramp.GetMeasResult(SITE, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampv(ACM acm_ramp1, ACM acm_ramp2, ACM acm_cap, ACM_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	acm_ramp1.Set(FV, scanStartValue, ACM_N2P18V, i_range, ACM_RELAY_ON, 0.5);
	acm_ramp2.Set(FV, scanStartValue, ACM_N2P18V, i_range, ACM_RELAY_ON, 0.5);
	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_20UA, ACM_RELAY_ON);
	delay_ms(1);
	if (DEBUG_MODE || (pat_unload == 1))
	{

		if (DEBUG_MODE || (pat_unload == 1))
		{
			acm_ramp1.AwgClear();
			acm_ramp2.AwgClear();

		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(acm_ramp1.GetChannel());
			temp_pattern.resource.push_back(acm_ramp2.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}

	}
	else
	{
		if (sts_first_load == 1)
		{
			acm_ramp1.AwgClear();
			acm_ramp2.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL
	{
		acm_ramp1.SetAlarmMask(SITE);
		acm_ramp2.SetAlarmMask(SITE);


	}
	acm_ramp1.AwgLoader(reg_str, FV, ACM_N2P18V, i_range, pat, patSamplesize);
	acm_ramp2.AwgLoader(reg_str, FV, ACM_N2P18V, i_range, pat, patSamplesize);
	SERIAL
	{
		acm_ramp1.SetAlarmMask(SITE, false);
		acm_ramp2.SetAlarmMask(SITE, false);
	}

	acm_ramp1.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	acm_ramp2.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);

	acm_cap.SetMeasVTrig(trig_level, trig_mode);


	acm_ramp1.MeasureVI(ACM_MV, scanSampleSize, interval, MEAS_AWG);
	acm_ramp2.MeasureVI(ACM_MV, scanSampleSize, interval, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MV, scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&acm_ramp1, &acm_ramp2);
	STSEnableMeas(&acm_ramp1, &acm_ramp2, &acm_cap);
	STSAWGRunTriggerStop(&acm_cap, &acm_ramp1, &acm_ramp2, &acm_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result[SITE] = acm_ramp1.GetMeasResult(SITE, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
BOOL AWG_FUNC::rampv(FOVIe fovi_ramp1, FOVIe fovi_ramp2, ACM acm_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fovi_ramp1.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	fovi_ramp2.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_20UA, ACM_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{

		if (DEBUG_MODE || (pat_unload == 1))
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp1.GetChannel());
			temp_pattern.resource.push_back(fovi_ramp2.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}

	}
	else
	{
		if (sts_first_load == 1)
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE);
		fovi_ramp2.SetAlarmMask(SITE);

	}
	fovi_ramp1.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	fovi_ramp2.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE, false);
		fovi_ramp2.SetAlarmMask(SITE, false);

	}

	fovi_ramp1.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fovi_ramp2.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);

	acm_cap.SetMeasVTrig(trig_level, trig_mode);


	fovi_ramp1.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	fovi_ramp2.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MV, scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&fovi_ramp1, &fovi_ramp2);
	STSEnableMeas(&fovi_ramp1, &fovi_ramp2, &acm_cap);
	STSAWGRunTriggerStop(&acm_cap, &fovi_ramp1, &fovi_ramp2, &acm_cap);

	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)acm_cap.GetMeasResult(SITE, TRIG_RESULT);
	delay_us(delaytime);
	SERIAL{
		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < scanSampleSize - 2)){
			//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			result[SITE] = fovi_ramp1.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}

	return TRUE;
}
//measure_VBUS2VOUT_INRANGE
BOOL AWG_FUNC::rampv2(FOVIe fovi_ramp1, FOVIe fovi_ramp2, FOVIe fovi_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result1, double *result2, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step)+1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step)+1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step)+1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fovi_ramp1.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	fovi_ramp2.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	fovi_cap.Set(FI, 0, FOVIe_10V, FOVIe_10UA, FOVIe_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{

		if (DEBUG_MODE || (pat_unload == 1))
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp1.GetChannel());
			temp_pattern.resource.push_back(fovi_ramp2.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}

	}
	else
	{
		if (sts_first_load == 1)
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE);
		fovi_ramp2.SetAlarmMask(SITE);

	}
	fovi_ramp1.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	fovi_ramp2.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE, false);
		fovi_ramp2.SetAlarmMask(SITE, false);

	}


	fovi_ramp1.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fovi_ramp2.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);


	fovi_ramp1.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	fovi_ramp2.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	fovi_cap.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);

	STSEnableAWG(&fovi_ramp1, &fovi_ramp2);
	STSEnableMeas(&fovi_ramp1, &fovi_ramp2, &fovi_cap);
	StsAWGRun();
	
	int Trig_Point[2][SITE_NUM];
	
	delay_us(delaytime);
	SERIAL	 fovi_cap.BlockRead(SITE, 0, scanSampleSize, cap[SITE], MVRET);

	SERIAL{
		for (int i = 0; i<scanSampleSize; i++) //inrange_l_r
		{
			if (trig_mode == TRIG_RISING )
			{ 
				if (cap[SITE][i] > trig_level)
				{
					Trig_Point[0][SITE] = i;
					break;
				}
			}
			else
			{
				if (cap[SITE][i] < trig_level)
				{
					Trig_Point[0][SITE] = i;
					break;
				}

			}
		}
		if ((Trig_Point[0][SITE] > 2) && (Trig_Point[0][SITE] < scanSampleSize - 2)){
			result1[SITE] = fovi_ramp1.GetMeasResult(SITE, MVRET, Trig_Point[0][SITE] - 1);

			for (int i = Trig_Point[0][SITE]; i<scanSampleSize; i++) //uc_l
			{
				if (trig_mode == TRIG_RISING)
				{
					if (cap[SITE][i] < trig_level)
					{
						Trig_Point[1][SITE] = i;
						break;
					}
				}
				else
				{
					if (cap[SITE][i] > trig_level)
					{
						Trig_Point[1][SITE] = i;
						break;
					}
				}
			
			}
			if ((Trig_Point[1][SITE] > 2) && (Trig_Point[1][SITE] < scanSampleSize - 2))
				result2[SITE] = fovi_ramp1.GetMeasResult(SITE, MVRET, Trig_Point[1][SITE] - 1);
			else
				result2[SITE] = 999999;
		}
		else{
			result1[SITE] = 999999;
			result2[SITE] = 999999;
		}

	}

	return TRUE;
}


BOOL AWG_FUNC::rampv2(FOVIe fovi_ramp1, FOVIe fovi_ramp2, ACM acm_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double M1_Value, double M2_Value, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result1, double *result2, double awgStartValue, double awgStopValue){
	int samplesize1, samplesize2;
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - M2_Value + M1_Value - scanStartValue) / step) + 1)+20;
		samplesize1 = int(fabs((scanStopValue - M2_Value) / step));
		samplesize2 = int(fabs((M1_Value - scanStartValue) / step));
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fovi_ramp1.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	fovi_ramp2.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_20UA, ACM_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{
		if (DEBUG_MODE || (pat_unload == 1))
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp1.GetChannel());
			temp_pattern.resource.push_back(fovi_ramp2.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();
		}

	}
	else
	{
		if (sts_first_load == 1)
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
	}
	if (awgStartValue == awgStopValue){
		int i;
		for (i = 0; i < samplesize2; i++)
			pat[i] = scanStartValue + (double)i / (samplesize2 - 1)*(M1_Value - scanStartValue);
		for (i = 0; i < (scanSampleSize - samplesize2 - samplesize1); i++)
			pat[i + samplesize2] = M1_Value + (double)i / (scanSampleSize - samplesize2 - samplesize1 - 1)*(M2_Value - M1_Value);
		for (i = 0; i < samplesize1; i++)
			pat[i + scanSampleSize - samplesize1] = M2_Value + (double)i / (samplesize1 - 1)*(scanStopValue - M2_Value);
	}
	else
	{
		STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);
	}

	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE);
		fovi_ramp2.SetAlarmMask(SITE);

	}
	fovi_ramp1.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	fovi_ramp2.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE, false);
		fovi_ramp2.SetAlarmMask(SITE, false);

	}


	
	fovi_ramp1.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fovi_ramp2.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);


	fovi_ramp1.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	fovi_ramp2.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MV, scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&fovi_ramp1, &fovi_ramp2);
	STSEnableMeas(&fovi_ramp1, &fovi_ramp2, &acm_cap);
	StsAWGRun();

	int Trig_Point[2][SITE_NUM];

	delay_us(delaytime);
	SERIAL	 acm_cap.BlockRead(SITE, 0, scanSampleSize, cap[SITE]);

	SERIAL{
		for (int i = 0; i<scanSampleSize; i++) //inrange_l_r
		{
			if (trig_mode == TRIG_RISING)
			{
				if (cap[SITE][i] > trig_level)
				{
					Trig_Point[0][SITE] = i;
					break;
				}
			}
			else
			{
				if (cap[SITE][i] < trig_level)
				{
					Trig_Point[0][SITE] = i;
					break;
				}

			}
		}
		if ((Trig_Point[0][SITE] > 2) && (Trig_Point[0][SITE] < scanSampleSize - 2)){
			result1[SITE] = fovi_ramp1.GetMeasResult(SITE, MVRET, Trig_Point[0][SITE] - 1);

			for (int i = Trig_Point[0][SITE]; i<scanSampleSize; i++) //uc_l
			{
				if (trig_mode == TRIG_RISING)
				{
					if (cap[SITE][i] < trig_level)
					{
						Trig_Point[1][SITE] = i;
						break;
					}
				}
				else
				{
					if (cap[SITE][i] > trig_level)
					{
						Trig_Point[1][SITE] = i;
						break;
					}
				}

			}
			if ((Trig_Point[1][SITE] > 2) && (Trig_Point[1][SITE] < scanSampleSize - 2))
				result2[SITE] = fovi_ramp1.GetMeasResult(SITE, MVRET, Trig_Point[1][SITE] - 1);
			else
				result2[SITE] = 999999;
		}
		else{
			result1[SITE] = 999999;
			result2[SITE] = 999999;
		}

	}

	return TRUE;
}
BOOL AWG_FUNC::rampv2(FOVIe fovi_ramp1, FOVIe fovi_ramp2, ACM acm_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result1, double *result2, double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step) + 1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step) + 1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fovi_ramp1.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	fovi_ramp2.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	acm_cap.Set(FI, 0, ACM_N2P18V, ACM_20UA, ACM_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{

		if (DEBUG_MODE || (pat_unload == 1))
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp1.GetChannel());
			temp_pattern.resource.push_back(fovi_ramp2.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}

	}
	else
	{
		if (sts_first_load == 1)
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE);
		fovi_ramp2.SetAlarmMask(SITE);

	}
	fovi_ramp1.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	fovi_ramp2.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE, false);
		fovi_ramp2.SetAlarmMask(SITE, false);

	}


	fovi_ramp1.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fovi_ramp2.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);


	fovi_ramp1.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	fovi_ramp2.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	acm_cap.MeasureVI(ACM_MV, scanSampleSize, interval, MEAS_AWG);

	STSEnableAWG(&fovi_ramp1, &fovi_ramp2);
	STSEnableMeas(&fovi_ramp1, &fovi_ramp2, &acm_cap);
	StsAWGRun();

	int Trig_Point[2][SITE_NUM];

	delay_us(delaytime);
	SERIAL	 acm_cap.BlockRead(SITE, 0, scanSampleSize, cap[SITE]);

	SERIAL{
		for (int i = 0; i<scanSampleSize; i++) //inrange_l_r
		{
			if (trig_mode == TRIG_RISING)
			{
				if (cap[SITE][i] > trig_level)
				{
					Trig_Point[0][SITE] = i;
					break;
				}
			}
			else
			{
				if (cap[SITE][i] < trig_level)
				{
					Trig_Point[0][SITE] = i;
					break;
				}

			}
		}
		if ((Trig_Point[0][SITE] > 2) && (Trig_Point[0][SITE] < scanSampleSize - 2)){
			result1[SITE] = fovi_ramp1.GetMeasResult(SITE, MVRET, Trig_Point[0][SITE] - 1);

			for (int i = Trig_Point[0][SITE]; i<scanSampleSize; i++) //uc_l
			{
				if (trig_mode == TRIG_RISING)
				{
					if (cap[SITE][i] < trig_level)
					{
						Trig_Point[1][SITE] = i;
						break;
					}
				}
				else
				{
					if (cap[SITE][i] > trig_level)
					{
						Trig_Point[1][SITE] = i;
						break;
					}
				}

			}
			if ((Trig_Point[1][SITE] > 2) && (Trig_Point[1][SITE] < scanSampleSize - 2))
				result2[SITE] = fovi_ramp1.GetMeasResult(SITE, MVRET, Trig_Point[1][SITE] - 1);
			else
				result2[SITE] = 999999;
		}
		else{
			result1[SITE] = 999999;
			result2[SITE] = 999999;
		}

	}

	return TRUE;
}
//measure_VOUT_TH_RISING
BOOL AWG_FUNC::rampv_cap_neg(FOVIe fovi_ramp1, FOVIe fovi_ramp2, FOVIe fovi_cap, FOVIe_VRNG v_range, FOVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result,double awgStartValue, double awgStopValue){
	if (interval < 10)	return FALSE;
	if (step == 0)	return FALSE;
	if (awgStartValue == awgStopValue)
	{
		startpoint = 0;
		awgPatStart = scanStartValue;
		awgPatStop = scanStopValue;
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step)+1);
		patSamplesize = scanSampleSize;
	}

	else
	{
		if (!(((scanStartValue <= awgStartValue) && (scanStopValue >= awgStopValue)) || ((scanStartValue >= awgStartValue) && (scanStopValue <= awgStopValue)))) return FALSE;
		awgPatStart = awgStartValue;
		awgPatStop = awgStopValue;
		patSamplesize = int(fabs((awgStopValue - awgStartValue) / step)+1);
		startpoint = int(fabs((awgStartValue - scanStartValue) / step));
		scanSampleSize = int(fabs((scanStopValue - scanStartValue) / step)+1);
	}

	if ((patSamplesize <= 1) || (patSamplesize > MAX_SAMPLES)){
		patSamplesize = MAX_SAMPLES;
	}
	if ((scanSampleSize <= 1) || (scanSampleSize > MAX_SAMPLES)){
		scanSampleSize = MAX_SAMPLES;
	}
	fovi_ramp1.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	fovi_ramp2.Set(FV, scanStartValue, v_range, i_range, FOVIe_RELAY_ON, 1);
	fovi_cap.Set(FI, 0, FOVIe_10V, FOVIe_10UA, FOVIe_RELAY_ON);
	if (DEBUG_MODE || (pat_unload == 1))
	{

		if (DEBUG_MODE || (pat_unload == 1))
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
		if (pattern_unloaded(reg_str))
		{
			temp_pattern.id = id;
			temp_pattern.pattern_name = reg_str;
			temp_pattern.samplecount = patSamplesize;
			temp_pattern.startvalue = awgPatStart;
			temp_pattern.stopvalue = awgPatStop;
			temp_pattern.stepvalue = step;
			temp_pattern.resource.push_back(fovi_ramp1.GetChannel());
			temp_pattern.resource.push_back(fovi_ramp2.GetChannel());
			pattern_store.push_back(temp_pattern);
			temp_pattern.resource.clear();

		}

	}
	else
	{
		if (sts_first_load == 1)
		{
			fovi_ramp1.AwgClear();
			fovi_ramp2.AwgClear();
		}
	}
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, awgPatStart, awgPatStop);

	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE);
		fovi_ramp2.SetAlarmMask(SITE);

	}
	fovi_ramp1.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	fovi_ramp2.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE, false);
		fovi_ramp2.SetAlarmMask(SITE, false);

	}

	fovi_ramp1.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);
	fovi_ramp2.AwgSelect(reg_str, startpoint, startpoint + scanSampleSize - 1, startpoint + scanSampleSize - 1, interval);


	fovi_ramp1.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	fovi_ramp2.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);
	fovi_cap.MeasureVI(scanSampleSize, interval, FOVIe_MI_X1, MEAS_AWG);

	STSEnableAWG(&fovi_ramp1, &fovi_ramp2);
	STSEnableMeas(&fovi_ramp1, &fovi_ramp2, &fovi_cap);
	StsAWGRun();
	int Trig_Point[SITE_NUM];
	delay_us(delaytime);
	SERIAL fovi_cap.BlockRead(SITE, 0, scanSampleSize, cap[SITE], MVRET);

	SERIAL{
		for (int i = scanSampleSize - 1; i>1; i--)
		{
			if (cap[SITE][i] > trig_level)
			{
				fovi_ramp1.Set(FV, scanStartValue + (i - 1)*step, v_range, i_range, FOVIe_RELAY_ON);
				fovi_ramp2.Set(FV, scanStartValue + (i - 1)*step, v_range, i_range, FOVIe_RELAY_ON);
				delay_ms(1);
				fovi_ramp1.MeasureVI(40, 10);
				result[SITE] = fovi_ramp1.GetMeasResult(SITE, MVRET);
				Trig_Point[SITE] = i;
				break;
			}
		}
		if ((Trig_Point[SITE] <= 2) || (Trig_Point[SITE] >= scanSampleSize - 2)){
			result[SITE] = 9999999;
		}
	}

	return TRUE;
}
