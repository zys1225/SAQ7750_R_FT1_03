#pragma once
#include "stdafx.h"
#include "LogDataStruct.h"
#include "mylib.h"

class CGenerateTextFile
{
public:
	Cmylib mylib;

public:
	CGenerateTextFile(void) {}
	~CGenerateTextFile(void) {}

public:
	BOOL generate_csv(string file, map<DWORD, map<DWORD, string>>& data_map, string& error);
	BOOL CGenerateTextFile::generate_csv(string file, map<DWORD, map<DWORD, int>>& data_map, string& error);
	BOOL CGenerateTextFile::generate_csv(string file, map<DWORD, map<DWORD, double>>& data_map, string& error);
	//BOOL generate_csv_tcs(map<string,CAccoCsvData> &acco_data, string& error);
	//BOOL generate_csv_tcs(string file, map<DWORD, map<DWORD, string>>& data_map, map<string,string>& str_mgb_map, map<string,string>& str_grr_map, string& error);
	//BOOL generate_csv_repeat(string file, CAccoCsvData& acco_data, CTestStatisticStruct& statistic, string& error);
	//BOOL generate_csv_correlation(string file, CAccoCsvData& golden_data, CAccoCsvData& corr_data, map<string,string>& mgb_map, string& error);
};
