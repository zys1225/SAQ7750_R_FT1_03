#pragma once

#define TCS						0
#define REPEAT					1
#define RELIABILITY				2
#define CORRELATION				3
#define BOARDCHECK				4
#define TO_SCA					5
#define TO_TCRA					6
#define PROD_CPK				7
#define LOADMGB					8
#define PROD_CYCLE				9
#define DROP_FILE_EDIT			WM_USER+100
#define THREADFUNC_LIST_END		WM_USER+101
#define THREADFUNC_TWO_END		WM_USER+102
#define THREADFUNC_ONE_END		WM_USER+103
#define THREADFUNC_THREE_END	WM_USER+104

